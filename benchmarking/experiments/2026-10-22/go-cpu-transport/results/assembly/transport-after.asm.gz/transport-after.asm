TEXT internal/runtime/syscall/linux.Syscall6(SB) /usr/local/go/src/internal/runtime/syscall/linux/asm_linux_amd64.s
  asm_linux_amd64.s:30	0x411020		4989f2			MOVQ SI, R10		
  asm_linux_amd64.s:31	0x411023		4889fa			MOVQ DI, DX		
  asm_linux_amd64.s:32	0x411026		4889ce			MOVQ CX, SI		
  asm_linux_amd64.s:33	0x411029		4889df			MOVQ BX, DI		
  asm_linux_amd64.s:35	0x41102c		0f05			SYSCALL			
  asm_linux_amd64.s:36	0x41102e		483d01f0ffff		CMPQ AX, $-0xfff	
  asm_linux_amd64.s:37	0x411034		7613			JBE 0x411049		
  asm_linux_amd64.s:38	0x411036		48f7d8			NEGQ AX			
  asm_linux_amd64.s:39	0x411039		4889c1			MOVQ AX, CX		
  asm_linux_amd64.s:40	0x41103c		48c7c0ffffffff		MOVQ $-0x1, AX		
  asm_linux_amd64.s:41	0x411043		bb00000000		MOVL $0x0, BX		
  asm_linux_amd64.s:42	0x411048		c3			RET			
  asm_linux_amd64.s:45	0x411049		4889d3			MOVQ DX, BX		
  asm_linux_amd64.s:46	0x41104c		b900000000		MOVL $0x0, CX		
  asm_linux_amd64.s:47	0x411051		c3			RET			

TEXT syscall.RawSyscall6(SB) /usr/local/go/src/syscall/syscall_linux.go
  syscall_linux.go:63	0x4b3de0		55			PUSHQ BP						
  syscall_linux.go:63	0x4b3de1		4889e5			MOVQ SP, BP						
  syscall_linux.go:63	0x4b3de4		4883ec38		SUBQ $0x38, SP						
  syscall_linux.go:65	0x4b3de8		e833d2f5ff		CALL internal/runtime/syscall/linux.Syscall6(SB)	
  syscall_linux.go:67	0x4b3ded		4883c438		ADDQ $0x38, SP						
  syscall_linux.go:67	0x4b3df1		5d			POPQ BP							
  syscall_linux.go:67	0x4b3df2		c3			RET							

TEXT syscall.Syscall(SB) /usr/local/go/src/syscall/syscall_linux.go
  syscall_linux.go:73	0x4b3e00		55			PUSHQ BP			
  syscall_linux.go:73	0x4b3e01		4889e5			MOVQ SP, BP			
  syscall_linux.go:73	0x4b3e04		4883ec50		SUBQ $0x50, SP			
  syscall_linux.go:89	0x4b3e08		4889442460		MOVQ AX, 0x60(SP)		
  syscall_linux.go:89	0x4b3e0d		48895c2468		MOVQ BX, 0x68(SP)		
  syscall_linux.go:89	0x4b3e12		48894c2470		MOVQ CX, 0x70(SP)		
  syscall_linux.go:89	0x4b3e17		48897c2478		MOVQ DI, 0x78(SP)		
  syscall_linux.go:74	0x4b3e1c		0f1f4000		NOPL 0(AX)			
  syscall_linux.go:74	0x4b3e20		e8db76fdff		CALL runtime.entersyscall(SB)	
  syscall_linux.go:87	0x4b3e25		488b442460		MOVQ 0x60(SP), AX		
  syscall_linux.go:87	0x4b3e2a		488b5c2468		MOVQ 0x68(SP), BX		
  syscall_linux.go:87	0x4b3e2f		488b4c2470		MOVQ 0x70(SP), CX		
  syscall_linux.go:87	0x4b3e34		488b7c2478		MOVQ 0x78(SP), DI		
  syscall_linux.go:87	0x4b3e39		31f6			XORL SI, SI			
  syscall_linux.go:87	0x4b3e3b		4189f0			MOVL SI, R8			
  syscall_linux.go:87	0x4b3e3e		4189f1			MOVL SI, R9			
  syscall_linux.go:87	0x4b3e41		e89affffff		CALL syscall.RawSyscall6(SB)	
  syscall_linux.go:87	0x4b3e46		4889442448		MOVQ AX, 0x48(SP)		
  syscall_linux.go:87	0x4b3e4b		48895c2440		MOVQ BX, 0x40(SP)		
  syscall_linux.go:87	0x4b3e50		48894c2438		MOVQ CX, 0x38(SP)		
  syscall_linux.go:88	0x4b3e55		e88679fdff		CALL runtime.exitsyscall(SB)	
  syscall_linux.go:89	0x4b3e5a		488b442448		MOVQ 0x48(SP), AX		
  syscall_linux.go:89	0x4b3e5f		488b5c2440		MOVQ 0x40(SP), BX		
  syscall_linux.go:89	0x4b3e64		488b4c2438		MOVQ 0x38(SP), CX		
  syscall_linux.go:89	0x4b3e69		4883c450		ADDQ $0x50, SP			
  syscall_linux.go:89	0x4b3e6d		5d			POPQ BP				
  syscall_linux.go:89	0x4b3e6e		c3			RET				

TEXT syscall.Syscall6(SB) /usr/local/go/src/syscall/syscall_linux.go
  syscall_linux.go:95	0x4b3e80		55			PUSHQ BP			
  syscall_linux.go:95	0x4b3e81		4889e5			MOVQ SP, BP			
  syscall_linux.go:95	0x4b3e84		4883ec50		SUBQ $0x50, SP			
  syscall_linux.go:99	0x4b3e88		4889442460		MOVQ AX, 0x60(SP)		
  syscall_linux.go:99	0x4b3e8d		48895c2468		MOVQ BX, 0x68(SP)		
  syscall_linux.go:99	0x4b3e92		48894c2470		MOVQ CX, 0x70(SP)		
  syscall_linux.go:99	0x4b3e97		48897c2478		MOVQ DI, 0x78(SP)		
  syscall_linux.go:99	0x4b3e9c		4889b42480000000	MOVQ SI, 0x80(SP)		
  syscall_linux.go:99	0x4b3ea4		4c89842488000000	MOVQ R8, 0x88(SP)		
  syscall_linux.go:99	0x4b3eac		4c898c2490000000	MOVQ R9, 0x90(SP)		
  syscall_linux.go:96	0x4b3eb4		e84776fdff		CALL runtime.entersyscall(SB)	
  syscall_linux.go:97	0x4b3eb9		488b442460		MOVQ 0x60(SP), AX		
  syscall_linux.go:97	0x4b3ebe		488b5c2468		MOVQ 0x68(SP), BX		
  syscall_linux.go:97	0x4b3ec3		488b4c2470		MOVQ 0x70(SP), CX		
  syscall_linux.go:97	0x4b3ec8		488b7c2478		MOVQ 0x78(SP), DI		
  syscall_linux.go:97	0x4b3ecd		488bb42480000000	MOVQ 0x80(SP), SI		
  syscall_linux.go:97	0x4b3ed5		4c8b842488000000	MOVQ 0x88(SP), R8		
  syscall_linux.go:97	0x4b3edd		4c8b8c2490000000	MOVQ 0x90(SP), R9		
  syscall_linux.go:97	0x4b3ee5		e8f6feffff		CALL syscall.RawSyscall6(SB)	
  syscall_linux.go:97	0x4b3eea		4889442448		MOVQ AX, 0x48(SP)		
  syscall_linux.go:97	0x4b3eef		48895c2440		MOVQ BX, 0x40(SP)		
  syscall_linux.go:97	0x4b3ef4		48894c2438		MOVQ CX, 0x38(SP)		
  syscall_linux.go:98	0x4b3ef9		e8e278fdff		CALL runtime.exitsyscall(SB)	
  syscall_linux.go:99	0x4b3efe		488b442448		MOVQ 0x48(SP), AX		
  syscall_linux.go:99	0x4b3f03		488b5c2440		MOVQ 0x40(SP), BX		
  syscall_linux.go:99	0x4b3f08		488b4c2438		MOVQ 0x38(SP), CX		
  syscall_linux.go:99	0x4b3f0d		4883c450		ADDQ $0x50, SP			
  syscall_linux.go:99	0x4b3f11		5d			POPQ BP				
  syscall_linux.go:99	0x4b3f12		c3			RET				

TEXT internal/poll.(*FD).Write(SB) /usr/local/go/src/internal/poll/fd_unix.go
  fd_unix.go:365		0x4ee3e0		4c8d6424a0		LEAQ -0x60(SP), R12					
  fd_unix.go:365		0x4ee3e5		4d3b6610		CMPQ R12, 0x10(R14)					
  fd_unix.go:365		0x4ee3e9		0f86f4040000		JBE 0x4ee8e3						
  fd_unix.go:365		0x4ee3ef		55			PUSHQ BP						
  fd_unix.go:365		0x4ee3f0		4889e5			MOVQ SP, BP						
  fd_unix.go:365		0x4ee3f3		4881ecd8000000		SUBQ $0xd8, SP						
  fd_unix.go:365		0x4ee3fa		66440fd6bc24d0000000	MOVQ X15, 0xd0(SP)					
  fd_mutex.go:250		0x4ee404		48898424e8000000	MOVQ AX, 0xe8(SP)					
  fd_mutex.go:250		0x4ee40c		4889bc2400010000	MOVQ DI, 0x100(SP)					
  fd_mutex.go:250		0x4ee414		48898c24f8000000	MOVQ CX, 0xf8(SP)					
  fd_mutex.go:250		0x4ee41c		48899c24f0000000	MOVQ BX, 0xf0(SP)					
  fd_unix.go:365		0x4ee424		c644244f00		MOVB $0x0, 0x4f(SP)					
  fd_unix.go:365		0x4ee429		48c744245800000000	MOVQ $0x0, 0x58(SP)					
  fd_unix.go:365		0x4ee432		440f11bc2490000000	MOVUPS X15, 0x90(SP)					
  fd_mutex.go:250		0x4ee43b		8400			TESTB AL, 0(AX)						
  fd_mutex.go:250		0x4ee43d		31db			XORL BX, BX						
  fd_mutex.go:250		0x4ee43f		b901000000		MOVL $0x1, CX						
  fd_mutex.go:250		0x4ee444		e8f7eaffff		CALL internal/poll.(*fdMutex).rwlock(SB)		
  fd_mutex.go:250		0x4ee449		84c0			TESTL AL, AL						
  fd_mutex.go:250		0x4ee44b		740e			JE 0x4ee45b						
  fd_unix.go:369		0x4ee44d		488b8424e8000000	MOVQ 0xe8(SP), AX					
  fd_unix.go:369		0x4ee455		31db			XORL BX, BX						
  fd_unix.go:369		0x4ee457		31c9			XORL CX, CX						
  fd_unix.go:366		0x4ee459		eb2c			JMP 0x4ee487						
  fd_mutex.go:251		0x4ee45b		488b8424e8000000	MOVQ 0xe8(SP), AX					
  fd_mutex.go:251		0x4ee463		80783200		CMPB 0x32(AX), $0x0					
  fd.go:43			0x4ee467		7410			JE 0x4ee479						
  fd_mutex.go:251		0x4ee469		488b1d5014b000		MOVQ internal/poll.ErrFileClosing(SB), BX		
  fd_mutex.go:251		0x4ee470		488b0d5114b000		MOVQ internal/poll.ErrFileClosing+8(SB), CX		
  fd_mutex.go:251		0x4ee477		eb0e			JMP 0x4ee487						
  fd_mutex.go:251		0x4ee479		488d1dd08ba900		LEAQ 0xa98bd0(IP), BX					
  fd_mutex.go:251		0x4ee480		488d0df962b300		LEAQ 0xb362f9(IP), CX					
  fd_unix.go:366		0x4ee487		4885db			TESTQ BX, BX						
  fd_unix.go:366		0x4ee48a		0f859b000000		JNE 0x4ee52b						
  fd_unix.go:369		0x4ee490		488d1589270000		LEAQ internal/poll.(*FD).Write.deferwrap1(SB), DX	
  fd_unix.go:369		0x4ee497		48899424c0000000	MOVQ DX, 0xc0(SP)					
  fd_unix.go:369		0x4ee49f		48898424c8000000	MOVQ AX, 0xc8(SP)					
  fd_unix.go:369		0x4ee4a7		488d9424c0000000	LEAQ 0xc0(SP), DX					
  fd_unix.go:369		0x4ee4af		48899424d0000000	MOVQ DX, 0xd0(SP)					
  fd_unix.go:369		0x4ee4b7		c644244f01		MOVB $0x1, 0x4f(SP)					
  fd_unix.go:370		0x4ee4bc		488d5020		LEAQ 0x20(AX), DX					
  fd_unix.go:370		0x4ee4c0		48899424a8000000	MOVQ DX, 0xa8(SP)					
  fd_unix.go:370		0x4ee4c8		0fb64832		MOVZX 0x32(AX), CX					
  fd_poll_runtime.go:77		0x4ee4cc		4889d0			MOVQ DX, AX						
  fd_poll_runtime.go:77		0x4ee4cf		bb77000000		MOVL $0x77, BX						
  fd_poll_runtime.go:77		0x4ee4d4		e827efffff		CALL internal/poll.(*pollDesc).prepare(SB)		
  fd_unix.go:370		0x4ee4d9		4885c0			TESTQ AX, AX						
  fd_unix.go:370		0x4ee4dc		7504			JNE 0x4ee4e2						
  fd_unix.go:370		0x4ee4de		31c0			XORL AX, AX						
  fd_unix.go:370		0x4ee4e0		eb73			JMP 0x4ee555						
  fd_unix.go:371		0x4ee4e2		48c744245800000000	MOVQ $0x0, 0x58(SP)					
  fd_unix.go:371		0x4ee4eb		4889842490000000	MOVQ AX, 0x90(SP)					
  fd_unix.go:371		0x4ee4f3		48899c2498000000	MOVQ BX, 0x98(SP)					
  fd_unix.go:371		0x4ee4fb		c644244f00		MOVB $0x0, 0x4f(SP)					
  fd_unix.go:371		0x4ee500		488b9424d0000000	MOVQ 0xd0(SP), DX					
  fd_unix.go:371		0x4ee508		488b02			MOVQ 0(DX), AX						
  fd_unix.go:371		0x4ee50b		ffd0			CALL AX							
  fd_unix.go:371		0x4ee50d		488b442458		MOVQ 0x58(SP), AX					
  fd_unix.go:371		0x4ee512		488b9c2490000000	MOVQ 0x90(SP), BX					
  fd_unix.go:371		0x4ee51a		488b8c2498000000	MOVQ 0x98(SP), CX					
  fd_unix.go:371		0x4ee522		4881c4d8000000		ADDQ $0xd8, SP						
  fd_unix.go:371		0x4ee529		5d			POPQ BP							
  fd_unix.go:371		0x4ee52a		c3			RET							
  fd_unix.go:367		0x4ee52b		48c744245800000000	MOVQ $0x0, 0x58(SP)					
  fd_unix.go:367		0x4ee534		48899c2490000000	MOVQ BX, 0x90(SP)					
  fd_unix.go:367		0x4ee53c		48898c2498000000	MOVQ CX, 0x98(SP)					
  fd_unix.go:367		0x4ee544		488b442458		MOVQ 0x58(SP), AX					
  fd_unix.go:367		0x4ee549		4881c4d8000000		ADDQ $0xd8, SP						
  fd_unix.go:367		0x4ee550		5d			POPQ BP							
  fd_unix.go:367		0x4ee551		c3			RET							
  fd_unix.go:367		0x4ee552		4889f0			MOVQ SI, AX						
  fd_unix.go:376		0x4ee555		488b9424e8000000	MOVQ 0xe8(SP), DX					
  fd_unix.go:376		0x4ee55d		807a3000		CMPB 0x30(DX), $0x0					
  fd_unix.go:376		0x4ee561		7420			JE 0x4ee583						
  fd_unix.go:376		0x4ee563		488b8c24f8000000	MOVQ 0xf8(SP), CX					
  fd_unix.go:376		0x4ee56b		4889ce			MOVQ CX, SI						
  fd_unix.go:376		0x4ee56e		4829c6			SUBQ AX, SI						
  fd_unix.go:376		0x4ee571		4881fe00000040		CMPQ SI, $0x40000000					
  fd_unix.go:376		0x4ee578		7e11			JLE 0x4ee58b						
  fd_unix.go:377		0x4ee57a		488db000000040		LEAQ 0x40000000(AX), SI					
  fd_unix.go:377		0x4ee581		eb0b			JMP 0x4ee58e						
  fd_unix.go:379		0x4ee583		488b8c24f8000000	MOVQ 0xf8(SP), CX					
  fd_unix.go:379		0x4ee58b		4889ce			MOVQ CX, SI						
  fd_unix.go:379		0x4ee58e		488bbc2400010000	MOVQ 0x100(SP), DI					
  fd_unix.go:379		0x4ee596		4839f7			CMPQ DI, SI						
  fd_unix.go:379		0x4ee599		0f821a030000		JB 0x4ee8b9						
  fd_unix.go:379		0x4ee59f		90			NOPL							
  fd_unix.go:379		0x4ee5a0		4839c6			CMPQ SI, AX						
  fd_unix.go:379		0x4ee5a3		0f820b030000		JB 0x4ee8b4						
  fd_unix.go:379		0x4ee5a9		4889442470		MOVQ AX, 0x70(SP)					
  fd_unix.go:379		0x4ee5ae		4989f8			MOVQ DI, R8						
  fd_unix.go:379		0x4ee5b1		4929c0			SUBQ AX, R8						
  fd_unix.go:379		0x4ee5b4		4c89442468		MOVQ R8, 0x68(SP)					
  fd_unix.go:379		0x4ee5b9		4d89c1			MOVQ R8, R9						
  fd_unix.go:379		0x4ee5bc		49f7d8			NEGQ R8							
  fd_unix.go:379		0x4ee5bf		49c1f83f		SARQ $0x3f, R8						
  fd_unix.go:379		0x4ee5c3		4921c0			ANDQ AX, R8						
  fd_unix.go:379		0x4ee5c6		4c8b5210		MOVQ 0x10(DX), R10					
  fd_unix.go:379		0x4ee5ca		4c89942480000000	MOVQ R10, 0x80(SP)					
  fd_unix.go:379		0x4ee5d2		4829c6			SUBQ AX, SI						
  fd_unix.go:379		0x4ee5d5		4889742460		MOVQ SI, 0x60(SP)					
  fd_unix.go:379		0x4ee5da		4c8b9c24f0000000	MOVQ 0xf0(SP), R11					
  fd_unix.go:379		0x4ee5e2		4b8d1c03		LEAQ 0(R11)(R8*1), BX					
  fd_unix.go:379		0x4ee5e6		48899c24b0000000	MOVQ BX, 0xb0(SP)					
  fd_unix.go:742		0x4ee5ee		eb1a			JMP 0x4ee60a						
  syscall_unix.go:211		0x4ee5f0		488b9c24b0000000	MOVQ 0xb0(SP), BX					
  syscall_unix.go:211		0x4ee5f8		488b742460		MOVQ 0x60(SP), SI					
  syscall_unix.go:211		0x4ee5fd		4c8b4c2468		MOVQ 0x68(SP), R9					
  syscall_unix.go:211		0x4ee602		4c8b942480000000	MOVQ 0x80(SP), R10					
  fd_unix.go:743		0x4ee60a		90			NOPL							
  syscall_unix.go:211		0x4ee60b		4c89d0			MOVQ R10, AX						
  syscall_unix.go:211		0x4ee60e		4889f1			MOVQ SI, CX						
  syscall_unix.go:211		0x4ee611		4c89cf			MOVQ R9, DI						
  syscall_unix.go:211		0x4ee614		e82741fcff		CALL syscall.write(SB)					
  syscall_unix.go:211		0x4ee619		48899c2488000000	MOVQ BX, 0x88(SP)					
  syscall_unix.go:211		0x4ee621		4889442478		MOVQ AX, 0x78(SP)					
  syscall_unix.go:211		0x4ee626		48898c24b8000000	MOVQ CX, 0xb8(SP)					
  fd_unix.go:744		0x4ee62e		488d155b86a900		LEAQ 0xa9865b(IP), DX					
  fd_unix.go:744		0x4ee635		4839d3			CMPQ BX, DX						
  fd_unix.go:744		0x4ee638		752f			JNE 0x4ee669						
  fd_unix.go:744		0x4ee63a		4889d0			MOVQ DX, AX						
  fd_unix.go:744		0x4ee63d		488d1d5cfb5400		LEAQ 0x54fb5c(IP), BX					
  fd_unix.go:744		0x4ee644		e87784f2ff		CALL runtime.ifaceeq(SB)				
  fd_unix.go:744		0x4ee649		84c0			TESTL AL, AL						
  fd_unix.go:744		0x4ee64b		75a3			JNE 0x4ee5f0						
  fd_unix.go:380		0x4ee64d		488b442478		MOVQ 0x78(SP), AX					
  fd_unix.go:399		0x4ee652		488b8c24b8000000	MOVQ 0xb8(SP), CX					
  fd_unix.go:399		0x4ee65a		488d152f86a900		LEAQ 0xa9862f(IP), DX					
  fd_unix.go:744		0x4ee661		488b9c2488000000	MOVQ 0x88(SP), BX					
  fd_unix.go:380		0x4ee669		4885c0			TESTQ AX, AX						
  fd_unix.go:380		0x4ee66c		7e18			JLE 0x4ee686						
  fd_unix.go:381		0x4ee66e		488b742460		MOVQ 0x60(SP), SI					
  fd_unix.go:381		0x4ee673		4839f0			CMPQ AX, SI						
  fd_unix.go:381		0x4ee676		0f8fca010000		JG 0x4ee846						
  fd_unix.go:389		0x4ee67c		488b742470		MOVQ 0x70(SP), SI					
  fd_unix.go:389		0x4ee681		4801c6			ADDQ AX, SI						
  fd_unix.go:389		0x4ee684		eb05			JMP 0x4ee68b						
  fd_unix.go:391		0x4ee686		488b742470		MOVQ 0x70(SP), SI					
  fd_unix.go:391		0x4ee68b		4c8b8424f8000000	MOVQ 0xf8(SP), R8					
  fd_unix.go:391		0x4ee693		4939f0			CMPQ R8, SI						
  fd_unix.go:391		0x4ee696		0f8465010000		JE 0x4ee801						
  fd_unix.go:391		0x4ee69c		4889742470		MOVQ SI, 0x70(SP)					
  fd_unix.go:744		0x4ee6a1		4839d3			CMPQ BX, DX						
  fd_unix.go:394		0x4ee6a4		7404			JE 0x4ee6aa						
  fd_unix.go:394		0x4ee6a6		31d2			XORL DX, DX						
  fd_unix.go:394		0x4ee6a8		eb36			JMP 0x4ee6e0						
  fd_unix.go:394		0x4ee6aa		4889d0			MOVQ DX, AX						
  fd_unix.go:394		0x4ee6ad		488d1d3cfc5400		LEAQ 0x54fc3c(IP), BX					
  fd_unix.go:394		0x4ee6b4		e80784f2ff		CALL runtime.ifaceeq(SB)				
  fd_unix.go:399		0x4ee6b9		488b8c24b8000000	MOVQ 0xb8(SP), CX					
  fd_unix.go:399		0x4ee6c1		488b9c2488000000	MOVQ 0x88(SP), BX					
  fd_unix.go:399		0x4ee6c9		488b742470		MOVQ 0x70(SP), SI					
  fd_unix.go:376		0x4ee6ce		4c8b8424f8000000	MOVQ 0xf8(SP), R8					
  fd_unix.go:394		0x4ee6d6		89c2			MOVL AX, DX						
  fd_unix.go:380		0x4ee6d8		488b442478		MOVQ 0x78(SP), AX					
  fd_unix.go:380		0x4ee6dd		0f1f00			NOPL 0(AX)						
  fd_unix.go:394		0x4ee6e0		84d2			TESTL DL, DL						
  fd_unix.go:394		0x4ee6e2		7467			JE 0x4ee74b						
  fd_poll_runtime.go:104	0x4ee6e4		4c8b8c24e8000000	MOVQ 0xe8(SP), R9					
  fd_poll_runtime.go:104	0x4ee6ec		4983792000		CMPQ 0x20(R9), $0x0					
  fd_unix.go:394		0x4ee6f1		7460			JE 0x4ee753						
  fd_unix.go:395		0x4ee6f3		410fb64932		MOVZX 0x32(R9), CX					
  fd_poll_runtime.go:93		0x4ee6f8		488b8424a8000000	MOVQ 0xa8(SP), AX					
  fd_poll_runtime.go:93		0x4ee700		bb77000000		MOVL $0x77, BX						
  fd_poll_runtime.go:93		0x4ee705		e816eeffff		CALL internal/poll.(*pollDesc).wait(SB)			
  fd_unix.go:395		0x4ee70a		4885c0			TESTQ AX, AX						
  fd_unix.go:395		0x4ee70d		7422			JE 0x4ee731						
  fd_unix.go:395		0x4ee70f		488b742470		MOVQ 0x70(SP), SI					
  fd_unix.go:376		0x4ee714		4c8b8424f8000000	MOVQ 0xf8(SP), R8					
  fd_unix.go:376		0x4ee71c		4c8b8c24e8000000	MOVQ 0xe8(SP), R9					
  fd_unix.go:399		0x4ee724		4889d9			MOVQ BX, CX						
  fd_unix.go:399		0x4ee727		4889c3			MOVQ AX, BX						
  fd_unix.go:380		0x4ee72a		488b442478		MOVQ 0x78(SP), AX					
  fd_unix.go:395		0x4ee72f		eb22			JMP 0x4ee753						
  fd_unix.go:395		0x4ee731		488b742470		MOVQ 0x70(SP), SI					
  fd_unix.go:376		0x4ee736		4c8b8424f8000000	MOVQ 0xf8(SP), R8					
  fd_unix.go:376		0x4ee73e		4c8b8c24e8000000	MOVQ 0xe8(SP), R9					
  fd_unix.go:396		0x4ee746		e907feffff		JMP 0x4ee552						
  fd_unix.go:376		0x4ee74b		4c8b8c24e8000000	MOVQ 0xe8(SP), R9					
  fd_unix.go:399		0x4ee753		4885db			TESTQ BX, BX						
  fd_unix.go:399		0x4ee756		7564			JNE 0x4ee7bc						
  fd_unix.go:399		0x4ee758		0f1f840000000000	NOPL 0(AX)(AX*1)					
  fd_unix.go:380		0x4ee760		4885c0			TESTQ AX, AX						
  fd_unix.go:402		0x4ee763		0f85e9fdffff		JNE 0x4ee552						
  fd_unix.go:403		0x4ee769		488b05c008b000		MOVQ io.ErrUnexpectedEOF(SB), AX			
  fd_unix.go:403		0x4ee770		488b0dc108b000		MOVQ io.ErrUnexpectedEOF+8(SB), CX			
  fd_unix.go:403		0x4ee777		4889742458		MOVQ SI, 0x58(SP)					
  fd_unix.go:403		0x4ee77c		4889842490000000	MOVQ AX, 0x90(SP)					
  fd_unix.go:403		0x4ee784		48898c2498000000	MOVQ CX, 0x98(SP)					
  fd_unix.go:403		0x4ee78c		c644244f00		MOVB $0x0, 0x4f(SP)					
  fd_unix.go:403		0x4ee791		488b9424d0000000	MOVQ 0xd0(SP), DX					
  fd_unix.go:403		0x4ee799		488b02			MOVQ 0(DX), AX						
  fd_unix.go:403		0x4ee79c		ffd0			CALL AX							
  fd_unix.go:403		0x4ee79e		488b442458		MOVQ 0x58(SP), AX					
  fd_unix.go:403		0x4ee7a3		488b9c2490000000	MOVQ 0x90(SP), BX					
  fd_unix.go:403		0x4ee7ab		488b8c2498000000	MOVQ 0x98(SP), CX					
  fd_unix.go:403		0x4ee7b3		4881c4d8000000		ADDQ $0xd8, SP						
  fd_unix.go:403		0x4ee7ba		5d			POPQ BP							
  fd_unix.go:403		0x4ee7bb		c3			RET							
  fd_unix.go:400		0x4ee7bc		4889742458		MOVQ SI, 0x58(SP)					
  fd_unix.go:400		0x4ee7c1		48899c2490000000	MOVQ BX, 0x90(SP)					
  fd_unix.go:400		0x4ee7c9		48898c2498000000	MOVQ CX, 0x98(SP)					
  fd_unix.go:400		0x4ee7d1		c644244f00		MOVB $0x0, 0x4f(SP)					
  fd_unix.go:400		0x4ee7d6		488b9424d0000000	MOVQ 0xd0(SP), DX					
  fd_unix.go:400		0x4ee7de		488b02			MOVQ 0(DX), AX						
  fd_unix.go:400		0x4ee7e1		ffd0			CALL AX							
  fd_unix.go:400		0x4ee7e3		488b442458		MOVQ 0x58(SP), AX					
  fd_unix.go:400		0x4ee7e8		488b9c2490000000	MOVQ 0x90(SP), BX					
  fd_unix.go:400		0x4ee7f0		488b8c2498000000	MOVQ 0x98(SP), CX					
  fd_unix.go:400		0x4ee7f8		4881c4d8000000		ADDQ $0xd8, SP						
  fd_unix.go:400		0x4ee7ff		5d			POPQ BP							
  fd_unix.go:400		0x4ee800		c3			RET							
  fd_unix.go:392		0x4ee801		4889742458		MOVQ SI, 0x58(SP)					
  fd_unix.go:392		0x4ee806		48899c2490000000	MOVQ BX, 0x90(SP)					
  fd_unix.go:392		0x4ee80e		48898c2498000000	MOVQ CX, 0x98(SP)					
  fd_unix.go:392		0x4ee816		c644244f00		MOVB $0x0, 0x4f(SP)					
  fd_unix.go:392		0x4ee81b		488b9424d0000000	MOVQ 0xd0(SP), DX					
  fd_unix.go:392		0x4ee823		488b02			MOVQ 0(DX), AX						
  fd_unix.go:392		0x4ee826		ffd0			CALL AX							
  fd_unix.go:392		0x4ee828		488b442458		MOVQ 0x58(SP), AX					
  fd_unix.go:392		0x4ee82d		488b9c2490000000	MOVQ 0x90(SP), BX					
  fd_unix.go:392		0x4ee835		488b8c2498000000	MOVQ 0x98(SP), CX					
  fd_unix.go:392		0x4ee83d		4881c4d8000000		ADDQ $0xd8, SP						
  fd_unix.go:392		0x4ee844		5d			POPQ BP							
  fd_unix.go:392		0x4ee845		c3			RET							
  itoa.go:53			0x4ee846		bb0a000000		MOVL $0xa, BX						
  itoa.go:53			0x4ee84b		e8d091f1ff		CALL internal/strconv.FormatInt(SB)			
  itoa.go:53			0x4ee850		48898424a0000000	MOVQ AX, 0xa0(SP)					
  itoa.go:53			0x4ee858		48895c2450		MOVQ BX, 0x50(SP)					
  itoa.go:53			0x4ee85d		488b442460		MOVQ 0x60(SP), AX					
  itoa.go:53			0x4ee862		bb0a000000		MOVL $0xa, BX						
  itoa.go:53			0x4ee867		e8b491f1ff		CALL internal/strconv.FormatInt(SB)			
  fd_unix.go:387		0x4ee86c		b91f000000		MOVL $0x1f, CX						
  fd_unix.go:387		0x4ee871		488bbc24a0000000	MOVQ 0xa0(SP), DI					
  fd_unix.go:387		0x4ee879		488b742450		MOVQ 0x50(SP), SI					
  fd_unix.go:387		0x4ee87e		4c8d05269c5100		LEAQ 0x519c26(IP), R8					
  fd_unix.go:387		0x4ee885		41b911000000		MOVL $0x11, R9						
  fd_unix.go:387		0x4ee88b		4989c2			MOVQ AX, R10						
  fd_unix.go:387		0x4ee88e		4989db			MOVQ BX, R11						
  fd_unix.go:387		0x4ee891		31c0			XORL AX, AX						
  fd_unix.go:387		0x4ee893		488d1dc3145200		LEAQ 0x5214c3(IP), BX					
  fd_unix.go:387		0x4ee89a		e861ecf7ff		CALL runtime.concatstring4(SB)				
  fd_unix.go:387		0x4ee89f		90			NOPL							
  fd_unix.go:387		0x4ee8a0		e89b8ff9ff		CALL runtime.convTstring(SB)				
  fd_unix.go:387		0x4ee8a5		4889c3			MOVQ AX, BX						
  fd_unix.go:387		0x4ee8a8		488d05911ea300		LEAQ 0xa31e91(IP), AX					
  fd_unix.go:387		0x4ee8af		e80cc4f9ff		CALL runtime.gopanic(SB)				
  fd_unix.go:379		0x4ee8b4		e8873cfaff		CALL runtime.panicBounds(SB)				
  fd_unix.go:379		0x4ee8b9		e8823cfaff		CALL runtime.panicBounds(SB)				
  fd_unix.go:379		0x4ee8be		90			NOPL							
  fd_unix.go:379		0x4ee8bf		90			NOPL							
  fd_unix.go:379		0x4ee8c0		e83bfff5ff		CALL runtime.deferreturn(SB)				
  fd_unix.go:379		0x4ee8c5		488b442458		MOVQ 0x58(SP), AX					
  fd_unix.go:379		0x4ee8ca		488b9c2490000000	MOVQ 0x90(SP), BX					
  fd_unix.go:379		0x4ee8d2		488b8c2498000000	MOVQ 0x98(SP), CX					
  fd_unix.go:379		0x4ee8da		4881c4d8000000		ADDQ $0xd8, SP						
  fd_unix.go:379		0x4ee8e1		5d			POPQ BP							
  fd_unix.go:379		0x4ee8e2		c3			RET							
  fd_unix.go:365		0x4ee8e3		4889442408		MOVQ AX, 0x8(SP)					
  fd_unix.go:365		0x4ee8e8		48895c2410		MOVQ BX, 0x10(SP)					
  fd_unix.go:365		0x4ee8ed		48894c2418		MOVQ CX, 0x18(SP)					
  fd_unix.go:365		0x4ee8f2		48897c2420		MOVQ DI, 0x20(SP)					
  fd_unix.go:365		0x4ee8f7		e80420faff		CALL runtime.morestack_noctxt.abi0(SB)			
  fd_unix.go:365		0x4ee8fc		488b442408		MOVQ 0x8(SP), AX					
  fd_unix.go:365		0x4ee901		488b5c2410		MOVQ 0x10(SP), BX					
  fd_unix.go:365		0x4ee906		488b4c2418		MOVQ 0x18(SP), CX					
  fd_unix.go:365		0x4ee90b		488b7c2420		MOVQ 0x20(SP), DI					
  fd_unix.go:365		0x4ee910		e9cbfaffff		JMP internal/poll.(*FD).Write(SB)			

TEXT github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).enqueue(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/network/websocket.go
  websocket.go:140	0x9807a0		4c8da42458ffffff		LEAQ 0xffffff58(SP), R12											
  websocket.go:140	0x9807a8		4d3b6610			CMPQ R12, 0x10(R14)												
  websocket.go:140	0x9807ac		0f8666060000			JBE 0x980e18													
  websocket.go:140	0x9807b2		55				PUSHQ BP													
  websocket.go:140	0x9807b3		4889e5				MOVQ SP, BP													
  websocket.go:140	0x9807b6		4881ec20010000			SUBQ $0x120, SP													
  websocket.go:140	0x9807bd		66440fd6bc2418010000		MOVQ X15, 0x118(SP)												
  mutex.go:63		0x9807c7		4889842430010000		MOVQ AX, 0x130(SP)												
  mutex.go:63		0x9807cf		889c2438010000			MOVB BL, 0x138(SP)												
  mutex.go:63		0x9807d6		4889bc2448010000		MOVQ DI, 0x148(SP)												
  mutex.go:63		0x9807de		48898c2440010000		MOVQ CX, 0x140(SP)												
  websocket.go:140	0x9807e6		c644243700			MOVB $0x0, 0x37(SP)												
  websocket.go:140	0x9807eb		440f117c2460			MOVUPS X15, 0x60(SP)												
  mutex.go:46		0x9807f1		90				NOPL														
  mutex.go:63		0x9807f2		4889c2				MOVQ AX, DX													
  websocket.go:141	0x9807f5		31c0				XORL AX, AX													
  websocket.go:141	0x9807f7		be01000000			MOVL $0x1, SI													
  websocket.go:141	0x9807fc		f00fb132			LOCK CMPXCHGL SI, 0(DX)												
  websocket.go:141	0x980800		400f94c6			SETE SI														
  mutex.go:63		0x980804		4084f6				TESTL SI, SI													
  mutex.go:63		0x980807		7510				JNE 0x980819													
  mutex.go:70		0x980809		4889d0				MOVQ DX, AX													
  mutex.go:70		0x98080c		e8cf5bb1ff			CALL internal/sync.(*Mutex).lockSlow(SB)									
  websocket.go:142	0x980811		488b942430010000		MOVQ 0x130(SP), DX												
  websocket.go:142	0x980819		488d0dc0b50000			LEAQ github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).enqueue.deferwrap1(SB), CX	
  websocket.go:142	0x980820		48898c24c0000000		MOVQ CX, 0xc0(SP)												
  websocket.go:142	0x980828		48899424c8000000		MOVQ DX, 0xc8(SP)												
  websocket.go:142	0x980830		488d8c24c0000000		LEAQ 0xc0(SP), CX												
  websocket.go:142	0x980838		48898c2418010000		MOVQ CX, 0x118(SP)												
  websocket.go:142	0x980840		c644243701			MOVB $0x1, 0x37(SP)												
  websocket.go:145	0x980845		488b5a58			MOVQ 0x58(DX), BX												
  websocket.go:145	0x980849		31c0				XORL AX, AX													
  websocket.go:145	0x98084b		e8b085a9ff			CALL runtime.selectnbrecv(SB)											
  websocket.go:145	0x980850		84c0				TESTL AL, AL													
  websocket.go:145	0x980852		0f8561050000			JNE 0x980db9													
  type.go:128		0x980858		488b8c2448010000		MOVQ 0x148(SP), CX												
  type.go:128		0x980860		488b842430010000		MOVQ 0x130(SP), AX												
  type.go:128		0x980868		4889ca				MOVQ CX, DX													
  type.go:128		0x98086b		f0480fc14870			LOCK XADDQ CX, 0x70(AX)												
  type.go:128		0x980871		4801d1				ADDQ DX, CX													
  type.go:128		0x980874		660f1f840000000000		NOPW 0(AX)(AX*1)												
  type.go:128		0x98087d		0f1f00				NOPL 0(AX)													
  websocket.go:150	0x980880		4881f900001000			CMPQ CX, $0x100000												
  websocket.go:150	0x980887		0f8fe1040000			JG 0x980d6e													
  websocket.go:159	0x98088d		488b5850			MOVQ 0x50(AX), BX												
  websocket.go:159	0x980891		48c78424f800000000000000	MOVQ $0x0, 0xf8(SP)												
  websocket.go:159	0x98089d		440f11bc2400010000		MOVUPS X15, 0x100(SP)												
  websocket.go:159	0x9808a6		488d8424f8000000		LEAQ 0xf8(SP), AX												
  websocket.go:159	0x9808ae		e84d85a9ff			CALL runtime.selectnbrecv(SB)											
  websocket.go:159	0x9808b3		84c0				TESTL AL, AL													
  websocket.go:159	0x9808b5		7412				JE 0x9808c9													
  websocket.go:159	0x9808b7		488b9c24f8000000		MOVQ 0xf8(SP), BX												
  websocket.go:159	0x9808bf		488bbc2408010000		MOVQ 0x108(SP), DI												
  websocket.go:159	0x9808c7		eb04				JMP 0x9808cd													
  websocket.go:159	0x9808c9		31ff				XORL DI, DI													
  websocket.go:159	0x9808cb		31db				XORL BX, BX													
  websocket.go:163	0x9808cd		488b8c2448010000		MOVQ 0x148(SP), CX												
  websocket.go:163	0x9808d5		488d510a			LEAQ 0xa(CX), DX												
  websocket.go:163	0x9808d9		4889542440			MOVQ DX, 0x40(SP)												
  websocket.go:163	0x9808de		6690				NOPW														
  websocket.go:165	0x9808e0		4839d7				CMPQ DI, DX													
  websocket.go:165	0x9808e3		7c07				JL 0x9808ec													
  websocket.go:168	0x9808e5		732a				JAE 0x980911													
  websocket.go:168	0x9808e7		e90a050000			JMP 0x980df6													
  websocket.go:166	0x9808ec		488d05cdfe5900			LEAQ 0x59fecd(IP), AX												
  websocket.go:166	0x9808f3		4889d3				MOVQ DX, BX													
  websocket.go:166	0x9808f6		4889d9				MOVQ BX, CX													
  websocket.go:166	0x9808f9		e882cbb0ff			CALL runtime.makeslice(SB)											
  websocket.go:171	0x9808fe		488b8c2448010000		MOVQ 0x148(SP), CX												
  websocket.go:173	0x980906		488b542440			MOVQ 0x40(SP), DX												
  websocket.go:171	0x98090b		4889d7				MOVQ DX, DI													
  websocket.go:171	0x98090e		4889c3				MOVQ AX, BX													
  websocket.go:171	0x980911		48897c2448			MOVQ DI, 0x48(SP)												
  websocket.go:171	0x980916		48899c2498000000		MOVQ BX, 0x98(SP)												
  websocket.go:171	0x98091e		4c8d4ff6			LEAQ -0xa(DI), R9												
  websocket.go:171	0x980922		4d89ca				MOVQ R9, R10													
  websocket.go:171	0x980925		49f7d9				NEGQ R9														
  websocket.go:171	0x980928		49c1f93f			SARQ $0x3f, R9													
  websocket.go:171	0x98092c		4183e10a			ANDL $0xa, R9													
  websocket.go:171	0x980930		4a8d040b			LEAQ 0(BX)(R9*1), AX												
  websocket.go:171	0x980934		48898424f8000000		MOVQ AX, 0xf8(SP)												
  websocket.go:171	0x98093c		48898c2400010000		MOVQ CX, 0x100(SP)												
  websocket.go:171	0x980944		4c89942408010000		MOVQ R10, 0x108(SP)												
  websocket.go:171	0x98094c		4c8b8c2440010000		MOVQ 0x140(SP), R9												
  websocket.go:171	0x980954		4939c1				CMPQ R9, AX													
  websocket.go:171	0x980957		7426				JE 0x98097f													
  websocket.go:171	0x980959		4c89cb				MOVQ R9, BX													
  websocket.go:171	0x98095c		0f1f4000			NOPL 0(AX)													
  websocket.go:171	0x980960		e87b1fb1ff			CALL runtime.memmove(SB)											
  websocket.go:207	0x980965		488b8c2448010000		MOVQ 0x148(SP), CX												
  websocket.go:173	0x98096d		488b542440			MOVQ 0x40(SP), DX												
  websocket.go:173	0x980972		488b9c2498000000		MOVQ 0x98(SP), BX												
  websocket.go:173	0x98097a		488b7c2448			MOVQ 0x48(SP), DI												
  websocket.go:173	0x98097f		4c8d4c2470			LEAQ 0x70(SP), R9												
  websocket.go:173	0x980984		450f1139			MOVUPS X15, 0(R9)												
  websocket.go:173	0x980988		450f117910			MOVUPS X15, 0x10(R9)												
  websocket.go:173	0x98098d		450f117918			MOVUPS X15, 0x18(R9)												
  websocket.go:173	0x980992		0fb6842438010000		MOVZX 0x138(SP), AX												
  websocket.go:173	0x98099a		88442478			MOVB AL, 0x78(SP)												
  websocket.go:173	0x98099e		48899c2480000000		MOVQ BX, 0x80(SP)												
  websocket.go:173	0x9809a6		4889942488000000		MOVQ DX, 0x88(SP)												
  websocket.go:173	0x9809ae		4889bc2490000000		MOVQ DI, 0x90(SP)												
  websocket.go:175	0x9809b6		4c8b942430010000		MOVQ 0x130(SP), R10												
  websocket.go:175	0x9809be		49837a1000			CMPQ 0x10(R10), $0x0												
  websocket.go:175	0x9809c3		740d				JE 0x9809d2													
  type.go:114		0x9809c5		4d8b5a08			MOVQ 0x8(R10), R11												
  websocket.go:175	0x9809c9		4d85db				TESTQ R11, R11													
  websocket.go:175	0x9809cc		410f94c3			SETE R11													
  websocket.go:175	0x9809d0		eb03				JMP 0x9809d5													
  websocket.go:175	0x9809d2		4531db				XORL R11, R11													
  websocket.go:175	0x9809d5		4584db				TESTL R11, R11													
  websocket.go:175	0x9809d8		7456				JE 0x980a30													
  websocket.go:176	0x9809da		4889d1				MOVQ DX, CX													
  websocket.go:176	0x9809dd		0f1f00				NOPL 0(AX)													
  websocket.go:176	0x9809e0		e8db070000			CALL github.com/burntcustard/unicorn-mining-co/src/server/network.frameBytes(SB)				
  websocket.go:176	0x9809e5		48895c2458			MOVQ BX, 0x58(SP)												
  websocket.go:177	0x9809ea		488b942430010000		MOVQ 0x130(SP), DX												
  websocket.go:177	0x9809f2		488b5210			MOVQ 0x10(DX), DX												
  websocket.go:177	0x9809f6		4889cf				MOVQ CX, DI													
  websocket.go:177	0x9809f9		4889d9				MOVQ BX, CX													
  websocket.go:177	0x9809fc		4889c3				MOVQ AX, BX													
  websocket.go:177	0x9809ff		4889d0				MOVQ DX, AX													
  websocket.go:177	0x980a02		e8b9efffff			CALL github.com/burntcustard/unicorn-mining-co/src/server/network.(*directSender).send(SB)			
  websocket.go:179	0x980a07		4885db				TESTQ BX, BX													
  websocket.go:179	0x980a0a		0f85af020000			JNE 0x980cbf													
  websocket.go:186	0x980a10		488b542458			MOVQ 0x58(SP), DX												
  websocket.go:186	0x980a15		4839d0				CMPQ AX, DX													
  websocket.go:186	0x980a18		0f8407020000			JE 0x980c25													
  websocket.go:197	0x980a1e		4889442470			MOVQ AX, 0x70(SP)												
  websocket.go:173	0x980a23		4c8d4c2470			LEAQ 0x70(SP), R9												
  type.go:128		0x980a28		4c8b942430010000		MOVQ 0x130(SP), R10												
  websocket.go:200	0x980a30		90				NOPL														
  type.go:128		0x980a31		ba01000000			MOVL $0x1, DX													
  type.go:128		0x980a36		f0490fc15208			LOCK XADDQ DX, 0x8(R10)												
  websocket.go:203	0x980a3c		498b5248			MOVQ 0x48(R10), DX												
  websocket.go:203	0x980a40		4c8d9c24d0000000		LEAQ 0xd0(SP), R11												
  websocket.go:203	0x980a48		450f1031			MOVUPS 0(R9), X14												
  websocket.go:203	0x980a4c		450f1133			MOVUPS X14, 0(R11)												
  websocket.go:203	0x980a50		450f107110			MOVUPS 0x10(R9), X14												
  websocket.go:203	0x980a55		450f117310			MOVUPS X14, 0x10(R11)												
  websocket.go:203	0x980a5a		450f107118			MOVUPS 0x18(R9), X14												
  websocket.go:203	0x980a5f		450f117318			MOVUPS X14, 0x18(R11)												
  websocket.go:205	0x980a64		4d8b4a58			MOVQ 0x58(R10), R9												
  websocket.go:202	0x980a68		4c8d9424a0000000		LEAQ 0xa0(SP), R10												
  websocket.go:202	0x980a70		450f113a			MOVUPS X15, 0(R10)												
  websocket.go:202	0x980a74		450f117a10			MOVUPS X15, 0x10(R10)												
  websocket.go:203	0x980a79		48899424a0000000		MOVQ DX, 0xa0(SP)												
  websocket.go:203	0x980a81		4c899c24a8000000		MOVQ R11, 0xa8(SP)												
  websocket.go:205	0x980a89		4c898c24b0000000		MOVQ R9, 0xb0(SP)												
  websocket.go:202	0x980a91		488d8424a0000000		LEAQ 0xa0(SP), AX												
  websocket.go:202	0x980a99		488d5c2438			LEAQ 0x38(SP), BX												
  websocket.go:202	0x980a9e		31c9				XORL CX, CX													
  websocket.go:202	0x980aa0		bf01000000			MOVL $0x1, DI													
  websocket.go:202	0x980aa5		89fe				MOVL DI, SI													
  websocket.go:202	0x980aa7		4531c0				XORL R8, R8													
  websocket.go:202	0x980aaa		e8513baeff			CALL runtime.selectgo(SB)											
  websocket.go:210	0x980aaf		4885c0				TESTQ AX, AX													
  websocket.go:210	0x980ab2		0f8ccd000000			JL 0x980b85													
  websocket.go:203	0x980ab8		752b				JNE 0x980ae5													
  websocket.go:204	0x980aba		440f117c2460			MOVUPS X15, 0x60(SP)												
  websocket.go:204	0x980ac0		c644243700			MOVB $0x0, 0x37(SP)												
  websocket.go:204	0x980ac5		488b942418010000		MOVQ 0x118(SP), DX												
  websocket.go:204	0x980acd		488b02				MOVQ 0(DX), AX													
  websocket.go:204	0x980ad0		ffd0				CALL AX														
  websocket.go:204	0x980ad2		488b5c2468			MOVQ 0x68(SP), BX												
  websocket.go:204	0x980ad7		488b442460			MOVQ 0x60(SP), AX												
  websocket.go:204	0x980adc		4881c420010000			ADDQ $0x120, SP													
  websocket.go:204	0x980ae3		5d				POPQ BP														
  websocket.go:204	0x980ae4		c3				RET														
  websocket.go:207	0x980ae5		488b8c2448010000		MOVQ 0x148(SP), CX												
  websocket.go:207	0x980aed		48f7d9				NEGQ CX														
  websocket.go:206	0x980af0		90				NOPL														
  type.go:128		0x980af1		48c7c2ffffffff			MOVQ $-0x1, DX													
  type.go:128		0x980af8		488bb42430010000		MOVQ 0x130(SP), SI												
  type.go:128		0x980b00		f0480fc15608			LOCK XADDQ DX, 0x8(SI)												
  type.go:128		0x980b06		f0480fc14e70			LOCK XADDQ CX, 0x70(SI)												
  websocket.go:224	0x980b0c		488b4650			MOVQ 0x50(SI), AX												
  websocket.go:208	0x980b10		90				NOPL														
  websocket.go:224	0x980b11		488b8c2498000000		MOVQ 0x98(SP), CX												
  websocket.go:224	0x980b19		48898c24f8000000		MOVQ CX, 0xf8(SP)												
  websocket.go:224	0x980b21		488b4c2440			MOVQ 0x40(SP), CX												
  websocket.go:224	0x980b26		48898c2400010000		MOVQ CX, 0x100(SP)												
  websocket.go:224	0x980b2e		488b4c2448			MOVQ 0x48(SP), CX												
  websocket.go:224	0x980b33		48898c2408010000		MOVQ CX, 0x108(SP)												
  websocket.go:224	0x980b3b		488d9c24f8000000		LEAQ 0xf8(SP), BX												
  websocket.go:224	0x980b43		e87882a9ff			CALL runtime.selectnbsend(SB)											
  websocket.go:209	0x980b48		488b0d01df6600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrClosed(SB), CX				
  websocket.go:209	0x980b4f		488b1502df6600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrClosed+8(SB), DX				
  websocket.go:209	0x980b56		48894c2460			MOVQ CX, 0x60(SP)												
  websocket.go:209	0x980b5b		4889542468			MOVQ DX, 0x68(SP)												
  websocket.go:209	0x980b60		c644243700			MOVB $0x0, 0x37(SP)												
  websocket.go:209	0x980b65		488b942418010000		MOVQ 0x118(SP), DX												
  websocket.go:209	0x980b6d		488b0a				MOVQ 0(DX), CX													
  websocket.go:209	0x980b70		ffd1				CALL CX														
  websocket.go:209	0x980b72		488b442460			MOVQ 0x60(SP), AX												
  websocket.go:209	0x980b77		488b5c2468			MOVQ 0x68(SP), BX												
  websocket.go:209	0x980b7c		4881c420010000			ADDQ $0x120, SP													
  websocket.go:209	0x980b83		5d				POPQ BP														
  websocket.go:209	0x980b84		c3				RET														
  websocket.go:212	0x980b85		488b8c2448010000		MOVQ 0x148(SP), CX												
  websocket.go:212	0x980b8d		48f7d9				NEGQ CX														
  websocket.go:211	0x980b90		90				NOPL														
  type.go:128		0x980b91		48c7c2ffffffff			MOVQ $-0x1, DX													
  type.go:128		0x980b98		488bb42430010000		MOVQ 0x130(SP), SI												
  type.go:128		0x980ba0		f0480fc15608			LOCK XADDQ DX, 0x8(SI)												
  type.go:128		0x980ba6		f0480fc14e70			LOCK XADDQ CX, 0x70(SI)												
  websocket.go:224	0x980bac		488b4650			MOVQ 0x50(SI), AX												
  websocket.go:213	0x980bb0		90				NOPL														
  websocket.go:224	0x980bb1		488b8c2498000000		MOVQ 0x98(SP), CX												
  websocket.go:224	0x980bb9		48898c24f8000000		MOVQ CX, 0xf8(SP)												
  websocket.go:224	0x980bc1		488b4c2440			MOVQ 0x40(SP), CX												
  websocket.go:224	0x980bc6		48898c2400010000		MOVQ CX, 0x100(SP)												
  websocket.go:224	0x980bce		488b4c2448			MOVQ 0x48(SP), CX												
  websocket.go:224	0x980bd3		48898c2408010000		MOVQ CX, 0x108(SP)												
  websocket.go:224	0x980bdb		488d9c24f8000000		LEAQ 0xf8(SP), BX												
  websocket.go:224	0x980be3		e8d881a9ff			CALL runtime.selectnbsend(SB)											
  websocket.go:214	0x980be8		488b0d51de6600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrQueueFull(SB), CX				
  websocket.go:214	0x980bef		488b1552de6600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrQueueFull+8(SB), DX			
  websocket.go:214	0x980bf6		48894c2460			MOVQ CX, 0x60(SP)												
  websocket.go:214	0x980bfb		4889542468			MOVQ DX, 0x68(SP)												
  websocket.go:214	0x980c00		c644243700			MOVB $0x0, 0x37(SP)												
  websocket.go:214	0x980c05		488b942418010000		MOVQ 0x118(SP), DX												
  websocket.go:214	0x980c0d		488b0a				MOVQ 0(DX), CX													
  websocket.go:214	0x980c10		ffd1				CALL CX														
  websocket.go:214	0x980c12		488b442460			MOVQ 0x60(SP), AX												
  websocket.go:214	0x980c17		488b5c2468			MOVQ 0x68(SP), BX												
  websocket.go:214	0x980c1c		4881c420010000			ADDQ $0x120, SP													
  websocket.go:214	0x980c23		5d				POPQ BP														
  websocket.go:214	0x980c24		c3				RET														
  websocket.go:187	0x980c25		488b8c2448010000		MOVQ 0x148(SP), CX												
  websocket.go:187	0x980c2d		48f7d9				NEGQ CX														
  type.go:128		0x980c30		488b942430010000		MOVQ 0x130(SP), DX												
  type.go:128		0x980c38		f0480fc14a70			LOCK XADDQ CX, 0x70(DX)												
  websocket.go:224	0x980c3e		488b4250			MOVQ 0x50(DX), AX												
  websocket.go:188	0x980c42		90				NOPL														
  websocket.go:224	0x980c43		488b8c2498000000		MOVQ 0x98(SP), CX												
  websocket.go:224	0x980c4b		48898c24f8000000		MOVQ CX, 0xf8(SP)												
  websocket.go:224	0x980c53		488b4c2440			MOVQ 0x40(SP), CX												
  websocket.go:224	0x980c58		48898c2400010000		MOVQ CX, 0x100(SP)												
  websocket.go:224	0x980c60		488b4c2448			MOVQ 0x48(SP), CX												
  websocket.go:224	0x980c65		48898c2408010000		MOVQ CX, 0x108(SP)												
  websocket.go:224	0x980c6d		488d9c24f8000000		LEAQ 0xf8(SP), BX												
  websocket.go:224	0x980c75		e84681a9ff			CALL runtime.selectnbsend(SB)											
  websocket.go:190	0x980c7a		0fb68c2438010000		MOVZX 0x138(SP), CX												
  websocket.go:190	0x980c82		80f908				CMPL CL, $0x8													
  websocket.go:224	0x980c85		750d				JNE 0x980c94													
  websocket.go:191	0x980c87		488b842430010000		MOVQ 0x130(SP), AX												
  websocket.go:191	0x980c8f		e8acf8ffff			CALL github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).closeTransport(SB)		
  websocket.go:194	0x980c94		440f117c2460			MOVUPS X15, 0x60(SP)												
  websocket.go:194	0x980c9a		c644243700			MOVB $0x0, 0x37(SP)												
  websocket.go:194	0x980c9f		488b942418010000		MOVQ 0x118(SP), DX												
  websocket.go:194	0x980ca7		488b02				MOVQ 0(DX), AX													
  websocket.go:194	0x980caa		ffd0				CALL AX														
  websocket.go:194	0x980cac		488b5c2468			MOVQ 0x68(SP), BX												
  websocket.go:194	0x980cb1		488b442460			MOVQ 0x60(SP), AX												
  websocket.go:194	0x980cb6		4881c420010000			ADDQ $0x120, SP													
  websocket.go:194	0x980cbd		5d				POPQ BP														
  websocket.go:194	0x980cbe		c3				RET														
  websocket.go:177	0x980cbf		48898c2410010000		MOVQ CX, 0x110(SP)												
  websocket.go:177	0x980cc7		48895c2450			MOVQ BX, 0x50(SP)												
  websocket.go:180	0x980ccc		488b8c2448010000		MOVQ 0x148(SP), CX												
  websocket.go:180	0x980cd4		48f7d9				NEGQ CX														
  type.go:128		0x980cd7		488b942430010000		MOVQ 0x130(SP), DX												
  type.go:128		0x980cdf		f0480fc14a70			LOCK XADDQ CX, 0x70(DX)												
  websocket.go:224	0x980ce5		488b4250			MOVQ 0x50(DX), AX												
  websocket.go:181	0x980ce9		90				NOPL														
  websocket.go:224	0x980cea		488b8c2498000000		MOVQ 0x98(SP), CX												
  websocket.go:224	0x980cf2		48898c24f8000000		MOVQ CX, 0xf8(SP)												
  websocket.go:224	0x980cfa		488b4c2440			MOVQ 0x40(SP), CX												
  websocket.go:224	0x980cff		48898c2400010000		MOVQ CX, 0x100(SP)												
  websocket.go:224	0x980d07		488b4c2448			MOVQ 0x48(SP), CX												
  websocket.go:224	0x980d0c		48898c2408010000		MOVQ CX, 0x108(SP)												
  websocket.go:224	0x980d14		488d9c24f8000000		LEAQ 0xf8(SP), BX												
  websocket.go:224	0x980d1c		0f1f4000			NOPL 0(AX)													
  websocket.go:224	0x980d20		e89b80a9ff			CALL runtime.selectnbsend(SB)											
  websocket.go:182	0x980d25		488b842430010000		MOVQ 0x130(SP), AX												
  websocket.go:182	0x980d2d		e80ef8ffff			CALL github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).closeTransport(SB)		
  websocket.go:183	0x980d32		488b4c2450			MOVQ 0x50(SP), CX												
  websocket.go:183	0x980d37		48894c2460			MOVQ CX, 0x60(SP)												
  websocket.go:183	0x980d3c		488b8c2410010000		MOVQ 0x110(SP), CX												
  websocket.go:183	0x980d44		48894c2468			MOVQ CX, 0x68(SP)												
  websocket.go:183	0x980d49		c644243700			MOVB $0x0, 0x37(SP)												
  websocket.go:183	0x980d4e		488b942418010000		MOVQ 0x118(SP), DX												
  websocket.go:183	0x980d56		488b0a				MOVQ 0(DX), CX													
  websocket.go:183	0x980d59		ffd1				CALL CX														
  websocket.go:183	0x980d5b		488b442460			MOVQ 0x60(SP), AX												
  websocket.go:183	0x980d60		488b5c2468			MOVQ 0x68(SP), BX												
  websocket.go:183	0x980d65		4881c420010000			ADDQ $0x120, SP													
  websocket.go:183	0x980d6c		5d				POPQ BP														
  websocket.go:183	0x980d6d		c3				RET														
  websocket.go:151	0x980d6e		48f7da				NEGQ DX														
  type.go:128		0x980d71		f0480fc15070			LOCK XADDQ DX, 0x70(AX)												
  websocket.go:152	0x980d77		e8c4f7ffff			CALL github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).closeTransport(SB)		
  websocket.go:153	0x980d7c		488b0daddc6600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrSlowClient(SB), CX				
  websocket.go:153	0x980d83		488b15aedc6600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrSlowClient+8(SB), DX			
  websocket.go:153	0x980d8a		48894c2460			MOVQ CX, 0x60(SP)												
  websocket.go:153	0x980d8f		4889542468			MOVQ DX, 0x68(SP)												
  websocket.go:153	0x980d94		c644243700			MOVB $0x0, 0x37(SP)												
  websocket.go:153	0x980d99		488b942418010000		MOVQ 0x118(SP), DX												
  websocket.go:153	0x980da1		488b0a				MOVQ 0(DX), CX													
  websocket.go:153	0x980da4		ffd1				CALL CX														
  websocket.go:153	0x980da6		488b442460			MOVQ 0x60(SP), AX												
  websocket.go:153	0x980dab		488b5c2468			MOVQ 0x68(SP), BX												
  websocket.go:153	0x980db0		4881c420010000			ADDQ $0x120, SP													
  websocket.go:153	0x980db7		5d				POPQ BP														
  websocket.go:153	0x980db8		c3				RET														
  websocket.go:146	0x980db9		488b0590dc6600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrClosed(SB), AX				
  websocket.go:146	0x980dc0		488b0d91dc6600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrClosed+8(SB), CX				
  websocket.go:146	0x980dc7		4889442460			MOVQ AX, 0x60(SP)												
  websocket.go:146	0x980dcc		48894c2468			MOVQ CX, 0x68(SP)												
  websocket.go:146	0x980dd1		c644243700			MOVB $0x0, 0x37(SP)												
  websocket.go:146	0x980dd6		488b942418010000		MOVQ 0x118(SP), DX												
  websocket.go:146	0x980dde		488b02				MOVQ 0(DX), AX													
  websocket.go:146	0x980de1		ffd0				CALL AX														
  websocket.go:146	0x980de3		488b442460			MOVQ 0x60(SP), AX												
  websocket.go:146	0x980de8		488b5c2468			MOVQ 0x68(SP), BX												
  websocket.go:146	0x980ded		4881c420010000			ADDQ $0x120, SP													
  websocket.go:146	0x980df4		5d				POPQ BP														
  websocket.go:146	0x980df5		c3				RET														
  websocket.go:168	0x980df6		e84517b1ff			CALL runtime.panicBounds(SB)											
  websocket.go:168	0x980dfb		90				NOPL														
  websocket.go:168	0x980dfc		0f1f4000			NOPL 0(AX)													
  websocket.go:168	0x980e00		e8fbd9acff			CALL runtime.deferreturn(SB)											
  websocket.go:168	0x980e05		488b442460			MOVQ 0x60(SP), AX												
  websocket.go:168	0x980e0a		488b5c2468			MOVQ 0x68(SP), BX												
  websocket.go:168	0x980e0f		4881c420010000			ADDQ $0x120, SP													
  websocket.go:168	0x980e16		5d				POPQ BP														
  websocket.go:168	0x980e17		c3				RET														
  websocket.go:140	0x980e18		4889442408			MOVQ AX, 0x8(SP)												
  websocket.go:140	0x980e1d		885c2410			MOVB BL, 0x10(SP)												
  websocket.go:140	0x980e21		48894c2418			MOVQ CX, 0x18(SP)												
  websocket.go:140	0x980e26		48897c2420			MOVQ DI, 0x20(SP)												
  websocket.go:140	0x980e2b		4889742428			MOVQ SI, 0x28(SP)												
  websocket.go:140	0x980e30		e8cbfab0ff			CALL runtime.morestack_noctxt.abi0(SB)										
  websocket.go:140	0x980e35		488b442408			MOVQ 0x8(SP), AX												
  websocket.go:140	0x980e3a		0fb65c2410			MOVZX 0x10(SP), BX												
  websocket.go:140	0x980e3f		488b4c2418			MOVQ 0x18(SP), CX												
  websocket.go:140	0x980e44		488b7c2420			MOVQ 0x20(SP), DI												
  websocket.go:140	0x980e49		488b742428			MOVQ 0x28(SP), SI												
  websocket.go:140	0x980e4e		e94df9ffff			JMP github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).enqueue(SB)			

TEXT github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).writePump(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/network/websocket.go
  websocket.go:233	0x980ec0		4c8d6424b0		LEAQ -0x50(SP), R12											
  websocket.go:233	0x980ec5		4d3b6610		CMPQ R12, 0x10(R14)											
  websocket.go:233	0x980ec9		0f8672010000		JBE 0x981041												
  websocket.go:233	0x980ecf		55			PUSHQ BP												
  websocket.go:233	0x980ed0		4889e5			MOVQ SP, BP												
  websocket.go:233	0x980ed3		4881ecc8000000		SUBQ $0xc8, SP												
  websocket.go:234	0x980eda		48898424d8000000	MOVQ AX, 0xd8(SP)											
  websocket.go:236	0x980ee2		488b5058		MOVQ 0x58(AX), DX											
  websocket.go:238	0x980ee6		4c8b4848		MOVQ 0x48(AX), R9											
  websocket.go:238	0x980eea		4c8d9424a0000000	LEAQ 0xa0(SP), R10											
  websocket.go:238	0x980ef2		450f113a		MOVUPS X15, 0(R10)											
  websocket.go:238	0x980ef6		450f117a10		MOVUPS X15, 0x10(R10)											
  websocket.go:238	0x980efb		450f117a18		MOVUPS X15, 0x18(R10)											
  websocket.go:235	0x980f00		4c8d5c2468		LEAQ 0x68(SP), R11											
  websocket.go:235	0x980f05		450f113b		MOVUPS X15, 0(R11)											
  websocket.go:235	0x980f09		450f117b10		MOVUPS X15, 0x10(R11)											
  websocket.go:236	0x980f0e		4889542478		MOVQ DX, 0x78(SP)											
  websocket.go:238	0x980f13		4c894c2468		MOVQ R9, 0x68(SP)											
  websocket.go:238	0x980f18		4c89542470		MOVQ R10, 0x70(SP)											
  websocket.go:235	0x980f1d		488d442468		LEAQ 0x68(SP), AX											
  websocket.go:235	0x980f22		488d5c2430		LEAQ 0x30(SP), BX											
  websocket.go:235	0x980f27		31c9			XORL CX, CX												
  websocket.go:235	0x980f29		31ff			XORL DI, DI												
  websocket.go:235	0x980f2b		be02000000		MOVL $0x2, SI												
  websocket.go:235	0x980f30		41b801000000		MOVL $0x1, R8												
  websocket.go:235	0x980f36		e8c536aeff		CALL runtime.selectgo(SB)										
  websocket.go:235	0x980f3b		0f1f440000		NOPL 0(AX)(AX*1)											
  websocket.go:238	0x980f40		4885c0			TESTQ AX, AX												
  websocket.go:238	0x980f43		0f85ee000000		JNE 0x981037												
  websocket.go:239	0x980f49		0fb69c24a8000000	MOVZX 0xa8(SP), BX											
  websocket.go:239	0x980f51		488b8c24b0000000	MOVQ 0xb0(SP), CX											
  websocket.go:239	0x980f59		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  websocket.go:239	0x980f61		488bb424c0000000	MOVQ 0xc0(SP), SI											
  websocket.go:239	0x980f69		4c8b8424a0000000	MOVQ 0xa0(SP), R8											
  websocket.go:238	0x980f71		488d542440		LEAQ 0x40(SP), DX											
  websocket.go:238	0x980f76		4c8d8c24a0000000	LEAQ 0xa0(SP), R9											
  websocket.go:238	0x980f7e		450f1031		MOVUPS 0(R9), X14											
  websocket.go:238	0x980f82		440f1132		MOVUPS X14, 0(DX)											
  websocket.go:238	0x980f86		450f107110		MOVUPS 0x10(R9), X14											
  websocket.go:238	0x980f8b		440f117210		MOVUPS X14, 0x10(DX)											
  websocket.go:238	0x980f90		450f107118		MOVUPS 0x18(R9), X14											
  websocket.go:238	0x980f95		440f117218		MOVUPS X14, 0x18(DX)											
  websocket.go:239	0x980f9a		488b8424d8000000	MOVQ 0xd8(SP), AX											
  websocket.go:239	0x980fa2		e8b9000000		CALL github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).writePartialFrame(SB)	
  websocket.go:239	0x980fa7		4889442438		MOVQ AX, 0x38(SP)											
  websocket.go:240	0x980fac		488b542458		MOVQ 0x58(SP), DX											
  websocket.go:240	0x980fb1		4883c2f6		ADDQ $-0xa, DX												
  websocket.go:240	0x980fb5		48f7da			NEGQ DX													
  type.go:128		0x980fb8		4c8b8c24d8000000	MOVQ 0xd8(SP), R9											
  type.go:128		0x980fc0		f0490fc15170		LOCK XADDQ DX, 0x70(R9)											
  websocket.go:241	0x980fc6		488b542450		MOVQ 0x50(SP), DX											
  websocket.go:241	0x980fcb		4c8b542458		MOVQ 0x58(SP), R10											
  websocket.go:241	0x980fd0		4c8b5c2460		MOVQ 0x60(SP), R11											
  websocket.go:224	0x980fd5		498b4150		MOVQ 0x50(R9), AX											
  websocket.go:224	0x980fd9		4889942488000000	MOVQ DX, 0x88(SP)											
  websocket.go:224	0x980fe1		4c89942490000000	MOVQ R10, 0x90(SP)											
  websocket.go:224	0x980fe9		4c899c2498000000	MOVQ R11, 0x98(SP)											
  websocket.go:224	0x980ff1		488d9c2488000000	LEAQ 0x88(SP), BX											
  websocket.go:224	0x980ff9		e8c27da9ff		CALL runtime.selectnbsend(SB)										
  websocket.go:242	0x980ffe		90			NOPL													
  type.go:128		0x980fff		48c7c2ffffffff		MOVQ $-0x1, DX												
  type.go:128		0x981006		488b8424d8000000	MOVQ 0xd8(SP), AX											
  type.go:128		0x98100e		f0480fc15008		LOCK XADDQ DX, 0x8(AX)											
  websocket.go:244	0x981014		488b542438		MOVQ 0x38(SP), DX											
  websocket.go:244	0x981019		4885d2			TESTQ DX, DX												
  websocket.go:244	0x98101c		750b			JNE 0x981029												
  websocket.go:244	0x98101e		807c244808		CMPB 0x48(SP), $0x8											
  websocket.go:244	0x981023		0f85b9feffff		JNE 0x980ee2												
  websocket.go:245	0x981029		e812f5ffff		CALL github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).closeTransport(SB)	
  websocket.go:246	0x98102e		4881c4c8000000		ADDQ $0xc8, SP												
  websocket.go:246	0x981035		5d			POPQ BP													
  websocket.go:246	0x981036		c3			RET													
  websocket.go:237	0x981037		4881c4c8000000		ADDQ $0xc8, SP												
  websocket.go:237	0x98103e		5d			POPQ BP													
  websocket.go:237	0x98103f		90			NOPL													
  websocket.go:237	0x981040		c3			RET													
  websocket.go:233	0x981041		4889442408		MOVQ AX, 0x8(SP)											
  websocket.go:233	0x981046		e8b5f8b0ff		CALL runtime.morestack_noctxt.abi0(SB)									
  websocket.go:233	0x98104b		488b442408		MOVQ 0x8(SP), AX											
  websocket.go:233	0x981050		e96bfeffff		JMP github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).writePump(SB)		

TEXT github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).writePartialFrame(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/network/websocket.go
  websocket.go:260	0x981060		493b6610		CMPQ SP, 0x10(R14)											
  websocket.go:260	0x981064		0f86f5000000		JBE 0x98115f												
  websocket.go:260	0x98106a		55			PUSHQ BP												
  websocket.go:260	0x98106b		4889e5			MOVQ SP, BP												
  websocket.go:260	0x98106e		4883ec28		SUBQ $0x28, SP												
  websocket.go:261	0x981072		4889442438		MOVQ AX, 0x38(SP)											
  websocket.go:261	0x981077		885c2440		MOVB BL, 0x40(SP)											
  websocket.go:261	0x98107b		4c89442460		MOVQ R8, 0x60(SP)											
  websocket.go:261	0x981080		48894c2448		MOVQ CX, 0x48(SP)											
  websocket.go:261	0x981085		48897c2450		MOVQ DI, 0x50(SP)											
  websocket.go:261	0x98108a		4889742458		MOVQ SI, 0x58(SP)											
  websocket.go:261	0x98108f		e88c43b4ff		CALL time.Now(SB)											
  websocket.go:261	0x981094		48bf00e40b5402000000	MOVQ $0x2540be400, DI											
  websocket.go:261	0x98109e		6690			NOPW													
  websocket.go:261	0x9810a0		e81bceb3ff		CALL time.Time.Add(SB)											
  websocket.go:261	0x9810a5		488b542438		MOVQ 0x38(SP), DX											
  websocket.go:261	0x9810aa		488b7220		MOVQ 0x20(DX), SI											
  websocket.go:261	0x9810ae		488b5228		MOVQ 0x28(DX), DX											
  websocket.go:261	0x9810b2		488b7648		MOVQ 0x48(SI), SI											
  websocket.go:261	0x9810b6		4889cf			MOVQ CX, DI												
  websocket.go:261	0x9810b9		4889d9			MOVQ BX, CX												
  websocket.go:261	0x9810bc		4889c3			MOVQ AX, BX												
  websocket.go:261	0x9810bf		4889d0			MOVQ DX, AX												
  websocket.go:261	0x9810c2		ffd6			CALL SI													
  websocket.go:261	0x9810c4		4885c0			TESTQ AX, AX												
  websocket.go:261	0x9810c7		0f8586000000		JNE 0x981153												
  websocket.go:265	0x9810cd		0fb6442440		MOVZX 0x40(SP), AX											
  websocket.go:265	0x9810d2		488b5c2448		MOVQ 0x48(SP), BX											
  websocket.go:265	0x9810d7		488b4c2450		MOVQ 0x50(SP), CX											
  websocket.go:265	0x9810dc		488b7c2458		MOVQ 0x58(SP), DI											
  websocket.go:265	0x9810e1		e8da000000		CALL github.com/burntcustard/unicorn-mining-co/src/server/network.frameBytes(SB)			
  websocket.go:265	0x9810e6		488b542460		MOVQ 0x60(SP), DX											
  websocket.go:265	0x9810eb		4839d3			CMPQ BX, DX												
  websocket.go:265	0x9810ee		7269			JB 0x981159												
  websocket.go:265	0x9810f0		4829d3			SUBQ DX, BX												
  websocket.go:265	0x9810f3		48895c2420		MOVQ BX, 0x20(SP)											
  websocket.go:265	0x9810f8		4829d1			SUBQ DX, CX												
  websocket.go:265	0x9810fb		4889cf			MOVQ CX, DI												
  websocket.go:265	0x9810fe		48f7d9			NEGQ CX													
  websocket.go:265	0x981101		48c1f93f		SARQ $0x3f, CX												
  websocket.go:265	0x981105		4821ca			ANDQ CX, DX												
  websocket.go:265	0x981108		4801c2			ADDQ AX, DX												
  websocket.go:266	0x98110b		488b742438		MOVQ 0x38(SP), SI											
  websocket.go:266	0x981110		4c8b4620		MOVQ 0x20(SI), R8											
  websocket.go:266	0x981114		488b4628		MOVQ 0x28(SI), AX											
  websocket.go:266	0x981118		498b7050		MOVQ 0x50(R8), SI											
  websocket.go:266	0x98111c		4889d9			MOVQ BX, CX												
  websocket.go:266	0x98111f		4889d3			MOVQ DX, BX												
  websocket.go:266	0x981122		ffd6			CALL SI													
  websocket.go:268	0x981124		4885db			TESTQ BX, BX												
  websocket.go:268	0x981127		750a			JNE 0x981133												
  websocket.go:268	0x981129		488b542420		MOVQ 0x20(SP), DX											
  websocket.go:268	0x98112e		4839d0			CMPQ AX, DX												
  websocket.go:268	0x981131		750c			JNE 0x98113f												
  websocket.go:272	0x981133		4889d8			MOVQ BX, AX												
  websocket.go:272	0x981136		4889cb			MOVQ CX, BX												
  websocket.go:272	0x981139		4883c428		ADDQ $0x28, SP												
  websocket.go:272	0x98113d		5d			POPQ BP													
  websocket.go:272	0x98113e		c3			RET													
  websocket.go:269	0x98113f		488b05aade6600		MOVQ io.ErrShortWrite(SB), AX										
  websocket.go:269	0x981146		488b1dabde6600		MOVQ io.ErrShortWrite+8(SB), BX										
  websocket.go:269	0x98114d		4883c428		ADDQ $0x28, SP												
  websocket.go:269	0x981151		5d			POPQ BP													
  websocket.go:269	0x981152		c3			RET													
  websocket.go:262	0x981153		4883c428		ADDQ $0x28, SP												
  websocket.go:262	0x981157		5d			POPQ BP													
  websocket.go:262	0x981158		c3			RET													
  websocket.go:265	0x981159		e8e213b1ff		CALL runtime.panicBounds(SB)										
  websocket.go:265	0x98115e		90			NOPL													
  websocket.go:260	0x98115f		4889442408		MOVQ AX, 0x8(SP)											
  websocket.go:260	0x981164		885c2410		MOVB BL, 0x10(SP)											
  websocket.go:260	0x981168		48894c2418		MOVQ CX, 0x18(SP)											
  websocket.go:260	0x98116d		48897c2420		MOVQ DI, 0x20(SP)											
  websocket.go:260	0x981172		4889742428		MOVQ SI, 0x28(SP)											
  websocket.go:260	0x981177		4c89442430		MOVQ R8, 0x30(SP)											
  websocket.go:260	0x98117c		0f1f4000		NOPL 0(AX)												
  websocket.go:260	0x981180		e87bf7b0ff		CALL runtime.morestack_noctxt.abi0(SB)									
  websocket.go:260	0x981185		488b442408		MOVQ 0x8(SP), AX											
  websocket.go:260	0x98118a		0fb65c2410		MOVZX 0x10(SP), BX											
  websocket.go:260	0x98118f		488b4c2418		MOVQ 0x18(SP), CX											
  websocket.go:260	0x981194		488b7c2420		MOVQ 0x20(SP), DI											
  websocket.go:260	0x981199		488b742428		MOVQ 0x28(SP), SI											
  websocket.go:260	0x98119e		4c8b442430		MOVQ 0x30(SP), R8											
  websocket.go:260	0x9811a3		e9b8feffff		JMP github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).writePartialFrame(SB)	

TEXT github.com/burntcustard/unicorn-mining-co/src/server/network.newDirectSender.func1(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/network/websocket-direct_linux.go
  websocket-direct_linux.go:34	0x98bc00		493b6610		CMPQ SP, 0x10(R14)										
  websocket-direct_linux.go:34	0x98bc04		0f86c6000000		JBE 0x98bcd0											
  websocket-direct_linux.go:34	0x98bc0a		55			PUSHQ BP											
  websocket-direct_linux.go:34	0x98bc0b		4889e5			MOVQ SP, BP											
  websocket-direct_linux.go:34	0x98bc0e		4883ec60		SUBQ $0x60, SP											
  websocket-direct_linux.go:34	0x98bc12		488b5208		MOVQ 0x8(DX), DX										
  websocket-direct_linux.go:34	0x98bc16		4889542438		MOVQ DX, 0x38(SP)										
  websocket-direct_linux.go:35	0x98bc1b		488b4a18		MOVQ 0x18(DX), CX										
  websocket-direct_linux.go:35	0x98bc1f		48894c2440		MOVQ CX, 0x40(SP)										
  websocket-direct_linux.go:35	0x98bc24		488b7a20		MOVQ 0x20(DX), DI										
  websocket-direct_linux.go:35	0x98bc28		4889c3			MOVQ AX, BX											
  websocket-direct_linux.go:35	0x98bc2b		be40400000		MOVL $0x4040, SI										
  websocket-direct_linux.go:35	0x98bc30		4531c0			XORL R8, R8											
  websocket-direct_linux.go:35	0x98bc33		4589c1			MOVL R8, R9											
  websocket-direct_linux.go:35	0x98bc36		b82c000000		MOVL $0x2c, AX											
  websocket-direct_linux.go:35	0x98bc3b		0f1f440000		NOPL 0(AX)(AX*1)										
  websocket-direct_linux.go:35	0x98bc40		e89b81b2ff		CALL syscall.RawSyscall6(SB)									
  websocket-direct_linux.go:36	0x98bc45		488b542438		MOVQ 0x38(SP), DX										
  websocket-direct_linux.go:36	0x98bc4a		4c8b5218		MOVQ 0x18(DX), R10										
  websocket-direct_linux.go:36	0x98bc4e		4c8b5a20		MOVQ 0x20(DX), R11										
  websocket-direct_linux.go:36	0x98bc52		4c8b6228		MOVQ 0x28(DX), R12										
  websocket-direct_linux.go:36	0x98bc56		4c89542448		MOVQ R10, 0x48(SP)										
  websocket-direct_linux.go:36	0x98bc5b		4c895c2450		MOVQ R11, 0x50(SP)										
  websocket-direct_linux.go:36	0x98bc60		4c89642458		MOVQ R12, 0x58(SP)										
  websocket-direct_linux.go:37	0x98bc65		48894230		MOVQ AX, 0x30(DX)										
  websocket-direct_linux.go:37	0x98bc69		48c7423800000000	MOVQ $0x0, 0x38(DX)										
  websocket-direct_linux.go:37	0x98bc71		833dd896690000		CMPL runtime.writeBarrier(SB), $0x0								
  websocket-direct_linux.go:37	0x98bc78		740e			JE 0x98bc88											
  websocket-direct_linux.go:37	0x98bc7a		488b5a40		MOVQ 0x40(DX), BX										
  websocket-direct_linux.go:37	0x98bc7e		6690			NOPW												
  websocket-direct_linux.go:37	0x98bc80		e8fb64b0ff		CALL runtime.gcWriteBarrier1(SB)								
  websocket-direct_linux.go:37	0x98bc85		49891b			MOVQ BX, 0(R11)											
  websocket-direct_linux.go:37	0x98bc88		48c7424000000000	MOVQ $0x0, 0x40(DX)										
  websocket-direct_linux.go:39	0x98bc90		4885c9			TESTQ CX, CX											
  websocket-direct_linux.go:39	0x98bc93		7435			JE 0x98bcca											
  websocket-direct_linux.go:40	0x98bc95		4889c8			MOVQ CX, AX											
  websocket-direct_linux.go:40	0x98bc98		e843bbafff		CALL runtime.convT64(SB)									
  websocket-direct_linux.go:40	0x98bc9d		488d0decaf5f00		LEAQ 0x5fafec(IP), CX										
  websocket-direct_linux.go:40	0x98bca4		488b542438		MOVQ 0x38(SP), DX										
  websocket-direct_linux.go:40	0x98bca9		48894a38		MOVQ CX, 0x38(DX)										
  websocket-direct_linux.go:40	0x98bcad		833d9c96690000		CMPL runtime.writeBarrier(SB), $0x0								
  websocket-direct_linux.go:40	0x98bcb4		7410			JE 0x98bcc6											
  websocket-direct_linux.go:40	0x98bcb6		488b4a40		MOVQ 0x40(DX), CX										
  websocket-direct_linux.go:40	0x98bcba		e8e164b0ff		CALL runtime.gcWriteBarrier2(SB)								
  websocket-direct_linux.go:40	0x98bcbf		498903			MOVQ AX, 0(R11)											
  websocket-direct_linux.go:40	0x98bcc2		49894b08		MOVQ CX, 0x8(R11)										
  websocket-direct_linux.go:40	0x98bcc6		48894240		MOVQ AX, 0x40(DX)										
  websocket-direct_linux.go:42	0x98bcca		4883c460		ADDQ $0x60, SP											
  websocket-direct_linux.go:42	0x98bcce		5d			POPQ BP												
  websocket-direct_linux.go:42	0x98bccf		c3			RET												
  websocket-direct_linux.go:34	0x98bcd0		4889442408		MOVQ AX, 0x8(SP)										
  websocket-direct_linux.go:34	0x98bcd5		e8864bb0ff		CALL runtime.morestack.abi0(SB)									
  websocket-direct_linux.go:34	0x98bcda		488b442408		MOVQ 0x8(SP), AX										
  websocket-direct_linux.go:34	0x98bcdf		90			NOPL												
  websocket-direct_linux.go:34	0x98bce0		e91bffffff		JMP github.com/burntcustard/unicorn-mining-co/src/server/network.newDirectSender.func1(SB)	

TEXT github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).enqueue.deferwrap1(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/network/websocket.go
  websocket.go:142	0x98bde0		493b6610		CMPQ SP, 0x10(R14)											
  websocket.go:142	0x98bde4		7625			JBE 0x98be0b												
  websocket.go:142	0x98bde6		55			PUSHQ BP												
  websocket.go:142	0x98bde7		4889e5			MOVQ SP, BP												
  websocket.go:142	0x98bdea		4883ec10		SUBQ $0x10, SP												
  websocket.go:142	0x98bdee		488b4208		MOVQ 0x8(DX), AX											
  mutex.go:65		0x98bdf2		bbffffffff		MOVL $-0x1, BX												
  mutex.go:65		0x98bdf7		f00fc118		LOCK XADDL BX, 0(AX)											
  mutex.go:194		0x98bdfb		ffcb			DECL BX													
  mutex.go:195		0x98bdfd		7406			JE 0x98be05												
  mutex.go:198		0x98bdff		90			NOPL													
  mutex.go:198		0x98be00		e8bba8b0ff		CALL internal/sync.(*Mutex).unlockSlow(SB)								
  websocket.go:142	0x98be05		4883c410		ADDQ $0x10, SP												
  websocket.go:142	0x98be09		5d			POPQ BP													
  websocket.go:142	0x98be0a		c3			RET													
  websocket.go:142	0x98be0b		e8504ab0ff		CALL runtime.morestack.abi0(SB)										
  websocket.go:142	0x98be10		ebce			JMP github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).enqueue.deferwrap1(SB)	
