TEXT internal/runtime/syscall/linux.Syscall6(SB) /usr/local/go/src/internal/runtime/syscall/linux/asm_linux_amd64.s
  asm_linux_amd64.s:30	0x411020		4989f2			MOVQ SI, R10		
  asm_linux_amd64.s:31	0x411023		4889fa			MOVQ DI, DX		
  asm_linux_amd64.s:32	0x411026		4889ce			MOVQ CX, SI		
  asm_linux_amd64.s:33	0x411029		4889df			MOVQ BX, DI		
  asm_linux_amd64.s:35	0x41102c		0f05			SYSCALL			
  asm_linux_amd64.s:36	0x41102e		483d01f0ffff		CMPQ AX, $-0xfff	
  asm_linux_amd64.s:37	0x411034		7613			JBE 0x411049		
  asm_linux_amd64.s:38	0x411036		48f7d8			NEGQ AX			
  asm_linux_amd64.s:39	0x411039		4889c1			MOVQ AX, CX		
  asm_linux_amd64.s:40	0x41103c		48c7c0ffffffff		MOVQ $-0x1, AX		
  asm_linux_amd64.s:41	0x411043		bb00000000		MOVL $0x0, BX		
  asm_linux_amd64.s:42	0x411048		c3			RET			
  asm_linux_amd64.s:45	0x411049		4889d3			MOVQ DX, BX		
  asm_linux_amd64.s:46	0x41104c		b900000000		MOVL $0x0, CX		
  asm_linux_amd64.s:47	0x411051		c3			RET			

TEXT syscall.RawSyscall6(SB) /usr/local/go/src/syscall/syscall_linux.go
  syscall_linux.go:63	0x4b3de0		55			PUSHQ BP						
  syscall_linux.go:63	0x4b3de1		4889e5			MOVQ SP, BP						
  syscall_linux.go:63	0x4b3de4		4883ec38		SUBQ $0x38, SP						
  syscall_linux.go:65	0x4b3de8		e833d2f5ff		CALL internal/runtime/syscall/linux.Syscall6(SB)	
  syscall_linux.go:67	0x4b3ded		4883c438		ADDQ $0x38, SP						
  syscall_linux.go:67	0x4b3df1		5d			POPQ BP							
  syscall_linux.go:67	0x4b3df2		c3			RET							

TEXT syscall.Syscall(SB) /usr/local/go/src/syscall/syscall_linux.go
  syscall_linux.go:73	0x4b3e00		55			PUSHQ BP			
  syscall_linux.go:73	0x4b3e01		4889e5			MOVQ SP, BP			
  syscall_linux.go:73	0x4b3e04		4883ec50		SUBQ $0x50, SP			
  syscall_linux.go:89	0x4b3e08		4889442460		MOVQ AX, 0x60(SP)		
  syscall_linux.go:89	0x4b3e0d		48895c2468		MOVQ BX, 0x68(SP)		
  syscall_linux.go:89	0x4b3e12		48894c2470		MOVQ CX, 0x70(SP)		
  syscall_linux.go:89	0x4b3e17		48897c2478		MOVQ DI, 0x78(SP)		
  syscall_linux.go:74	0x4b3e1c		0f1f4000		NOPL 0(AX)			
  syscall_linux.go:74	0x4b3e20		e8db76fdff		CALL runtime.entersyscall(SB)	
  syscall_linux.go:87	0x4b3e25		488b442460		MOVQ 0x60(SP), AX		
  syscall_linux.go:87	0x4b3e2a		488b5c2468		MOVQ 0x68(SP), BX		
  syscall_linux.go:87	0x4b3e2f		488b4c2470		MOVQ 0x70(SP), CX		
  syscall_linux.go:87	0x4b3e34		488b7c2478		MOVQ 0x78(SP), DI		
  syscall_linux.go:87	0x4b3e39		31f6			XORL SI, SI			
  syscall_linux.go:87	0x4b3e3b		4189f0			MOVL SI, R8			
  syscall_linux.go:87	0x4b3e3e		4189f1			MOVL SI, R9			
  syscall_linux.go:87	0x4b3e41		e89affffff		CALL syscall.RawSyscall6(SB)	
  syscall_linux.go:87	0x4b3e46		4889442448		MOVQ AX, 0x48(SP)		
  syscall_linux.go:87	0x4b3e4b		48895c2440		MOVQ BX, 0x40(SP)		
  syscall_linux.go:87	0x4b3e50		48894c2438		MOVQ CX, 0x38(SP)		
  syscall_linux.go:88	0x4b3e55		e88679fdff		CALL runtime.exitsyscall(SB)	
  syscall_linux.go:89	0x4b3e5a		488b442448		MOVQ 0x48(SP), AX		
  syscall_linux.go:89	0x4b3e5f		488b5c2440		MOVQ 0x40(SP), BX		
  syscall_linux.go:89	0x4b3e64		488b4c2438		MOVQ 0x38(SP), CX		
  syscall_linux.go:89	0x4b3e69		4883c450		ADDQ $0x50, SP			
  syscall_linux.go:89	0x4b3e6d		5d			POPQ BP				
  syscall_linux.go:89	0x4b3e6e		c3			RET				

TEXT syscall.Syscall6(SB) /usr/local/go/src/syscall/syscall_linux.go
  syscall_linux.go:95	0x4b3e80		55			PUSHQ BP			
  syscall_linux.go:95	0x4b3e81		4889e5			MOVQ SP, BP			
  syscall_linux.go:95	0x4b3e84		4883ec50		SUBQ $0x50, SP			
  syscall_linux.go:99	0x4b3e88		4889442460		MOVQ AX, 0x60(SP)		
  syscall_linux.go:99	0x4b3e8d		48895c2468		MOVQ BX, 0x68(SP)		
  syscall_linux.go:99	0x4b3e92		48894c2470		MOVQ CX, 0x70(SP)		
  syscall_linux.go:99	0x4b3e97		48897c2478		MOVQ DI, 0x78(SP)		
  syscall_linux.go:99	0x4b3e9c		4889b42480000000	MOVQ SI, 0x80(SP)		
  syscall_linux.go:99	0x4b3ea4		4c89842488000000	MOVQ R8, 0x88(SP)		
  syscall_linux.go:99	0x4b3eac		4c898c2490000000	MOVQ R9, 0x90(SP)		
  syscall_linux.go:96	0x4b3eb4		e84776fdff		CALL runtime.entersyscall(SB)	
  syscall_linux.go:97	0x4b3eb9		488b442460		MOVQ 0x60(SP), AX		
  syscall_linux.go:97	0x4b3ebe		488b5c2468		MOVQ 0x68(SP), BX		
  syscall_linux.go:97	0x4b3ec3		488b4c2470		MOVQ 0x70(SP), CX		
  syscall_linux.go:97	0x4b3ec8		488b7c2478		MOVQ 0x78(SP), DI		
  syscall_linux.go:97	0x4b3ecd		488bb42480000000	MOVQ 0x80(SP), SI		
  syscall_linux.go:97	0x4b3ed5		4c8b842488000000	MOVQ 0x88(SP), R8		
  syscall_linux.go:97	0x4b3edd		4c8b8c2490000000	MOVQ 0x90(SP), R9		
  syscall_linux.go:97	0x4b3ee5		e8f6feffff		CALL syscall.RawSyscall6(SB)	
  syscall_linux.go:97	0x4b3eea		4889442448		MOVQ AX, 0x48(SP)		
  syscall_linux.go:97	0x4b3eef		48895c2440		MOVQ BX, 0x40(SP)		
  syscall_linux.go:97	0x4b3ef4		48894c2438		MOVQ CX, 0x38(SP)		
  syscall_linux.go:98	0x4b3ef9		e8e278fdff		CALL runtime.exitsyscall(SB)	
  syscall_linux.go:99	0x4b3efe		488b442448		MOVQ 0x48(SP), AX		
  syscall_linux.go:99	0x4b3f03		488b5c2440		MOVQ 0x40(SP), BX		
  syscall_linux.go:99	0x4b3f08		488b4c2438		MOVQ 0x38(SP), CX		
  syscall_linux.go:99	0x4b3f0d		4883c450		ADDQ $0x50, SP			
  syscall_linux.go:99	0x4b3f11		5d			POPQ BP				
  syscall_linux.go:99	0x4b3f12		c3			RET				

TEXT internal/poll.(*FD).Write(SB) /usr/local/go/src/internal/poll/fd_unix.go
  fd_unix.go:365		0x4ee280		4c8d6424a0		LEAQ -0x60(SP), R12					
  fd_unix.go:365		0x4ee285		4d3b6610		CMPQ R12, 0x10(R14)					
  fd_unix.go:365		0x4ee289		0f86f4040000		JBE 0x4ee783						
  fd_unix.go:365		0x4ee28f		55			PUSHQ BP						
  fd_unix.go:365		0x4ee290		4889e5			MOVQ SP, BP						
  fd_unix.go:365		0x4ee293		4881ecd8000000		SUBQ $0xd8, SP						
  fd_unix.go:365		0x4ee29a		66440fd6bc24d0000000	MOVQ X15, 0xd0(SP)					
  fd_mutex.go:250		0x4ee2a4		48898424e8000000	MOVQ AX, 0xe8(SP)					
  fd_mutex.go:250		0x4ee2ac		4889bc2400010000	MOVQ DI, 0x100(SP)					
  fd_mutex.go:250		0x4ee2b4		48898c24f8000000	MOVQ CX, 0xf8(SP)					
  fd_mutex.go:250		0x4ee2bc		48899c24f0000000	MOVQ BX, 0xf0(SP)					
  fd_unix.go:365		0x4ee2c4		c644244f00		MOVB $0x0, 0x4f(SP)					
  fd_unix.go:365		0x4ee2c9		48c744245800000000	MOVQ $0x0, 0x58(SP)					
  fd_unix.go:365		0x4ee2d2		440f11bc2490000000	MOVUPS X15, 0x90(SP)					
  fd_mutex.go:250		0x4ee2db		8400			TESTB AL, 0(AX)						
  fd_mutex.go:250		0x4ee2dd		31db			XORL BX, BX						
  fd_mutex.go:250		0x4ee2df		b901000000		MOVL $0x1, CX						
  fd_mutex.go:250		0x4ee2e4		e857ecffff		CALL internal/poll.(*fdMutex).rwlock(SB)		
  fd_mutex.go:250		0x4ee2e9		84c0			TESTL AL, AL						
  fd_mutex.go:250		0x4ee2eb		740e			JE 0x4ee2fb						
  fd_unix.go:369		0x4ee2ed		488b8424e8000000	MOVQ 0xe8(SP), AX					
  fd_unix.go:369		0x4ee2f5		31db			XORL BX, BX						
  fd_unix.go:369		0x4ee2f7		31c9			XORL CX, CX						
  fd_unix.go:366		0x4ee2f9		eb2c			JMP 0x4ee327						
  fd_mutex.go:251		0x4ee2fb		488b8424e8000000	MOVQ 0xe8(SP), AX					
  fd_mutex.go:251		0x4ee303		80783200		CMPB 0x32(AX), $0x0					
  fd.go:43			0x4ee307		7410			JE 0x4ee319						
  fd_mutex.go:251		0x4ee309		488b1d80f5af00		MOVQ internal/poll.ErrFileClosing(SB), BX		
  fd_mutex.go:251		0x4ee310		488b0d81f5af00		MOVQ internal/poll.ErrFileClosing+8(SB), CX		
  fd_mutex.go:251		0x4ee317		eb0e			JMP 0x4ee327						
  fd_mutex.go:251		0x4ee319		488d1df867a900		LEAQ 0xa967f8(IP), BX					
  fd_mutex.go:251		0x4ee320		488d0d3944b300		LEAQ 0xb34439(IP), CX					
  fd_unix.go:366		0x4ee327		4885db			TESTQ BX, BX						
  fd_unix.go:366		0x4ee32a		0f859b000000		JNE 0x4ee3cb						
  fd_unix.go:369		0x4ee330		488d1549270000		LEAQ internal/poll.(*FD).Write.deferwrap1(SB), DX	
  fd_unix.go:369		0x4ee337		48899424c0000000	MOVQ DX, 0xc0(SP)					
  fd_unix.go:369		0x4ee33f		48898424c8000000	MOVQ AX, 0xc8(SP)					
  fd_unix.go:369		0x4ee347		488d9424c0000000	LEAQ 0xc0(SP), DX					
  fd_unix.go:369		0x4ee34f		48899424d0000000	MOVQ DX, 0xd0(SP)					
  fd_unix.go:369		0x4ee357		c644244f01		MOVB $0x1, 0x4f(SP)					
  fd_unix.go:370		0x4ee35c		488d5020		LEAQ 0x20(AX), DX					
  fd_unix.go:370		0x4ee360		48899424a8000000	MOVQ DX, 0xa8(SP)					
  fd_unix.go:370		0x4ee368		0fb64832		MOVZX 0x32(AX), CX					
  fd_poll_runtime.go:77		0x4ee36c		4889d0			MOVQ DX, AX						
  fd_poll_runtime.go:77		0x4ee36f		bb77000000		MOVL $0x77, BX						
  fd_poll_runtime.go:77		0x4ee374		e887f0ffff		CALL internal/poll.(*pollDesc).prepare(SB)		
  fd_unix.go:370		0x4ee379		4885c0			TESTQ AX, AX						
  fd_unix.go:370		0x4ee37c		7504			JNE 0x4ee382						
  fd_unix.go:370		0x4ee37e		31c0			XORL AX, AX						
  fd_unix.go:370		0x4ee380		eb73			JMP 0x4ee3f5						
  fd_unix.go:371		0x4ee382		48c744245800000000	MOVQ $0x0, 0x58(SP)					
  fd_unix.go:371		0x4ee38b		4889842490000000	MOVQ AX, 0x90(SP)					
  fd_unix.go:371		0x4ee393		48899c2498000000	MOVQ BX, 0x98(SP)					
  fd_unix.go:371		0x4ee39b		c644244f00		MOVB $0x0, 0x4f(SP)					
  fd_unix.go:371		0x4ee3a0		488b9424d0000000	MOVQ 0xd0(SP), DX					
  fd_unix.go:371		0x4ee3a8		488b02			MOVQ 0(DX), AX						
  fd_unix.go:371		0x4ee3ab		ffd0			CALL AX							
  fd_unix.go:371		0x4ee3ad		488b442458		MOVQ 0x58(SP), AX					
  fd_unix.go:371		0x4ee3b2		488b9c2490000000	MOVQ 0x90(SP), BX					
  fd_unix.go:371		0x4ee3ba		488b8c2498000000	MOVQ 0x98(SP), CX					
  fd_unix.go:371		0x4ee3c2		4881c4d8000000		ADDQ $0xd8, SP						
  fd_unix.go:371		0x4ee3c9		5d			POPQ BP							
  fd_unix.go:371		0x4ee3ca		c3			RET							
  fd_unix.go:367		0x4ee3cb		48c744245800000000	MOVQ $0x0, 0x58(SP)					
  fd_unix.go:367		0x4ee3d4		48899c2490000000	MOVQ BX, 0x90(SP)					
  fd_unix.go:367		0x4ee3dc		48898c2498000000	MOVQ CX, 0x98(SP)					
  fd_unix.go:367		0x4ee3e4		488b442458		MOVQ 0x58(SP), AX					
  fd_unix.go:367		0x4ee3e9		4881c4d8000000		ADDQ $0xd8, SP						
  fd_unix.go:367		0x4ee3f0		5d			POPQ BP							
  fd_unix.go:367		0x4ee3f1		c3			RET							
  fd_unix.go:367		0x4ee3f2		4889f0			MOVQ SI, AX						
  fd_unix.go:376		0x4ee3f5		488b9424e8000000	MOVQ 0xe8(SP), DX					
  fd_unix.go:376		0x4ee3fd		807a3000		CMPB 0x30(DX), $0x0					
  fd_unix.go:376		0x4ee401		7420			JE 0x4ee423						
  fd_unix.go:376		0x4ee403		488b8c24f8000000	MOVQ 0xf8(SP), CX					
  fd_unix.go:376		0x4ee40b		4889ce			MOVQ CX, SI						
  fd_unix.go:376		0x4ee40e		4829c6			SUBQ AX, SI						
  fd_unix.go:376		0x4ee411		4881fe00000040		CMPQ SI, $0x40000000					
  fd_unix.go:376		0x4ee418		7e11			JLE 0x4ee42b						
  fd_unix.go:377		0x4ee41a		488db000000040		LEAQ 0x40000000(AX), SI					
  fd_unix.go:377		0x4ee421		eb0b			JMP 0x4ee42e						
  fd_unix.go:379		0x4ee423		488b8c24f8000000	MOVQ 0xf8(SP), CX					
  fd_unix.go:379		0x4ee42b		4889ce			MOVQ CX, SI						
  fd_unix.go:379		0x4ee42e		488bbc2400010000	MOVQ 0x100(SP), DI					
  fd_unix.go:379		0x4ee436		4839f7			CMPQ DI, SI						
  fd_unix.go:379		0x4ee439		0f821a030000		JB 0x4ee759						
  fd_unix.go:379		0x4ee43f		90			NOPL							
  fd_unix.go:379		0x4ee440		4839c6			CMPQ SI, AX						
  fd_unix.go:379		0x4ee443		0f820b030000		JB 0x4ee754						
  fd_unix.go:379		0x4ee449		4889442470		MOVQ AX, 0x70(SP)					
  fd_unix.go:379		0x4ee44e		4989f8			MOVQ DI, R8						
  fd_unix.go:379		0x4ee451		4929c0			SUBQ AX, R8						
  fd_unix.go:379		0x4ee454		4c89442468		MOVQ R8, 0x68(SP)					
  fd_unix.go:379		0x4ee459		4d89c1			MOVQ R8, R9						
  fd_unix.go:379		0x4ee45c		49f7d8			NEGQ R8							
  fd_unix.go:379		0x4ee45f		49c1f83f		SARQ $0x3f, R8						
  fd_unix.go:379		0x4ee463		4921c0			ANDQ AX, R8						
  fd_unix.go:379		0x4ee466		4c8b5210		MOVQ 0x10(DX), R10					
  fd_unix.go:379		0x4ee46a		4c89942480000000	MOVQ R10, 0x80(SP)					
  fd_unix.go:379		0x4ee472		4829c6			SUBQ AX, SI						
  fd_unix.go:379		0x4ee475		4889742460		MOVQ SI, 0x60(SP)					
  fd_unix.go:379		0x4ee47a		4c8b9c24f0000000	MOVQ 0xf0(SP), R11					
  fd_unix.go:379		0x4ee482		4b8d1c03		LEAQ 0(R11)(R8*1), BX					
  fd_unix.go:379		0x4ee486		48899c24b0000000	MOVQ BX, 0xb0(SP)					
  fd_unix.go:742		0x4ee48e		eb1a			JMP 0x4ee4aa						
  syscall_unix.go:211		0x4ee490		488b9c24b0000000	MOVQ 0xb0(SP), BX					
  syscall_unix.go:211		0x4ee498		488b742460		MOVQ 0x60(SP), SI					
  syscall_unix.go:211		0x4ee49d		4c8b4c2468		MOVQ 0x68(SP), R9					
  syscall_unix.go:211		0x4ee4a2		4c8b942480000000	MOVQ 0x80(SP), R10					
  fd_unix.go:743		0x4ee4aa		90			NOPL							
  syscall_unix.go:211		0x4ee4ab		4c89d0			MOVQ R10, AX						
  syscall_unix.go:211		0x4ee4ae		4889f1			MOVQ SI, CX						
  syscall_unix.go:211		0x4ee4b1		4c89cf			MOVQ R9, DI						
  syscall_unix.go:211		0x4ee4b4		e88742fcff		CALL syscall.write(SB)					
  syscall_unix.go:211		0x4ee4b9		48899c2488000000	MOVQ BX, 0x88(SP)					
  syscall_unix.go:211		0x4ee4c1		4889442478		MOVQ AX, 0x78(SP)					
  syscall_unix.go:211		0x4ee4c6		48898c24b8000000	MOVQ CX, 0xb8(SP)					
  fd_unix.go:744		0x4ee4ce		488d158364a900		LEAQ 0xa96483(IP), DX					
  fd_unix.go:744		0x4ee4d5		4839d3			CMPQ BX, DX						
  fd_unix.go:744		0x4ee4d8		752f			JNE 0x4ee509						
  fd_unix.go:744		0x4ee4da		4889d0			MOVQ DX, AX						
  fd_unix.go:744		0x4ee4dd		488d1db4ec5400		LEAQ 0x54ecb4(IP), BX					
  fd_unix.go:744		0x4ee4e4		e8d785f2ff		CALL runtime.ifaceeq(SB)				
  fd_unix.go:744		0x4ee4e9		84c0			TESTL AL, AL						
  fd_unix.go:744		0x4ee4eb		75a3			JNE 0x4ee490						
  fd_unix.go:380		0x4ee4ed		488b442478		MOVQ 0x78(SP), AX					
  fd_unix.go:399		0x4ee4f2		488b8c24b8000000	MOVQ 0xb8(SP), CX					
  fd_unix.go:399		0x4ee4fa		488d155764a900		LEAQ 0xa96457(IP), DX					
  fd_unix.go:744		0x4ee501		488b9c2488000000	MOVQ 0x88(SP), BX					
  fd_unix.go:380		0x4ee509		4885c0			TESTQ AX, AX						
  fd_unix.go:380		0x4ee50c		7e18			JLE 0x4ee526						
  fd_unix.go:381		0x4ee50e		488b742460		MOVQ 0x60(SP), SI					
  fd_unix.go:381		0x4ee513		4839f0			CMPQ AX, SI						
  fd_unix.go:381		0x4ee516		0f8fca010000		JG 0x4ee6e6						
  fd_unix.go:389		0x4ee51c		488b742470		MOVQ 0x70(SP), SI					
  fd_unix.go:389		0x4ee521		4801c6			ADDQ AX, SI						
  fd_unix.go:389		0x4ee524		eb05			JMP 0x4ee52b						
  fd_unix.go:391		0x4ee526		488b742470		MOVQ 0x70(SP), SI					
  fd_unix.go:391		0x4ee52b		4c8b8424f8000000	MOVQ 0xf8(SP), R8					
  fd_unix.go:391		0x4ee533		4939f0			CMPQ R8, SI						
  fd_unix.go:391		0x4ee536		0f8465010000		JE 0x4ee6a1						
  fd_unix.go:391		0x4ee53c		4889742470		MOVQ SI, 0x70(SP)					
  fd_unix.go:744		0x4ee541		4839d3			CMPQ BX, DX						
  fd_unix.go:394		0x4ee544		7404			JE 0x4ee54a						
  fd_unix.go:394		0x4ee546		31d2			XORL DX, DX						
  fd_unix.go:394		0x4ee548		eb36			JMP 0x4ee580						
  fd_unix.go:394		0x4ee54a		4889d0			MOVQ DX, AX						
  fd_unix.go:394		0x4ee54d		488d1d94ed5400		LEAQ 0x54ed94(IP), BX					
  fd_unix.go:394		0x4ee554		e86785f2ff		CALL runtime.ifaceeq(SB)				
  fd_unix.go:399		0x4ee559		488b8c24b8000000	MOVQ 0xb8(SP), CX					
  fd_unix.go:399		0x4ee561		488b9c2488000000	MOVQ 0x88(SP), BX					
  fd_unix.go:399		0x4ee569		488b742470		MOVQ 0x70(SP), SI					
  fd_unix.go:376		0x4ee56e		4c8b8424f8000000	MOVQ 0xf8(SP), R8					
  fd_unix.go:394		0x4ee576		89c2			MOVL AX, DX						
  fd_unix.go:380		0x4ee578		488b442478		MOVQ 0x78(SP), AX					
  fd_unix.go:380		0x4ee57d		0f1f00			NOPL 0(AX)						
  fd_unix.go:394		0x4ee580		84d2			TESTL DL, DL						
  fd_unix.go:394		0x4ee582		7467			JE 0x4ee5eb						
  fd_poll_runtime.go:104	0x4ee584		4c8b8c24e8000000	MOVQ 0xe8(SP), R9					
  fd_poll_runtime.go:104	0x4ee58c		4983792000		CMPQ 0x20(R9), $0x0					
  fd_unix.go:394		0x4ee591		7460			JE 0x4ee5f3						
  fd_unix.go:395		0x4ee593		410fb64932		MOVZX 0x32(R9), CX					
  fd_poll_runtime.go:93		0x4ee598		488b8424a8000000	MOVQ 0xa8(SP), AX					
  fd_poll_runtime.go:93		0x4ee5a0		bb77000000		MOVL $0x77, BX						
  fd_poll_runtime.go:93		0x4ee5a5		e876efffff		CALL internal/poll.(*pollDesc).wait(SB)			
  fd_unix.go:395		0x4ee5aa		4885c0			TESTQ AX, AX						
  fd_unix.go:395		0x4ee5ad		7422			JE 0x4ee5d1						
  fd_unix.go:395		0x4ee5af		488b742470		MOVQ 0x70(SP), SI					
  fd_unix.go:376		0x4ee5b4		4c8b8424f8000000	MOVQ 0xf8(SP), R8					
  fd_unix.go:376		0x4ee5bc		4c8b8c24e8000000	MOVQ 0xe8(SP), R9					
  fd_unix.go:399		0x4ee5c4		4889d9			MOVQ BX, CX						
  fd_unix.go:399		0x4ee5c7		4889c3			MOVQ AX, BX						
  fd_unix.go:380		0x4ee5ca		488b442478		MOVQ 0x78(SP), AX					
  fd_unix.go:395		0x4ee5cf		eb22			JMP 0x4ee5f3						
  fd_unix.go:395		0x4ee5d1		488b742470		MOVQ 0x70(SP), SI					
  fd_unix.go:376		0x4ee5d6		4c8b8424f8000000	MOVQ 0xf8(SP), R8					
  fd_unix.go:376		0x4ee5de		4c8b8c24e8000000	MOVQ 0xe8(SP), R9					
  fd_unix.go:396		0x4ee5e6		e907feffff		JMP 0x4ee3f2						
  fd_unix.go:376		0x4ee5eb		4c8b8c24e8000000	MOVQ 0xe8(SP), R9					
  fd_unix.go:399		0x4ee5f3		4885db			TESTQ BX, BX						
  fd_unix.go:399		0x4ee5f6		7564			JNE 0x4ee65c						
  fd_unix.go:399		0x4ee5f8		0f1f840000000000	NOPL 0(AX)(AX*1)					
  fd_unix.go:380		0x4ee600		4885c0			TESTQ AX, AX						
  fd_unix.go:402		0x4ee603		0f85e9fdffff		JNE 0x4ee3f2						
  fd_unix.go:403		0x4ee609		488b0520eaaf00		MOVQ io.ErrUnexpectedEOF(SB), AX			
  fd_unix.go:403		0x4ee610		488b0d21eaaf00		MOVQ io.ErrUnexpectedEOF+8(SB), CX			
  fd_unix.go:403		0x4ee617		4889742458		MOVQ SI, 0x58(SP)					
  fd_unix.go:403		0x4ee61c		4889842490000000	MOVQ AX, 0x90(SP)					
  fd_unix.go:403		0x4ee624		48898c2498000000	MOVQ CX, 0x98(SP)					
  fd_unix.go:403		0x4ee62c		c644244f00		MOVB $0x0, 0x4f(SP)					
  fd_unix.go:403		0x4ee631		488b9424d0000000	MOVQ 0xd0(SP), DX					
  fd_unix.go:403		0x4ee639		488b02			MOVQ 0(DX), AX						
  fd_unix.go:403		0x4ee63c		ffd0			CALL AX							
  fd_unix.go:403		0x4ee63e		488b442458		MOVQ 0x58(SP), AX					
  fd_unix.go:403		0x4ee643		488b9c2490000000	MOVQ 0x90(SP), BX					
  fd_unix.go:403		0x4ee64b		488b8c2498000000	MOVQ 0x98(SP), CX					
  fd_unix.go:403		0x4ee653		4881c4d8000000		ADDQ $0xd8, SP						
  fd_unix.go:403		0x4ee65a		5d			POPQ BP							
  fd_unix.go:403		0x4ee65b		c3			RET							
  fd_unix.go:400		0x4ee65c		4889742458		MOVQ SI, 0x58(SP)					
  fd_unix.go:400		0x4ee661		48899c2490000000	MOVQ BX, 0x90(SP)					
  fd_unix.go:400		0x4ee669		48898c2498000000	MOVQ CX, 0x98(SP)					
  fd_unix.go:400		0x4ee671		c644244f00		MOVB $0x0, 0x4f(SP)					
  fd_unix.go:400		0x4ee676		488b9424d0000000	MOVQ 0xd0(SP), DX					
  fd_unix.go:400		0x4ee67e		488b02			MOVQ 0(DX), AX						
  fd_unix.go:400		0x4ee681		ffd0			CALL AX							
  fd_unix.go:400		0x4ee683		488b442458		MOVQ 0x58(SP), AX					
  fd_unix.go:400		0x4ee688		488b9c2490000000	MOVQ 0x90(SP), BX					
  fd_unix.go:400		0x4ee690		488b8c2498000000	MOVQ 0x98(SP), CX					
  fd_unix.go:400		0x4ee698		4881c4d8000000		ADDQ $0xd8, SP						
  fd_unix.go:400		0x4ee69f		5d			POPQ BP							
  fd_unix.go:400		0x4ee6a0		c3			RET							
  fd_unix.go:392		0x4ee6a1		4889742458		MOVQ SI, 0x58(SP)					
  fd_unix.go:392		0x4ee6a6		48899c2490000000	MOVQ BX, 0x90(SP)					
  fd_unix.go:392		0x4ee6ae		48898c2498000000	MOVQ CX, 0x98(SP)					
  fd_unix.go:392		0x4ee6b6		c644244f00		MOVB $0x0, 0x4f(SP)					
  fd_unix.go:392		0x4ee6bb		488b9424d0000000	MOVQ 0xd0(SP), DX					
  fd_unix.go:392		0x4ee6c3		488b02			MOVQ 0(DX), AX						
  fd_unix.go:392		0x4ee6c6		ffd0			CALL AX							
  fd_unix.go:392		0x4ee6c8		488b442458		MOVQ 0x58(SP), AX					
  fd_unix.go:392		0x4ee6cd		488b9c2490000000	MOVQ 0x90(SP), BX					
  fd_unix.go:392		0x4ee6d5		488b8c2498000000	MOVQ 0x98(SP), CX					
  fd_unix.go:392		0x4ee6dd		4881c4d8000000		ADDQ $0xd8, SP						
  fd_unix.go:392		0x4ee6e4		5d			POPQ BP							
  fd_unix.go:392		0x4ee6e5		c3			RET							
  itoa.go:53			0x4ee6e6		bb0a000000		MOVL $0xa, BX						
  itoa.go:53			0x4ee6eb		e83093f1ff		CALL internal/strconv.FormatInt(SB)			
  itoa.go:53			0x4ee6f0		48898424a0000000	MOVQ AX, 0xa0(SP)					
  itoa.go:53			0x4ee6f8		48895c2450		MOVQ BX, 0x50(SP)					
  itoa.go:53			0x4ee6fd		488b442460		MOVQ 0x60(SP), AX					
  itoa.go:53			0x4ee702		bb0a000000		MOVL $0xa, BX						
  itoa.go:53			0x4ee707		e81493f1ff		CALL internal/strconv.FormatInt(SB)			
  fd_unix.go:387		0x4ee70c		b91f000000		MOVL $0x1f, CX						
  fd_unix.go:387		0x4ee711		488bbc24a0000000	MOVQ 0xa0(SP), DI					
  fd_unix.go:387		0x4ee719		488b742450		MOVQ 0x50(SP), SI					
  fd_unix.go:387		0x4ee71e		4c8d057b8d5100		LEAQ 0x518d7b(IP), R8					
  fd_unix.go:387		0x4ee725		41b911000000		MOVL $0x11, R9						
  fd_unix.go:387		0x4ee72b		4989c2			MOVQ AX, R10						
  fd_unix.go:387		0x4ee72e		4989db			MOVQ BX, R11						
  fd_unix.go:387		0x4ee731		31c0			XORL AX, AX						
  fd_unix.go:387		0x4ee733		488d1d18065200		LEAQ 0x520618(IP), BX					
  fd_unix.go:387		0x4ee73a		e8c1edf7ff		CALL runtime.concatstring4(SB)				
  fd_unix.go:387		0x4ee73f		90			NOPL							
  fd_unix.go:387		0x4ee740		e8fb90f9ff		CALL runtime.convTstring(SB)				
  fd_unix.go:387		0x4ee745		4889c3			MOVQ AX, BX						
  fd_unix.go:387		0x4ee748		488d05b9fca200		LEAQ 0xa2fcb9(IP), AX					
  fd_unix.go:387		0x4ee74f		e86cc5f9ff		CALL runtime.gopanic(SB)				
  fd_unix.go:379		0x4ee754		e8e73dfaff		CALL runtime.panicBounds(SB)				
  fd_unix.go:379		0x4ee759		e8e23dfaff		CALL runtime.panicBounds(SB)				
  fd_unix.go:379		0x4ee75e		90			NOPL							
  fd_unix.go:379		0x4ee75f		90			NOPL							
  fd_unix.go:379		0x4ee760		e89b00f6ff		CALL runtime.deferreturn(SB)				
  fd_unix.go:379		0x4ee765		488b442458		MOVQ 0x58(SP), AX					
  fd_unix.go:379		0x4ee76a		488b9c2490000000	MOVQ 0x90(SP), BX					
  fd_unix.go:379		0x4ee772		488b8c2498000000	MOVQ 0x98(SP), CX					
  fd_unix.go:379		0x4ee77a		4881c4d8000000		ADDQ $0xd8, SP						
  fd_unix.go:379		0x4ee781		5d			POPQ BP							
  fd_unix.go:379		0x4ee782		c3			RET							
  fd_unix.go:365		0x4ee783		4889442408		MOVQ AX, 0x8(SP)					
  fd_unix.go:365		0x4ee788		48895c2410		MOVQ BX, 0x10(SP)					
  fd_unix.go:365		0x4ee78d		48894c2418		MOVQ CX, 0x18(SP)					
  fd_unix.go:365		0x4ee792		48897c2420		MOVQ DI, 0x20(SP)					
  fd_unix.go:365		0x4ee797		e86421faff		CALL runtime.morestack_noctxt.abi0(SB)			
  fd_unix.go:365		0x4ee79c		488b442408		MOVQ 0x8(SP), AX					
  fd_unix.go:365		0x4ee7a1		488b5c2410		MOVQ 0x10(SP), BX					
  fd_unix.go:365		0x4ee7a6		488b4c2418		MOVQ 0x18(SP), CX					
  fd_unix.go:365		0x4ee7ab		488b7c2420		MOVQ 0x20(SP), DI					
  fd_unix.go:365		0x4ee7b0		e9cbfaffff		JMP internal/poll.(*FD).Write(SB)			

TEXT github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).enqueue(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/network/websocket.go
  websocket.go:135	0x97fe80		4c8d6424d0			LEAQ -0x30(SP), R12											
  websocket.go:135	0x97fe85		4d3b6610			CMPQ R12, 0x10(R14)											
  websocket.go:135	0x97fe89		0f86df020000			JBE 0x98016e												
  websocket.go:135	0x97fe8f		55				PUSHQ BP												
  websocket.go:135	0x97fe90		4889e5				MOVQ SP, BP												
  websocket.go:135	0x97fe93		4881eca8000000			SUBQ $0xa8, SP												
  websocket.go:137	0x97fe9a		48898424b8000000		MOVQ AX, 0xb8(SP)											
  websocket.go:137	0x97fea2		889c24c0000000			MOVB BL, 0xc0(SP)											
  websocket.go:137	0x97fea9		48898c24c8000000		MOVQ CX, 0xc8(SP)											
  websocket.go:137	0x97feb1		4889bc24d0000000		MOVQ DI, 0xd0(SP)											
  websocket.go:137	0x97feb9		488b5840			MOVQ 0x40(AX), BX											
  websocket.go:137	0x97febd		31c0				XORL AX, AX												
  websocket.go:137	0x97febf		90				NOPL													
  websocket.go:137	0x97fec0		e83b8fa9ff			CALL runtime.selectnbrecv(SB)										
  websocket.go:137	0x97fec5		84c0				TESTL AL, AL												
  websocket.go:137	0x97fec7		0f8584020000			JNE 0x980151												
  type.go:128		0x97fecd		488b8c24d0000000		MOVQ 0xd0(SP), CX											
  type.go:128		0x97fed5		488b8424b8000000		MOVQ 0xb8(SP), AX											
  type.go:128		0x97fedd		4889ca				MOVQ CX, DX												
  type.go:128		0x97fee0		f0480fc14858			LOCK XADDQ CX, 0x58(AX)											
  type.go:128		0x97fee6		4801d1				ADDQ DX, CX												
  websocket.go:142	0x97fee9		4881f900001000			CMPQ CX, $0x100000											
  websocket.go:142	0x97fef0		0f8f36020000			JG 0x98012c												
  websocket.go:151	0x97fef6		488b5838			MOVQ 0x38(AX), BX											
  websocket.go:151	0x97fefa		48c784249000000000000000	MOVQ $0x0, 0x90(SP)											
  websocket.go:151	0x97ff06		440f11bc2498000000		MOVUPS X15, 0x98(SP)											
  websocket.go:151	0x97ff0f		488d842490000000		LEAQ 0x90(SP), AX											
  websocket.go:151	0x97ff17		e8e48ea9ff			CALL runtime.selectnbrecv(SB)										
  websocket.go:151	0x97ff1c		0f1f4000			NOPL 0(AX)												
  websocket.go:151	0x97ff20		84c0				TESTL AL, AL												
  websocket.go:151	0x97ff22		7412				JE 0x97ff36												
  websocket.go:151	0x97ff24		488b942490000000		MOVQ 0x90(SP), DX											
  websocket.go:151	0x97ff2c		4c8b8c24a0000000		MOVQ 0xa0(SP), R9											
  websocket.go:151	0x97ff34		eb05				JMP 0x97ff3b												
  websocket.go:151	0x97ff36		4531c9				XORL R9, R9												
  websocket.go:151	0x97ff39		31d2				XORL DX, DX												
  websocket.go:155	0x97ff3b		488b8c24d0000000		MOVQ 0xd0(SP), CX											
  websocket.go:155	0x97ff43		488d590a			LEAQ 0xa(CX), BX											
  websocket.go:155	0x97ff47		48895c2438			MOVQ BX, 0x38(SP)											
  websocket.go:157	0x97ff4c		4939d9				CMPQ R9, BX												
  websocket.go:157	0x97ff4f		7c07				JL 0x97ff58												
  websocket.go:160	0x97ff51		7327				JAE 0x97ff7a												
  websocket.go:160	0x97ff53		e910020000			JMP 0x980168												
  websocket.go:158	0x97ff58		488d0529e55900			LEAQ 0x59e529(IP), AX											
  websocket.go:158	0x97ff5f		4889d9				MOVQ BX, CX												
  websocket.go:158	0x97ff62		e819d5b0ff			CALL runtime.makeslice(SB)										
  websocket.go:163	0x97ff67		488b8c24d0000000		MOVQ 0xd0(SP), CX											
  websocket.go:166	0x97ff6f		488b5c2438			MOVQ 0x38(SP), BX											
  websocket.go:163	0x97ff74		4989d9				MOVQ BX, R9												
  websocket.go:163	0x97ff77		4889c2				MOVQ AX, DX												
  websocket.go:163	0x97ff7a		4c894c2440			MOVQ R9, 0x40(SP)											
  websocket.go:163	0x97ff7f		4889542448			MOVQ DX, 0x48(SP)											
  websocket.go:163	0x97ff84		4d8d51f6			LEAQ -0xa(R9), R10											
  websocket.go:163	0x97ff88		4d89d3				MOVQ R10, R11												
  websocket.go:163	0x97ff8b		49f7da				NEGQ R10												
  websocket.go:163	0x97ff8e		49c1fa3f			SARQ $0x3f, R10												
  websocket.go:163	0x97ff92		4183e20a			ANDL $0xa, R10												
  websocket.go:163	0x97ff96		4a8d0412			LEAQ 0(DX)(R10*1), AX											
  websocket.go:163	0x97ff9a		4889842490000000		MOVQ AX, 0x90(SP)											
  websocket.go:163	0x97ffa2		48898c2498000000		MOVQ CX, 0x98(SP)											
  websocket.go:163	0x97ffaa		4c899c24a0000000		MOVQ R11, 0xa0(SP)											
  websocket.go:163	0x97ffb2		4c8b9424c8000000		MOVQ 0xc8(SP), R10											
  websocket.go:163	0x97ffba		4939c2				CMPQ R10, AX												
  websocket.go:163	0x97ffbd		7417				JE 0x97ffd6												
  websocket.go:163	0x97ffbf		4c89d3				MOVQ R10, BX												
  websocket.go:163	0x97ffc2		e81929b1ff			CALL runtime.memmove(SB)										
  websocket.go:166	0x97ffc7		488b542448			MOVQ 0x48(SP), DX											
  websocket.go:166	0x97ffcc		488b5c2438			MOVQ 0x38(SP), BX											
  websocket.go:166	0x97ffd1		4c8b4c2440			MOVQ 0x40(SP), R9											
  websocket.go:166	0x97ffd6		4c8b9424b8000000		MOVQ 0xb8(SP), R10											
  websocket.go:166	0x97ffde		4d8b5a30			MOVQ 0x30(R10), R11											
  websocket.go:166	0x97ffe2		440fb6a424c0000000		MOVZX 0xc0(SP), R12											
  websocket.go:166	0x97ffeb		4488642470			MOVB R12, 0x70(SP)											
  websocket.go:166	0x97fff0		4889542478			MOVQ DX, 0x78(SP)											
  websocket.go:166	0x97fff5		48899c2480000000		MOVQ BX, 0x80(SP)											
  websocket.go:166	0x97fffd		4c898c2488000000		MOVQ R9, 0x88(SP)											
  websocket.go:168	0x980005		498b5240			MOVQ 0x40(R10), DX											
  websocket.go:165	0x980009		4c8d4c2450			LEAQ 0x50(SP), R9											
  websocket.go:165	0x98000e		450f1139			MOVUPS X15, 0(R9)											
  websocket.go:165	0x980012		450f117910			MOVUPS X15, 0x10(R9)											
  websocket.go:166	0x980017		4c895c2450			MOVQ R11, 0x50(SP)											
  websocket.go:166	0x98001c		4c8d4c2470			LEAQ 0x70(SP), R9											
  websocket.go:166	0x980021		4c894c2458			MOVQ R9, 0x58(SP)											
  websocket.go:168	0x980026		4889542460			MOVQ DX, 0x60(SP)											
  websocket.go:165	0x98002b		488d442450			LEAQ 0x50(SP), AX											
  websocket.go:165	0x980030		488d5c2430			LEAQ 0x30(SP), BX											
  websocket.go:165	0x980035		31c9				XORL CX, CX												
  websocket.go:165	0x980037		bf01000000			MOVL $0x1, DI												
  websocket.go:165	0x98003c		89fe				MOVL DI, SI												
  websocket.go:165	0x98003e		4531c0				XORL R8, R8												
  websocket.go:165	0x980041		e8ba45aeff			CALL runtime.selectgo(SB)										
  websocket.go:172	0x980046		4885c0				TESTQ AX, AX												
  websocket.go:172	0x980049		7c78				JL 0x9800c3												
  websocket.go:166	0x98004b		750d				JNE 0x98005a												
  websocket.go:167	0x98004d		31c0				XORL AX, AX												
  websocket.go:167	0x98004f		31db				XORL BX, BX												
  websocket.go:167	0x980051		4881c4a8000000			ADDQ $0xa8, SP												
  websocket.go:167	0x980058		5d				POPQ BP													
  websocket.go:167	0x980059		c3				RET													
  websocket.go:169	0x98005a		488b8c24d0000000		MOVQ 0xd0(SP), CX											
  websocket.go:169	0x980062		48f7d9				NEGQ CX													
  type.go:128		0x980065		488b9424b8000000		MOVQ 0xb8(SP), DX											
  type.go:128		0x98006d		f0480fc14a58			LOCK XADDQ CX, 0x58(DX)											
  websocket.go:185	0x980073		488b4238			MOVQ 0x38(DX), AX											
  websocket.go:170	0x980077		90				NOPL													
  websocket.go:185	0x980078		488b4c2448			MOVQ 0x48(SP), CX											
  websocket.go:185	0x98007d		48898c2490000000		MOVQ CX, 0x90(SP)											
  websocket.go:185	0x980085		488b4c2438			MOVQ 0x38(SP), CX											
  websocket.go:185	0x98008a		48898c2498000000		MOVQ CX, 0x98(SP)											
  websocket.go:185	0x980092		488b4c2440			MOVQ 0x40(SP), CX											
  websocket.go:185	0x980097		48898c24a0000000		MOVQ CX, 0xa0(SP)											
  websocket.go:185	0x98009f		488d9c2490000000		LEAQ 0x90(SP), BX											
  websocket.go:185	0x9800a7		e8148da9ff			CALL runtime.selectnbsend(SB)										
  websocket.go:171	0x9800ac		488b059dc96600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrClosed(SB), AX			
  websocket.go:171	0x9800b3		488b1d9ec96600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrClosed+8(SB), BX			
  websocket.go:171	0x9800ba		4881c4a8000000			ADDQ $0xa8, SP												
  websocket.go:171	0x9800c1		5d				POPQ BP													
  websocket.go:171	0x9800c2		c3				RET													
  websocket.go:173	0x9800c3		488b8c24d0000000		MOVQ 0xd0(SP), CX											
  websocket.go:173	0x9800cb		48f7d9				NEGQ CX													
  type.go:128		0x9800ce		488b9424b8000000		MOVQ 0xb8(SP), DX											
  type.go:128		0x9800d6		f0480fc14a58			LOCK XADDQ CX, 0x58(DX)											
  websocket.go:185	0x9800dc		488b4238			MOVQ 0x38(DX), AX											
  websocket.go:174	0x9800e0		90				NOPL													
  websocket.go:185	0x9800e1		488b4c2448			MOVQ 0x48(SP), CX											
  websocket.go:185	0x9800e6		48898c2490000000		MOVQ CX, 0x90(SP)											
  websocket.go:185	0x9800ee		488b4c2438			MOVQ 0x38(SP), CX											
  websocket.go:185	0x9800f3		48898c2498000000		MOVQ CX, 0x98(SP)											
  websocket.go:185	0x9800fb		488b4c2440			MOVQ 0x40(SP), CX											
  websocket.go:185	0x980100		48898c24a0000000		MOVQ CX, 0xa0(SP)											
  websocket.go:185	0x980108		488d9c2490000000		LEAQ 0x90(SP), BX											
  websocket.go:185	0x980110		e8ab8ca9ff			CALL runtime.selectnbsend(SB)										
  websocket.go:175	0x980115		488b0524c96600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrQueueFull(SB), AX			
  websocket.go:175	0x98011c		488b1d25c96600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrQueueFull+8(SB), BX		
  websocket.go:175	0x980123		4881c4a8000000			ADDQ $0xa8, SP												
  websocket.go:175	0x98012a		5d				POPQ BP													
  websocket.go:175	0x98012b		c3				RET													
  websocket.go:143	0x98012c		48f7da				NEGQ DX													
  type.go:128		0x98012f		f0480fc15058			LOCK XADDQ DX, 0x58(AX)											
  websocket.go:144	0x980135		e8e6faffff			CALL github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).closeTransport(SB)	
  websocket.go:145	0x98013a		488b05efc86600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrSlowClient(SB), AX			
  websocket.go:145	0x980141		488b1df0c86600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrSlowClient+8(SB), BX		
  websocket.go:145	0x980148		4881c4a8000000			ADDQ $0xa8, SP												
  websocket.go:145	0x98014f		5d				POPQ BP													
  websocket.go:145	0x980150		c3				RET													
  websocket.go:138	0x980151		488b05f8c86600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrClosed(SB), AX			
  websocket.go:138	0x980158		488b1df9c86600			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/network.ErrClosed+8(SB), BX			
  websocket.go:138	0x98015f		4881c4a8000000			ADDQ $0xa8, SP												
  websocket.go:138	0x980166		5d				POPQ BP													
  websocket.go:138	0x980167		c3				RET													
  websocket.go:160	0x980168		e8d323b1ff			CALL runtime.panicBounds(SB)										
  websocket.go:160	0x98016d		90				NOPL													
  websocket.go:135	0x98016e		4889442408			MOVQ AX, 0x8(SP)											
  websocket.go:135	0x980173		885c2410			MOVB BL, 0x10(SP)											
  websocket.go:135	0x980177		48894c2418			MOVQ CX, 0x18(SP)											
  websocket.go:135	0x98017c		48897c2420			MOVQ DI, 0x20(SP)											
  websocket.go:135	0x980181		4889742428			MOVQ SI, 0x28(SP)											
  websocket.go:135	0x980186		e87507b1ff			CALL runtime.morestack_noctxt.abi0(SB)									
  websocket.go:135	0x98018b		488b442408			MOVQ 0x8(SP), AX											
  websocket.go:135	0x980190		0fb65c2410			MOVZX 0x10(SP), BX											
  websocket.go:135	0x980195		488b4c2418			MOVQ 0x18(SP), CX											
  websocket.go:135	0x98019a		488b7c2420			MOVQ 0x20(SP), DI											
  websocket.go:135	0x98019f		488b742428			MOVQ 0x28(SP), SI											
  websocket.go:135	0x9801a4		e9d7fcffff			JMP github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).enqueue(SB)		

TEXT github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).writePump(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/network/websocket.go
  websocket.go:194	0x980220		4c8d6424c0			LEAQ -0x40(SP), R12											
  websocket.go:194	0x980225		4d3b6610			CMPQ R12, 0x10(R14)											
  websocket.go:194	0x980229		0f8659010000			JBE 0x980388												
  websocket.go:194	0x98022f		55				PUSHQ BP												
  websocket.go:194	0x980230		4889e5				MOVQ SP, BP												
  websocket.go:194	0x980233		4881ecb8000000			SUBQ $0xb8, SP												
  websocket.go:195	0x98023a		48898424c8000000		MOVQ AX, 0xc8(SP)											
  websocket.go:195	0x980242		eb08				JMP 0x98024c												
  websocket.go:197	0x980244		488b8424c8000000		MOVQ 0xc8(SP), AX											
  websocket.go:197	0x98024c		488b5040			MOVQ 0x40(AX), DX											
  websocket.go:199	0x980250		4c8b4830			MOVQ 0x30(AX), R9											
  websocket.go:199	0x980254		c684249800000000		MOVB $0x0, 0x98(SP)											
  websocket.go:199	0x98025c		48c78424a000000000000000	MOVQ $0x0, 0xa0(SP)											
  websocket.go:199	0x980268		440f11bc24a8000000		MOVUPS X15, 0xa8(SP)											
  websocket.go:196	0x980271		4c8d542460			LEAQ 0x60(SP), R10											
  websocket.go:196	0x980276		450f113a			MOVUPS X15, 0(R10)											
  websocket.go:196	0x98027a		450f117a10			MOVUPS X15, 0x10(R10)											
  websocket.go:197	0x98027f		4889542470			MOVQ DX, 0x70(SP)											
  websocket.go:199	0x980284		4c894c2460			MOVQ R9, 0x60(SP)											
  websocket.go:199	0x980289		488d942498000000		LEAQ 0x98(SP), DX											
  websocket.go:199	0x980291		4889542468			MOVQ DX, 0x68(SP)											
  websocket.go:196	0x980296		488d442460			LEAQ 0x60(SP), AX											
  websocket.go:196	0x98029b		488d5c2438			LEAQ 0x38(SP), BX											
  websocket.go:196	0x9802a0		31c9				XORL CX, CX												
  websocket.go:196	0x9802a2		31ff				XORL DI, DI												
  websocket.go:196	0x9802a4		be02000000			MOVL $0x2, SI												
  websocket.go:196	0x9802a9		41b801000000			MOVL $0x1, R8												
  websocket.go:196	0x9802af		e84c43aeff			CALL runtime.selectgo(SB)										
  websocket.go:199	0x9802b4		4885c0				TESTQ AX, AX												
  websocket.go:199	0x9802b7		0f85c2000000			JNE 0x98037f												
  websocket.go:199	0x9802bd		488bbc24a8000000		MOVQ 0xa8(SP), DI											
  websocket.go:199	0x9802c5		48897c2450			MOVQ DI, 0x50(SP)											
  websocket.go:199	0x9802ca		0fb69c2498000000		MOVZX 0x98(SP), BX											
  websocket.go:199	0x9802d2		885c2437			MOVB BL, 0x37(SP)											
  websocket.go:199	0x9802d6		488b8c24a0000000		MOVQ 0xa0(SP), CX											
  websocket.go:199	0x9802de		48894c2458			MOVQ CX, 0x58(SP)											
  websocket.go:199	0x9802e3		488bb424b0000000		MOVQ 0xb0(SP), SI											
  websocket.go:199	0x9802eb		4889742448			MOVQ SI, 0x48(SP)											
  websocket.go:200	0x9802f0		488b8424c8000000		MOVQ 0xc8(SP), AX											
  websocket.go:200	0x9802f8		e8a3000000			CALL github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).writeFrame(SB)		
  websocket.go:200	0x9802fd		4889442440			MOVQ AX, 0x40(SP)											
  websocket.go:201	0x980302		488b542450			MOVQ 0x50(SP), DX											
  websocket.go:201	0x980307		4c8d42f6			LEAQ -0xa(DX), R8											
  websocket.go:201	0x98030b		49f7d8				NEGQ R8													
  type.go:128		0x98030e		4c8b8c24c8000000		MOVQ 0xc8(SP), R9											
  type.go:128		0x980316		f04d0fc14158			LOCK XADDQ R8, 0x58(R9)											
  websocket.go:185	0x98031c		498b4138			MOVQ 0x38(R9), AX											
  websocket.go:202	0x980320		90				NOPL													
  websocket.go:185	0x980321		4c8b442458			MOVQ 0x58(SP), R8											
  websocket.go:185	0x980326		4c89842480000000		MOVQ R8, 0x80(SP)											
  websocket.go:185	0x98032e		4889942488000000		MOVQ DX, 0x88(SP)											
  websocket.go:185	0x980336		488b542448			MOVQ 0x48(SP), DX											
  websocket.go:185	0x98033b		4889942490000000		MOVQ DX, 0x90(SP)											
  websocket.go:185	0x980343		488d9c2480000000		LEAQ 0x80(SP), BX											
  websocket.go:185	0x98034b		e8708aa9ff			CALL runtime.selectnbsend(SB)										
  websocket.go:204	0x980350		488b542440			MOVQ 0x40(SP), DX											
  websocket.go:204	0x980355		4885d2				TESTQ DX, DX												
  websocket.go:204	0x980358		750f				JNE 0x980369												
  websocket.go:204	0x98035a		0fb6542437			MOVZX 0x37(SP), DX											
  websocket.go:204	0x98035f		90				NOPL													
  websocket.go:204	0x980360		80fa08				CMPL DL, $0x8												
  websocket.go:204	0x980363		0f85dbfeffff			JNE 0x980244												
  websocket.go:205	0x980369		488b8424c8000000		MOVQ 0xc8(SP), AX											
  websocket.go:205	0x980371		e8aaf8ffff			CALL github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).closeTransport(SB)	
  websocket.go:206	0x980376		4881c4b8000000			ADDQ $0xb8, SP												
  websocket.go:206	0x98037d		5d				POPQ BP													
  websocket.go:206	0x98037e		c3				RET													
  websocket.go:198	0x98037f		4881c4b8000000			ADDQ $0xb8, SP												
  websocket.go:198	0x980386		5d				POPQ BP													
  websocket.go:198	0x980387		c3				RET													
  websocket.go:194	0x980388		4889442408			MOVQ AX, 0x8(SP)											
  websocket.go:194	0x98038d		e86e05b1ff			CALL runtime.morestack_noctxt.abi0(SB)									
  websocket.go:194	0x980392		488b442408			MOVQ 0x8(SP), AX											
  websocket.go:194	0x980397		e984feffff			JMP github.com/burntcustard/unicorn-mining-co/src/server/network.(*WebSocket).writePump(SB)		
