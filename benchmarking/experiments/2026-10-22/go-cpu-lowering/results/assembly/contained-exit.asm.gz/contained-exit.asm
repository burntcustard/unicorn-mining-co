TEXT github.com/burntcustard/unicorn-mining-co/src/server/physics.recoveryContainedExit(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/physics/overlap-recovery.go
  overlap-recovery.go:151	0x6191a0		4889442408		MOVQ AX, 0x8(SP)			
  overlap-recovery.go:152	0x6191a5		90			NOPL					
  bits.go:27			0x6191a6		90			NOPL					
  overlap-recovery.go:153	0x6191a7		f20f101519195500	MOVSD_XMM $f64.7ff0000000000000(SB), X2	
  overlap-recovery.go:153	0x6191af		eb0f			JMP 0x6191c0				
  overlap-recovery.go:153	0x6191b1		488d4120		LEAQ 0x20(CX), AX			
  overlap-recovery.go:153	0x6191b5		48ffcb			DECQ BX					
  overlap-recovery.go:153	0x6191b8		0f10d5			MOVUPS X5, X2				
  overlap-recovery.go:153	0x6191bb		0f1f440000		NOPL 0(AX)(AX*1)			
  overlap-recovery.go:153	0x6191c0		4885db			TESTQ BX, BX				
  overlap-recovery.go:153	0x6191c3		7e59			JLE 0x61921e				
  overlap-recovery.go:153	0x6191c5		4889c1			MOVQ AX, CX				
  overlap-recovery.go:153	0x6191c8		f20f1018		MOVSD_XMM 0(AX), X3			
  overlap-recovery.go:153	0x6191cc		f20f106008		MOVSD_XMM 0x8(AX), X4			
  vector.go:59			0x6191d1		f20f59d8		MULSD X0, X3				
  vector.go:59			0x6191d5		f20f59e1		MULSD X1, X4				
  vector.go:59			0x6191d9		f20f58dc		ADDSD X4, X3				
  overlap-recovery.go:154	0x6191dd		90			NOPL					
  overlap-recovery.go:156	0x6191de		f20f1025a21e5500	MOVSD_XMM $f64.3ddb7cdfd9d7bdbb(SB), X4	
  overlap-recovery.go:156	0x6191e6		660f2edc		UCOMISD X4, X3				
  overlap-recovery.go:156	0x6191ea		7207			JB 0x6191f3				
  overlap-recovery.go:153	0x6191ec		f20f106818		MOVSD_XMM 0x18(AX), X5			
  overlap-recovery.go:157	0x6191f1		eb17			JMP 0x61920a				
  overlap-recovery.go:158	0x6191f3		f20f102dc51e5500	MOVSD_XMM $f64.bddb7cdfd9d7bdbb(SB), X5	
  overlap-recovery.go:158	0x6191fb		660f2eeb		UCOMISD X3, X5				
  overlap-recovery.go:158	0x6191ff		90			NOPL					
  overlap-recovery.go:158	0x619200		7217			JB 0x619219				
  overlap-recovery.go:153	0x619202		f20f107010		MOVSD_XMM 0x10(AX), X6			
  overlap-recovery.go:163	0x619207		0f10ee			MOVUPS X6, X5				
  overlap-recovery.go:163	0x61920a		f20f5eeb		DIVSD X3, X5				
  overlap-recovery.go:163	0x61920e		660f2ed5		UCOMISD X5, X2				
  overlap-recovery.go:163	0x619212		779d			JA 0x6191b1				
  overlap-recovery.go:163	0x619214		0f10ea			MOVUPS X2, X5				
  overlap-recovery.go:163	0x619217		eb98			JMP 0x6191b1				
  overlap-recovery.go:153	0x619219		0f10ea			MOVUPS X2, X5				
  overlap-recovery.go:161	0x61921c		eb93			JMP 0x6191b1				
  overlap-recovery.go:167	0x61921e		0f10c2			MOVUPS X2, X0				
  overlap-recovery.go:167	0x619221		c3			RET					
