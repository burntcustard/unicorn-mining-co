TEXT github.com/burntcustard/unicorn-mining-co/src/server/physics.recoveryContainedExit(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/physics/overlap-recovery.go
  overlap-recovery.go:151	0x614b00		4889442408		MOVQ AX, 0x8(SP)			
  overlap-recovery.go:152	0x614b05		90			NOPL					
  bits.go:27			0x614b06		90			NOPL					
  overlap-recovery.go:154	0x614b07		f20f1015b11f5500	MOVSD_XMM $f64.7ff0000000000000(SB), X2	
  overlap-recovery.go:154	0x614b0f		eb0f			JMP 0x614b20				
  overlap-recovery.go:154	0x614b11		488d4120		LEAQ 0x20(CX), AX			
  overlap-recovery.go:154	0x614b15		48ffcb			DECQ BX					
  overlap-recovery.go:154	0x614b18		0f10d5			MOVUPS X5, X2				
  overlap-recovery.go:154	0x614b1b		0f1f440000		NOPL 0(AX)(AX*1)			
  overlap-recovery.go:154	0x614b20		4885db			TESTQ BX, BX				
  overlap-recovery.go:154	0x614b23		7e59			JLE 0x614b7e				
  overlap-recovery.go:154	0x614b25		4889c1			MOVQ AX, CX				
  overlap-recovery.go:154	0x614b28		f20f1018		MOVSD_XMM 0(AX), X3			
  overlap-recovery.go:154	0x614b2c		f20f106008		MOVSD_XMM 0x8(AX), X4			
  vector.go:59			0x614b31		f20f59d8		MULSD X0, X3				
  vector.go:59			0x614b35		f20f59e1		MULSD X1, X4				
  vector.go:59			0x614b39		f20f58dc		ADDSD X4, X3				
  overlap-recovery.go:155	0x614b3d		90			NOPL					
  overlap-recovery.go:158	0x614b3e		f20f10253a255500	MOVSD_XMM $f64.3ddb7cdfd9d7bdbb(SB), X4	
  overlap-recovery.go:158	0x614b46		660f2edc		UCOMISD X4, X3				
  overlap-recovery.go:158	0x614b4a		7207			JB 0x614b53				
  overlap-recovery.go:154	0x614b4c		f20f106818		MOVSD_XMM 0x18(AX), X5			
  overlap-recovery.go:159	0x614b51		eb17			JMP 0x614b6a				
  overlap-recovery.go:160	0x614b53		f20f102d65255500	MOVSD_XMM $f64.bddb7cdfd9d7bdbb(SB), X5	
  overlap-recovery.go:160	0x614b5b		660f2eeb		UCOMISD X3, X5				
  overlap-recovery.go:160	0x614b5f		90			NOPL					
  overlap-recovery.go:160	0x614b60		7217			JB 0x614b79				
  overlap-recovery.go:154	0x614b62		f20f107010		MOVSD_XMM 0x10(AX), X6			
  overlap-recovery.go:166	0x614b67		0f10ee			MOVUPS X6, X5				
  overlap-recovery.go:166	0x614b6a		f20f5eeb		DIVSD X3, X5				
  overlap-recovery.go:166	0x614b6e		660f2ed5		UCOMISD X5, X2				
  overlap-recovery.go:166	0x614b72		779d			JA 0x614b11				
  overlap-recovery.go:166	0x614b74		0f10ea			MOVUPS X2, X5				
  overlap-recovery.go:166	0x614b77		eb98			JMP 0x614b11				
  overlap-recovery.go:154	0x614b79		0f10ea			MOVUPS X2, X5				
  overlap-recovery.go:163	0x614b7c		eb93			JMP 0x614b11				
  overlap-recovery.go:171	0x614b7e		0f10c2			MOVUPS X2, X0				
  overlap-recovery.go:171	0x614b81		c3			RET					
