TEXT github.com/burntcustard/unicorn-mining-co/src/server/simulation.UpdateEntities(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/simulation/update-tier.go
  update-tier.go:63	0x600080		4c8da42488fdffff	LEAQ 0xfffffd88(SP), R12																																								
  update-tier.go:63	0x600088		4d3b6610		CMPQ R12, 0x10(R14)																																									
  update-tier.go:63	0x60008c		0f8679230000		JBE 0x60240b																																										
  update-tier.go:63	0x600092		55			PUSHQ BP																																										
  update-tier.go:63	0x600093		4889e5			MOVQ SP, BP																																										
  update-tier.go:63	0x600096		4881ecf0020000		SUBQ $0x2f0, SP																																										
  update-tier.go:63	0x60009d		48899c2408030000	MOVQ BX, 0x308(SP)																																									
  update-tier.go:63	0x6000a5		48898c2410030000	MOVQ CX, 0x310(SP)																																									
  update-tier.go:63	0x6000ad		4889bc2418030000	MOVQ DI, 0x318(SP)																																									
  update-tier.go:63	0x6000b5		4889b42420030000	MOVQ SI, 0x320(SP)																																									
  update-tier.go:63	0x6000bd		4c89842428030000	MOVQ R8, 0x328(SP)																																									
  update-tier.go:63	0x6000c5		4c898c2430030000	MOVQ R9, 0x330(SP)																																									
  update-tier.go:63	0x6000cd		4c89942438030000	MOVQ R10, 0x338(SP)																																									
  update-tier.go:63	0x6000d5		f20f11842440030000	MOVSD_XMM X0, 0x340(SP)																																									
  update-tier.go:67	0x6000de		488b942420030000	MOVQ 0x320(SP), DX																																									
  update-tier.go:64	0x6000e6		4c8b8088010000		MOVQ 0x188(AX), R8																																									
  update-tier.go:67	0x6000ed		4885d2			TESTQ DX, DX																																										
  update-tier.go:67	0x6000f0		7403			JE 0x6000f5																																										
  update-tier.go:68	0x6000f2		4c8b02			MOVQ 0(DX), R8																																										
  update-tier.go:65	0x6000f5		f20f1080e0070000	MOVSD_XMM 0x7e0(AX), X0																																									
  update-tier.go:65	0x6000fd		0f1f00			NOPL 0(AX)																																										
  update-tier.go:71	0x600100		4d85d2			TESTQ R10, R10																																										
  update-tier.go:71	0x600103		7405			JE 0x60010a																																										
  update-tier.go:72	0x600105		f2410f1002		MOVSD_XMM 0(R10), X0																																									
  update-tier.go:67	0x60010a		4889842400030000	MOVQ AX, 0x300(SP)																																									
  update-tier.go:75	0x600112		f20f118424f0000000	MOVSD_XMM X0, 0xf0(SP)																																									
  update-tier.go:71	0x60011b		4c89842480000000	MOVQ R8, 0x80(SP)																																									
  update-tier.go:77	0x600123		4d85c9			TESTQ R9, R9																																										
  update-tier.go:77	0x600126		7532			JNE 0x60015a																																										
  update-tier.go:78	0x600128		b818000000		MOVL $0x18, AX																																										
  update-tier.go:78	0x60012d		488d1d24cfad00		LEAQ 0xadcf24(IP), BX																																									
  update-tier.go:78	0x600134		b901000000		MOVL $0x1, CX																																										
  update-tier.go:78	0x600139		e84213e2ff		CALL runtime.mallocgcSmallScanNoHeaderSC3(SB)																																						
  update-tier.go:169	0x60013e		4c8b842480000000	MOVQ 0x80(SP), R8																																									
  update-tier.go:216	0x600146		f20f108424f0000000	MOVSD_XMM 0xf0(SP), X0																																									
  update-tier.go:81	0x60014f		4989c1			MOVQ AX, R9																																										
  update-tier.go:85	0x600152		488b842400030000	MOVQ 0x300(SP), AX																																									
  update-tier.go:81	0x60015a		4c898c24c0010000	MOVQ R9, 0x1c0(SP)																																									
  update-tier.go:82	0x600162		488b942408030000	MOVQ 0x308(SP), DX																																									
  update-tier.go:82	0x60016a		4c8b942410030000	MOVQ 0x310(SP), R10																																									
  update-tier.go:84	0x600172		4885d2			TESTQ DX, DX																																										
  update-tier.go:84	0x600175		7575			JNE 0x6001ec																																										
  update-tier.go:85	0x600177		488b5878		MOVQ 0x78(AX), BX																																									
  update-tier.go:85	0x60017b		0f1f440000		NOPL 0(AX)(AX*1)																																									
  update-tier.go:85	0x600180		4885db			TESTQ BX, BX																																										
  update-tier.go:85	0x600183		742e			JE 0x6001b3																																										
  update-tier.go:85	0x600185		48c1e304		SHLQ $0x4, BX																																										
  update-tier.go:85	0x600189		488b4070		MOVQ 0x70(AX), AX																																									
  update-tier.go:85	0x60018d		e8eee3e8ff		CALL runtime.memclrHasPointers(SB)																																							
  update-tier.go:86	0x600192		488b842400030000	MOVQ 0x300(SP), AX																																									
  update-tier.go:169	0x60019a		4c8b842480000000	MOVQ 0x80(SP), R8																																									
  update-tier.go:268	0x6001a2		4c8b8c24c0010000	MOVQ 0x1c0(SP), R9																																									
  update-tier.go:216	0x6001aa		f20f108424f0000000	MOVSD_XMM 0xf0(SP), X0																																									
  update-tier.go:86	0x6001b3		48c7407800000000	MOVQ $0x0, 0x78(AX)																																									
  update-tier.go:88	0x6001bb		488b9018010000		MOVQ 0x118(AX), DX																																									
  update-tier.go:88	0x6001c2		4889942410020000	MOVQ DX, 0x210(SP)																																									
  update-tier.go:88	0x6001ca		4c8b5070		MOVQ 0x70(AX), R10																																									
  update-tier.go:88	0x6001ce		488b8880000000		MOVQ 0x80(AX), CX																																									
  ordered-map.go:71	0x6001d5		4c8b5a10		MOVQ 0x10(DX), R11																																									
  ordered-map.go:71	0x6001d9		4c899c2458010000	MOVQ R11, 0x158(SP)																																									
  ordered-map.go:71	0x6001e1		4531e4			XORL R12, R12																																										
  ordered-map.go:71	0x6001e4		4531ed			XORL R13, R13																																										
  ordered-map.go:71	0x6001e7		e9d8200000		JMP 0x6022c4																																										
  update-tier.go:93	0x6001ec		4c899424a8000000	MOVQ R10, 0xa8(SP)																																									
  update-tier.go:93	0x6001f4		48899424b8010000	MOVQ DX, 0x1b8(SP)																																									
  update-tier.go:93	0x6001fc		488b5848		MOVQ 0x48(AX), BX																																									
  update-tier.go:93	0x600200		4885db			TESTQ BX, BX																																										
  update-tier.go:93	0x600203		743e			JE 0x600243																																										
  update-tier.go:93	0x600205		48c1e304		SHLQ $0x4, BX																																										
  update-tier.go:93	0x600209		488b4040		MOVQ 0x40(AX), AX																																									
  update-tier.go:93	0x60020d		e86ee3e8ff		CALL runtime.memclrHasPointers(SB)																																							
  update-tier.go:94	0x600212		488b842400030000	MOVQ 0x300(SP), AX																																									
  update-tier.go:135	0x60021a		488b9424b8010000	MOVQ 0x1b8(SP), DX																																									
  update-tier.go:169	0x600222		4c8b842480000000	MOVQ 0x80(SP), R8																																									
  update-tier.go:268	0x60022a		4c8b8c24c0010000	MOVQ 0x1c0(SP), R9																																									
  update-tier.go:135	0x600232		4c8b9424a8000000	MOVQ 0xa8(SP), R10																																									
  update-tier.go:216	0x60023a		f20f108424f0000000	MOVSD_XMM 0xf0(SP), X0																																									
  update-tier.go:94	0x600243		48c7404800000000	MOVQ $0x0, 0x48(AX)																																									
  update-tier.go:95	0x60024b		488b5860		MOVQ 0x60(AX), BX																																									
  update-tier.go:95	0x60024f		4885db			TESTQ BX, BX																																										
  update-tier.go:95	0x600252		7419			JE 0x60026d																																										
  update-tier.go:95	0x600254		48c1e304		SHLQ $0x4, BX																																										
  update-tier.go:95	0x600258		488b4058		MOVQ 0x58(AX), AX																																									
  update-tier.go:95	0x60025c		0f1f4000		NOPL 0(AX)																																										
  update-tier.go:95	0x600260		e81be3e8ff		CALL runtime.memclrHasPointers(SB)																																							
  update-tier.go:96	0x600265		488b842400030000	MOVQ 0x300(SP), AX																																									
  update-tier.go:96	0x60026d		48c7406000000000	MOVQ $0x0, 0x60(AX)																																									
  update-tier.go:98	0x600275		48c780a800000000000000	MOVQ $0x0, 0xa8(AX)																																									
  update-tier.go:81	0x600280		488d5040		LEAQ 0x40(AX), DX																																									
  update-tier.go:81	0x600284		4889942460010000	MOVQ DX, 0x160(SP)																																									
  update-tier.go:100	0x60028c		488d35cd400000		LEAQ github.com/burntcustard/unicorn-mining-co/src/server/simulation.UpdateEntities.func1(SB), SI																															
  update-tier.go:100	0x600293		4889b424d8020000	MOVQ SI, 0x2d8(SP)																																									
  update-tier.go:100	0x60029b		48898424e0020000	MOVQ AX, 0x2e0(SP)																																									
  update-tier.go:100	0x6002a3		48899424e8020000	MOVQ DX, 0x2e8(SP)																																									
  update-tier.go:100	0x6002ab		488b8078010000		MOVQ 0x178(AX), AX																																									
  update-tier.go:100	0x6002b2		488d1d67c05700		LEAQ github.com/burntcustard/unicorn-mining-co/src/server/utilities..dict.OrderedMap[int64,github.com/burntcustard/unicorn-mining-co/src/server/simulation.Player](SB), BX																						
  update-tier.go:100	0x6002b9		488d8c24d8020000	LEAQ 0x2d8(SP), CX																																									
  update-tier.go:100	0x6002c1		e8fa4c0000		CALL github.com/burntcustard/unicorn-mining-co/src/server/utilities.(*OrderedMap[go.shape.int64,go.shape.struct { ID int64; ShipID int64; Credits *float64; ObserverRange float64 }]).ForEach(SB)																			
  update-tier.go:119	0x6002c6		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:119	0x6002ce		48c7829000000000000000	MOVQ $0x0, 0x90(DX)																																									
  update-tier.go:120	0x6002d9		48c782c000000000000000	MOVQ $0x0, 0xc0(DX)																																									
  update-tier.go:121	0x6002e4		48c782d800000000000000	MOVQ $0x0, 0xd8(DX)																																									
  update-tier.go:123	0x6002ef		488b7240		MOVQ 0x40(DX), SI																																									
  update-tier.go:123	0x6002f3		488b7a48		MOVQ 0x48(DX), DI																																									
  update-tier.go:123	0x6002f7		eb2e			JMP 0x600327																																										
  update-tier.go:123	0x6002f9		0f1f8000000000		NOPL 0(AX)																																										
  update-tier.go:127	0x600300		488999d8000000		MOVQ BX, 0xd8(CX)																																									
  update-tier.go:127	0x600307		f20f114cd8f8		MOVSD_XMM X1, -0x8(AX)(BX*8)																																								
  update-tier.go:123	0x60030d		488bb42408020000	MOVQ 0x208(SP), SI																																									
  update-tier.go:123	0x600315		4883c610		ADDQ $0x10, SI																																										
  update-tier.go:123	0x600319		488bbc2458010000	MOVQ 0x158(SP), DI																																									
  update-tier.go:123	0x600321		48ffcf			DECQ DI																																											
  update-tier.go:130	0x600324		4889ca			MOVQ CX, DX																																										
  update-tier.go:123	0x600327		4885ff			TESTQ DI, DI																																										
  update-tier.go:123	0x60032a		0f8ed8010000		JLE 0x600508																																										
  update-tier.go:123	0x600330		4889bc2458010000	MOVQ DI, 0x158(SP)																																									
  update-tier.go:123	0x600338		4889b42408020000	MOVQ SI, 0x208(SP)																																									
  update-tier.go:123	0x600340		488b0e			MOVQ 0(SI), CX																																										
  update-tier.go:123	0x600343		488b4608		MOVQ 0x8(SI), AX																																									
  update-tier.go:124	0x600347		488b4918		MOVQ 0x18(CX), CX																																									
  update-tier.go:124	0x60034b		ffd1			CALL CX																																											
  update-tier.go:125	0x60034d		488b8c2400030000	MOVQ 0x300(SP), CX																																									
  update-tier.go:125	0x600355		488b9198000000		MOVQ 0x98(CX), DX																																									
  update-tier.go:125	0x60035c		488b9990000000		MOVQ 0x90(CX), BX																																									
  update-tier.go:125	0x600363		48ffc3			INCQ BX																																											
  update-tier.go:124	0x600366		f20f104018		MOVSD_XMM 0x18(AX), X0																																									
  update-tier.go:124	0x60036b		f20f11842450010000	MOVSD_XMM X0, 0x150(SP)																																									
  update-tier.go:124	0x600374		f20f104820		MOVSD_XMM 0x20(AX), X1																																									
  update-tier.go:124	0x600379		f20f118c2448010000	MOVSD_XMM X1, 0x148(SP)																																									
  update-tier.go:125	0x600382		488b8188000000		MOVQ 0x88(CX), AX																																									
  update-tier.go:125	0x600389		4839da			CMPQ DX, BX																																										
  update-tier.go:125	0x60038c		735e			JAE 0x6003ec																																										
  update-tier.go:125	0x60038e		4889d1			MOVQ DX, CX																																										
  update-tier.go:125	0x600391		bf01000000		MOVL $0x1, DI																																										
  update-tier.go:125	0x600396		488d355313b500		LEAQ 0xb51353(IP), SI																																									
  update-tier.go:125	0x60039d		0f1f00			NOPL 0(AX)																																										
  update-tier.go:125	0x6003a0		e8db22e9ff		CALL runtime.growslice(SB)																																								
  update-tier.go:125	0x6003a5		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:125	0x6003ad		48898a98000000		MOVQ CX, 0x98(DX)																																									
  update-tier.go:125	0x6003b4		833da531c40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:125	0x6003bb		7413			JE 0x6003d0																																										
  update-tier.go:125	0x6003bd		4c8b8288000000		MOVQ 0x88(DX), R8																																									
  update-tier.go:125	0x6003c4		e8576fe9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  update-tier.go:125	0x6003c9		498903			MOVQ AX, 0(R11)																																										
  update-tier.go:125	0x6003cc		4d894308		MOVQ R8, 0x8(R11)																																									
  update-tier.go:125	0x6003d0		48898288000000		MOVQ AX, 0x88(DX)																																									
  update-tier.go:125	0x6003d7		4889d1			MOVQ DX, CX																																										
  update-tier.go:125	0x6003da		f20f10842450010000	MOVSD_XMM 0x150(SP), X0																																									
  update-tier.go:125	0x6003e3		f20f108c2448010000	MOVSD_XMM 0x148(SP), X1																																									
  update-tier.go:125	0x6003ec		48899990000000		MOVQ BX, 0x90(CX)																																									
  update-tier.go:125	0x6003f3		488d53ff		LEAQ -0x1(BX), DX																																									
  update-tier.go:125	0x6003f7		48c1e204		SHLQ $0x4, DX																																										
  update-tier.go:125	0x6003fb		f20f110410		MOVSD_XMM X0, 0(AX)(DX*1)																																								
  update-tier.go:125	0x600400		f20f114c1008		MOVSD_XMM X1, 0x8(AX)(DX*1)																																								
  update-tier.go:126	0x600406		488b91c8000000		MOVQ 0xc8(CX), DX																																									
  update-tier.go:126	0x60040d		488b99c0000000		MOVQ 0xc0(CX), BX																																									
  update-tier.go:126	0x600414		48ffc3			INCQ BX																																											
  update-tier.go:126	0x600417		488b81b8000000		MOVQ 0xb8(CX), AX																																									
  update-tier.go:126	0x60041e		6690			NOPW																																											
  update-tier.go:126	0x600420		4839da			CMPQ DX, BX																																										
  update-tier.go:126	0x600423		735b			JAE 0x600480																																										
  update-tier.go:126	0x600425		4889d1			MOVQ DX, CX																																										
  update-tier.go:126	0x600428		bf01000000		MOVL $0x1, DI																																										
  update-tier.go:126	0x60042d		488d355c41b200		LEAQ 0xb2415c(IP), SI																																									
  update-tier.go:126	0x600434		e84722e9ff		CALL runtime.growslice(SB)																																								
  update-tier.go:126	0x600439		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:126	0x600441		48898ac8000000		MOVQ CX, 0xc8(DX)																																									
  update-tier.go:126	0x600448		833d1131c40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:126	0x60044f		7413			JE 0x600464																																										
  update-tier.go:126	0x600451		4c8b82b8000000		MOVQ 0xb8(DX), R8																																									
  update-tier.go:126	0x600458		e8c36ee9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  update-tier.go:126	0x60045d		498903			MOVQ AX, 0(R11)																																										
  update-tier.go:126	0x600460		4d894308		MOVQ R8, 0x8(R11)																																									
  update-tier.go:126	0x600464		488982b8000000		MOVQ AX, 0xb8(DX)																																									
  update-tier.go:126	0x60046b		4889d1			MOVQ DX, CX																																										
  update-tier.go:126	0x60046e		f20f10842450010000	MOVSD_XMM 0x150(SP), X0																																									
  update-tier.go:127	0x600477		f20f108c2448010000	MOVSD_XMM 0x148(SP), X1																																									
  update-tier.go:126	0x600480		488999c0000000		MOVQ BX, 0xc0(CX)																																									
  update-tier.go:126	0x600487		f20f1144d8f8		MOVSD_XMM X0, -0x8(AX)(BX*8)																																								
  update-tier.go:127	0x60048d		488b91e0000000		MOVQ 0xe0(CX), DX																																									
  update-tier.go:127	0x600494		488b99d8000000		MOVQ 0xd8(CX), BX																																									
  update-tier.go:127	0x60049b		48ffc3			INCQ BX																																											
  update-tier.go:127	0x60049e		488b81d0000000		MOVQ 0xd0(CX), AX																																									
  update-tier.go:127	0x6004a5		4839da			CMPQ DX, BX																																										
  update-tier.go:127	0x6004a8		0f8352feffff		JAE 0x600300																																										
  update-tier.go:127	0x6004ae		4889d1			MOVQ DX, CX																																										
  update-tier.go:127	0x6004b1		bf01000000		MOVL $0x1, DI																																										
  update-tier.go:127	0x6004b6		488d35d340b200		LEAQ 0xb240d3(IP), SI																																									
  update-tier.go:127	0x6004bd		0f1f00			NOPL 0(AX)																																										
  update-tier.go:127	0x6004c0		e8bb21e9ff		CALL runtime.growslice(SB)																																								
  update-tier.go:127	0x6004c5		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:127	0x6004cd		48898ae0000000		MOVQ CX, 0xe0(DX)																																									
  update-tier.go:127	0x6004d4		833d8530c40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:127	0x6004db		7413			JE 0x6004f0																																										
  update-tier.go:127	0x6004dd		488bb2d0000000		MOVQ 0xd0(DX), SI																																									
  update-tier.go:127	0x6004e4		e8376ee9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  update-tier.go:127	0x6004e9		498903			MOVQ AX, 0(R11)																																										
  update-tier.go:127	0x6004ec		49897308		MOVQ SI, 0x8(R11)																																									
  update-tier.go:127	0x6004f0		488982d0000000		MOVQ AX, 0xd0(DX)																																									
  update-tier.go:127	0x6004f7		4889d1			MOVQ DX, CX																																										
  update-tier.go:127	0x6004fa		f20f108c2448010000	MOVSD_XMM 0x148(SP), X1																																									
  update-tier.go:127	0x600503		e9f8fdffff		JMP 0x600300																																										
  update-tier.go:130	0x600508		488b9a18080000		MOVQ 0x818(DX), BX																																									
  update-tier.go:130	0x60050f		488d05caebae00		LEAQ 0xaeebca(IP), AX																																									
  update-tier.go:130	0x600516		488d0d5aea5100		LEAQ 0x51ea5a(IP), CX																																									
  update-tier.go:130	0x60051d		bf07000000		MOVL $0x7, DI																																										
  update-tier.go:130	0x600522		e859fce0ff		CALL runtime.mapaccess1_faststr(SB)																																							
  update-tier.go:130	0x600527		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:130	0x60052f		488b9a18080000		MOVQ 0x818(DX), BX																																									
  update-tier.go:130	0x600536		488b10			MOVQ 0(AX), DX																																										
  update-tier.go:130	0x600539		4889942458010000	MOVQ DX, 0x158(SP)																																									
  update-tier.go:130	0x600541		488b5008		MOVQ 0x8(AX), DX																																									
  update-tier.go:130	0x600545		4889942440010000	MOVQ DX, 0x140(SP)																																									
  update-tier.go:130	0x60054d		488b5010		MOVQ 0x10(AX), DX																																									
  update-tier.go:130	0x600551		4889942438010000	MOVQ DX, 0x138(SP)																																									
  update-tier.go:130	0x600559		488d0580ebae00		LEAQ 0xaeeb80(IP), AX																																									
  update-tier.go:130	0x600560		488d0d09ea5100		LEAQ 0x51ea09(IP), CX																																									
  update-tier.go:130	0x600567		bf07000000		MOVL $0x7, DI																																										
  update-tier.go:130	0x60056c		e80ffce0ff		CALL runtime.mapaccess1_faststr(SB)																																							
  update-tier.go:130	0x600571		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:130	0x600579		488b9a18080000		MOVQ 0x818(DX), BX																																									
  update-tier.go:130	0x600580		488b10			MOVQ 0(AX), DX																																										
  update-tier.go:130	0x600583		4889942430010000	MOVQ DX, 0x130(SP)																																									
  update-tier.go:130	0x60058b		488b5008		MOVQ 0x8(AX), DX																																									
  update-tier.go:130	0x60058f		4889942428010000	MOVQ DX, 0x128(SP)																																									
  update-tier.go:130	0x600597		488b5010		MOVQ 0x10(AX), DX																																									
  update-tier.go:130	0x60059b		4889942420010000	MOVQ DX, 0x120(SP)																																									
  update-tier.go:130	0x6005a3		488d0536ebae00		LEAQ 0xaeeb36(IP), AX																																									
  update-tier.go:130	0x6005aa		488d0d1de35100		LEAQ 0x51e31d(IP), CX																																									
  update-tier.go:130	0x6005b1		bf05000000		MOVL $0x5, DI																																										
  update-tier.go:130	0x6005b6		e8c5fbe0ff		CALL runtime.mapaccess1_faststr(SB)																																							
  update-tier.go:132	0x6005bb		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:132	0x6005c3		488bb2f0000000		MOVQ 0xf0(DX), SI																																									
  update-tier.go:130	0x6005ca		4c8b00			MOVQ 0(AX), R8																																										
  update-tier.go:130	0x6005cd		4c89842418010000	MOVQ R8, 0x118(SP)																																									
  update-tier.go:130	0x6005d5		4c8b4808		MOVQ 0x8(AX), R9																																									
  update-tier.go:130	0x6005d9		4c898c2410010000	MOVQ R9, 0x110(SP)																																									
  update-tier.go:131	0x6005e1		f20f1082f8070000	MOVSD_XMM 0x7f8(DX), X0																																									
  update-tier.go:132	0x6005e9		4885f6			TESTQ SI, SI																																										
  update-tier.go:132	0x6005ec		743a			JE 0x600628																																										
  update-tier.go:131	0x6005ee		f20f11842450010000	MOVSD_XMM X0, 0x150(SP)																																									
  update-tier.go:132	0x6005f7		486bde38		IMULQ $0x38, SI, BX																																									
  update-tier.go:132	0x6005fb		488b82e8000000		MOVQ 0xe8(DX), AX																																									
  update-tier.go:132	0x600602		e879dfe8ff		CALL runtime.memclrHasPointers(SB)																																							
  update-tier.go:133	0x600607		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:168	0x60060f		4c8b842418010000	MOVQ 0x118(SP), R8																																									
  update-tier.go:168	0x600617		4c8b8c2410010000	MOVQ 0x110(SP), R9																																									
  update-tier.go:131	0x60061f		f20f10842450010000	MOVSD_XMM 0x150(SP), X0																																									
  update-tier.go:133	0x600628		48c782f000000000000000	MOVQ $0x0, 0xf0(DX)																																									
  update-tier.go:131	0x600633		f20f59c0		MULSD X0, X0																																										
  update-tier.go:131	0x600637		f20f11842498000000	MOVSD_XMM X0, 0x98(SP)																																									
  update-tier.go:135	0x600640		488bb424b8010000	MOVQ 0x1b8(SP), SI																																									
  update-tier.go:135	0x600648		488b8424a8000000	MOVQ 0xa8(SP), AX																																									
  update-tier.go:135	0x600650		eb5c			JMP 0x6006ae																																										
  update-tier.go:169	0x600652		440f1031		MOVUPS 0(CX), X14																																									
  update-tier.go:169	0x600656		440f1132		MOVUPS X14, 0(DX)																																									
  update-tier.go:169	0x60065a		440f107110		MOVUPS 0x10(CX), X14																																									
  update-tier.go:169	0x60065f		440f117210		MOVUPS X14, 0x10(DX)																																									
  update-tier.go:169	0x600664		440f107120		MOVUPS 0x20(CX), X14																																									
  update-tier.go:169	0x600669		440f117220		MOVUPS X14, 0x20(DX)																																									
  update-tier.go:169	0x60066e		440f107128		MOVUPS 0x28(CX), X14																																									
  update-tier.go:169	0x600673		440f117228		MOVUPS X14, 0x28(DX)																																									
  update-tier.go:135	0x600678		4c8b9c2408020000	MOVQ 0x208(SP), R11																																									
  update-tier.go:135	0x600680		4983c310		ADDQ $0x10, R11																																										
  update-tier.go:135	0x600684		488b842408010000	MOVQ 0x108(SP), AX																																									
  update-tier.go:135	0x60068c		48ffc8			DECQ AX																																											
  update-tier.go:181	0x60068f		4c89c2			MOVQ R8, DX																																										
  update-tier.go:168	0x600692		4c8b842418010000	MOVQ 0x118(SP), R8																																									
  update-tier.go:168	0x60069a		4c8b8c2410010000	MOVQ 0x110(SP), R9																																									
  observers.go:7	0x6006a2		f20f10842498000000	MOVSD_XMM 0x98(SP), X0																																									
  update-tier.go:135	0x6006ab		4c89de			MOVQ R11, SI																																										
  update-tier.go:135	0x6006ae		4885c0			TESTQ AX, AX																																										
  update-tier.go:135	0x6006b1		0f8e06050000		JLE 0x600bbd																																										
  update-tier.go:135	0x6006b7		4889842408010000	MOVQ AX, 0x108(SP)																																									
  update-tier.go:135	0x6006bf		4889b42408020000	MOVQ SI, 0x208(SP)																																									
  update-tier.go:135	0x6006c7		488b0e			MOVQ 0(SI), CX																																										
  update-tier.go:135	0x6006ca		48898c24d0000000	MOVQ CX, 0xd0(SP)																																									
  update-tier.go:135	0x6006d2		488b4608		MOVQ 0x8(SI), AX																																									
  update-tier.go:135	0x6006d6		48898424e0010000	MOVQ AX, 0x1e0(SP)																																									
  update-tier.go:136	0x6006de		488b4918		MOVQ 0x18(CX), CX																																									
  update-tier.go:136	0x6006e2		ffd1			CALL CX																																											
  update-tier.go:136	0x6006e4		48898424a8010000	MOVQ AX, 0x1a8(SP)																																									
  update-tier.go:139	0x6006ec		4883bc240803000000	CMPQ 0x308(SP), $0x0																																									
  update-tier.go:139	0x6006f5		741d			JE 0x600714																																										
  update-tier.go:162	0x6006f7		488b8c24d0000000	MOVQ 0xd0(SP), CX																																									
  update-tier.go:145	0x6006ff		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:169	0x600707		4c8ba424e0010000	MOVQ 0x1e0(SP), R12																																									
  update-tier.go:139	0x60070f		e9f7000000		JMP 0x60080b																																										
  update-tier.go:140	0x600714		488b9424d0000000	MOVQ 0xd0(SP), DX																																									
  update-tier.go:140	0x60071c		0f1f4000		NOPL 0(AX)																																										
  update-tier.go:140	0x600720		4885d2			TESTQ DX, DX																																										
  update-tier.go:140	0x600723		7417			JE 0x60073c																																										
  update-tier.go:140	0x600725		488b5a08		MOVQ 0x8(DX), BX																																									
  update-tier.go:140	0x600729		4c8b0520bfc000		MOVQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.4(SB), R8																																
  update-tier.go:140	0x600730		4d8b08			MOVQ 0(R8), R9																																										
  update-tier.go:140	0x600733		448b5210		MOVL 0x10(DX), R10																																									
  update-tier.go:140	0x600737		e9291b0000		JMP 0x602265																																										
  update-tier.go:135	0x60073c		4889d1			MOVQ DX, CX																																										
  update-tier.go:135	0x60073f		90			NOPL																																											
  update-tier.go:140	0x600740		4885d2			TESTQ DX, DX																																										
  update-tier.go:140	0x600743		0f84b2000000		JE 0x6007fb																																										
  update-tier.go:141	0x600749		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:141	0x600751		4c8b4268		MOVQ 0x68(DX), R8																																									
  update-tier.go:141	0x600755		488b5a60		MOVQ 0x60(DX), BX																																									
  update-tier.go:141	0x600759		48ffc3			INCQ BX																																											
  update-tier.go:141	0x60075c		4c8b4a58		MOVQ 0x58(DX), R9																																									
  update-tier.go:141	0x600760		4939d8			CMPQ R8, BX																																										
  update-tier.go:141	0x600763		7353			JAE 0x6007b8																																										
  update-tier.go:141	0x600765		4c89c8			MOVQ R9, AX																																										
  update-tier.go:141	0x600768		4c89c1			MOVQ R8, CX																																										
  update-tier.go:141	0x60076b		bf01000000		MOVL $0x1, DI																																										
  update-tier.go:141	0x600770		488d35c9b7b300		LEAQ 0xb3b7c9(IP), SI																																									
  update-tier.go:141	0x600777		e8041fe9ff		CALL runtime.growslice(SB)																																								
  update-tier.go:141	0x60077c		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:141	0x600784		48894a68		MOVQ CX, 0x68(DX)																																									
  update-tier.go:141	0x600788		833dd12dc40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:141	0x60078f		7410			JE 0x6007a1																																										
  update-tier.go:141	0x600791		4c8b4258		MOVQ 0x58(DX), R8																																									
  update-tier.go:141	0x600795		e8866be9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  update-tier.go:141	0x60079a		498903			MOVQ AX, 0(R11)																																										
  update-tier.go:141	0x60079d		4d894308		MOVQ R8, 0x8(R11)																																									
  update-tier.go:141	0x6007a1		48894258		MOVQ AX, 0x58(DX)																																									
  update-tier.go:141	0x6007a5		488b8c24d0000000	MOVQ 0xd0(SP), CX																																									
  update-tier.go:141	0x6007ad		4989c1			MOVQ AX, R9																																										
  update-tier.go:148	0x6007b0		488b8424a8010000	MOVQ 0x1a8(SP), AX																																									
  update-tier.go:141	0x6007b8		48895a60		MOVQ BX, 0x60(DX)																																									
  update-tier.go:141	0x6007bc		4c8d43ff		LEAQ -0x1(BX), R8																																									
  update-tier.go:141	0x6007c0		49c1e004		SHLQ $0x4, R8																																										
  update-tier.go:141	0x6007c4		4b890c01		MOVQ CX, 0(R9)(R8*1)																																									
  update-tier.go:141	0x6007c8		833d912dc40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:141	0x6007cf		750a			JNE 0x6007db																																										
  update-tier.go:141	0x6007d1		4c8ba424e0010000	MOVQ 0x1e0(SP), R12																																									
  update-tier.go:141	0x6007d9		eb19			JMP 0x6007f4																																										
  update-tier.go:141	0x6007db		4f8b540108		MOVQ 0x8(R9)(R8*1), R10																																									
  update-tier.go:141	0x6007e0		e83b6be9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  update-tier.go:141	0x6007e5		4c8ba424e0010000	MOVQ 0x1e0(SP), R12																																									
  update-tier.go:141	0x6007ed		4d8923			MOVQ R12, 0(R11)																																									
  update-tier.go:141	0x6007f0		4d895308		MOVQ R10, 0x8(R11)																																									
  update-tier.go:141	0x6007f4		4f89640108		MOVQ R12, 0x8(R9)(R8*1)																																									
  update-tier.go:141	0x6007f9		eb10			JMP 0x60080b																																										
  update-tier.go:145	0x6007fb		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:169	0x600803		4c8ba424e0010000	MOVQ 0x1e0(SP), R12																																									
  update-tier.go:145	0x60080b		4c8b8290000000		MOVQ 0x90(DX), R8																																									
  update-tier.go:145	0x600812		4d85c0			TESTQ R8, R8																																										
  update-tier.go:145	0x600815		750b			JNE 0x600822																																										
  update-tier.go:145	0x600817		4883baa800000000	CMPQ 0xa8(DX), $0x0																																									
  update-tier.go:145	0x60081f		90			NOPL																																											
  update-tier.go:145	0x600820		7479			JE 0x60089b																																										
  update-tier.go:148	0x600822		f20f104018		MOVSD_XMM 0x18(AX), X0																																									
  update-tier.go:148	0x600827		f20f104820		MOVSD_XMM 0x20(AX), X1																																									
  observers-simd.go:14	0x60082c		803d1c21c40000		CMPB github.com/burntcustard/unicorn-mining-co/src/server/simulation.vectorObservers(SB), $0x0																																
  observers-simd.go:14	0x600833		7450			JE 0x600885																																										
  observers-simd.go:14	0x600835		4983f808		CMPQ R8, $0x8																																										
  observers-simd.go:14	0x600839		7c4a			JL 0x600885																																										
  observers-simd.go:18	0x60083b		488b842460010000	MOVQ 0x160(SP), AX																																									
  observers-simd.go:18	0x600843		f20f10942498000000	MOVSD_XMM 0x98(SP), X2																																									
  observers-simd.go:18	0x60084c		e8ef15ffff		CALL github.com/burntcustard/unicorn-mining-co/src/server/simulation.(*movementSchedule).withinObserversVector(SB)																													
  update-tier.go:162	0x600851		488b8c24d0000000	MOVQ 0xd0(SP), CX																																									
  update-tier.go:154	0x600859		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:169	0x600861		4c8ba424e0010000	MOVQ 0x1e0(SP), R12																																									
  observers.go:7	0x600869		f20f10942498000000	MOVSD_XMM 0x98(SP), X2																																									
  update-tier.go:148	0x600872		4189c0			MOVL AX, R8																																										
  update-tier.go:155	0x600875		488b8424a8010000	MOVQ 0x1a8(SP), AX																																									
  update-tier.go:155	0x60087d		0f1f00			NOPL 0(AX)																																										
  update-tier.go:148	0x600880		e987190000		JMP 0x60220c																																										
  update-tier.go:145	0x600885		4c8b8a88000000		MOVQ 0x88(DX), R9																																									
  observers-simd.go:15	0x60088c		90			NOPL																																											
  observers.go:6	0x60088d		f20f10942498000000	MOVSD_XMM 0x98(SP), X2																																									
  observers.go:6	0x600896		e937190000		JMP 0x6021d2																																										
  update-tier.go:153	0x60089b		488b9c2458010000	MOVQ 0x158(SP), BX																																									
  update-tier.go:153	0x6008a3		488bb42438010000	MOVQ 0x138(SP), SI																																									
  update-tier.go:153	0x6008ab		488bbc2440010000	MOVQ 0x140(SP), DI																																									
  update-tier.go:153	0x6008b3		4c8b842458010000	MOVQ 0x158(SP), R8																																									
  update-tier.go:153	0x6008bb		0f1f440000		NOPL 0(AX)(AX*1)																																									
  update-tier.go:153	0x6008c0		4c39c3			CMPQ BX, R8																																										
  update-tier.go:153	0x6008c3		754a			JNE 0x60090f																																										
  update-tier.go:153	0x6008c5		4c8b8c2440010000	MOVQ 0x140(SP), R9																																									
  update-tier.go:153	0x6008cd		4c39cf			CMPQ DI, R9																																										
  update-tier.go:153	0x6008d0		7533			JNE 0x600905																																										
  update-tier.go:153	0x6008d2		4c8b942438010000	MOVQ 0x138(SP), R10																																									
  update-tier.go:153	0x6008da		4c39d6			CMPQ SI, R10																																										
  update-tier.go:153	0x6008dd		7540			JNE 0x60091f																																										
  update-tier.go:162	0x6008df		4989f9			MOVQ DI, R9																																										
  update-tier.go:162	0x6008e2		4989d8			MOVQ BX, R8																																										
  update-tier.go:162	0x6008e5		4989f2			MOVQ SI, R10																																										
  update-tier.go:164	0x6008e8		488b9c2438010000	MOVQ 0x138(SP), BX																																									
  update-tier.go:164	0x6008f0		488bb42440010000	MOVQ 0x140(SP), SI																																									
  update-tier.go:164	0x6008f8		488bbc2458010000	MOVQ 0x158(SP), DI																																									
  update-tier.go:153	0x600900		e9a3000000		JMP 0x6009a8																																										
  update-tier.go:153	0x600905		4c8b942438010000	MOVQ 0x138(SP), R10																																									
  update-tier.go:153	0x60090d		eb10			JMP 0x60091f																																										
  update-tier.go:153	0x60090f		4c8b8c2440010000	MOVQ 0x140(SP), R9																																									
  update-tier.go:153	0x600917		4c8b942438010000	MOVQ 0x138(SP), R10																																									
  update-tier.go:154	0x60091f		4c8b9aa0000000		MOVQ 0xa0(DX), R11																																									
  update-tier.go:154	0x600926		4c8baaa8000000		MOVQ 0xa8(DX), R13																																									
  update-tier.go:154	0x60092d		eb18			JMP 0x600947																																										
  update-tier.go:154	0x60092f		660f1f840000000000	NOPW 0(AX)(AX*1)																																									
  update-tier.go:154	0x600938		0f1f840000000000	NOPL 0(AX)(AX*1)																																									
  update-tier.go:154	0x600940		4d8d5f18		LEAQ 0x18(R15), R11																																									
  update-tier.go:154	0x600944		49ffcd			DECQ R13																																										
  update-tier.go:154	0x600947		4d85ed			TESTQ R13, R13																																										
  update-tier.go:154	0x60094a		7e3b			JLE 0x600987																																										
  update-tier.go:154	0x60094c		4d89df			MOVQ R11, R15																																										
  update-tier.go:154	0x60094f		f2410f104b10		MOVSD_XMM 0x10(R11), X1																																									
  update-tier.go:155	0x600955		f20f105018		MOVSD_XMM 0x18(AX), X2																																									
  update-tier.go:155	0x60095a		f20f105820		MOVSD_XMM 0x20(AX), X3																																									
  vector.go:63		0x60095f		f2410f5c13		SUBSD 0(R11), X2																																									
  vector.go:63		0x600964		f2410f5c5b08		SUBSD 0x8(R11), X3																																									
  vector.go:63		0x60096a		f20f59d2		MULSD X2, X2																																										
  vector.go:63		0x60096e		f20f59db		MULSD X3, X3																																										
  vector.go:63		0x600972		f20f58da		ADDSD X2, X3																																										
  update-tier.go:155	0x600976		660f2ecb		UCOMISD X3, X1																																										
  update-tier.go:155	0x60097a		72c4			JB 0x600940																																										
  update-tier.go:130	0x60097c		4c89d3			MOVQ R10, BX																																										
  update-tier.go:130	0x60097f		4c89ce			MOVQ R9, SI																																										
  update-tier.go:130	0x600982		4c89c7			MOVQ R8, DI																																										
  update-tier.go:157	0x600985		eb21			JMP 0x6009a8																																										
  update-tier.go:157	0x600987		4989f2			MOVQ SI, R10																																										
  update-tier.go:157	0x60098a		4989f9			MOVQ DI, R9																																										
  update-tier.go:157	0x60098d		4989d8			MOVQ BX, R8																																										
  update-tier.go:164	0x600990		488b9c2438010000	MOVQ 0x138(SP), BX																																									
  update-tier.go:164	0x600998		488bb42440010000	MOVQ 0x140(SP), SI																																									
  update-tier.go:164	0x6009a0		488bbc2458010000	MOVQ 0x158(SP), DI																																									
  update-tier.go:162	0x6009a8		4885c9			TESTQ CX, CX																																										
  update-tier.go:162	0x6009ab		7418			JE 0x6009c5																																										
  update-tier.go:162	0x6009ad		4c8b5908		MOVQ 0x8(CX), R11																																									
  update-tier.go:162	0x6009b1		4c8b2db8bcc000		MOVQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.5(SB), R13																																
  update-tier.go:162	0x6009b8		4d8b7d00		MOVQ 0(R13), R15																																									
  update-tier.go:162	0x6009bc		448b6110		MOVL 0x10(CX), R12																																									
  update-tier.go:162	0x6009c0		e94a170000		JMP 0x60210f																																										
  update-tier.go:135	0x6009c5		4989cb			MOVQ CX, R11																																										
  update-tier.go:164	0x6009c8		4939f8			CMPQ R8, DI																																										
  update-tier.go:164	0x6009cb		7548			JNE 0x600a15																																										
  update-tier.go:164	0x6009cd		4939f1			CMPQ R9, SI																																										
  update-tier.go:164	0x6009d0		753e			JNE 0x600a10																																										
  update-tier.go:164	0x6009d2		4939da			CMPQ R10, BX																																										
  update-tier.go:164	0x6009d5		7534			JNE 0x600a0b																																										
  update-tier.go:164	0x6009d7		f20f104828		MOVSD_XMM 0x28(AX), X1																																									
  update-tier.go:164	0x6009dc		0f57d2			XORPS X2, X2																																										
  update-tier.go:164	0x6009df		660f2ed1		UCOMISD X1, X2																																										
  update-tier.go:164	0x6009e3		7533			JNE 0x600a18																																										
  update-tier.go:164	0x6009e5		7a31			JP 0x600a18																																										
  update-tier.go:164	0x6009e7		f20f104830		MOVSD_XMM 0x30(AX), X1																																									
  update-tier.go:164	0x6009ec		660f2eca		UCOMISD X2, X1																																										
  update-tier.go:164	0x6009f0		7526			JNE 0x600a18																																										
  update-tier.go:164	0x6009f2		7a24			JP 0x600a18																																										
  update-tier.go:162	0x6009f4		4885c9			TESTQ CX, CX																																										
  update-tier.go:164	0x6009f7		751f			JNE 0x600a18																																										
  update-tier.go:168	0x6009f9		4c8b8c2410010000	MOVQ 0x110(SP), R9																																									
  update-tier.go:168	0x600a01		4c8b842418010000	MOVQ 0x118(SP), R8																																									
  update-tier.go:165	0x600a09		eb0d			JMP 0x600a18																																										
  update-tier.go:165	0x600a0b		0f57d2			XORPS X2, X2																																										
  update-tier.go:164	0x600a0e		eb08			JMP 0x600a18																																										
  update-tier.go:164	0x600a10		0f57d2			XORPS X2, X2																																										
  update-tier.go:164	0x600a13		eb03			JMP 0x600a18																																										
  update-tier.go:164	0x600a15		0f57d2			XORPS X2, X2																																										
  update-tier.go:168	0x600a18		f20f1088d8000000	MOVSD_XMM 0xd8(AX), X1																																									
  update-tier.go:168	0x600a20		f20f588ae0070000	ADDSD 0x7e0(DX), X1																																									
  update-tier.go:168	0x600a28		0f57db			XORPS X3, X3																																										
  update-tier.go:168	0x600a2b		f2490f2ad8		CVTSI2SDQ R8, X3																																									
  update-tier.go:169	0x600a30		488d8c2458020000	LEAQ 0x258(SP), CX																																									
  update-tier.go:169	0x600a38		440f1139		MOVUPS X15, 0(CX)																																									
  update-tier.go:169	0x600a3c		440f117910		MOVUPS X15, 0x10(CX)																																									
  update-tier.go:169	0x600a41		440f117920		MOVUPS X15, 0x20(CX)																																									
  update-tier.go:169	0x600a46		440f117928		MOVUPS X15, 0x28(CX)																																									
  update-tier.go:169	0x600a4b		4c899c2458020000	MOVQ R11, 0x258(SP)																																									
  update-tier.go:169	0x600a53		4c89a42460020000	MOVQ R12, 0x260(SP)																																									
  update-tier.go:169	0x600a5b		4889842468020000	MOVQ AX, 0x268(SP)																																									
  update-tier.go:169	0x600a63		4c89842470020000	MOVQ R8, 0x270(SP)																																									
  update-tier.go:168	0x600a6b		f20f5ecb		DIVSD X3, X1																																										
  update-tier.go:169	0x600a6f		4d85c9			TESTQ R9, R9																																										
  update-tier.go:169	0x600a72		0f8492160000		JE 0x60210a																																										
  update-tier.go:169	0x600a78		488b842480000000	MOVQ 0x80(SP), AX																																									
  update-tier.go:169	0x600a80		4c8d4001		LEAQ 0x1(AX), R8																																									
  update-tier.go:71	0x600a84		4989c2			MOVQ AX, R10																																										
  update-tier.go:169	0x600a87		4c89c0			MOVQ R8, AX																																										
  update-tier.go:67	0x600a8a		4989d0			MOVQ DX, R8																																										
  update-tier.go:169	0x600a8d		31d2			XORL DX, DX																																										
  update-tier.go:169	0x600a8f		49f7f1			DIVQ R9																																											
  update-tier.go:169	0x600a92		4885d2			TESTQ DX, DX																																										
  update-tier.go:169	0x600a95		0f94842478020000	SETE 0x278(SP)																																										
  update-tier.go:169	0x600a9d		f20f118c2480020000	MOVSD_XMM X1, 0x280(SP)																																									
  update-tier.go:169	0x600aa6		498b90f8000000		MOVQ 0xf8(R8), DX																																									
  update-tier.go:169	0x600aad		4d8b88f0000000		MOVQ 0xf0(R8), R9																																									
  update-tier.go:169	0x600ab4		49ffc1			INCQ R9																																											
  update-tier.go:169	0x600ab7		498b80e8000000		MOVQ 0xe8(R8), AX																																									
  update-tier.go:169	0x600abe		6690			NOPW																																											
  update-tier.go:169	0x600ac0		4c39ca			CMPQ DX, R9																																										
  update-tier.go:169	0x600ac3		737f			JAE 0x600b44																																										
  update-tier.go:169	0x600ac5		4c89cb			MOVQ R9, BX																																										
  update-tier.go:169	0x600ac8		4889d1			MOVQ DX, CX																																										
  update-tier.go:169	0x600acb		bf01000000		MOVL $0x1, DI																																										
  update-tier.go:169	0x600ad0		488d35c17bb700		LEAQ 0xb77bc1(IP), SI																																									
  update-tier.go:169	0x600ad7		e8a41be9ff		CALL runtime.growslice(SB)																																								
  update-tier.go:169	0x600adc		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:169	0x600ae4		48898af8000000		MOVQ CX, 0xf8(DX)																																									
  update-tier.go:169	0x600aeb		833d6e2ac40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:169	0x600af2		7418			JE 0x600b0c																																										
  update-tier.go:169	0x600af4		488bb2e8000000		MOVQ 0xe8(DX), SI																																									
  update-tier.go:169	0x600afb		0f1f440000		NOPL 0(AX)(AX*1)																																									
  update-tier.go:169	0x600b00		e81b68e9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  update-tier.go:169	0x600b05		498903			MOVQ AX, 0(R11)																																										
  update-tier.go:169	0x600b08		49897308		MOVQ SI, 0x8(R11)																																									
  update-tier.go:169	0x600b0c		488982e8000000		MOVQ AX, 0xe8(DX)																																									
  update-tier.go:169	0x600b13		488d8c2458020000	LEAQ 0x258(SP), CX																																									
  update-tier.go:153	0x600b1b		488bb42440010000	MOVQ 0x140(SP), SI																																									
  update-tier.go:153	0x600b23		488bbc2458010000	MOVQ 0x158(SP), DI																																									
  update-tier.go:169	0x600b2b		4989d0			MOVQ DX, R8																																										
  update-tier.go:169	0x600b2e		4c8b942480000000	MOVQ 0x80(SP), R10																																									
  update-tier.go:169	0x600b36		0f57d2			XORPS X2, X2																																										
  update-tier.go:169	0x600b39		4989d9			MOVQ BX, R9																																										
  update-tier.go:153	0x600b3c		488b9c2438010000	MOVQ 0x138(SP), BX																																									
  update-tier.go:169	0x600b44		4d8988f0000000		MOVQ R9, 0xf0(R8)																																									
  update-tier.go:169	0x600b4b		496bd138		IMULQ $0x38, R9, DX																																									
  update-tier.go:169	0x600b4f		488d1402		LEAQ 0(DX)(AX*1), DX																																									
  update-tier.go:169	0x600b53		488d52c8		LEAQ -0x38(DX), DX																																									
  update-tier.go:169	0x600b57		833d022ac40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:169	0x600b5e		6690			NOPW																																											
  update-tier.go:169	0x600b60		0f84ecfaffff		JE 0x600652																																										
  update-tier.go:169	0x600b66		4889942400020000	MOVQ DX, 0x200(SP)																																									
  update-tier.go:169	0x600b6e		488d05237bb700		LEAQ 0xb77b23(IP), AX																																									
  update-tier.go:169	0x600b75		4889d3			MOVQ DX, BX																																										
  update-tier.go:169	0x600b78		e8434ce2ff		CALL runtime.wbMove(SB)																																									
  update-tier.go:169	0x600b7d		488d8c2458020000	LEAQ 0x258(SP), CX																																									
  update-tier.go:169	0x600b85		488b942400020000	MOVQ 0x200(SP), DX																																									
  update-tier.go:153	0x600b8d		488b9c2438010000	MOVQ 0x138(SP), BX																																									
  update-tier.go:153	0x600b95		488bb42440010000	MOVQ 0x140(SP), SI																																									
  update-tier.go:153	0x600b9d		488bbc2458010000	MOVQ 0x158(SP), DI																																									
  update-tier.go:181	0x600ba5		4c8b842400030000	MOVQ 0x300(SP), R8																																									
  update-tier.go:169	0x600bad		4c8b942480000000	MOVQ 0x80(SP), R10																																									
  update-tier.go:169	0x600bb5		0f57d2			XORPS X2, X2																																										
  update-tier.go:169	0x600bb8		e995faffff		JMP 0x600652																																										
  update-tier.go:172	0x600bbd		4883bc240803000000	CMPQ 0x308(SP), $0x0																																									
  update-tier.go:172	0x600bc6		7445			JE 0x600c0d																																										
  update-tier.go:173	0x600bc8		488d3511360000		LEAQ github.com/burntcustard/unicorn-mining-co/src/server/simulation.UpdateEntities.func2(SB), SI																															
  update-tier.go:173	0x600bcf		4889b424c8020000	MOVQ SI, 0x2c8(SP)																																									
  update-tier.go:173	0x600bd7		488bb42460010000	MOVQ 0x160(SP), SI																																									
  update-tier.go:173	0x600bdf		4889b424d0020000	MOVQ SI, 0x2d0(SP)																																									
  update-tier.go:173	0x600be7		488b8218010000		MOVQ 0x118(DX), AX																																									
  update-tier.go:173	0x600bee		488d1dabb45700		LEAQ github.com/burntcustard/unicorn-mining-co/src/server/utilities..dict.OrderedMap[int64,github.com/burntcustard/unicorn-mining-co/src/server/simulation.Entity](SB), BX																						
  update-tier.go:173	0x600bf5		488d8c24c8020000	LEAQ 0x2c8(SP), CX																																									
  update-tier.go:173	0x600bfd		0f1f00			NOPL 0(AX)																																										
  update-tier.go:173	0x600c00		e8bb3f0000		CALL github.com/burntcustard/unicorn-mining-co/src/server/utilities.(*OrderedMap[go.shape.int64,go.shape.interface { Base() *github.com/burntcustard/unicorn-mining-co/src/server/simulation.GameObject; Hitbox() []*github.com/burntcustard/unicorn-mining-co/src/server/collision.Collider; MaxSpeed() float64; Update(float64) }]).ForEach(SB)	
  update-tier.go:181	0x600c05		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:181	0x600c0d		48837a5800		CMPQ 0x58(DX), $0x0																																									
  update-tier.go:181	0x600c12		7525			JNE 0x600c39																																										
  update-tier.go:182	0x600c14		440f117a60		MOVUPS X15, 0x60(DX)																																									
  update-tier.go:182	0x600c19		833d4029c40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:182	0x600c20		740c			JE 0x600c2e																																										
  update-tier.go:182	0x600c22		488b7258		MOVQ 0x58(DX), SI																																									
  update-tier.go:182	0x600c26		e8d566e9ff		CALL runtime.gcWriteBarrier1(SB)																																							
  update-tier.go:182	0x600c2b		498933			MOVQ SI, 0(R11)																																										
  update-tier.go:182	0x600c2e		488d35eb1cc400		LEAQ 0xc41ceb(IP), SI																																									
  update-tier.go:182	0x600c35		48897258		MOVQ SI, 0x58(DX)																																									
  update-tier.go:185	0x600c39		488b7260		MOVQ 0x60(DX), SI																																									
  update-tier.go:185	0x600c3d		488b7a68		MOVQ 0x68(DX), DI																																									
  update-tier.go:185	0x600c41		4c8b4258		MOVQ 0x58(DX), R8																																									
  update-tier.go:185	0x600c45		4889b228010000		MOVQ SI, 0x128(DX)																																									
  update-tier.go:185	0x600c4c		4889ba30010000		MOVQ DI, 0x130(DX)																																									
  update-tier.go:185	0x600c53		833d0629c40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:185	0x600c5a		7413			JE 0x600c6f																																										
  update-tier.go:185	0x600c5c		488bb220010000		MOVQ 0x120(DX), SI																																									
  update-tier.go:185	0x600c63		e8b866e9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  update-tier.go:185	0x600c68		4d8903			MOVQ R8, 0(R11)																																										
  update-tier.go:185	0x600c6b		49897308		MOVQ SI, 0x8(R11)																																									
  update-tier.go:185	0x600c6f		4c898220010000		MOVQ R8, 0x120(DX)																																									
  update-tier.go:186	0x600c76		488bb208010000		MOVQ 0x108(DX), SI																																									
  update-tier.go:186	0x600c7d		0f1f00			NOPL 0(AX)																																										
  update-tier.go:186	0x600c80		4885f6			TESTQ SI, SI																																										
  update-tier.go:186	0x600c83		7418			JE 0x600c9d																																										
  update-tier.go:186	0x600c85		486bde38		IMULQ $0x38, SI, BX																																									
  update-tier.go:186	0x600c89		488b8200010000		MOVQ 0x100(DX), AX																																									
  update-tier.go:186	0x600c90		e8ebd8e8ff		CALL runtime.memclrHasPointers(SB)																																							
  update-tier.go:187	0x600c95		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:187	0x600c9d		48c7820801000000000000	MOVQ $0x0, 0x108(DX)																																									
  update-tier.go:189	0x600ca8		488b7258		MOVQ 0x58(DX), SI																																									
  update-tier.go:189	0x600cac		488b7a60		MOVQ 0x60(DX), DI																																									
  update-tier.go:189	0x600cb0		eb4e			JMP 0x600d00																																										
  update-tier.go:189	0x600cb2		660f1f840000000000	NOPW 0(AX)(AX*1)																																									
  update-tier.go:189	0x600cbb		0f1f440000		NOPL 0(AX)(AX*1)																																									
  update-tier.go:197	0x600cc0		450f1030		MOVUPS 0(R8), X14																																									
  update-tier.go:197	0x600cc4		440f1133		MOVUPS X14, 0(BX)																																									
  update-tier.go:197	0x600cc8		450f107010		MOVUPS 0x10(R8), X14																																									
  update-tier.go:197	0x600ccd		440f117310		MOVUPS X14, 0x10(BX)																																									
  update-tier.go:197	0x600cd2		450f107020		MOVUPS 0x20(R8), X14																																									
  update-tier.go:197	0x600cd7		440f117320		MOVUPS X14, 0x20(BX)																																									
  update-tier.go:197	0x600cdc		450f107028		MOVUPS 0x28(R8), X14																																									
  update-tier.go:197	0x600ce1		440f117328		MOVUPS X14, 0x28(BX)																																									
  update-tier.go:189	0x600ce6		488bb42408020000	MOVQ 0x208(SP), SI																																									
  update-tier.go:189	0x600cee		4883c610		ADDQ $0x10, SI																																										
  update-tier.go:189	0x600cf2		488bbc2440010000	MOVQ 0x140(SP), DI																																									
  update-tier.go:189	0x600cfa		48ffcf			DECQ DI																																											
  update-tier.go:189	0x600cfd		0f1f00			NOPL 0(AX)																																										
  update-tier.go:189	0x600d00		4885ff			TESTQ DI, DI																																										
  update-tier.go:189	0x600d03		0f8e31020000		JLE 0x600f3a																																										
  update-tier.go:189	0x600d09		4889bc2440010000	MOVQ DI, 0x140(SP)																																									
  update-tier.go:189	0x600d11		4889b42408020000	MOVQ SI, 0x208(SP)																																									
  update-tier.go:189	0x600d19		488b0e			MOVQ 0(SI), CX																																										
  update-tier.go:189	0x600d1c		48898c24c8000000	MOVQ CX, 0xc8(SP)																																									
  update-tier.go:189	0x600d24		488b4608		MOVQ 0x8(SI), AX																																									
  update-tier.go:189	0x600d28		48898424d8010000	MOVQ AX, 0x1d8(SP)																																									
  update-tier.go:190	0x600d30		488b4918		MOVQ 0x18(CX), CX																																									
  update-tier.go:190	0x600d34		ffd1			CALL CX																																											
  update-tier.go:190	0x600d36		488b8c24c8000000	MOVQ 0xc8(SP), CX																																									
  update-tier.go:190	0x600d3e		6690			NOPW																																											
  update-tier.go:190	0x600d40		4885c9			TESTQ CX, CX																																										
  update-tier.go:190	0x600d43		0f84b5130000		JE 0x6020fe																																										
  update-tier.go:190	0x600d49		488b5908		MOVQ 0x8(CX), BX																																									
  update-tier.go:190	0x600d4d		488b153cb9c000		MOVQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.6(SB), DX																																
  update-tier.go:190	0x600d54		4c8b02			MOVQ 0(DX), R8																																										
  update-tier.go:190	0x600d57		448b4910		MOVL 0x10(CX), R9																																									
  update-tier.go:190	0x600d5b		4d89ca			MOVQ R9, R10																																										
  update-tier.go:190	0x600d5e		4d21c1			ANDQ R8, R9																																										
  update-tier.go:190	0x600d61		49c1e104		SHLQ $0x4, R9																																										
  update-tier.go:190	0x600d65		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11																																									
  update-tier.go:190	0x600d6a		4939db			CMPQ R11, BX																																										
  update-tier.go:190	0x600d6d		7433			JE 0x600da2																																										
  update-tier.go:190	0x600d6f		4d8d4a01		LEAQ 0x1(R10), R9																																									
  update-tier.go:190	0x600d73		4d85db			TESTQ R11, R11																																										
  update-tier.go:190	0x600d76		75e3			JNE 0x600d5b																																										
  update-tier.go:190	0x600d78		48898424f0010000	MOVQ AX, 0x1f0(SP)																																									
  update-tier.go:190	0x600d80		488d0509b9c000		LEAQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.6(SB), AX																																
  update-tier.go:190	0x600d87		e8f4c8e1ff		CALL runtime.typeAssert(SB)																																								
  update-tier.go:190	0x600d8c		488b8c24c8000000	MOVQ 0xc8(SP), CX																																									
  update-tier.go:190	0x600d94		4889c2			MOVQ AX, DX																																										
  update-tier.go:190	0x600d97		488b8424f0010000	MOVQ 0x1f0(SP), AX																																									
  update-tier.go:190	0x600d9f		90			NOPL																																											
  update-tier.go:190	0x600da0		eb05			JMP 0x600da7																																										
  update-tier.go:190	0x600da2		4a8b540a10		MOVQ 0x10(DX)(R9*1), DX																																									
  update-tier.go:190	0x600da7		4c8d842468010000	LEAQ 0x168(SP), R8																																									
  update-tier.go:190	0x600daf		450f1138		MOVUPS X15, 0(R8)																																									
  update-tier.go:190	0x600db3		450f117810		MOVUPS X15, 0x10(R8)																																									
  update-tier.go:190	0x600db8		450f117820		MOVUPS X15, 0x20(R8)																																									
  update-tier.go:190	0x600dbd		450f117828		MOVUPS X15, 0x28(R8)																																									
  update-tier.go:190	0x600dc2		48898c2468010000	MOVQ CX, 0x168(SP)																																									
  update-tier.go:190	0x600dca		4c8b8c24d8010000	MOVQ 0x1d8(SP), R9																																									
  update-tier.go:190	0x600dd2		4c898c2470010000	MOVQ R9, 0x170(SP)																																									
  update-tier.go:190	0x600dda		4889842478010000	MOVQ AX, 0x178(SP)																																									
  update-tier.go:190	0x600de2		4889942480010000	MOVQ DX, 0x180(SP)																																									
  update-tier.go:190	0x600dea		4c898c2488010000	MOVQ R9, 0x188(SP)																																									
  update-tier.go:192	0x600df2		488b5908		MOVQ 0x8(CX), BX																																									
  update-tier.go:192	0x600df6		488b15b3b8c000		MOVQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.7(SB), DX																																
  update-tier.go:192	0x600dfd		4c8b12			MOVQ 0(DX), R10																																										
  update-tier.go:192	0x600e00		448b5910		MOVL 0x10(CX), R11																																									
  update-tier.go:192	0x600e04		4d89dc			MOVQ R11, R12																																										
  update-tier.go:192	0x600e07		4d21d3			ANDQ R10, R11																																										
  update-tier.go:192	0x600e0a		49c1e304		SHLQ $0x4, R11																																										
  update-tier.go:192	0x600e0e		4e8b6c1a08		MOVQ 0x8(DX)(R11*1), R13																																								
  update-tier.go:192	0x600e13		4939dd			CMPQ R13, BX																																										
  update-tier.go:192	0x600e16		742b			JE 0x600e43																																										
  update-tier.go:192	0x600e18		4d8d5c2401		LEAQ 0x1(R12), R11																																									
  update-tier.go:192	0x600e1d		0f1f00			NOPL 0(AX)																																										
  update-tier.go:192	0x600e20		4d85ed			TESTQ R13, R13																																										
  update-tier.go:192	0x600e23		75df			JNE 0x600e04																																										
  update-tier.go:192	0x600e25		488d0584b8c000		LEAQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.7(SB), AX																																
  update-tier.go:192	0x600e2c		e84fc8e1ff		CALL runtime.typeAssert(SB)																																								
  update-tier.go:190	0x600e31		4c8d842468010000	LEAQ 0x168(SP), R8																																									
  update-tier.go:193	0x600e39		4c8b8c24d8010000	MOVQ 0x1d8(SP), R9																																									
  update-tier.go:192	0x600e41		eb05			JMP 0x600e48																																										
  update-tier.go:192	0x600e43		4a8b441a10		MOVQ 0x10(DX)(R11*1), AX																																								
  update-tier.go:192	0x600e48		4885c0			TESTQ AX, AX																																										
  update-tier.go:192	0x600e4b		7426			JE 0x600e73																																										
  update-tier.go:193	0x600e4d		488b4818		MOVQ 0x18(AX), CX																																									
  update-tier.go:193	0x600e51		4c89c8			MOVQ R9, AX																																										
  update-tier.go:193	0x600e54		ffd1			CALL CX																																											
  update-tier.go:194	0x600e56		f20f59c0		MULSD X0, X0																																										
  update-tier.go:194	0x600e5a		f20f11842490010000	MOVSD_XMM X0, 0x190(SP)																																									
  update-tier.go:194	0x600e63		c684249801000001	MOVB $0x1, 0x198(SP)																																									
  update-tier.go:190	0x600e6b		4c8d842468010000	LEAQ 0x168(SP), R8																																									
  update-tier.go:197	0x600e73		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:197	0x600e7b		488b8a10010000		MOVQ 0x110(DX), CX																																									
  update-tier.go:197	0x600e82		488b9a08010000		MOVQ 0x108(DX), BX																																									
  update-tier.go:197	0x600e89		48ffc3			INCQ BX																																											
  update-tier.go:197	0x600e8c		488b8200010000		MOVQ 0x100(DX), AX																																									
  update-tier.go:197	0x600e93		4839d9			CMPQ CX, BX																																										
  update-tier.go:197	0x600e96		734c			JAE 0x600ee4																																										
  update-tier.go:197	0x600e98		bf01000000		MOVL $0x1, DI																																										
  update-tier.go:197	0x600e9d		488d356c15b700		LEAQ 0xb7156c(IP), SI																																									
  update-tier.go:197	0x600ea4		e8d717e9ff		CALL runtime.growslice(SB)																																								
  update-tier.go:197	0x600ea9		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:197	0x600eb1		48898a10010000		MOVQ CX, 0x110(DX)																																									
  update-tier.go:197	0x600eb8		833da126c40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:197	0x600ebf		90			NOPL																																											
  update-tier.go:197	0x600ec0		7413			JE 0x600ed5																																										
  update-tier.go:197	0x600ec2		488bb200010000		MOVQ 0x100(DX), SI																																									
  update-tier.go:197	0x600ec9		e85264e9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  update-tier.go:197	0x600ece		498903			MOVQ AX, 0(R11)																																										
  update-tier.go:197	0x600ed1		49897308		MOVQ SI, 0x8(R11)																																									
  update-tier.go:197	0x600ed5		48898200010000		MOVQ AX, 0x100(DX)																																									
  update-tier.go:190	0x600edc		4c8d842468010000	LEAQ 0x168(SP), R8																																									
  update-tier.go:197	0x600ee4		48899a08010000		MOVQ BX, 0x108(DX)																																									
  update-tier.go:197	0x600eeb		486bf338		IMULQ $0x38, BX, SI																																									
  update-tier.go:197	0x600eef		488d1c06		LEAQ 0(SI)(AX*1), BX																																									
  update-tier.go:197	0x600ef3		488d5bc8		LEAQ -0x38(BX), BX																																									
  update-tier.go:197	0x600ef7		833d6226c40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:197	0x600efe		6690			NOPW																																											
  update-tier.go:197	0x600f00		0f84bafdffff		JE 0x600cc0																																										
  update-tier.go:197	0x600f06		48899c24e8010000	MOVQ BX, 0x1e8(SP)																																									
  update-tier.go:197	0x600f0e		488d05fb14b700		LEAQ 0xb714fb(IP), AX																																									
  update-tier.go:197	0x600f15		4c89c1			MOVQ R8, CX																																										
  update-tier.go:197	0x600f18		e8a348e2ff		CALL runtime.wbMove(SB)																																									
  update-tier.go:200	0x600f1d		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:197	0x600f25		488b9c24e8010000	MOVQ 0x1e8(SP), BX																																									
  update-tier.go:190	0x600f2d		4c8d842468010000	LEAQ 0x168(SP), R8																																									
  update-tier.go:197	0x600f35		e986fdffff		JMP 0x600cc0																																										
  update-tier.go:200	0x600f3a		4883ba0001000000	CMPQ 0x100(DX), $0x0																																									
  update-tier.go:200	0x600f42		7532			JNE 0x600f76																																										
  update-tier.go:201	0x600f44		440f11ba08010000	MOVUPS X15, 0x108(DX)																																									
  update-tier.go:201	0x600f4c		833d0d26c40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:201	0x600f53		7413			JE 0x600f68																																										
  update-tier.go:201	0x600f55		488bb200010000		MOVQ 0x100(DX), SI																																									
  update-tier.go:201	0x600f5c		0f1f4000		NOPL 0(AX)																																										
  update-tier.go:201	0x600f60		e89b63e9ff		CALL runtime.gcWriteBarrier1(SB)																																							
  update-tier.go:201	0x600f65		498933			MOVQ SI, 0(R11)																																										
  update-tier.go:201	0x600f68		488d35b119c400		LEAQ 0xc419b1(IP), SI																																									
  update-tier.go:201	0x600f6f		4889b200010000		MOVQ SI, 0x100(DX)																																									
  update-tier.go:204	0x600f76		488bb208010000		MOVQ 0x108(DX), SI																																									
  update-tier.go:204	0x600f7d		488bba10010000		MOVQ 0x110(DX), DI																																									
  update-tier.go:204	0x600f84		4c8b8200010000		MOVQ 0x100(DX), R8																																									
  update-tier.go:204	0x600f8b		4889b240010000		MOVQ SI, 0x140(DX)																																									
  update-tier.go:204	0x600f92		4889ba48010000		MOVQ DI, 0x148(DX)																																									
  update-tier.go:204	0x600f99		833dc025c40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:204	0x600fa0		7413			JE 0x600fb5																																										
  update-tier.go:204	0x600fa2		488bb238010000		MOVQ 0x138(DX), SI																																									
  update-tier.go:204	0x600fa9		e87263e9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  update-tier.go:204	0x600fae		4d8903			MOVQ R8, 0(R11)																																										
  update-tier.go:204	0x600fb1		49897308		MOVQ SI, 0x8(R11)																																									
  update-tier.go:204	0x600fb5		4c898238010000		MOVQ R8, 0x138(DX)																																									
  update-tier.go:206	0x600fbc		31f6			XORL SI, SI																																										
  update-tier.go:206	0x600fbe		31ff			XORL DI, DI																																										
  update-tier.go:206	0x600fc0		4c8b842458010000	MOVQ 0x158(SP), R8																																									
  update-tier.go:206	0x600fc8		f20f108424f0000000	MOVSD_XMM 0xf0(SP), X0																																									
  update-tier.go:206	0x600fd1		eb03			JMP 0x600fd6																																										
  update-tier.go:206	0x600fd3		48ffc7			INCQ DI																																											
  update-tier.go:206	0x600fd6		4c39c7			CMPQ DI, R8																																										
  update-tier.go:206	0x600fd9		0f8d53010000		JGE 0x601132																																										
  update-tier.go:206	0x600fdf		4889bc2488000000	MOVQ DI, 0x88(SP)																																									
  update-tier.go:207	0x600fe7		4c8b8af0000000		MOVQ 0xf0(DX), R9																																									
  update-tier.go:207	0x600fee		4c898c2440010000	MOVQ R9, 0x140(SP)																																									
  update-tier.go:207	0x600ff6		4531d2			XORL R10, R10																																										
  update-tier.go:207	0x600ff9		eb08			JMP 0x601003																																										
  update-tier.go:207	0x600ffb		0f1f440000		NOPL 0(AX)(AX*1)																																									
  update-tier.go:207	0x601000		49ffc2			INCQ R10																																										
  update-tier.go:207	0x601003		4d39ca			CMPQ R10, R9																																										
  update-tier.go:207	0x601006		7dcb			JGE 0x600fd3																																										
  update-tier.go:208	0x601008		4c8b9af0000000		MOVQ 0xf0(DX), R11																																									
  update-tier.go:208	0x60100f		4d39da			CMPQ R10, R11																																										
  update-tier.go:208	0x601012		0f83e1100000		JAE 0x6020f9																																										
  update-tier.go:208	0x601018		4c8b9ae8000000		MOVQ 0xe8(DX), R11																																									
  update-tier.go:208	0x60101f		4d6be238		IMULQ $0x38, R10, R12																																									
  update-tier.go:209	0x601023		4f8b6c2310		MOVQ 0x10(R11)(R12*1), R13																																								
  update-tier.go:209	0x601028		4f8b3c23		MOVQ 0(R11)(R12*1), R15																																									
  update-tier.go:209	0x60102c		4b8b442308		MOVQ 0x8(R11)(R12*1), AX																																								
  update-tier.go:211	0x601031		4180bd9100000000	CMPB 0x91(R13), $0x0																																									
  update-tier.go:211	0x601039		7407			JE 0x601042																																										
  update-tier.go:211	0x60103b		0f57d2			XORPS X2, X2																																										
  update-tier.go:211	0x60103e		6690			NOPW																																											
  update-tier.go:212	0x601040		ebbe			JMP 0x601000																																										
  update-tier.go:215	0x601042		4885ff			TESTQ DI, DI																																										
  update-tier.go:215	0x601045		7516			JNE 0x60105d																																										
  update-tier.go:216	0x601047		f2410f108dd8000000	MOVSD_XMM 0xd8(R13), X1																																									
  update-tier.go:216	0x601050		f20f58c8		ADDSD X0, X1																																										
  update-tier.go:216	0x601054		f2410f118dd8000000	MOVSD_XMM X1, 0xd8(R13)																																									
  update-tier.go:219	0x60105d		430fb64c2320		MOVZX 0x20(R11)(R12*1), CX																																								
  update-tier.go:219	0x601063		84c9			TESTL CL, CL																																										
  update-tier.go:219	0x601065		0f84bf000000		JE 0x60112a																																										
  update-tier.go:219	0x60106b		4b8b4c1c18		MOVQ 0x18(R12)(R11*1), CX																																								
  update-tier.go:219	0x601070		4839f9			CMPQ CX, DI																																										
  update-tier.go:219	0x601073		0f8eb1000000		JLE 0x60112a																																										
  update-tier.go:223	0x601079		f2410f108dd8000000	MOVSD_XMM 0xd8(R13), X1																																									
  update-tier.go:223	0x601082		0f57d2			XORPS X2, X2																																										
  update-tier.go:223	0x601085		660f2ed1		UCOMISD X1, X2																																										
  update-tier.go:223	0x601089		0f8371ffffff		JAE 0x601000																																										
  update-tier.go:208	0x60108f		4c899c2400020000	MOVQ R11, 0x200(SP)																																									
  update-tier.go:207	0x601097		4c899424b0000000	MOVQ R10, 0xb0(SP)																																									
  update-tier.go:209	0x60109f		4c89ac24a0010000	MOVQ R13, 0x1a0(SP)																																									
  update-tier.go:209	0x6010a7		4c89bc24c0000000	MOVQ R15, 0xc0(SP)																																									
  update-tier.go:209	0x6010af		48898424d0010000	MOVQ AX, 0x1d0(SP)																																									
  update-tier.go:207	0x6010b7		408874244f		MOVB SI, 0x4f(SP)																																									
  update-tier.go:208	0x6010bc		4c89a42438010000	MOVQ R12, 0x138(SP)																																									
  update-tier.go:227	0x6010c4		f2430f105c2328		MOVSD_XMM 0x28(R11)(R12*1), X3																																								
  update-tier.go:227	0x6010cb		0f10e1			MOVUPS X1, X4																																										
  update-tier.go:227	0x6010ce		f20f5dcb		MINSD X3, X1																																										
  update-tier.go:227	0x6010d2		0f10d9			MOVUPS X1, X3																																										
  update-tier.go:227	0x6010d5		f20f5dcc		MINSD X4, X1																																										
  update-tier.go:227	0x6010d9		660febd9		POR X1, X3																																										
  update-tier.go:228	0x6010dd		0f10c8			MOVUPS X0, X1																																										
  update-tier.go:228	0x6010e0		f20f5ccc		SUBSD X4, X1																																										
  update-tier.go:228	0x6010e4		f20f118c24e0000000	MOVSD_XMM X1, 0xe0(SP)																																									
  update-tier.go:229	0x6010ed		f20f5ce3		SUBSD X3, X4																																										
  update-tier.go:229	0x6010f1		f2410f11a5d8000000	MOVSD_XMM X4, 0xd8(R13)																																									
  update-tier.go:230	0x6010fa		f20f58d9		ADDSD X1, X3																																										
  update-tier.go:230	0x6010fe		f20f119c24d8000000	MOVSD_XMM X3, 0xd8(SP)																																									
  update-tier.go:232	0x601107		4d85ff			TESTQ R15, R15																																										
  update-tier.go:232	0x60110a		7419			JE 0x601125																																										
  update-tier.go:232	0x60110c		498b5f08		MOVQ 0x8(R15), BX																																									
  update-tier.go:232	0x601110		488b0db9b5c000		MOVQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.8(SB), CX																																
  update-tier.go:232	0x601117		4c8b01			MOVQ 0(CX), R8																																										
  update-tier.go:232	0x60111a		418b5710		MOVL 0x10(R15), DX																																									
  update-tier.go:232	0x60111e		6690			NOPW																																											
  update-tier.go:232	0x601120		e9f00e0000		JMP 0x602015																																										
  update-tier.go:209	0x601125		4c89f9			MOVQ R15, CX																																										
  update-tier.go:232	0x601128		eb5a			JMP 0x601184																																										
  update-tier.go:232	0x60112a		0f57d2			XORPS X2, X2																																										
  update-tier.go:220	0x60112d		e9cefeffff		JMP 0x601000																																										
  update-tier.go:294	0x601132		440f11ba28010000	MOVUPS X15, 0x128(DX)																																									
  update-tier.go:294	0x60113a		833d1f24c40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:294	0x601141		741a			JE 0x60115d																																										
  update-tier.go:294	0x601143		488b8220010000		MOVQ 0x120(DX), AX																																									
  update-tier.go:295	0x60114a		488b8a38010000		MOVQ 0x138(DX), CX																																									
  update-tier.go:294	0x601151		e8ca61e9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  update-tier.go:294	0x601156		498903			MOVQ AX, 0(R11)																																										
  update-tier.go:295	0x601159		49894b08		MOVQ CX, 0x8(R11)																																									
  update-tier.go:294	0x60115d		48c7822001000000000000	MOVQ $0x0, 0x120(DX)																																									
  update-tier.go:295	0x601168		440f11ba40010000	MOVUPS X15, 0x140(DX)																																									
  update-tier.go:295	0x601170		48c7823801000000000000	MOVQ $0x0, 0x138(DX)																																									
  update-tier.go:296	0x60117b		4881c4f0020000		ADDQ $0x2f0, SP																																										
  update-tier.go:296	0x601182		5d			POPQ BP																																											
  update-tier.go:296	0x601183		c3			RET																																											
  update-tier.go:232	0x601184		4d85ff			TESTQ R15, R15																																										
  update-tier.go:232	0x601187		0f84be000000		JE 0x60124b																																										
  update-tier.go:232	0x60118d		4983bd7001000000	CMPQ 0x170(R13), $0x0																																									
  update-tier.go:232	0x601195		0f84b0000000		JE 0x60124b																																										
  update-tier.go:232	0x60119b		4c89bc24f8010000	MOVQ R15, 0x1f8(SP)																																									
  update-tier.go:233	0x6011a3		488d942490020000	LEAQ 0x290(SP), DX																																									
  update-tier.go:233	0x6011ab		440f113a		MOVUPS X15, 0(DX)																																									
  update-tier.go:233	0x6011af		440f117a10		MOVUPS X15, 0x10(DX)																																									
  update-tier.go:233	0x6011b4		440f117a20		MOVUPS X15, 0x20(DX)																																									
  update-tier.go:233	0x6011b9		440f117a28		MOVUPS X15, 0x28(DX)																																									
  update-tier.go:233	0x6011be		488b9c2428030000	MOVQ 0x328(SP), BX																																									
  update-tier.go:233	0x6011c6		498b9570010000		MOVQ 0x170(R13), DX																																									
  update-tier.go:233	0x6011cd		488b0a			MOVQ 0(DX), CX																																										
  update-tier.go:233	0x6011d0		488d0589b4ae00		LEAQ 0xaeb489(IP), AX																																									
  update-tier.go:233	0x6011d7		e884e4e0ff		CALL runtime.mapaccess2_fast64(SB)																																							
  update-tier.go:233	0x6011dc		488d942490020000	LEAQ 0x290(SP), DX																																									
  update-tier.go:233	0x6011e4		440f1030		MOVUPS 0(AX), X14																																									
  update-tier.go:233	0x6011e8		440f1132		MOVUPS X14, 0(DX)																																									
  update-tier.go:233	0x6011ec		440f107010		MOVUPS 0x10(AX), X14																																									
  update-tier.go:233	0x6011f1		440f117210		MOVUPS X14, 0x10(DX)																																									
  update-tier.go:233	0x6011f6		440f107020		MOVUPS 0x20(AX), X14																																									
  update-tier.go:233	0x6011fb		440f117220		MOVUPS X14, 0x20(DX)																																									
  update-tier.go:233	0x601200		440f107028		MOVUPS 0x28(AX), X14																																									
  update-tier.go:233	0x601205		440f117228		MOVUPS X14, 0x28(DX)																																									
  update-tier.go:233	0x60120a		84db			TESTL BL, BL																																										
  update-tier.go:233	0x60120c		742f			JE 0x60123d																																										
  update-tier.go:234	0x60120e		488b9424b0020000	MOVQ 0x2b0(SP), DX																																									
  update-tier.go:234	0x601216		488bb424b8020000	MOVQ 0x2b8(SP), SI																																									
  update-tier.go:234	0x60121e		f20f108c24e0000000	MOVSD_XMM 0xe0(SP), X1																																									
  update-tier.go:234	0x601227		f20f108424d8000000	MOVSD_XMM 0xd8(SP), X0																																									
  update-tier.go:234	0x601230		488bbc24c0000000	MOVQ 0xc0(SP), DI																																									
  update-tier.go:234	0x601238		e9a90b0000		JMP 0x601de6																																										
  update-tier.go:234	0x60123d		f20f108424e0000000	MOVSD_XMM 0xe0(SP), X0																																									
  update-tier.go:233	0x601246		e9220b0000		JMP 0x601d6d																																										
  update-tier.go:259	0x60124b		f20f5cd9		SUBSD X1, X3																																										
  update-tier.go:259	0x60124f		4c8d3d0a05ba00		LEAQ 0xba050a(IP), R15																																									
  update-tier.go:259	0x601256		4c39f9			CMPQ CX, R15																																										
  update-tier.go:259	0x601259		7507			JNE 0x601262																																										
  update-tier.go:209	0x60125b		4889c3			MOVQ AX, BX																																										
  update-tier.go:209	0x60125e		6690			NOPW																																											
  update-tier.go:259	0x601260		eb08			JMP 0x60126a																																										
  update-tier.go:259	0x601262		4889c3			MOVQ AX, BX																																										
  update-tier.go:259	0x601265		b800000000		MOVL $0x0, AX																																										
  update-tier.go:259	0x60126a		f20f119c24e8000000	MOVSD_XMM X3, 0xe8(SP)																																									
  update-tier.go:259	0x601273		0f85ac040000		JNE 0x601725																																										
  game-object.go:213	0x601279		80b89100000000		CMPB 0x91(AX), $0x0																																									
  game-object.go:213	0x601280		0f8580090000		JNE 0x601c06																																										
  game-object.go:213	0x601286		80b89200000000		CMPB 0x92(AX), $0x0																																									
  game-object.go:213	0x60128d		0f8573090000		JNE 0x601c06																																										
  game-object.go:217	0x601293		f20f108850010000	MOVSD_XMM 0x150(AX), X1																																									
  game-object.go:217	0x60129b		660f2ed1		UCOMISD X1, X2																																										
  game-object.go:217	0x60129f		90			NOPL																																											
  game-object.go:217	0x6012a0		7506			JNE 0x6012a8																																										
  game-object.go:217	0x6012a2		0f8b9d000000		JNP 0x601345																																										
  game-object.go:218	0x6012a8		f20f10a0e0000000	MOVSD_XMM 0xe0(AX), X4																																									
  game-object.go:218	0x6012b0		f20f59cb		MULSD X3, X1																																										
  game-object.go:218	0x6012b4		f20f5ce1		SUBSD X1, X4																																										
  game-object.go:218	0x6012b8		f20f11a0e0000000	MOVSD_XMM X4, 0xe0(AX)																																									
  game-object.go:220	0x6012c0		660f2ed4		UCOMISD X4, X2																																										
  game-object.go:220	0x6012c4		727f			JB 0x601345																																										
  game-object.go:221	0x6012c6		e875e0feff		CALL github.com/burntcustard/unicorn-mining-co/src/server/simulation.(*GameObject).Remove(SB)																																
  update-tier.go:232	0x6012cb		488b8c24c0000000	MOVQ 0xc0(SP), CX																																									
  update-tier.go:208	0x6012d3		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:268	0x6012db		488b9c24d0010000	MOVQ 0x1d0(SP), BX																																									
  update-tier.go:264	0x6012e3		488bbc2488000000	MOVQ 0x88(SP), DI																																									
  update-tier.go:206	0x6012eb		4c8b842458010000	MOVQ 0x158(SP), R8																																									
  update-tier.go:207	0x6012f3		4c8b8c2440010000	MOVQ 0x140(SP), R9																																									
  update-tier.go:207	0x6012fb		4c8b9424b0000000	MOVQ 0xb0(SP), R10																																									
  update-tier.go:262	0x601303		4c8b9c2400020000	MOVQ 0x200(SP), R11																																									
  update-tier.go:262	0x60130b		4c8ba42438010000	MOVQ 0x138(SP), R12																																									
  update-tier.go:264	0x601313		4c8bac24a0010000	MOVQ 0x1a0(SP), R13																																									
  update-tier.go:264	0x60131b		4c8d3d3e04ba00		LEAQ 0xba043e(IP), R15																																									
  update-tier.go:216	0x601322		f20f108424f0000000	MOVSD_XMM 0xf0(SP), X0																																									
  update-tier.go:216	0x60132b		0f57d2			XORPS X2, X2																																										
  update-tier.go:262	0x60132e		f20f109c24e8000000	MOVSD_XMM 0xe8(SP), X3																																									
  update-tier.go:262	0x601337		0fb674244f		MOVZX 0x4f(SP), SI																																									
  update-tier.go:262	0x60133c		0f1f4000		NOPL 0(AX)																																										
  update-tier.go:259	0x601340		e9c1080000		JMP 0x601c06																																										
  update-tier.go:259	0x601345		48898424b0010000	MOVQ AX, 0x1b0(SP)																																									
  game-object.go:226	0x60134d		f20f1088a8000000	MOVSD_XMM 0xa8(AX), X1																																									
  game-object.go:226	0x601355		660f2ed1		UCOMISD X1, X2																																										
  game-object.go:226	0x601359		750b			JNE 0x601366																																										
  game-object.go:226	0x60135b		0f1f440000		NOPL 0(AX)(AX*1)																																									
  game-object.go:226	0x601360		0f8bb5000000		JNP 0x60141b																																										
  game-object.go:227	0x601366		f20f100562875600	MOVSD_XMM $f64.8000000000000000(SB), X0																																							
  game-object.go:227	0x60136e		660fefc8		PXOR X0, X1																																										
  game-object.go:227	0x601372		f20f59cb		MULSD X3, X1																																										
  exp.go:18		0x601376		f20f110c24		MOVSD_XMM X1, 0(SP)																																									
  exp.go:18		0x60137b		0f1f440000		NOPL 0(AX)(AX*1)																																									
  exp.go:18		0x601380		e87bb4edff		CALL math.archExp.abi0(SB)																																								
  exp.go:18		0x601385		450f57ff		XORPS X15, X15																																										
  exp.go:18		0x601389		644c8b3425f8ffffff	MOVQ FS:0xfffffff8, R14																																									
  exp.go:18		0x601392		f20f10442408		MOVSD_XMM 0x8(SP), X0																																									
  game-object.go:227	0x601398		488b8424b0010000	MOVQ 0x1b0(SP), AX																																									
  game-object.go:227	0x6013a0		f20f594040		MULSD 0x40(AX), X0																																									
  game-object.go:227	0x6013a5		f20f114040		MOVSD_XMM X0, 0x40(AX)																																									
  update-tier.go:232	0x6013aa		488b8c24c0000000	MOVQ 0xc0(SP), CX																																									
  update-tier.go:208	0x6013b2		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:268	0x6013ba		488b9c24d0010000	MOVQ 0x1d0(SP), BX																																									
  ordered-map.go:71	0x6013c2		0fb674244f		MOVZX 0x4f(SP), SI																																									
  update-tier.go:264	0x6013c7		488bbc2488000000	MOVQ 0x88(SP), DI																																									
  update-tier.go:206	0x6013cf		4c8b842458010000	MOVQ 0x158(SP), R8																																									
  update-tier.go:207	0x6013d7		4c8b8c2440010000	MOVQ 0x140(SP), R9																																									
  update-tier.go:207	0x6013df		4c8b9424b0000000	MOVQ 0xb0(SP), R10																																									
  update-tier.go:262	0x6013e7		4c8b9c2400020000	MOVQ 0x200(SP), R11																																									
  update-tier.go:262	0x6013ef		4c8ba42438010000	MOVQ 0x138(SP), R12																																									
  update-tier.go:264	0x6013f7		4c8bac24a0010000	MOVQ 0x1a0(SP), R13																																									
  update-tier.go:264	0x6013ff		4c8d3d5a03ba00		LEAQ 0xba035a(IP), R15																																									
  update-tier.go:216	0x601406		f20f108424f0000000	MOVSD_XMM 0xf0(SP), X0																																									
  update-tier.go:216	0x60140f		0f57d2			XORPS X2, X2																																										
  game-object.go:230	0x601412		f20f109c24e8000000	MOVSD_XMM 0xe8(SP), X3																																									
  game-object.go:230	0x60141b		f20f104840		MOVSD_XMM 0x40(AX), X1																																									
  game-object.go:230	0x601420		f20f59cb		MULSD X3, X1																																										
  game-object.go:230	0x601424		f20f584838		ADDSD 0x38(AX), X1																																									
  game-object.go:230	0x601429		f20f114838		MOVSD_XMM X1, 0x38(AX)																																									
  game-object.go:231	0x60142e		f20f1088c8000000	MOVSD_XMM 0xc8(AX), X1																																									
  bits.go:39		0x601436		660f2ec9		UCOMISD X1, X1																																										
  game-object.go:233	0x60143a		7502			JNE 0x60143e																																										
  game-object.go:233	0x60143c		7b08			JNP 0x601446																																										
  game-object.go:234	0x60143e		f20f1088c8010000	MOVSD_XMM 0x1c8(AX), X1																																									
  game-object.go:237	0x601446		f20f118c24f8000000	MOVSD_XMM X1, 0xf8(SP)																																									
  game-object.go:237	0x60144f		488b8898000000		MOVQ 0x98(AX), CX																																									
  game-object.go:237	0x601456		488b80a0000000		MOVQ 0xa0(AX), AX																																									
  game-object.go:237	0x60145d		488b4928		MOVQ 0x28(CX), CX																																									
  game-object.go:237	0x601461		ffd1			CALL CX																																											
  game-object.go:238	0x601463		488b8c24b0010000	MOVQ 0x1b0(SP), CX																																									
  game-object.go:238	0x60146b		f20f104928		MOVSD_XMM 0x28(CX), X1																																									
  game-object.go:238	0x601470		f20f59c9		MULSD X1, X1																																										
  game-object.go:238	0x601474		f20f105130		MOVSD_XMM 0x30(CX), X2																																									
  game-object.go:238	0x601479		f20f59d2		MULSD X2, X2																																										
  game-object.go:238	0x60147d		f20f58d1		ADDSD X1, X2																																										
  game-object.go:240	0x601481		f20f1089e0010000	MOVSD_XMM 0x1e0(CX), X1																																									
  game-object.go:240	0x601489		660f2eca		UCOMISD X2, X1																																										
  game-object.go:240	0x60148d		760a			JBE 0x601499																																										
  game-object.go:241	0x60148f		440f117928		MOVUPS X15, 0x28(CX)																																									
  game-object.go:241	0x601494		e959010000		JMP 0x6015f2																																										
  game-object.go:237	0x601499		f20f118424a0000000	MOVSD_XMM X0, 0xa0(SP)																																									
  game-object.go:238	0x6014a2		f20f11942490000000	MOVSD_XMM X2, 0x90(SP)																																									
  game-object.go:243	0x6014ab		f20f108424f8000000	MOVSD_XMM 0xf8(SP), X0																																									
  game-object.go:243	0x6014b4		f20f100d14865600	MOVSD_XMM $f64.8000000000000000(SB), X1																																							
  game-object.go:243	0x6014bc		660fefc1		PXOR X1, X0																																										
  game-object.go:243	0x6014c0		f20f108c24e8000000	MOVSD_XMM 0xe8(SP), X1																																									
  game-object.go:243	0x6014c9		f20f59c1		MULSD X1, X0																																										
  exp.go:18		0x6014cd		f20f110424		MOVSD_XMM X0, 0(SP)																																									
  exp.go:18		0x6014d2		e829b3edff		CALL math.archExp.abi0(SB)																																								
  exp.go:18		0x6014d7		450f57ff		XORPS X15, X15																																										
  exp.go:18		0x6014db		644c8b3425f8ffffff	MOVQ FS:0xfffffff8, R14																																									
  exp.go:18		0x6014e4		f20f10442408		MOVSD_XMM 0x8(SP), X0																																									
  exp.go:18		0x6014ea		f20f11442460		MOVSD_XMM X0, 0x60(SP)																																									
  game-object.go:246	0x6014f0		0f57c9			XORPS X1, X1																																										
  game-object.go:246	0x6014f3		f20f109424a0000000	MOVSD_XMM 0xa0(SP), X2																																									
  game-object.go:246	0x6014fc		660f2eca		UCOMISD X2, X1																																										
  game-object.go:246	0x601500		771c			JA 0x60151e																																										
  game-object.go:246	0x601502		0f10da			MOVUPS X2, X3																																										
  game-object.go:246	0x601505		f20f59d2		MULSD X2, X2																																										
  game-object.go:246	0x601509		f20f10a42490000000	MOVSD_XMM 0x90(SP), X4																																									
  game-object.go:246	0x601512		660f2ee2		UCOMISD X2, X4																																										
  game-object.go:246	0x601516		0f86af000000		JBE 0x6015cb																																										
  game-object.go:246	0x60151c		eb0c			JMP 0x60152a																																										
  game-object.go:248	0x60151e		0f10da			MOVUPS X2, X3																																										
  sqrt.go:94		0x601521		f20f10a42490000000	MOVSD_XMM 0x90(SP), X4																																									
  game-object.go:248	0x60152a		f20f10159e855600	MOVSD_XMM $f64.8000000000000000(SB), X2																																							
  game-object.go:248	0x601532		660fefda		PXOR X2, X3																																										
  game-object.go:248	0x601536		f20f119c2450010000	MOVSD_XMM X3, 0x150(SP)																																									
  game-object.go:248	0x60153f		488b8424b0010000	MOVQ 0x1b0(SP), AX																																									
  game-object.go:248	0x601547		f20f1080d8010000	MOVSD_XMM 0x1d8(AX), X0																																									
  game-object.go:248	0x60154f		f20f100db9835600	MOVSD_XMM $f64.404e000000000000(SB), X1																																							
  game-object.go:248	0x601557		f20f109424e8000000	MOVSD_XMM 0xe8(SP), X2																																									
  game-object.go:248	0x601560		f20f59ca		MULSD X2, X1																																										
  sqrt.go:94		0x601564		f20f51d4		SQRTSD X4, X2																																										
  sqrt.go:94		0x601568		f20f11542458		MOVSD_XMM X2, 0x58(SP)																																									
  game-object.go:247	0x60156e		90			NOPL																																											
  pow.go:52		0x60156f		e84c9bedff		CALL math.pow(SB)																																									
  game-object.go:248	0x601574		f20f10542458		MOVSD_XMM 0x58(SP), X2																																									
  game-object.go:248	0x60157a		f20f59c2		MULSD X2, X0																																										
  game-object.go:248	0x60157e		f20f101d4a855600	MOVSD_XMM $f64.8000000000000000(SB), X3																																							
  game-object.go:248	0x601586		660fefc3		PXOR X3, X0																																										
  game-object.go:248	0x60158a		f20f10a42450010000	MOVSD_XMM 0x150(SP), X4																																									
  game-object.go:248	0x601593		0f10ec			MOVUPS X4, X5																																										
  game-object.go:248	0x601596		f20f5de0		MINSD X0, X4																																										
  game-object.go:248	0x60159a		0f10f4			MOVUPS X4, X6																																										
  game-object.go:248	0x60159d		f20f5de5		MINSD X5, X4																																										
  game-object.go:248	0x6015a1		660febe6		POR X6, X4																																										
  game-object.go:248	0x6015a5		660fefdc		PXOR X4, X3																																										
  game-object.go:248	0x6015a9		f20f5eda		DIVSD X2, X3																																										
  game-object.go:248	0x6015ad		f20f10442460		MOVSD_XMM 0x60(SP), X0																																									
  game-object.go:248	0x6015b3		0f10d0			MOVUPS X0, X2																																										
  game-object.go:248	0x6015b6		f20f5dd3		MINSD X3, X2																																										
  game-object.go:248	0x6015ba		0f10da			MOVUPS X2, X3																																										
  game-object.go:248	0x6015bd		f20f5dd0		MINSD X0, X2																																										
  game-object.go:248	0x6015c1		660febd3		POR X3, X2																																										
  game-object.go:248	0x6015c5		0f57c9			XORPS X1, X1																																										
  game-object.go:251	0x6015c8		0f10c2			MOVUPS X2, X0																																										
  game-object.go:251	0x6015cb		488b9424b0010000	MOVQ 0x1b0(SP), DX																																									
  game-object.go:251	0x6015d3		f20f105230		MOVSD_XMM 0x30(DX), X2																																									
  game-object.go:251	0x6015d8		f20f105a28		MOVSD_XMM 0x28(DX), X3																																									
  vector.go:26		0x6015dd		f20f59d8		MULSD X0, X3																																										
  vector.go:26		0x6015e1		f20f59c2		MULSD X2, X0																																										
  game-object.go:251	0x6015e5		f20f115a28		MOVSD_XMM X3, 0x28(DX)																																									
  game-object.go:251	0x6015ea		f20f114230		MOVSD_XMM X0, 0x30(DX)																																									
  game-object.go:254	0x6015ef		4889d1			MOVQ DX, CX																																										
  game-object.go:254	0x6015f2		f20f104928		MOVSD_XMM 0x28(CX), X1																																									
  game-object.go:254	0x6015f7		f20f105130		MOVSD_XMM 0x30(CX), X2																																									
  vector.go:21		0x6015fc		f20f108424e8000000	MOVSD_XMM 0xe8(SP), X0																																									
  vector.go:21		0x601605		f20f59c8		MULSD X0, X1																																										
  vector.go:21		0x601609		f20f584918		ADDSD 0x18(CX), X1																																									
  vector.go:21		0x60160e		f20f59d0		MULSD X0, X2																																										
  vector.go:21		0x601612		f20f585120		ADDSD 0x20(CX), X2																																									
  game-object.go:254	0x601617		f20f114918		MOVSD_XMM X1, 0x18(CX)																																									
  game-object.go:254	0x60161c		f20f115120		MOVSD_XMM X2, 0x20(CX)																																									
  game-object.go:257	0x601621		488b5158		MOVQ 0x58(CX), DX																																									
  game-object.go:257	0x601625		4885d2			TESTQ DX, DX																																										
  game-object.go:257	0x601628		0f84c1000000		JE 0x6016ef																																										
  game-object.go:258	0x60162e		4c8b9a20010000		MOVQ 0x120(DX), R11																																									
  game-object.go:258	0x601635		488bba28010000		MOVQ 0x128(DX), DI																																									
  game-object.go:258	0x60163c		488bb230010000		MOVQ 0x130(DX), SI																																									
  game-object.go:260	0x601643		4d85db			TESTQ R11, R11																																										
  game-object.go:260	0x601646		0f8599000000		JNE 0x6016e5																																										
  game-object.go:261	0x60164c		488b9218010000		MOVQ 0x118(DX), DX																																									
  ordered-map.go:50	0x601653		4c8b5a20		MOVQ 0x20(DX), R11																																									
  ordered-map.go:50	0x601657		4d85db			TESTQ R11, R11																																										
  ordered-map.go:50	0x60165a		7406			JE 0x601662																																										
  ordered-map.go:50	0x60165c		498b33			MOVQ 0(R11), SI																																										
  ordered-map.go:50	0x60165f		90			NOPL																																											
  ordered-map.go:50	0x601660		eb02			JMP 0x601664																																										
  ordered-map.go:50	0x601662		31f6			XORL SI, SI																																										
  game-object.go:261	0x601664		4889942410020000	MOVQ DX, 0x210(SP)																																									
  ordered-map.go:67	0x60166c		4883fe02		CMPQ SI, $0x2																																										
  ordered-map.go:67	0x601670		771b			JA 0x60168d																																										
  ordered-map.go:67	0x601672		4c8d9c2438020000	LEAQ 0x238(SP), R11																																									
  ordered-map.go:67	0x60167a		450f113b		MOVUPS X15, 0(R11)																																									
  ordered-map.go:67	0x60167e		450f117b10		MOVUPS X15, 0x10(R11)																																									
  ordered-map.go:67	0x601683		488d842438020000	LEAQ 0x238(SP), AX																																									
  ordered-map.go:67	0x60168b		eb36			JMP 0x6016c3																																										
  ordered-map.go:67	0x60168d		4889742450		MOVQ SI, 0x50(SP)																																									
  ordered-map.go:67	0x601692		488d05a7a8b300		LEAQ 0xb3a8a7(IP), AX																																									
  ordered-map.go:67	0x601699		31db			XORL BX, BX																																										
  ordered-map.go:67	0x60169b		4889f1			MOVQ SI, CX																																										
  ordered-map.go:67	0x60169e		6690			NOPW																																											
  ordered-map.go:67	0x6016a0		e8fb0ee9ff		CALL runtime.makeslice(SB)																																								
  game-object.go:269	0x6016a5		488b8c24b0010000	MOVQ 0x1b0(SP), CX																																									
  ordered-map.go:71	0x6016ad		488b942410020000	MOVQ 0x210(SP), DX																																									
  ordered-map.go:71	0x6016b5		488b742450		MOVQ 0x50(SP), SI																																									
  game-object.go:273	0x6016ba		f20f108424e8000000	MOVSD_XMM 0xe8(SP), X0																																									
  ordered-map.go:71	0x6016c3		4c8b5a10		MOVQ 0x10(DX), R11																																									
  ordered-map.go:71	0x6016c7		4c899c2430010000	MOVQ R11, 0x130(SP)																																									
  ordered-map.go:71	0x6016cf		4531e4			XORL R12, R12																																										
  ordered-map.go:71	0x6016d2		4531ed			XORL R13, R13																																										
  ordered-map.go:71	0x6016d5		440fb67c244f		MOVZX 0x4f(SP), R15																																									
  ordered-map.go:71	0x6016db		0f1f440000		NOPL 0(AX)(AX*1)																																									
  ordered-map.go:71	0x6016e0		e92f050000		JMP 0x601c14																																										
  ordered-map.go:71	0x6016e5		0fb644244f		MOVZX 0x4f(SP), AX																																									
  game-object.go:260	0x6016ea		e956040000		JMP 0x601b45																																										
  game-object.go:263	0x6016ef		4883b9a001000001	CMPQ 0x1a0(CX), $0x1																																									
  game-object.go:263	0x6016f7		7e18			JLE 0x601711																																										
  game-object.go:263	0x6016f9		488b9198010000		MOVQ 0x198(CX), DX																																									
  game-object.go:264	0x601700		488b5208		MOVQ 0x8(DX), DX																																									
  game-object.go:264	0x601704		4c8b1a			MOVQ 0(DX), R11																																										
  game-object.go:264	0x601707		488b7a08		MOVQ 0x8(DX), DI																																									
  game-object.go:264	0x60170b		488b7210		MOVQ 0x10(DX), SI																																									
  game-object.go:264	0x60170f		eb07			JMP 0x601718																																										
  game-object.go:264	0x601711		31f6			XORL SI, SI																																										
  game-object.go:264	0x601713		31ff			XORL DI, DI																																										
  game-object.go:264	0x601715		4531db			XORL R11, R11																																										
  game-object.go:267	0x601718		0fb644244f		MOVZX 0x4f(SP), AX																																									
  game-object.go:267	0x60171d		0f1f00			NOPL 0(AX)																																										
  game-object.go:267	0x601720		e920040000		JMP 0x601b45																																										
  update-tier.go:259	0x601725		488b4930		MOVQ 0x30(CX), CX																																									
  update-tier.go:259	0x601729		4889d8			MOVQ BX, AX																																										
  update-tier.go:259	0x60172c		0f10c3			MOVUPS X3, X0																																										
  update-tier.go:259	0x60172f		ffd1			CALL CX																																											
  update-tier.go:262	0x601731		0fb644244f		MOVZX 0x4f(SP), AX																																									
  update-tier.go:262	0x601736		8844244e		MOVB AL, 0x4e(SP)																																									
  update-tier.go:262	0x60173a		488b942438010000	MOVQ 0x138(SP), DX																																									
  update-tier.go:262	0x601742		488bb42400020000	MOVQ 0x200(SP), SI																																									
  update-tier.go:262	0x60174a		f20f104c1630		MOVSD_XMM 0x30(SI)(DX*1), X1																																								
  update-tier.go:262	0x601750		f20f109424e8000000	MOVSD_XMM 0xe8(SP), X2																																									
  update-tier.go:262	0x601759		f20f58d1		ADDSD X1, X2																																										
  update-tier.go:262	0x60175d		f20f11541630		MOVSD_XMM X2, 0x30(SI)(DX*1)																																								
  update-tier.go:264	0x601763		488b7c3218		MOVQ 0x18(DX)(SI*1), DI																																									
  update-tier.go:264	0x601768		48ffcf			DECQ DI																																											
  update-tier.go:264	0x60176b		4c8b842488000000	MOVQ 0x88(SP), R8																																									
  update-tier.go:264	0x601773		4939f8			CMPQ R8, DI																																										
  update-tier.go:264	0x601776		7520			JNE 0x601798																																										
  update-tier.go:232	0x601778		488bbc24c0000000	MOVQ 0xc0(SP), DI																																									
  update-tier.go:232	0x601780		4885ff			TESTQ DI, DI																																										
  update-tier.go:274	0x601783		488bbc24a0010000	MOVQ 0x1a0(SP), DI																																									
  update-tier.go:265	0x60178b		4c8b8c24c0000000	MOVQ 0xc0(SP), R9																																									
  update-tier.go:265	0x601793		0f57d2			XORPS X2, X2																																										
  update-tier.go:264	0x601796		eb24			JMP 0x6017bc																																										
  update-tier.go:264	0x601798		488bbc24a0010000	MOVQ 0x1a0(SP), DI																																									
  update-tier.go:264	0x6017a0		f20f108fd8000000	MOVSD_XMM 0xd8(DI), X1																																									
  update-tier.go:264	0x6017a8		0f57d2			XORPS X2, X2																																										
  update-tier.go:264	0x6017ab		660f2ed1		UCOMISD X1, X2																																										
  update-tier.go:264	0x6017af		722c			JB 0x6017dd																																										
  update-tier.go:232	0x6017b1		4c8b8c24c0000000	MOVQ 0xc0(SP), R9																																									
  update-tier.go:232	0x6017b9		4d85c9			TESTQ R9, R9																																										
  update-tier.go:265	0x6017bc		7417			JE 0x6017d5																																										
  update-tier.go:265	0x6017be		498b5908		MOVQ 0x8(R9), BX																																									
  update-tier.go:265	0x6017c2		4c8b1547afc000		MOVQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.10(SB), R10																																
  update-tier.go:265	0x6017c9		4d8b1a			MOVQ 0(R10), R11																																									
  update-tier.go:265	0x6017cc		458b6110		MOVL 0x10(R9), R12																																									
  update-tier.go:265	0x6017d0		e9ff020000		JMP 0x601ad4																																										
  update-tier.go:209	0x6017d5		4c89c9			MOVQ R9, CX																																										
  update-tier.go:265	0x6017d8		e998020000		JMP 0x601a75																																										
  update-tier.go:274	0x6017dd		80bf9100000000		CMPB 0x91(DI), $0x0																																									
  update-tier.go:274	0x6017e4		7429			JE 0x60180f																																										
  update-tier.go:232	0x6017e6		488b9424c0000000	MOVQ 0xc0(SP), DX																																									
  update-tier.go:232	0x6017ee		4885d2			TESTQ DX, DX																																										
  update-tier.go:275	0x6017f1		7417			JE 0x60180a																																										
  update-tier.go:275	0x6017f3		488b5a08		MOVQ 0x8(DX), BX																																									
  update-tier.go:275	0x6017f7		488b3532afc000		MOVQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.11(SB), SI																																
  update-tier.go:275	0x6017fe		4c8b0e			MOVQ 0(SI), R9																																										
  update-tier.go:275	0x601801		448b5210		MOVL 0x10(DX), R10																																									
  update-tier.go:275	0x601805		e908020000		JMP 0x601a12																																										
  update-tier.go:209	0x60180a		4889d1			MOVQ DX, CX																																										
  update-tier.go:275	0x60180d		eb36			JMP 0x601845																																										
  update-tier.go:208	0x60180f		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:215	0x601817		4c89c7			MOVQ R8, DI																																										
  update-tier.go:206	0x60181a		4c8b842458010000	MOVQ 0x158(SP), R8																																									
  update-tier.go:207	0x601822		4c8b8c2440010000	MOVQ 0x140(SP), R9																																									
  update-tier.go:207	0x60182a		4c8b9424b0000000	MOVQ 0xb0(SP), R10																																									
  update-tier.go:216	0x601832		f20f108424f0000000	MOVSD_XMM 0xf0(SP), X0																																									
  update-tier.go:207	0x60183b		89c6			MOVL AX, SI																																										
  update-tier.go:207	0x60183d		0f1f00			NOPL 0(AX)																																										
  update-tier.go:207	0x601840		e9bbf7ffff		JMP 0x601000																																										
  update-tier.go:275	0x601845		4885d2			TESTQ DX, DX																																										
  update-tier.go:275	0x601848		7505			JNE 0x60184f																																										
  update-tier.go:232	0x60184a		4885c9			TESTQ CX, CX																																										
  update-tier.go:275	0x60184d		eb39			JMP 0x601888																																										
  update-tier.go:278	0x60184f		488b4a18		MOVQ 0x18(DX), CX																																									
  update-tier.go:278	0x601853		488b8424d0010000	MOVQ 0x1d0(SP), AX																																									
  update-tier.go:278	0x60185b		488b9c24c0010000	MOVQ 0x1c0(SP), BX																																									
  update-tier.go:278	0x601863		ffd1			CALL CX																																											
  update-tier.go:232	0x601865		488b8c24c0000000	MOVQ 0xc0(SP), CX																																									
  update-tier.go:232	0x60186d		4885c9			TESTQ CX, CX																																										
  update-tier.go:207	0x601870		0fb644244e		MOVZX 0x4e(SP), AX																																									
  update-tier.go:289	0x601875		488bbc24a0010000	MOVQ 0x1a0(SP), DI																																									
  update-tier.go:215	0x60187d		4c8b842488000000	MOVQ 0x88(SP), R8																																									
  update-tier.go:215	0x601885		0f57d2			XORPS X2, X2																																										
  update-tier.go:281	0x601888		741b			JE 0x6018a5																																										
  update-tier.go:281	0x60188a		488b5908		MOVQ 0x8(CX), BX																																									
  update-tier.go:281	0x60188e		488b15bbaec000		MOVQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.12(SB), DX																																
  update-tier.go:281	0x601895		488b32			MOVQ 0(DX), SI																																										
  update-tier.go:281	0x601898		448b4910		MOVL 0x10(CX), R9																																									
  update-tier.go:281	0x60189c		0f1f4000		NOPL 0(AX)																																										
  update-tier.go:281	0x6018a0		e91a010000		JMP 0x6019bf																																										
  update-tier.go:281	0x6018a5		4885c9			TESTQ CX, CX																																										
  update-tier.go:281	0x6018a8		0f84dd000000		JE 0x60198b																																										
  update-tier.go:284	0x6018ae		488b4918		MOVQ 0x18(CX), CX																																									
  update-tier.go:284	0x6018b2		488b8424d0010000	MOVQ 0x1d0(SP), AX																																									
  update-tier.go:284	0x6018ba		ffd1			CALL CX																																											
  update-tier.go:284	0x6018bc		0f1f4000		NOPL 0(AX)																																										
  update-tier.go:284	0x6018c0		4885c0			TESTQ AX, AX																																										
  update-tier.go:284	0x6018c3		0f84b2000000		JE 0x60197b																																										
  update-tier.go:285	0x6018c9		488b9424c0010000	MOVQ 0x1c0(SP), DX																																									
  update-tier.go:285	0x6018d1		488b4a10		MOVQ 0x10(DX), CX																																									
  update-tier.go:285	0x6018d5		4c8b4208		MOVQ 0x8(DX), R8																																									
  update-tier.go:285	0x6018d9		49ffc0			INCQ R8																																											
  update-tier.go:285	0x6018dc		4c8b0a			MOVQ 0(DX), R9																																										
  update-tier.go:285	0x6018df		90			NOPL																																											
  update-tier.go:285	0x6018e0		4c39c1			CMPQ CX, R8																																										
  update-tier.go:285	0x6018e3		7365			JAE 0x60194a																																										
  update-tier.go:284	0x6018e5		48899c24c8010000	MOVQ BX, 0x1c8(SP)																																									
  update-tier.go:284	0x6018ed		48898424b8000000	MOVQ AX, 0xb8(SP)																																									
  update-tier.go:285	0x6018f5		4c89c8			MOVQ R9, AX																																										
  update-tier.go:285	0x6018f8		4c89c3			MOVQ R8, BX																																										
  update-tier.go:285	0x6018fb		bf01000000		MOVL $0x1, DI																																										
  update-tier.go:285	0x601900		488d35f908b300		LEAQ 0xb308f9(IP), SI																																									
  update-tier.go:285	0x601907		e8740de9ff		CALL runtime.growslice(SB)																																								
  update-tier.go:285	0x60190c		488b9424c0010000	MOVQ 0x1c0(SP), DX																																									
  update-tier.go:285	0x601914		48894a10		MOVQ CX, 0x10(DX)																																									
  update-tier.go:285	0x601918		833d411cc40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:285	0x60191f		90			NOPL																																											
  update-tier.go:285	0x601920		740f			JE 0x601931																																										
  update-tier.go:285	0x601922		488b32			MOVQ 0(DX), SI																																										
  update-tier.go:285	0x601925		e8f659e9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  update-tier.go:285	0x60192a		498903			MOVQ AX, 0(R11)																																										
  update-tier.go:285	0x60192d		49897308		MOVQ SI, 0x8(R11)																																									
  update-tier.go:285	0x601931		488902			MOVQ AX, 0(DX)																																										
  update-tier.go:285	0x601934		4989c1			MOVQ AX, R9																																										
  update-tier.go:285	0x601937		4989d8			MOVQ BX, R8																																										
  update-tier.go:285	0x60193a		488b8424b8000000	MOVQ 0xb8(SP), AX																																									
  update-tier.go:285	0x601942		488b9c24c8010000	MOVQ 0x1c8(SP), BX																																									
  update-tier.go:285	0x60194a		4c894208		MOVQ R8, 0x8(DX)																																									
  update-tier.go:285	0x60194e		498d70ff		LEAQ -0x1(R8), SI																																									
  update-tier.go:285	0x601952		48c1e604		SHLQ $0x4, SI																																										
  update-tier.go:285	0x601956		49890431		MOVQ AX, 0(R9)(SI*1)																																									
  update-tier.go:285	0x60195a		833dff1bc40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:285	0x601961		7411			JE 0x601974																																										
  update-tier.go:285	0x601963		498b7c3108		MOVQ 0x8(R9)(SI*1), DI																																									
  update-tier.go:285	0x601968		e8b359e9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  update-tier.go:285	0x60196d		49891b			MOVQ BX, 0(R11)																																										
  update-tier.go:285	0x601970		49897b08		MOVQ DI, 0x8(R11)																																									
  update-tier.go:285	0x601974		49895c3108		MOVQ BX, 0x8(R9)(SI*1)																																									
  update-tier.go:285	0x601979		eb08			JMP 0x601983																																										
  update-tier.go:268	0x60197b		488b9424c0010000	MOVQ 0x1c0(SP), DX																																									
  update-tier.go:289	0x601983		488bbc24a0010000	MOVQ 0x1a0(SP), DI																																									
  update-tier.go:289	0x60198b		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:289	0x601993		488b8218010000		MOVQ 0x118(DX), AX																																									
  update-tier.go:289	0x60199a		488b4f10		MOVQ 0x10(DI), CX																																									
  update-tier.go:289	0x60199e		488d1dfba65700		LEAQ github.com/burntcustard/unicorn-mining-co/src/server/utilities..dict.OrderedMap[int64,github.com/burntcustard/unicorn-mining-co/src/server/simulation.Entity](SB), BX																						
  update-tier.go:289	0x6019a5		e816330000		CALL github.com/burntcustard/unicorn-mining-co/src/server/utilities.(*OrderedMap[go.shape.int64,go.shape.interface { Base() *github.com/burntcustard/unicorn-mining-co/src/server/simulation.GameObject; Hitbox() []*github.com/burntcustard/unicorn-mining-co/src/server/collision.Collider; MaxSpeed() float64; Update(float64) }]).Delete(SB)	
  update-tier.go:207	0x6019aa		0fb644244e		MOVZX 0x4e(SP), AX																																									
  update-tier.go:215	0x6019af		4c8b842488000000	MOVQ 0x88(SP), R8																																									
  update-tier.go:215	0x6019b7		0f57d2			XORPS X2, X2																																										
  update-tier.go:289	0x6019ba		e950feffff		JMP 0x60180f																																										
  update-tier.go:281	0x6019bf		4d89ca			MOVQ R9, R10																																										
  update-tier.go:281	0x6019c2		4921f1			ANDQ SI, R9																																										
  update-tier.go:281	0x6019c5		49c1e104		SHLQ $0x4, R9																																										
  update-tier.go:281	0x6019c9		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11																																									
  update-tier.go:281	0x6019ce		4939db			CMPQ R11, BX																																										
  update-tier.go:281	0x6019d1		7435			JE 0x601a08																																										
  update-tier.go:281	0x6019d3		4d8d4a01		LEAQ 0x1(R10), R9																																									
  update-tier.go:281	0x6019d7		4d85db			TESTQ R11, R11																																										
  update-tier.go:281	0x6019da		75e3			JNE 0x6019bf																																										
  update-tier.go:281	0x6019dc		488d056dadc000		LEAQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.12(SB), AX																																
  update-tier.go:281	0x6019e3		e898bce1ff		CALL runtime.typeAssert(SB)																																								
  update-tier.go:289	0x6019e8		488bbc24a0010000	MOVQ 0x1a0(SP), DI																																									
  update-tier.go:215	0x6019f0		4c8b842488000000	MOVQ 0x88(SP), R8																																									
  update-tier.go:215	0x6019f8		0f57d2			XORPS X2, X2																																										
  update-tier.go:281	0x6019fb		4889c1			MOVQ AX, CX																																										
  update-tier.go:207	0x6019fe		0fb644244e		MOVZX 0x4e(SP), AX																																									
  update-tier.go:281	0x601a03		e99dfeffff		JMP 0x6018a5																																										
  update-tier.go:281	0x601a08		4a8b4c0a10		MOVQ 0x10(DX)(R9*1), CX																																									
  update-tier.go:281	0x601a0d		e993feffff		JMP 0x6018a5																																										
  update-tier.go:275	0x601a12		4d89d3			MOVQ R10, R11																																										
  update-tier.go:275	0x601a15		4d21ca			ANDQ R9, R10																																										
  update-tier.go:275	0x601a18		49c1e204		SHLQ $0x4, R10																																										
  update-tier.go:275	0x601a1c		4e8b641608		MOVQ 0x8(SI)(R10*1), R12																																								
  update-tier.go:275	0x601a21		4939dc			CMPQ R12, BX																																										
  update-tier.go:275	0x601a24		743f			JE 0x601a65																																										
  update-tier.go:275	0x601a26		4d8d5301		LEAQ 0x1(R11), R10																																									
  update-tier.go:275	0x601a2a		4d85e4			TESTQ R12, R12																																										
  update-tier.go:275	0x601a2d		75e3			JNE 0x601a12																																										
  update-tier.go:275	0x601a2f		488d05faacc000		LEAQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.11(SB), AX																																
  update-tier.go:275	0x601a36		e845bce1ff		CALL runtime.typeAssert(SB)																																								
  update-tier.go:232	0x601a3b		488b8c24c0000000	MOVQ 0xc0(SP), CX																																									
  update-tier.go:289	0x601a43		488bbc24a0010000	MOVQ 0x1a0(SP), DI																																									
  update-tier.go:215	0x601a4b		4c8b842488000000	MOVQ 0x88(SP), R8																																									
  update-tier.go:215	0x601a53		0f57d2			XORPS X2, X2																																										
  update-tier.go:275	0x601a56		4889c2			MOVQ AX, DX																																										
  update-tier.go:207	0x601a59		0fb644244e		MOVZX 0x4e(SP), AX																																									
  update-tier.go:207	0x601a5e		6690			NOPW																																											
  update-tier.go:275	0x601a60		e9e0fdffff		JMP 0x601845																																										
  update-tier.go:275	0x601a65		4a8b741610		MOVQ 0x10(SI)(R10*1), SI																																								
  update-tier.go:232	0x601a6a		4889d1			MOVQ DX, CX																																										
  update-tier.go:275	0x601a6d		4889f2			MOVQ SI, DX																																										
  update-tier.go:275	0x601a70		e9d0fdffff		JMP 0x601845																																										
  update-tier.go:265	0x601a75		4d85c9			TESTQ R9, R9																																										
  update-tier.go:265	0x601a78		744c			JE 0x601ac6																																										
  update-tier.go:268	0x601a7a		498b4918		MOVQ 0x18(R9), CX																																									
  update-tier.go:268	0x601a7e		f20f10441630		MOVSD_XMM 0x30(SI)(DX*1), X0																																								
  update-tier.go:268	0x601a84		488b8424d0010000	MOVQ 0x1d0(SP), AX																																									
  update-tier.go:268	0x601a8c		488b9c24c0010000	MOVQ 0x1c0(SP), BX																																									
  update-tier.go:268	0x601a94		ffd1			CALL CX																																											
  update-tier.go:207	0x601a96		0fb644244e		MOVZX 0x4e(SP), AX																																									
  update-tier.go:232	0x601a9b		488b8c24c0000000	MOVQ 0xc0(SP), CX																																									
  update-tier.go:271	0x601aa3		488b942438010000	MOVQ 0x138(SP), DX																																									
  update-tier.go:271	0x601aab		488bb42400020000	MOVQ 0x200(SP), SI																																									
  update-tier.go:274	0x601ab3		488bbc24a0010000	MOVQ 0x1a0(SP), DI																																									
  update-tier.go:215	0x601abb		4c8b842488000000	MOVQ 0x88(SP), R8																																									
  update-tier.go:215	0x601ac3		0f57d2			XORPS X2, X2																																										
  update-tier.go:271	0x601ac6		48c744163000000000	MOVQ $0x0, 0x30(SI)(DX*1)																																								
  update-tier.go:271	0x601acf		e909fdffff		JMP 0x6017dd																																										
  update-tier.go:265	0x601ad4		4d89e5			MOVQ R12, R13																																										
  update-tier.go:265	0x601ad7		4d21dc			ANDQ R11, R12																																										
  update-tier.go:265	0x601ada		49c1e404		SHLQ $0x4, R12																																										
  update-tier.go:265	0x601ade		4f8b7c2208		MOVQ 0x8(R10)(R12*1), R15																																								
  update-tier.go:265	0x601ae3		4939df			CMPQ R15, BX																																										
  update-tier.go:265	0x601ae6		744d			JE 0x601b35																																										
  update-tier.go:265	0x601ae8		4d8d6501		LEAQ 0x1(R13), R12																																									
  update-tier.go:265	0x601aec		4d85ff			TESTQ R15, R15																																										
  update-tier.go:265	0x601aef		75e3			JNE 0x601ad4																																										
  update-tier.go:265	0x601af1		488d0518acc000		LEAQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.10(SB), AX																																
  update-tier.go:265	0x601af8		e883bbe1ff		CALL runtime.typeAssert(SB)																																								
  update-tier.go:232	0x601afd		488b8c24c0000000	MOVQ 0xc0(SP), CX																																									
  update-tier.go:271	0x601b05		488b942438010000	MOVQ 0x138(SP), DX																																									
  update-tier.go:271	0x601b0d		488bb42400020000	MOVQ 0x200(SP), SI																																									
  update-tier.go:274	0x601b15		488bbc24a0010000	MOVQ 0x1a0(SP), DI																																									
  update-tier.go:215	0x601b1d		4c8b842488000000	MOVQ 0x88(SP), R8																																									
  update-tier.go:215	0x601b25		0f57d2			XORPS X2, X2																																										
  update-tier.go:265	0x601b28		4989c1			MOVQ AX, R9																																										
  update-tier.go:207	0x601b2b		0fb644244e		MOVZX 0x4e(SP), AX																																									
  update-tier.go:265	0x601b30		e940ffffff		JMP 0x601a75																																										
  update-tier.go:265	0x601b35		4f8b542210		MOVQ 0x10(R10)(R12*1), R10																																								
  update-tier.go:232	0x601b3a		4c89c9			MOVQ R9, CX																																										
  update-tier.go:265	0x601b3d		4d89d1			MOVQ R10, R9																																										
  update-tier.go:265	0x601b40		e930ffffff		JMP 0x601a75																																										
  game-object.go:267	0x601b45		8844244e		MOVB AL, 0x4e(SP)																																									
  game-object.go:269	0x601b49		488b5158		MOVQ 0x58(CX), DX																																									
  game-object.go:269	0x601b4d		4885d2			TESTQ DX, DX																																										
  game-object.go:269	0x601b50		7417			JE 0x601b69																																										
  game-object.go:270	0x601b52		4c8b8238010000		MOVQ 0x138(DX), R8																																									
  game-object.go:270	0x601b59		4c8b8a40010000		MOVQ 0x140(DX), R9																																									
  game-object.go:270	0x601b60		4c8b9248010000		MOVQ 0x148(DX), R10																																									
  game-object.go:270	0x601b67		eb09			JMP 0x601b72																																										
  game-object.go:270	0x601b69		4531d2			XORL R10, R10																																										
  game-object.go:270	0x601b6c		4531c9			XORL R9, R9																																										
  game-object.go:270	0x601b6f		4531c0			XORL R8, R8																																										
  game-object.go:273	0x601b72		488b8198000000		MOVQ 0x98(CX), AX																																									
  game-object.go:273	0x601b79		488b99a0000000		MOVQ 0xa0(CX), BX																																									
  game-object.go:273	0x601b80		4c89d9			MOVQ R11, CX																																										
  game-object.go:273	0x601b83		e878fbfeff		CALL github.com/burntcustard/unicorn-mining-co/src/server/simulation.localMovement(SB)																																	
  game-object.go:274	0x601b88		488b8424b0010000	MOVQ 0x1b0(SP), AX																																									
  game-object.go:274	0x601b90		e88be0feff		CALL github.com/burntcustard/unicorn-mining-co/src/server/simulation.(*GameObject).RoundMotion(SB)																															
  update-tier.go:232	0x601b95		488b8c24c0000000	MOVQ 0xc0(SP), CX																																									
  update-tier.go:208	0x601b9d		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:268	0x601ba5		488b9c24d0010000	MOVQ 0x1d0(SP), BX																																									
  update-tier.go:264	0x601bad		488bbc2488000000	MOVQ 0x88(SP), DI																																									
  update-tier.go:206	0x601bb5		4c8b842458010000	MOVQ 0x158(SP), R8																																									
  update-tier.go:207	0x601bbd		4c8b8c2440010000	MOVQ 0x140(SP), R9																																									
  update-tier.go:207	0x601bc5		4c8b9424b0000000	MOVQ 0xb0(SP), R10																																									
  update-tier.go:262	0x601bcd		4c8b9c2400020000	MOVQ 0x200(SP), R11																																									
  update-tier.go:262	0x601bd5		4c8ba42438010000	MOVQ 0x138(SP), R12																																									
  update-tier.go:264	0x601bdd		4c8bac24a0010000	MOVQ 0x1a0(SP), R13																																									
  update-tier.go:264	0x601be5		4c8d3d74fbb900		LEAQ 0xb9fb74(IP), R15																																									
  update-tier.go:216	0x601bec		f20f108424f0000000	MOVSD_XMM 0xf0(SP), X0																																									
  update-tier.go:216	0x601bf5		0f57d2			XORPS X2, X2																																										
  update-tier.go:262	0x601bf8		f20f109c24e8000000	MOVSD_XMM 0xe8(SP), X3																																									
  update-tier.go:262	0x601c01		0fb674244e		MOVZX 0x4e(SP), SI																																									
  update-tier.go:262	0x601c06		89f0			MOVL SI, AX																																										
  update-tier.go:259	0x601c08		e929fbffff		JMP 0x601736																																										
  ordered-map.go:71	0x601c0d		4c8d6f01		LEAQ 0x1(DI), R13																																									
  ordered-map.go:71	0x601c11		4d89c4			MOVQ R8, R12																																										
  ordered-map.go:71	0x601c14		4d39dd			CMPQ R13, R11																																										
  ordered-map.go:71	0x601c17		0f8d3d010000		JGE 0x601d5a																																										
  ordered-map.go:72	0x601c1d		488b5a10		MOVQ 0x10(DX), BX																																									
  ordered-map.go:72	0x601c21		4939dd			CMPQ R13, BX																																										
  ordered-map.go:72	0x601c24		0f833e010000		JAE 0x601d68																																										
  ordered-map.go:72	0x601c2a		488b5a08		MOVQ 0x8(DX), BX																																									
  ordered-map.go:72	0x601c2e		4c89ef			MOVQ R13, DI																																										
  ordered-map.go:72	0x601c31		49c1e505		SHLQ $0x5, R13																																										
  ordered-map.go:72	0x601c35		450fb6441d18		MOVZX 0x18(R13)(BX*1), R8																																								
  ordered-map.go:72	0x601c3b		0f1f440000		NOPL 0(AX)(AX*1)																																									
  ordered-map.go:72	0x601c40		4584c0			TESTL R8, R8																																										
  ordered-map.go:72	0x601c43		0f8409010000		JE 0x601d52																																										
  ordered-map.go:73	0x601c49		4d8d442401		LEAQ 0x1(R12), R8																																									
  ordered-map.go:73	0x601c4e		4d8b4c1d10		MOVQ 0x10(R13)(BX*1), R9																																								
  ordered-map.go:73	0x601c53		4d8b6c1d08		MOVQ 0x8(R13)(BX*1), R13																																								
  ordered-map.go:73	0x601c58		0f1f840000000000	NOPL 0(AX)(AX*1)																																									
  ordered-map.go:73	0x601c60		4c39c6			CMPQ SI, R8																																										
  ordered-map.go:73	0x601c63		0f83aa000000		JAE 0x601d13																																										
  ordered-map.go:73	0x601c69		4c898c24f8010000	MOVQ R9, 0x1f8(SP)																																									
  ordered-map.go:73	0x601c71		4c89ac2400010000	MOVQ R13, 0x100(SP)																																									
  ordered-map.go:71	0x601c79		4889bc2428010000	MOVQ DI, 0x128(SP)																																									
  ordered-map.go:71	0x601c81		44887c244d		MOVB R15, 0x4d(SP)																																									
  ordered-map.go:73	0x601c86		4983f802		CMPQ R8, $0x2																																										
  ordered-map.go:73	0x601c8a		7f28			JG 0x601cb4																																										
  ordered-map.go:71	0x601c8c		4584ff			TESTL R15, R15																																										
  ordered-map.go:73	0x601c8f		7523			JNE 0x601cb4																																										
  ordered-map.go:73	0x601c91		4d85e4			TESTQ R12, R12																																										
  ordered-map.go:73	0x601c94		751e			JNE 0x601cb4																																										
  ordered-map.go:73	0x601c96		488d842418020000	LEAQ 0x218(SP), AX																																									
  ordered-map.go:73	0x601c9e		440f1138		MOVUPS X15, 0(AX)																																									
  ordered-map.go:73	0x601ca2		440f117810		MOVUPS X15, 0x10(AX)																																									
  ordered-map.go:73	0x601ca7		be02000000		MOVL $0x2, SI																																										
  ordered-map.go:73	0x601cac		41bf01000000		MOVL $0x1, R15																																										
  ordered-map.go:73	0x601cb2		eb5f			JMP 0x601d13																																										
  ordered-map.go:73	0x601cb4		488d1585a2b300		LEAQ 0xb3a285(IP), DX																																									
  ordered-map.go:73	0x601cbb		4c89c3			MOVQ R8, BX																																										
  ordered-map.go:73	0x601cbe		4889f1			MOVQ SI, CX																																										
  ordered-map.go:73	0x601cc1		bf01000000		MOVL $0x1, DI																																										
  ordered-map.go:73	0x601cc6		4889d6			MOVQ DX, SI																																										
  ordered-map.go:73	0x601cc9		e8b209e9ff		CALL runtime.growslice(SB)																																								
  ordered-map.go:72	0x601cce		488b942410020000	MOVQ 0x210(SP), DX																																									
  ordered-map.go:71	0x601cd6		488bbc2428010000	MOVQ 0x128(SP), DI																																									
  ordered-map.go:73	0x601cde		4c8b8c24f8010000	MOVQ 0x1f8(SP), R9																																									
  ordered-map.go:71	0x601ce6		4c8b9c2430010000	MOVQ 0x130(SP), R11																																									
  ordered-map.go:73	0x601cee		4c8bac2400010000	MOVQ 0x100(SP), R13																																									
  game-object.go:273	0x601cf6		f20f108424e8000000	MOVSD_XMM 0xe8(SP), X0																																									
  ordered-map.go:73	0x601cff		4989d8			MOVQ BX, R8																																										
  ordered-map.go:73	0x601d02		4889ce			MOVQ CX, SI																																										
  ordered-map.go:73	0x601d05		440fb67c244d		MOVZX 0x4d(SP), R15																																									
  game-object.go:269	0x601d0b		488b8c24b0010000	MOVQ 0x1b0(SP), CX																																									
  ordered-map.go:73	0x601d13		498d58ff		LEAQ -0x1(R8), BX																																									
  ordered-map.go:73	0x601d17		48c1e304		SHLQ $0x4, BX																																										
  ordered-map.go:73	0x601d1b		4c892c18		MOVQ R13, 0(AX)(BX*1)																																									
  ordered-map.go:73	0x601d1f		833d3a18c40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  ordered-map.go:73	0x601d26		7420			JE 0x601d48																																										
  ordered-map.go:73	0x601d28		4c8b641808		MOVQ 0x8(AX)(BX*1), R12																																									
  ordered-map.go:71	0x601d2d		4d89da			MOVQ R11, R10																																										
  ordered-map.go:73	0x601d30		e8eb55e9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  ordered-map.go:73	0x601d35		4d890b			MOVQ R9, 0(R11)																																										
  ordered-map.go:73	0x601d38		4d896308		MOVQ R12, 0x8(R11)																																									
  ordered-map.go:71	0x601d3c		4d89d3			MOVQ R10, R11																																										
  game-object.go:273	0x601d3f		f20f108424e8000000	MOVSD_XMM 0xe8(SP), X0																																									
  ordered-map.go:73	0x601d48		4c894c1808		MOVQ R9, 0x8(AX)(BX*1)																																									
  ordered-map.go:73	0x601d4d		e9bbfeffff		JMP 0x601c0d																																										
  ordered-map.go:73	0x601d52		4d89e0			MOVQ R12, R8																																										
  ordered-map.go:72	0x601d55		e9b3feffff		JMP 0x601c0d																																										
  ordered-map.go:72	0x601d5a		4c89e7			MOVQ R12, DI																																										
  ordered-map.go:72	0x601d5d		4989c3			MOVQ AX, R11																																										
  ordered-map.go:72	0x601d60		4489f8			MOVL R15, AX																																										
  game-object.go:261	0x601d63		e9ddfdffff		JMP 0x601b45																																										
  ordered-map.go:72	0x601d68		e85359e9ff		CALL runtime.panicBounds(SB)																																								
  update-tier.go:259	0x601d6d		488b8424d0010000	MOVQ 0x1d0(SP), AX																																									
  update-tier.go:259	0x601d75		488b8c24c0000000	MOVQ 0xc0(SP), CX																																									
  update-tier.go:208	0x601d7d		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:208	0x601d85		0fb674244f		MOVZX 0x4f(SP), SI																																									
  update-tier.go:264	0x601d8a		488bbc2488000000	MOVQ 0x88(SP), DI																																									
  update-tier.go:206	0x601d92		4c8b842458010000	MOVQ 0x158(SP), R8																																									
  update-tier.go:207	0x601d9a		4c8b8c2440010000	MOVQ 0x140(SP), R9																																									
  update-tier.go:207	0x601da2		4c8b9424b0000000	MOVQ 0xb0(SP), R10																																									
  update-tier.go:262	0x601daa		4c8b9c2400020000	MOVQ 0x200(SP), R11																																									
  update-tier.go:262	0x601db2		4c8ba42438010000	MOVQ 0x138(SP), R12																																									
  update-tier.go:264	0x601dba		4c8bac24a0010000	MOVQ 0x1a0(SP), R13																																									
  update-tier.go:264	0x601dc2		0f57d2			XORPS X2, X2																																										
  update-tier.go:259	0x601dc5		f20f109c24d8000000	MOVSD_XMM 0xd8(SP), X3																																									
  update-tier.go:259	0x601dce		0f10c8			MOVUPS X0, X1																																										
  update-tier.go:216	0x601dd1		f20f108424f0000000	MOVSD_XMM 0xf0(SP), X0																																									
  update-tier.go:216	0x601dda		e96cf4ffff		JMP 0x60124b																																										
  update-tier.go:234	0x601ddf		4883c228		ADDQ $0x28, DX																																										
  update-tier.go:234	0x601de3		48ffce			DECQ SI																																											
  update-tier.go:234	0x601de6		4885f6			TESTQ SI, SI																																										
  update-tier.go:234	0x601de9		0f8ead010000		JLE 0x601f9c																																										
  update-tier.go:235	0x601def		f20f105220		MOVSD_XMM 0x20(DX), X2																																									
  update-tier.go:234	0x601df4		4c8d842490020000	LEAQ 0x290(SP), R8																																									
  update-tier.go:234	0x601dfc		440f1032		MOVUPS 0(DX), X14																																									
  update-tier.go:234	0x601e00		450f1130		MOVUPS X14, 0(R8)																																									
  update-tier.go:234	0x601e04		440f107210		MOVUPS 0x10(DX), X14																																									
  update-tier.go:234	0x601e09		450f117010		MOVUPS X14, 0x10(R8)																																									
  update-tier.go:234	0x601e0e		440f107218		MOVUPS 0x18(DX), X14																																									
  update-tier.go:234	0x601e13		450f117018		MOVUPS X14, 0x18(R8)																																									
  update-tier.go:235	0x601e18		f20f5c942440030000	SUBSD 0x340(SP), X2																																									
  update-tier.go:237	0x601e21		660f2eca		UCOMISD X2, X1																																										
  update-tier.go:237	0x601e25		77b8			JA 0x601ddf																																										
  update-tier.go:237	0x601e27		660f2ed0		UCOMISD X0, X2																																										
  update-tier.go:237	0x601e2b		73b2			JAE 0x601ddf																																										
  update-tier.go:234	0x601e2d		4889b42430010000	MOVQ SI, 0x130(SP)																																									
  update-tier.go:234	0x601e35		4889942408020000	MOVQ DX, 0x208(SP)																																									
  update-tier.go:235	0x601e3d		f20f119424e0000000	MOVSD_XMM X2, 0xe0(SP)																																									
  update-tier.go:241	0x601e46		660f2ed1		UCOMISD X1, X2																																										
  update-tier.go:241	0x601e4a		7705			JA 0x601e51																																										
  update-tier.go:232	0x601e4c		4885ff			TESTQ DI, DI																																										
  update-tier.go:241	0x601e4f		eb77			JMP 0x601ec8																																										
  update-tier.go:242	0x601e51		488b4f30		MOVQ 0x30(DI), CX																																									
  update-tier.go:242	0x601e55		0f10c2			MOVUPS X2, X0																																										
  update-tier.go:242	0x601e58		f20f5cc1		SUBSD X1, X0																																										
  update-tier.go:242	0x601e5c		f20f11842450010000	MOVSD_XMM X0, 0x150(SP)																																									
  update-tier.go:242	0x601e65		488b8424d0010000	MOVQ 0x1d0(SP), AX																																									
  update-tier.go:242	0x601e6d		ffd1			CALL CX																																											
  update-tier.go:243	0x601e6f		488b8c2438010000	MOVQ 0x138(SP), CX																																									
  update-tier.go:243	0x601e77		488b942400020000	MOVQ 0x200(SP), DX																																									
  update-tier.go:243	0x601e7f		f20f104c0a30		MOVSD_XMM 0x30(DX)(CX*1), X1																																								
  update-tier.go:243	0x601e85		f20f10942450010000	MOVSD_XMM 0x150(SP), X2																																									
  update-tier.go:243	0x601e8e		f20f58d1		ADDSD X1, X2																																										
  update-tier.go:243	0x601e92		f20f11540a30		MOVSD_XMM X2, 0x30(DX)(CX*1)																																								
  update-tier.go:232	0x601e98		488b9c24c0000000	MOVQ 0xc0(SP), BX																																									
  update-tier.go:232	0x601ea0		4885db			TESTQ BX, BX																																										
  update-tier.go:234	0x601ea3		488b942408020000	MOVQ 0x208(SP), DX																																									
  update-tier.go:234	0x601eab		488bb42430010000	MOVQ 0x130(SP), SI																																									
  update-tier.go:246	0x601eb3		4889df			MOVQ BX, DI																																										
  update-tier.go:237	0x601eb6		f20f108424d8000000	MOVSD_XMM 0xd8(SP), X0																																									
  update-tier.go:234	0x601ebf		f20f109424e0000000	MOVSD_XMM 0xe0(SP), X2																																									
  update-tier.go:246	0x601ec8		741b			JE 0x601ee5																																										
  update-tier.go:246	0x601eca		488b5f08		MOVQ 0x8(DI), BX																																									
  update-tier.go:246	0x601ece		488b0d1ba8c000		MOVQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.9(SB), CX																																
  update-tier.go:246	0x601ed5		4c8b01			MOVQ 0(CX), R8																																										
  update-tier.go:246	0x601ed8		448b4f10		MOVL 0x10(DI), R9																																									
  update-tier.go:246	0x601edc		0f1f4000		NOPL 0(AX)																																										
  update-tier.go:246	0x601ee0		e9c0000000		JMP 0x601fa5																																										
  update-tier.go:209	0x601ee5		4889f8			MOVQ DI, AX																																										
  update-tier.go:246	0x601ee8		4885ff			TESTQ DI, DI																																										
  update-tier.go:246	0x601eeb		742c			JE 0x601f19																																										
  update-tier.go:249	0x601eed		488b4f18		MOVQ 0x18(DI), CX																																									
  update-tier.go:249	0x601ef1		488b942438010000	MOVQ 0x138(SP), DX																																									
  update-tier.go:249	0x601ef9		488bb42400020000	MOVQ 0x200(SP), SI																																									
  update-tier.go:249	0x601f01		f20f10441630		MOVSD_XMM 0x30(SI)(DX*1), X0																																								
  update-tier.go:249	0x601f07		488b8424d0010000	MOVQ 0x1d0(SP), AX																																									
  update-tier.go:249	0x601f0f		488b9c24c0010000	MOVQ 0x1c0(SP), BX																																									
  update-tier.go:249	0x601f17		ffd1			CALL CX																																											
  update-tier.go:252	0x601f19		488b8c2438010000	MOVQ 0x138(SP), CX																																									
  update-tier.go:252	0x601f21		488b942400020000	MOVQ 0x200(SP), DX																																									
  update-tier.go:252	0x601f29		48c7440a3000000000	MOVQ $0x0, 0x30(DX)(CX*1)																																								
  update-tier.go:253	0x601f32		488b8c24f8010000	MOVQ 0x1f8(SP), CX																																									
  update-tier.go:253	0x601f3a		488b4920		MOVQ 0x20(CX), CX																																									
  update-tier.go:253	0x601f3e		4889e2			MOVQ SP, DX																																										
  update-tier.go:253	0x601f41		488db42490020000	LEAQ 0x290(SP), SI																																									
  update-tier.go:253	0x601f49		440f1036		MOVUPS 0(SI), X14																																									
  update-tier.go:253	0x601f4d		440f1132		MOVUPS X14, 0(DX)																																									
  update-tier.go:253	0x601f51		440f107610		MOVUPS 0x10(SI), X14																																									
  update-tier.go:253	0x601f56		440f117210		MOVUPS X14, 0x10(DX)																																									
  update-tier.go:253	0x601f5b		488b8424d0010000	MOVQ 0x1d0(SP), AX																																									
  update-tier.go:253	0x601f63		488b9c24c0010000	MOVQ 0x1c0(SP), BX																																									
  update-tier.go:253	0x601f6b		ffd1			CALL CX																																											
  update-tier.go:234	0x601f6d		488b942408020000	MOVQ 0x208(SP), DX																																									
  update-tier.go:234	0x601f75		488bb42430010000	MOVQ 0x130(SP), SI																																									
  update-tier.go:232	0x601f7d		488bbc24c0000000	MOVQ 0xc0(SP), DI																																									
  update-tier.go:237	0x601f85		f20f108424d8000000	MOVSD_XMM 0xd8(SP), X0																																									
  update-tier.go:234	0x601f8e		f20f108c24e0000000	MOVSD_XMM 0xe0(SP), X1																																									
  update-tier.go:254	0x601f97		e943feffff		JMP 0x601ddf																																										
  update-tier.go:254	0x601f9c		0f10c1			MOVUPS X1, X0																																										
  update-tier.go:254	0x601f9f		90			NOPL																																											
  update-tier.go:234	0x601fa0		e9c8fdffff		JMP 0x601d6d																																										
  update-tier.go:246	0x601fa5		4d89ca			MOVQ R9, R10																																										
  update-tier.go:246	0x601fa8		4d21c1			ANDQ R8, R9																																										
  update-tier.go:246	0x601fab		49c1e104		SHLQ $0x4, R9																																										
  update-tier.go:246	0x601faf		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11																																									
  update-tier.go:246	0x601fb4		4939db			CMPQ R11, BX																																										
  update-tier.go:246	0x601fb7		744c			JE 0x602005																																										
  update-tier.go:246	0x601fb9		4d8d4a01		LEAQ 0x1(R10), R9																																									
  update-tier.go:246	0x601fbd		0f1f00			NOPL 0(AX)																																										
  update-tier.go:246	0x601fc0		4d85db			TESTQ R11, R11																																										
  update-tier.go:246	0x601fc3		75e0			JNE 0x601fa5																																										
  update-tier.go:246	0x601fc5		488d0524a7c000		LEAQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.9(SB), AX																																
  update-tier.go:246	0x601fcc		e8afb6e1ff		CALL runtime.typeAssert(SB)																																								
  update-tier.go:234	0x601fd1		488b942408020000	MOVQ 0x208(SP), DX																																									
  update-tier.go:234	0x601fd9		488bb42430010000	MOVQ 0x130(SP), SI																																									
  update-tier.go:237	0x601fe1		f20f108424d8000000	MOVSD_XMM 0xd8(SP), X0																																									
  update-tier.go:234	0x601fea		f20f109424e0000000	MOVSD_XMM 0xe0(SP), X2																																									
  update-tier.go:246	0x601ff3		4889c7			MOVQ AX, DI																																										
  update-tier.go:232	0x601ff6		488b8424c0000000	MOVQ 0xc0(SP), AX																																									
  update-tier.go:232	0x601ffe		6690			NOPW																																											
  update-tier.go:246	0x602000		e9e3feffff		JMP 0x601ee8																																										
  update-tier.go:246	0x602005		4a8b4c0910		MOVQ 0x10(CX)(R9*1), CX																																									
  update-tier.go:232	0x60200a		4889f8			MOVQ DI, AX																																										
  update-tier.go:246	0x60200d		4889cf			MOVQ CX, DI																																										
  update-tier.go:246	0x602010		e9d3feffff		JMP 0x601ee8																																										
  update-tier.go:232	0x602015		4889942400010000	MOVQ DX, 0x100(SP)																																									
  update-tier.go:232	0x60201d		4c21c2			ANDQ R8, DX																																										
  update-tier.go:232	0x602020		48c1e204		SHLQ $0x4, DX																																										
  update-tier.go:232	0x602024		4c8b4c1108		MOVQ 0x8(CX)(DX*1), R9																																									
  update-tier.go:232	0x602029		4939d9			CMPQ R9, BX																																										
  update-tier.go:232	0x60202c		0f849a000000		JE 0x6020cc																																										
  update-tier.go:232	0x602032		488b942400010000	MOVQ 0x100(SP), DX																																									
  update-tier.go:232	0x60203a		48ffc2			INCQ DX																																											
  update-tier.go:232	0x60203d		0f1f00			NOPL 0(AX)																																										
  update-tier.go:232	0x602040		4d85c9			TESTQ R9, R9																																										
  update-tier.go:232	0x602043		75d0			JNE 0x602015																																										
  update-tier.go:232	0x602045		488d0584a6c000		LEAQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.8(SB), AX																																
  update-tier.go:232	0x60204c		e82fb6e1ff		CALL runtime.typeAssert(SB)																																								
  update-tier.go:259	0x602051		488b8c24c0000000	MOVQ 0xc0(SP), CX																																									
  update-tier.go:208	0x602059		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:208	0x602061		0fb674244f		MOVZX 0x4f(SP), SI																																									
  update-tier.go:264	0x602066		488bbc2488000000	MOVQ 0x88(SP), DI																																									
  update-tier.go:206	0x60206e		4c8b842458010000	MOVQ 0x158(SP), R8																																									
  update-tier.go:207	0x602076		4c8b8c2440010000	MOVQ 0x140(SP), R9																																									
  update-tier.go:207	0x60207e		4c8b9424b0000000	MOVQ 0xb0(SP), R10																																									
  update-tier.go:262	0x602086		4c8b9c2400020000	MOVQ 0x200(SP), R11																																									
  update-tier.go:262	0x60208e		4c8ba42438010000	MOVQ 0x138(SP), R12																																									
  update-tier.go:232	0x602096		4c8bac24a0010000	MOVQ 0x1a0(SP), R13																																									
  update-tier.go:216	0x60209e		f20f108424f0000000	MOVSD_XMM 0xf0(SP), X0																																									
  update-tier.go:259	0x6020a7		f20f108c24e0000000	MOVSD_XMM 0xe0(SP), X1																																									
  update-tier.go:259	0x6020b0		0f57d2			XORPS X2, X2																																										
  update-tier.go:259	0x6020b3		f20f109c24d8000000	MOVSD_XMM 0xd8(SP), X3																																									
  update-tier.go:232	0x6020bc		4989c7			MOVQ AX, R15																																										
  update-tier.go:259	0x6020bf		488b8424d0010000	MOVQ 0x1d0(SP), AX																																									
  update-tier.go:232	0x6020c7		e9b8f0ffff		JMP 0x601184																																										
  update-tier.go:232	0x6020cc		488b4c1110		MOVQ 0x10(CX)(DX*1), CX																																									
  update-tier.go:208	0x6020d1		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:206	0x6020d9		4c8b842458010000	MOVQ 0x158(SP), R8																																									
  update-tier.go:207	0x6020e1		4c8b8c2440010000	MOVQ 0x140(SP), R9																																									
  update-tier.go:232	0x6020e9		4989cf			MOVQ CX, R15																																										
  update-tier.go:259	0x6020ec		488b8c24c0000000	MOVQ 0xc0(SP), CX																																									
  update-tier.go:232	0x6020f4		e98bf0ffff		JMP 0x601184																																										
  update-tier.go:208	0x6020f9		e8c255e9ff		CALL runtime.panicBounds(SB)																																								
  update-tier.go:190	0x6020fe		488d052befb400		LEAQ 0xb4ef2b(IP), AX																																									
  update-tier.go:190	0x602105		e8d6b2e1ff		CALL runtime.panicnildottype(SB)																																							
  update-tier.go:169	0x60210a		e851e0e4ff		CALL runtime.panicdivide(SB)																																								
  update-tier.go:162	0x60210f		4c89a42400010000	MOVQ R12, 0x100(SP)																																									
  update-tier.go:162	0x602117		4d21fc			ANDQ R15, R12																																										
  update-tier.go:162	0x60211a		49c1e404		SHLQ $0x4, R12																																										
  update-tier.go:162	0x60211e		4b8b4c2508		MOVQ 0x8(R13)(R12*1), CX																																								
  update-tier.go:162	0x602123		4c39d9			CMPQ CX, R11																																										
  update-tier.go:162	0x602126		0f847d000000		JE 0x6021a9																																										
  update-tier.go:162	0x60212c		4c8ba42400010000	MOVQ 0x100(SP), R12																																									
  update-tier.go:162	0x602134		49ffc4			INCQ R12																																										
  update-tier.go:162	0x602137		4885c9			TESTQ CX, CX																																										
  update-tier.go:162	0x60213a		75d3			JNE 0x60210f																																										
  update-tier.go:162	0x60213c		4c89542478		MOVQ R10, 0x78(SP)																																									
  update-tier.go:162	0x602141		4c894c2468		MOVQ R9, 0x68(SP)																																									
  update-tier.go:162	0x602146		4c89442470		MOVQ R8, 0x70(SP)																																									
  update-tier.go:162	0x60214b		488d051ea5c000		LEAQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.5(SB), AX																																
  update-tier.go:162	0x602152		4c89db			MOVQ R11, BX																																										
  update-tier.go:162	0x602155		e826b5e1ff		CALL runtime.typeAssert(SB)																																								
  update-tier.go:168	0x60215a		488b942400030000	MOVQ 0x300(SP), DX																																									
  update-tier.go:164	0x602162		488b9c2438010000	MOVQ 0x138(SP), BX																																									
  update-tier.go:164	0x60216a		488bb42440010000	MOVQ 0x140(SP), SI																																									
  update-tier.go:164	0x602172		488bbc2458010000	MOVQ 0x158(SP), DI																																									
  update-tier.go:164	0x60217a		4c8b442470		MOVQ 0x70(SP), R8																																									
  update-tier.go:164	0x60217f		4c8b4c2468		MOVQ 0x68(SP), R9																																									
  update-tier.go:164	0x602184		4c8b542478		MOVQ 0x78(SP), R10																																									
  update-tier.go:169	0x602189		4c8b9c24d0000000	MOVQ 0xd0(SP), R11																																									
  update-tier.go:169	0x602191		4c8ba424e0010000	MOVQ 0x1e0(SP), R12																																									
  update-tier.go:162	0x602199		4889c1			MOVQ AX, CX																																										
  update-tier.go:168	0x60219c		488b8424a8010000	MOVQ 0x1a8(SP), AX																																									
  update-tier.go:162	0x6021a4		e91fe8ffff		JMP 0x6009c8																																										
  update-tier.go:162	0x6021a9		4b8b4c2510		MOVQ 0x10(R13)(R12*1), CX																																								
  update-tier.go:169	0x6021ae		4c8b9c24d0000000	MOVQ 0xd0(SP), R11																																									
  update-tier.go:169	0x6021b6		4c8ba424e0010000	MOVQ 0x1e0(SP), R12																																									
  update-tier.go:169	0x6021be		6690			NOPW																																											
  update-tier.go:162	0x6021c0		e903e8ffff		JMP 0x6009c8																																										
  observers.go:6	0x6021c5		4d8d4a10		LEAQ 0x10(R10), R9																																									
  observers.go:6	0x6021c9		49ffc8			DECQ R8																																											
  vector.go:63		0x6021cc		0f10c5			MOVUPS X5, X0																																										
  vector.go:63		0x6021cf		0f10cb			MOVUPS X3, X1																																										
  observers.go:6	0x6021d2		4d85c0			TESTQ R8, R8																																										
  observers.go:6	0x6021d5		7e31			JLE 0x602208																																										
  observers.go:6	0x6021d7		4d89ca			MOVQ R9, R10																																										
  observers.go:6	0x6021da		f2410f1019		MOVSD_XMM 0(R9), X3																																									
  observers.go:6	0x6021df		f2410f106108		MOVSD_XMM 0x8(R9), X4																																									
  vector.go:63		0x6021e5		0f10e8			MOVUPS X0, X5																																										
  vector.go:63		0x6021e8		f20f5cc3		SUBSD X3, X0																																										
  vector.go:63		0x6021ec		0f10d9			MOVUPS X1, X3																																										
  vector.go:63		0x6021ef		f20f5ccc		SUBSD X4, X1																																										
  vector.go:63		0x6021f3		f20f59c0		MULSD X0, X0																																										
  vector.go:63		0x6021f7		f20f59c9		MULSD X1, X1																																										
  vector.go:63		0x6021fb		f20f58c8		ADDSD X0, X1																																										
  observers.go:7	0x6021ff		660f2ed1		UCOMISD X1, X2																																										
  observers.go:7	0x602203		72c0			JB 0x6021c5																																										
  observers.go:6	0x602205		4d85c0			TESTQ R8, R8																																										
  observers.go:6	0x602208		410f9fc0		SETG R8																																											
  update-tier.go:148	0x60220c		4584c0			TESTL R8, R8																																										
  update-tier.go:148	0x60220f		488bb42420010000	MOVQ 0x120(SP), SI																																									
  update-tier.go:148	0x602217		4c8b842438010000	MOVQ 0x138(SP), R8																																									
  update-tier.go:148	0x60221f		4989f1			MOVQ SI, R9																																										
  update-tier.go:148	0x602222		4d0f45c8		CMOVNE R8, R9																																										
  update-tier.go:148	0x602226		488bbc2428010000	MOVQ 0x128(SP), DI																																									
  update-tier.go:148	0x60222e		4c8b942440010000	MOVQ 0x140(SP), R10																																									
  update-tier.go:148	0x602236		4989fb			MOVQ DI, R11																																										
  update-tier.go:148	0x602239		4d0f45da		CMOVNE R10, R11																																										
  update-tier.go:148	0x60223d		488b9c2430010000	MOVQ 0x130(SP), BX																																									
  update-tier.go:148	0x602245		4c8bac2458010000	MOVQ 0x158(SP), R13																																									
  update-tier.go:148	0x60224d		4989df			MOVQ BX, R15																																										
  update-tier.go:148	0x602250		4d0f45fd		CMOVNE R13, R15																																										
  update-tier.go:153	0x602254		4c89fb			MOVQ R15, BX																																										
  update-tier.go:153	0x602257		4c89ce			MOVQ R9, SI																																										
  update-tier.go:153	0x60225a		4c89df			MOVQ R11, DI																																										
  update-tier.go:153	0x60225d		0f1f00			NOPL 0(AX)																																										
  update-tier.go:148	0x602260		e94ee6ffff		JMP 0x6008b3																																										
  update-tier.go:140	0x602265		4d89d3			MOVQ R10, R11																																										
  update-tier.go:140	0x602268		4d21ca			ANDQ R9, R10																																										
  update-tier.go:140	0x60226b		49c1e204		SHLQ $0x4, R10																																										
  update-tier.go:140	0x60226f		4f8b641008		MOVQ 0x8(R8)(R10*1), R12																																								
  update-tier.go:140	0x602274		4939dc			CMPQ R12, BX																																										
  update-tier.go:140	0x602277		7430			JE 0x6022a9																																										
  update-tier.go:140	0x602279		4d8d5301		LEAQ 0x1(R11), R10																																									
  update-tier.go:140	0x60227d		0f1f00			NOPL 0(AX)																																										
  update-tier.go:140	0x602280		4d85e4			TESTQ R12, R12																																										
  update-tier.go:140	0x602283		75e0			JNE 0x602265																																										
  update-tier.go:140	0x602285		488d05c4a3c000		LEAQ github.com/burntcustard/unicorn-mining-co/src/server/simulation..typeAssert.4(SB), AX																																
  update-tier.go:140	0x60228c		e8efb3e1ff		CALL runtime.typeAssert(SB)																																								
  update-tier.go:141	0x602291		488b8c24d0000000	MOVQ 0xd0(SP), CX																																									
  update-tier.go:140	0x602299		4889c2			MOVQ AX, DX																																										
  update-tier.go:148	0x60229c		488b8424a8010000	MOVQ 0x1a8(SP), AX																																									
  update-tier.go:140	0x6022a4		e997e4ffff		JMP 0x600740																																										
  update-tier.go:140	0x6022a9		4f8b441010		MOVQ 0x10(R8)(R10*1), R8																																								
  update-tier.go:141	0x6022ae		4889d1			MOVQ DX, CX																																										
  update-tier.go:140	0x6022b1		4c89c2			MOVQ R8, DX																																										
  update-tier.go:140	0x6022b4		e987e4ffff		JMP 0x600740																																										
  update-tier.go:140	0x6022b9		0f1f8000000000		NOPL 0(AX)																																										
  ordered-map.go:71	0x6022c0		4c8d6301		LEAQ 0x1(BX), R12																																									
  ordered-map.go:71	0x6022c4		4d39dc			CMPQ R12, R11																																										
  ordered-map.go:71	0x6022c7		0f8df8000000		JGE 0x6023c5																																										
  ordered-map.go:72	0x6022cd		4c8b7a10		MOVQ 0x10(DX), R15																																									
  ordered-map.go:72	0x6022d1		4d39fc			CMPQ R12, R15																																										
  ordered-map.go:72	0x6022d4		0f832b010000		JAE 0x602405																																										
  ordered-map.go:72	0x6022da		4c8b7a08		MOVQ 0x8(DX), R15																																									
  ordered-map.go:72	0x6022de		4c89e3			MOVQ R12, BX																																										
  ordered-map.go:72	0x6022e1		49c1e405		SHLQ $0x5, R12																																										
  ordered-map.go:72	0x6022e5		430fb6743c18		MOVZX 0x18(R12)(R15*1), SI																																								
  ordered-map.go:72	0x6022eb		4084f6			TESTL SI, SI																																										
  ordered-map.go:72	0x6022ee		74d0			JE 0x6022c0																																										
  ordered-map.go:73	0x6022f0		49ffc5			INCQ R13																																										
  ordered-map.go:73	0x6022f3		4b8b743c10		MOVQ 0x10(R12)(R15*1), SI																																								
  ordered-map.go:73	0x6022f8		4f8b643c08		MOVQ 0x8(R12)(R15*1), R12																																								
  ordered-map.go:73	0x6022fd		0f1f00			NOPL 0(AX)																																										
  ordered-map.go:73	0x602300		4c39e9			CMPQ CX, R13																																										
  ordered-map.go:73	0x602303		737e			JAE 0x602383																																										
  ordered-map.go:71	0x602305		48899c2440010000	MOVQ BX, 0x140(SP)																																									
  ordered-map.go:73	0x60230d		4889b424f8010000	MOVQ SI, 0x1f8(SP)																																									
  ordered-map.go:73	0x602315		4c89a42400010000	MOVQ R12, 0x100(SP)																																									
  ordered-map.go:73	0x60231d		488d351c9cb300		LEAQ 0xb39c1c(IP), SI																																									
  ordered-map.go:73	0x602324		4c89d0			MOVQ R10, AX																																										
  ordered-map.go:73	0x602327		4c89eb			MOVQ R13, BX																																										
  ordered-map.go:73	0x60232a		bf01000000		MOVL $0x1, DI																																										
  ordered-map.go:73	0x60232f		e84c03e9ff		CALL runtime.growslice(SB)																																								
  ordered-map.go:72	0x602334		488b942410020000	MOVQ 0x210(SP), DX																																									
  ordered-map.go:73	0x60233c		488bb424f8010000	MOVQ 0x1f8(SP), SI																																									
  update-tier.go:169	0x602344		4c8b842480000000	MOVQ 0x80(SP), R8																																									
  update-tier.go:268	0x60234c		4c8b8c24c0010000	MOVQ 0x1c0(SP), R9																																									
  ordered-map.go:71	0x602354		4c8b9c2458010000	MOVQ 0x158(SP), R11																																									
  ordered-map.go:73	0x60235c		4c8ba42400010000	MOVQ 0x100(SP), R12																																									
  update-tier.go:216	0x602364		f20f108424f0000000	MOVSD_XMM 0xf0(SP), X0																																									
  ordered-map.go:73	0x60236d		4989c2			MOVQ AX, R10																																										
  ordered-map.go:73	0x602370		4989dd			MOVQ BX, R13																																										
  update-tier.go:88	0x602373		488b842400030000	MOVQ 0x300(SP), AX																																									
  ordered-map.go:71	0x60237b		488b9c2440010000	MOVQ 0x140(SP), BX																																									
  ordered-map.go:73	0x602383		4d8d7dff		LEAQ -0x1(R13), R15																																									
  ordered-map.go:73	0x602387		49c1e704		SHLQ $0x4, R15																																										
  ordered-map.go:73	0x60238b		4f89243a		MOVQ R12, 0(R10)(R15*1)																																									
  ordered-map.go:73	0x60238f		833dca11c40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  ordered-map.go:73	0x602396		7420			JE 0x6023b8																																										
  ordered-map.go:73	0x602398		4f8b643a08		MOVQ 0x8(R10)(R15*1), R12																																								
  ordered-map.go:71	0x60239d		4c89df			MOVQ R11, DI																																										
  ordered-map.go:73	0x6023a0		e87b4fe9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  ordered-map.go:73	0x6023a5		498933			MOVQ SI, 0(R11)																																										
  ordered-map.go:73	0x6023a8		4d896308		MOVQ R12, 0x8(R11)																																									
  ordered-map.go:71	0x6023ac		4989fb			MOVQ DI, R11																																										
  update-tier.go:216	0x6023af		f20f108424f0000000	MOVSD_XMM 0xf0(SP), X0																																									
  ordered-map.go:73	0x6023b8		4b89743a08		MOVQ SI, 0x8(R10)(R15*1)																																								
  ordered-map.go:73	0x6023bd		0f1f00			NOPL 0(AX)																																										
  ordered-map.go:73	0x6023c0		e9fbfeffff		JMP 0x6022c0																																										
  update-tier.go:88	0x6023c5		4c896878		MOVQ R13, 0x78(AX)																																									
  update-tier.go:88	0x6023c9		48898880000000		MOVQ CX, 0x80(AX)																																									
  update-tier.go:88	0x6023d0		833d8911c40000		CMPL runtime.writeBarrier(SB), $0x0																																							
  update-tier.go:88	0x6023d7		741c			JE 0x6023f5																																										
  update-tier.go:88	0x6023d9		488b5070		MOVQ 0x70(AX), DX																																									
  update-tier.go:88	0x6023dd		0f1f00			NOPL 0(AX)																																										
  update-tier.go:88	0x6023e0		e83b4fe9ff		CALL runtime.gcWriteBarrier2(SB)																																							
  update-tier.go:88	0x6023e5		4d8913			MOVQ R10, 0(R11)																																									
  update-tier.go:88	0x6023e8		49895308		MOVQ DX, 0x8(R11)																																									
  update-tier.go:216	0x6023ec		f20f108424f0000000	MOVSD_XMM 0xf0(SP), X0																																									
  update-tier.go:88	0x6023f5		4c895070		MOVQ R10, 0x70(AX)																																									
  update-tier.go:93	0x6023f9		4c89d2			MOVQ R10, DX																																										
  update-tier.go:93	0x6023fc		4d89ea			MOVQ R13, R10																																										
  update-tier.go:93	0x6023ff		90			NOPL																																											
  update-tier.go:90	0x602400		e9e7ddffff		JMP 0x6001ec																																										
  ordered-map.go:72	0x602405		e8b652e9ff		CALL runtime.panicBounds(SB)																																								
  ordered-map.go:72	0x60240a		90			NOPL																																											
  update-tier.go:63	0x60240b		4889442408		MOVQ AX, 0x8(SP)																																									
  update-tier.go:63	0x602410		48895c2410		MOVQ BX, 0x10(SP)																																									
  update-tier.go:63	0x602415		48894c2418		MOVQ CX, 0x18(SP)																																									
  update-tier.go:63	0x60241a		48897c2420		MOVQ DI, 0x20(SP)																																									
  update-tier.go:63	0x60241f		4889742428		MOVQ SI, 0x28(SP)																																									
  update-tier.go:63	0x602424		4c89442430		MOVQ R8, 0x30(SP)																																									
  update-tier.go:63	0x602429		4c894c2438		MOVQ R9, 0x38(SP)																																									
  update-tier.go:63	0x60242e		4c89542440		MOVQ R10, 0x40(SP)																																									
  update-tier.go:63	0x602433		f20f11442448		MOVSD_XMM X0, 0x48(SP)																																									
  update-tier.go:63	0x602439		e84236e9ff		CALL runtime.morestack_noctxt.abi0(SB)																																							
  update-tier.go:63	0x60243e		488b442408		MOVQ 0x8(SP), AX																																									
  update-tier.go:63	0x602443		488b5c2410		MOVQ 0x10(SP), BX																																									
  update-tier.go:63	0x602448		488b4c2418		MOVQ 0x18(SP), CX																																									
  update-tier.go:63	0x60244d		488b7c2420		MOVQ 0x20(SP), DI																																									
  update-tier.go:63	0x602452		488b742428		MOVQ 0x28(SP), SI																																									
  update-tier.go:63	0x602457		4c8b442430		MOVQ 0x30(SP), R8																																									
  update-tier.go:63	0x60245c		4c8b4c2438		MOVQ 0x38(SP), R9																																									
  update-tier.go:63	0x602461		4c8b542440		MOVQ 0x40(SP), R10																																									
  update-tier.go:63	0x602466		f20f10442448		MOVSD_XMM 0x48(SP), X0																																									
  update-tier.go:63	0x60246c		e90fdcffff		JMP github.com/burntcustard/unicorn-mining-co/src/server/simulation.UpdateEntities(SB)																																	
