TEXT github.com/burntcustard/unicorn-mining-co/src/server/gameplay.(*GameCollisions).findFree.func2(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/gameplay/game-collisions.go
  game-collisions.go:622	0x9fedc0		55			PUSHQ BP			
  game-collisions.go:622	0x9fedc1		4889e5			MOVQ SP, BP			
  game-collisions.go:622	0x9fedc4		488b4a10		MOVQ 0x10(DX), CX		
  game-collisions.go:623	0x9fedc8		4889c6			MOVQ AX, SI			
  game-collisions.go:623	0x9fedcb		48c1e002		SHLQ $0x2, AX			
  game-collisions.go:623	0x9fedcf		4839c1			CMPQ CX, AX			
  game-collisions.go:623	0x9fedd2		7647			JBE 0x9fee1b			
  game-collisions.go:622	0x9fedd4		488b5208		MOVQ 0x8(DX), DX		
  game-collisions.go:623	0x9fedd8		48c1e605		SHLQ $0x5, SI			
  game-collisions.go:623	0x9feddc		4889df			MOVQ BX, DI			
  game-collisions.go:623	0x9feddf		48c1e302		SHLQ $0x2, BX			
  game-collisions.go:623	0x9fede3		f20f100432		MOVSD_XMM 0(DX)(SI*1), X0	
  game-collisions.go:623	0x9fede8		4839d9			CMPQ CX, BX			
  game-collisions.go:623	0x9fedeb		7629			JBE 0x9fee16			
  game-collisions.go:623	0x9feded		48c1e705		SHLQ $0x5, DI			
  game-collisions.go:623	0x9fedf1		f20f100c3a		MOVSD_XMM 0(DX)(DI*1), X1	
  game-collisions.go:623	0x9fedf6		660f2ec8		UCOMISD X0, X1			
  game-collisions.go:623	0x9fedfa		7711			JA 0x9fee0d			
  game-collisions.go:627	0x9fedfc		660f2ec1		UCOMISD X1, X0			
  game-collisions.go:627	0x9fee00		7607			JBE 0x9fee09			
  game-collisions.go:628	0x9fee02		b801000000		MOVL $0x1, AX			
  game-collisions.go:628	0x9fee07		5d			POPQ BP				
  game-collisions.go:628	0x9fee08		c3			RET				
  game-collisions.go:631	0x9fee09		31c0			XORL AX, AX			
  game-collisions.go:631	0x9fee0b		5d			POPQ BP				
  game-collisions.go:631	0x9fee0c		c3			RET				
  game-collisions.go:624	0x9fee0d		48c7c0ffffffff		MOVQ $-0x1, AX			
  game-collisions.go:624	0x9fee14		5d			POPQ BP				
  game-collisions.go:624	0x9fee15		c3			RET				
  game-collisions.go:623	0x9fee16		e8a588a9ff		CALL runtime.panicBounds(SB)	
  game-collisions.go:623	0x9fee1b		0f1f440000		NOPL 0(AX)(AX*1)		
  game-collisions.go:623	0x9fee20		e89b88a9ff		CALL runtime.panicBounds(SB)	
  game-collisions.go:623	0x9fee25		90			NOPL				

TEXT github.com/burntcustard/unicorn-mining-co/src/server/gameplay.(*GameCollisions).findFree.func1(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/gameplay/game-collisions.go
  game-collisions.go:587	0x9fee40		48394208		CMPQ 0x8(DX), AX	
  game-collisions.go:587	0x9fee44		0f9ec0			SETLE AL		
  game-collisions.go:587	0x9fee47		c3			RET			
