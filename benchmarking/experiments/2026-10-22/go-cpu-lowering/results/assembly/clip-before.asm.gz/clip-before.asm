TEXT github.com/burntcustard/unicorn-mining-co/src/server/physics.recoveryClip(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/physics/overlap-recovery.go
  overlap-recovery.go:120	0x6180e0		90			NOPL					
  vector.go:59			0x6180e1		f20f59e0		MULSD X0, X4				
  vector.go:59			0x6180e5		f20f59e9		MULSD X1, X5				
  vector.go:59			0x6180e9		f20f58e5		ADDSD X5, X4				
  unsafe.go:35			0x6180ed		66480f7ee0		MOVQ X4, AX				
  abs.go:14			0x6180f2		480fbaf03f		BTRQ $0x3f, AX				
  unsafe.go:41			0x6180f7		66480f6ee8		MOVQ AX, X5				
  overlap-recovery.go:121	0x6180fc		90			NOPL					
  overlap-recovery.go:123	0x6180fd		f2440f10057a1f5500	MOVSD_XMM $f64.3ddb7cdfd9d7bdbb(SB), X8	
  overlap-recovery.go:123	0x618106		66440f2ec5		UCOMISD X5, X8				
  overlap-recovery.go:123	0x61810b		7623			JBE 0x618130				
  overlap-recovery.go:124	0x61810d		f20f1025a31f5500	MOVSD_XMM $f64.be45798ee2308c3a(SB), X4	
  overlap-recovery.go:124	0x618115		660f2ed4		UCOMISD X4, X2				
  overlap-recovery.go:124	0x618119		730e			JAE 0x618129				
  overlap-recovery.go:124	0x61811b		f20f1015ad165500	MOVSD_XMM $f64.3e45798ee2308c3a(SB), X2	
  overlap-recovery.go:124	0x618123		660f2ed3		UCOMISD X3, X2				
  overlap-recovery.go:124	0x618127		727d			JB 0x6181a6				
  overlap-recovery.go:125	0x618129		0f57c0			XORPS X0, X0				
  overlap-recovery.go:125	0x61812c		0f10c8			MOVUPS X0, X1				
  overlap-recovery.go:125	0x61812f		c3			RET					
  overlap-recovery.go:128	0x618130		f20f5ed4		DIVSD X4, X2				
  overlap-recovery.go:128	0x618134		f20f5edc		DIVSD X4, X3				
  overlap-recovery.go:129	0x618138		0f10e2			MOVUPS X2, X4				
  overlap-recovery.go:129	0x61813b		f20f5dd3		MINSD X3, X2				
  overlap-recovery.go:129	0x61813f		0f10ea			MOVUPS X2, X5				
  overlap-recovery.go:129	0x618142		f20f5dd4		MINSD X4, X2				
  overlap-recovery.go:129	0x618146		660febd5		POR X5, X2				
  overlap-recovery.go:129	0x61814a		f20f10057e195500	MOVSD_XMM $f64.8000000000000000(SB), X0	
  overlap-recovery.go:129	0x618152		660feff0		PXOR X0, X6				
  overlap-recovery.go:129	0x618156		660fefd0		PXOR X0, X2				
  overlap-recovery.go:129	0x61815a		0f10ee			MOVUPS X6, X5				
  overlap-recovery.go:129	0x61815d		f20f5dea		MINSD X2, X5				
  overlap-recovery.go:129	0x618161		0f10d5			MOVUPS X5, X2				
  overlap-recovery.go:129	0x618164		f20f5dee		MINSD X6, X5				
  overlap-recovery.go:129	0x618168		660febea		POR X2, X5				
  overlap-recovery.go:129	0x61816c		660fefe0		PXOR X0, X4				
  overlap-recovery.go:129	0x618170		660fefd8		PXOR X0, X3				
  overlap-recovery.go:129	0x618174		0f10d4			MOVUPS X4, X2				
  overlap-recovery.go:129	0x618177		f20f5de3		MINSD X3, X4				
  overlap-recovery.go:129	0x61817b		0f10dc			MOVUPS X4, X3				
  overlap-recovery.go:129	0x61817e		f20f5de2		MINSD X2, X4				
  overlap-recovery.go:129	0x618182		660febe3		POR X3, X4				
  overlap-recovery.go:129	0x618186		660fefe0		PXOR X0, X4				
  overlap-recovery.go:129	0x61818a		0f10cf			MOVUPS X7, X1				
  overlap-recovery.go:129	0x61818d		f20f5dcc		MINSD X4, X1				
  overlap-recovery.go:129	0x618191		0f10d1			MOVUPS X1, X2				
  overlap-recovery.go:129	0x618194		f20f5dd7		MINSD X7, X2				
  overlap-recovery.go:129	0x618198		660fefc5		PXOR X5, X0				
  overlap-recovery.go:129	0x61819c		660febca		POR X2, X1				
  overlap-recovery.go:132	0x6181a0		0f10f0			MOVUPS X0, X6				
  overlap-recovery.go:132	0x6181a3		0f10f9			MOVUPS X1, X7				
  overlap-recovery.go:132	0x6181a6		0f10c6			MOVUPS X6, X0				
  overlap-recovery.go:132	0x6181a9		0f10cf			MOVUPS X7, X1				
  overlap-recovery.go:132	0x6181ac		c3			RET					
