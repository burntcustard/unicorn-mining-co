TEXT github.com/burntcustard/unicorn-mining-co/src/server/network.(*BinaryReplicationManager).encode(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/network/binary-replication.go
  binary-replication.go:763	0xa0ebc0		4989e4				MOVQ SP, R12													
  binary-replication.go:763	0xa0ebc3		4981ec78130000			SUBQ $0x1378, R12												
  binary-replication.go:763	0xa0ebca		0f82c0490000			JB 0xa13590													
  binary-replication.go:763	0xa0ebd0		4d3b6610			CMPQ R12, 0x10(R14)												
  binary-replication.go:763	0xa0ebd4		0f86b6490000			JBE 0xa13590													
  binary-replication.go:763	0xa0ebda		55				PUSHQ BP													
  binary-replication.go:763	0xa0ebdb		4889e5				MOVQ SP, BP													
  binary-replication.go:763	0xa0ebde		4881ecf0130000			SUBQ $0x13f0, SP												
  binary-replication.go:766	0xa0ebe5		4889842488140000		MOVQ AX, 0x1488(SP)												
  binary-replication.go:766	0xa0ebed		889c2490140000			MOVB BL, 0x1490(SP)												
  binary-replication.go:766	0xa0ebf4		84db				TESTL BL, BL													
  binary-replication.go:766	0xa0ebf6		744a				JE 0xa0ec42													
  binary-replication.go:767	0xa0ebf8		488b98a8000000			MOVQ 0xa8(AX), BX												
  binary-replication.go:767	0xa0ebff		488d05a2d66d00			LEAQ 0x6dd6a2(IP), AX												
  binary-replication.go:767	0xa0ec06		e8556ba1ff			CALL runtime.mapclear(SB)											
  binary-replication.go:768	0xa0ec0b		488bb42488140000		MOVQ 0x1488(SP), SI												
  binary-replication.go:768	0xa0ec13		488b9eb8000000			MOVQ 0xb8(SI), BX												
  binary-replication.go:768	0xa0ec1a		4885db				TESTQ BX, BX													
  binary-replication.go:768	0xa0ec1d		7418				JE 0xa0ec37													
  binary-replication.go:768	0xa0ec1f		48c1e303			SHLQ $0x3, BX													
  binary-replication.go:768	0xa0ec23		488b86b0000000			MOVQ 0xb0(SI), AX												
  binary-replication.go:768	0xa0ec2a		e851f9a7ff			CALL runtime.memclrHasPointers(SB)										
  binary-replication.go:781	0xa0ec2f		488bb42488140000		MOVQ 0x1488(SP), SI												
  binary-replication.go:781	0xa0ec37		4889f0				MOVQ SI, AX													
  binary-replication.go:766	0xa0ec3a		0fb69c2490140000		MOVZX 0x1490(SP), BX												
  binary-replication.go:772	0xa0ec42		488b942478140000		MOVQ 0x1478(SP), DX												
  binary-replication.go:771	0xa0ec4a		4c8b842418140000		MOVQ 0x1418(SP), R8												
  binary-replication.go:771	0xa0ec52		4c89842458020000		MOVQ R8, 0x258(SP)												
  binary-replication.go:774	0xa0ec5a		4885d2				TESTQ DX, DX													
  binary-replication.go:774	0xa0ec5d		754b				JNE 0xa0ecaa													
  replication-common.go:251	0xa0ec5f		488d05d29c7700			LEAQ 0x779cd2(IP), AX												
  replication-common.go:251	0xa0ec66		e8951ba1ff			CALL runtime.newobject(SB)											
  replication-common.go:251	0xa0ec6b		833dee48830000			CMPL runtime.writeBarrier(SB), $0x0										
  replication-common.go:251	0xa0ec72		750c				JNE 0xa0ec80													
  replication-common.go:251	0xa0ec74		488b942458020000		MOVQ 0x258(SP), DX												
  replication-common.go:251	0xa0ec7c		eb12				JMP 0xa0ec90													
  replication-common.go:251	0xa0ec7e		6690				NOPW														
  replication-common.go:251	0xa0ec80		e87b86a8ff			CALL runtime.gcWriteBarrier1(SB)										
  replication-common.go:251	0xa0ec85		488b942458020000		MOVQ 0x258(SP), DX												
  replication-common.go:251	0xa0ec8d		498913				MOVQ DX, 0(R11)													
  replication-common.go:251	0xa0ec90		48895008			MOVQ DX, 0x8(AX)												
  binary-replication.go:766	0xa0ec94		0fb69c2490140000		MOVZX 0x1490(SP), BX												
  binary-replication.go:797	0xa0ec9c		4989d0				MOVQ DX, R8													
  binary-replication.go:775	0xa0ec9f		4889c2				MOVQ AX, DX													
  binary-replication.go:781	0xa0eca2		488b842488140000		MOVQ 0x1488(SP), AX												
  binary-replication.go:775	0xa0ecaa		4889942478020000		MOVQ DX, 0x278(SP)												
  binary-replication.go:778	0xa0ecb2		4c8b8c2480140000		MOVQ 0x1480(SP), R9												
  binary-replication.go:778	0xa0ecba		660f1f440000			NOPW 0(AX)(AX*1)												
  binary-replication.go:780	0xa0ecc0		4d85c9				TESTQ R9, R9													
  binary-replication.go:780	0xa0ecc3		0f85c5000000			JNE 0xa0ed8e													
  binary-replication.go:781	0xa0ecc9		8400				TESTB AL, 0(AX)													
  binary-replication.go:781	0xa0eccb		488db0c8000000			LEAQ 0xc8(AX), SI												
  binary-replication.go:781	0xa0ecd2		488dbc24d8020000		LEAQ 0x2d8(SP), DI												
  binary-replication.go:781	0xa0ecda		b903010000			MOVL $0x103, CX													
  binary-replication.go:781	0xa0ecdf		f348a5				REP; MOVSQ DS:0(SI), ES:0(DI)											
  binary-replication.go:648	0xa0ece2		488d0567557100			LEAQ 0x715567(IP), AX												
  binary-replication.go:648	0xa0ece9		31db				XORL BX, BX													
  binary-replication.go:648	0xa0eceb		b900100000			MOVL $0x1000, CX												
  binary-replication.go:648	0xa0ecf0		e8ab38a8ff			CALL runtime.makeslice(SB)											
  binary-replication.go:648	0xa0ecf5		488dbc24500b0000		LEAQ 0xb50(SP), DI												
  binary-replication.go:648	0xa0ecfd		b908010000			MOVL $0x108, CX													
  binary-replication.go:648	0xa0ed02		4889c2				MOVQ AX, DX													
  binary-replication.go:648	0xa0ed05		31c0				XORL AX, AX													
  binary-replication.go:648	0xa0ed07		f348ab				REP; STOSQ AX, ES:0(DI)												
  binary-replication.go:648	0xa0ed0a		48c78424600b000000100000	MOVQ $0x1000, 0xb60(SP)												
  binary-replication.go:648	0xa0ed16		48899424500b0000		MOVQ DX, 0xb50(SP)												
  binary-replication.go:648	0xa0ed1e		488dbc24780b0000		LEAQ 0xb78(SP), DI												
  binary-replication.go:648	0xa0ed26		488db424d8020000		LEAQ 0x2d8(SP), SI												
  binary-replication.go:648	0xa0ed2e		b903010000			MOVL $0x103, CX													
  binary-replication.go:648	0xa0ed33		f348a5				REP; MOVSQ DS:0(SI), ES:0(DI)											
  type.go:195			0xa0ed36		ba01000000			MOVL $0x1, DX													
  type.go:195			0xa0ed3b		4c8d058e3e8300			LEAQ github.com/burntcustard/unicorn-mining-co/src/server/network.nextBatchGeneration(SB), R8			
  type.go:195			0xa0ed42		f0490fc110			LOCK XADDQ DX, 0(R8)												
  type.go:195			0xa0ed47		48ffc2				INCQ DX														
  binary-replication.go:652	0xa0ed4a		48899424680b0000		MOVQ DX, 0xb68(SP)												
  binary-replication.go:653	0xa0ed52		488b942478020000		MOVQ 0x278(SP), DX												
  binary-replication.go:653	0xa0ed5a		48899424700b0000		MOVQ DX, 0xb70(SP)												
  binary-replication.go:654	0xa0ed62		48c78424580b000000000000	MOVQ $0x0, 0xb58(SP)												
  binary-replication.go:786	0xa0ed6e		488b842488140000		MOVQ 0x1488(SP), AX												
  binary-replication.go:766	0xa0ed76		0fb69c2490140000		MOVZX 0x1490(SP), BX												
  binary-replication.go:797	0xa0ed7e		4c8b842458020000		MOVQ 0x258(SP), R8												
  binary-replication.go:648	0xa0ed86		4c8d8c24500b0000		LEAQ 0xb50(SP), R9												
  binary-replication.go:781	0xa0ed8e		4c898c24f00a0000		MOVQ R9, 0xaf0(SP)												
  binary-replication.go:784	0xa0ed96		90				NOPL														
  replication-common.go:255	0xa0ed97		803a00				CMPB 0(DX), $0x0												
  replication-common.go:255	0xa0ed9a		753d				JNE 0xa0edd9													
  replication-common.go:256	0xa0ed9c		c60201				MOVB $0x1, 0(DX)												
  replication-common.go:257	0xa0ed9f		48c7421800000000		MOVQ $0x0, 0x18(DX)												
  replication-common.go:259	0xa0eda7		4c8b5208			MOVQ 0x8(DX), R10												
  replication-common.go:259	0xa0edab		4d8b9218010000			MOVQ 0x118(R10), R10												
  replication-common.go:259	0xa0edb2		4c899424480b0000		MOVQ R10, 0xb48(SP)												
  replication-common.go:259	0xa0edba		4c8b5a10			MOVQ 0x10(DX), R11												
  replication-common.go:259	0xa0edbe		488b4a20			MOVQ 0x20(DX), CX												
  ordered-map.go:71		0xa0edc2		4d8b6210			MOVQ 0x10(R10), R12												
  ordered-map.go:71		0xa0edc6		4c89a42440020000		MOVQ R12, 0x240(SP)												
  ordered-map.go:71		0xa0edce		4531ed				XORL R13, R13													
  ordered-map.go:71		0xa0edd1		4531ff				XORL R15, R15													
  ordered-map.go:71		0xa0edd4		e907410000			JMP 0xa12ee0													
  binary-replication.go:786	0xa0edd9		488b88c0000000			MOVQ 0xc0(AX), CX												
  replication-common.go:300	0xa0ede0		4c8b5218			MOVQ 0x18(DX), R10												
  replication-common.go:300	0xa0ede4		4c89942498000000		MOVQ R10, 0x98(SP)												
  replication-common.go:300	0xa0edec		4c8b5a10			MOVQ 0x10(DX), R11												
  replication-common.go:300	0xa0edf0		4c899c2450020000		MOVQ R11, 0x250(SP)												
  replication-common.go:300	0xa0edf8		0f1f840000000000		NOPL 0(AX)(AX*1)												
  binary-replication.go:786	0xa0ee00		4939ca				CMPQ R10, CX													
  binary-replication.go:786	0xa0ee03		0f8e03010000			JLE 0xa0ef0c													
  binary-replication.go:786	0xa0ee09		4c8ba0b8000000			MOVQ 0xb8(AX), R12												
  binary-replication.go:787	0xa0ee10		4b8d3c12			LEAQ 0(R10)(R10*1), DI												
  binary-replication.go:787	0xa0ee14		4989fd				MOVQ DI, R13													
  binary-replication.go:787	0xa0ee17		4d29e5				SUBQ R12, R13													
  binary-replication.go:787	0xa0ee1a		660f1f440000			NOPW 0(AX)(AX*1)												
  binary-replication.go:787	0xa0ee20		4d85ed				TESTQ R13, R13													
  binary-replication.go:787	0xa0ee23		0f8ca1400000			JL 0xa12eca													
  binary-replication.go:786	0xa0ee29		4c8bb8b0000000			MOVQ 0xb0(AX), R15												
  binary-replication.go:787	0xa0ee30		0f849f000000			JE 0xa0eed5													
  binary-replication.go:787	0xa0ee36		4839f9				CMPQ CX, DI													
  binary-replication.go:787	0xa0ee39		7247				JB 0xa0ee82													
  binary-replication.go:787	0xa0ee3b		4889bc2440020000		MOVQ DI, 0x240(SP)												
  binary-replication.go:786	0xa0ee43		48898c2438020000		MOVQ CX, 0x238(SP)												
  binary-replication.go:786	0xa0ee4b		4c89bc24400b0000		MOVQ R15, 0xb40(SP)												
  binary-replication.go:787	0xa0ee53		4c29ef				SUBQ R13, DI													
  binary-replication.go:787	0xa0ee56		498d04ff			LEAQ 0(R15)(DI*8), AX												
  binary-replication.go:787	0xa0ee5a		49c1e503			SHLQ $0x3, R13													
  binary-replication.go:787	0xa0ee5e		4c89eb				MOVQ R13, BX													
  binary-replication.go:787	0xa0ee61		e81af7a7ff			CALL runtime.memclrHasPointers(SB)										
  binary-replication.go:787	0xa0ee66		488b8c2438020000		MOVQ 0x238(SP), CX												
  binary-replication.go:787	0xa0ee6e		488b9c2440020000		MOVQ 0x240(SP), BX												
  binary-replication.go:787	0xa0ee76		488b8424400b0000		MOVQ 0xb40(SP), AX												
  binary-replication.go:787	0xa0ee7e		6690				NOPW														
  binary-replication.go:787	0xa0ee80		eb15				JMP 0xa0ee97													
  binary-replication.go:787	0xa0ee82		4c89f8				MOVQ R15, AX													
  binary-replication.go:787	0xa0ee85		4889fb				MOVQ DI, BX													
  binary-replication.go:787	0xa0ee88		4c89ef				MOVQ R13, DI													
  binary-replication.go:787	0xa0ee8b		488d357ec46a00			LEAQ 0x6ac47e(IP), SI												
  binary-replication.go:787	0xa0ee92		e8e937a8ff			CALL runtime.growslice(SB)											
  binary-replication.go:819	0xa0ee97		488b942478020000		MOVQ 0x278(SP), DX												
  binary-replication.go:797	0xa0ee9f		4c8b842458020000		MOVQ 0x258(SP), R8												
  binary-replication.go:1040	0xa0eea7		4c8b8c24f00a0000		MOVQ 0xaf0(SP), R9												
  binary-replication.go:790	0xa0eeaf		4c8b942498000000		MOVQ 0x98(SP), R10												
  binary-replication.go:872	0xa0eeb7		4c8b9c2450020000		MOVQ 0x250(SP), R11												
  binary-replication.go:872	0xa0eebf		4989dc				MOVQ BX, R12													
  binary-replication.go:872	0xa0eec2		4989c7				MOVQ AX, R15													
  binary-replication.go:787	0xa0eec5		488b842488140000		MOVQ 0x1488(SP), AX												
  binary-replication.go:766	0xa0eecd		0fb69c2490140000		MOVZX 0x1490(SP), BX												
  binary-replication.go:787	0xa0eed5		4c89a0b8000000			MOVQ R12, 0xb8(AX)												
  binary-replication.go:787	0xa0eedc		488988c0000000			MOVQ CX, 0xc0(AX)												
  binary-replication.go:787	0xa0eee3		833d7646830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:787	0xa0eeea		7419				JE 0xa0ef05													
  binary-replication.go:787	0xa0eeec		488bb0b0000000			MOVQ 0xb0(AX), SI												
  replication-common.go:300	0xa0eef3		4c89d9				MOVQ R11, CX													
  binary-replication.go:787	0xa0eef6		e82584a8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:787	0xa0eefb		4d893b				MOVQ R15, 0(R11)												
  binary-replication.go:787	0xa0eefe		49897308			MOVQ SI, 0x8(R11)												
  binary-replication.go:872	0xa0ef02		4989cb				MOVQ CX, R11													
  binary-replication.go:787	0xa0ef05		4c89b8b0000000			MOVQ R15, 0xb0(AX)												
  binary-replication.go:790	0xa0ef0c		488bb0b8000000			MOVQ 0xb8(AX), SI												
  binary-replication.go:790	0xa0ef13		4939f2				CMPQ R10, SI													
  binary-replication.go:790	0xa0ef16		7d52				JGE 0xa0ef6a													
  binary-replication.go:790	0xa0ef18		488b88b0000000			MOVQ 0xb0(AX), CX												
  binary-replication.go:791	0xa0ef1f		4a8d04d1			LEAQ 0(CX)(R10*8), AX												
  binary-replication.go:791	0xa0ef23		4c29d6				SUBQ R10, SI													
  binary-replication.go:791	0xa0ef26		48c1e603			SHLQ $0x3, SI													
  binary-replication.go:791	0xa0ef2a		4889f3				MOVQ SI, BX													
  binary-replication.go:791	0xa0ef2d		e84ef6a7ff			CALL runtime.memclrHasPointers(SB)										
  binary-replication.go:794	0xa0ef32		488b842488140000		MOVQ 0x1488(SP), AX												
  binary-replication.go:819	0xa0ef3a		488b942478020000		MOVQ 0x278(SP), DX												
  binary-replication.go:766	0xa0ef42		0fb69c2490140000		MOVZX 0x1490(SP), BX												
  binary-replication.go:797	0xa0ef4a		4c8b842458020000		MOVQ 0x258(SP), R8												
  binary-replication.go:1040	0xa0ef52		4c8b8c24f00a0000		MOVQ 0xaf0(SP), R9												
  binary-replication.go:794	0xa0ef5a		4c8b942498000000		MOVQ 0x98(SP), R10												
  binary-replication.go:872	0xa0ef62		4c8b9c2450020000		MOVQ 0x250(SP), R11												
  binary-replication.go:794	0xa0ef6a		488bb0c0000000			MOVQ 0xc0(AX), SI												
  binary-replication.go:794	0xa0ef71		4939f2				CMPQ R10, SI													
  binary-replication.go:794	0xa0ef74		0f874b3f0000			JA 0xa12ec5													
  binary-replication.go:794	0xa0ef7a		4c8990b8000000			MOVQ R10, 0xb8(AX)												
  binary-replication.go:797	0xa0ef81		498b9018010000			MOVQ 0x118(R8), DX												
  binary-replication.go:797	0xa0ef88		48899424480b0000		MOVQ DX, 0xb48(SP)												
  binary-replication.go:797	0xa0ef90		488b8c2420140000		MOVQ 0x1420(SP), CX												
  ordered-map.go:32		0xa0ef98		488b5a20			MOVQ 0x20(DX), BX												
  ordered-map.go:32		0xa0ef9c		488d0515d46d00			LEAQ 0x6dd415(IP), AX												
  binary-replication.go:795	0xa0efa3		f20f10842428140000		MOVSD_XMM 0x1428(SP), X0											
  binary-replication.go:795	0xa0efac		f20f11842430020000		MOVSD_XMM X0, 0x230(SP)												
  binary-replication.go:795	0xa0efb5		f20f10842430140000		MOVSD_XMM 0x1430(SP), X0											
  binary-replication.go:795	0xa0efbe		f20f11842428020000		MOVSD_XMM X0, 0x228(SP)												
  ordered-map.go:32		0xa0efc7		e85406a0ff			CALL runtime.mapaccess1_fast64(SB)										
  ordered-map.go:32		0xa0efcc		488b10				MOVQ 0(AX), DX													
  ordered-map.go:32		0xa0efcf		4885d2				TESTQ DX, DX													
  ordered-map.go:32		0xa0efd2		743c				JE 0xa0f010													
  ordered-map.go:33		0xa0efd4		488b8c24480b0000		MOVQ 0xb48(SP), CX												
  ordered-map.go:33		0xa0efdc		488b5910			MOVQ 0x10(CX), BX												
  ordered-map.go:33		0xa0efe0		48ffca				DECQ DX														
  ordered-map.go:33		0xa0efe3		4839d3				CMPQ BX, DX													
  ordered-map.go:33		0xa0efe6		0f86d03e0000			JBE 0xa12ebc													
  ordered-map.go:33		0xa0efec		488b4908			MOVQ 0x8(CX), CX												
  ordered-map.go:33		0xa0eff0		48c1e205			SHLQ $0x5, DX													
  ordered-map.go:33		0xa0eff4		488b5c0a08			MOVQ 0x8(DX)(CX*1), BX												
  binary-replication.go:798	0xa0eff9		488b5b18			MOVQ 0x18(BX), BX												
  ordered-map.go:33		0xa0effd		488b440a10			MOVQ 0x10(DX)(CX*1), AX												
  binary-replication.go:798	0xa0f002		ffd3				CALL BX														
  binary-replication.go:798	0xa0f004		f20f104018			MOVSD_XMM 0x18(AX), X0												
  binary-replication.go:798	0xa0f009		f20f104820			MOVSD_XMM 0x20(AX), X1												
  binary-replication.go:798	0xa0f00e		eb12				JMP 0xa0f022													
  binary-replication.go:798	0xa0f010		f20f10842430020000		MOVSD_XMM 0x230(SP), X0												
  binary-replication.go:798	0xa0f019		f20f108c2428020000		MOVSD_XMM 0x228(SP), X1												
  binary-replication.go:801	0xa0f022		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:801	0xa0f02a		488b7208			MOVQ 0x8(DX), SI												
  binary-replication.go:801	0xa0f02e		4c8d4601			LEAQ 0x1(SI), R8												
  binary-replication.go:801	0xa0f032		4c894208			MOVQ R8, 0x8(DX)												
  binary-replication.go:803	0xa0f036		4c8b8aa8000000			MOVQ 0xa8(DX), R9												
  binary-replication.go:803	0xa0f03d		0f1f00				NOPL 0(AX)													
  binary-replication.go:803	0xa0f040		4d85c9				TESTQ R9, R9													
  binary-replication.go:803	0xa0f043		7411				JE 0xa0f056													
  binary-replication.go:803	0xa0f045		4d8b09				MOVQ 0(R9), R9													
  binary-replication.go:766	0xa0f048		440fb6942490140000		MOVZX 0x1490(SP), R10												
  binary-replication.go:766	0xa0f051		4584d2				TESTL R10, R10													
  binary-replication.go:803	0xa0f054		eb12				JMP 0xa0f068													
  binary-replication.go:766	0xa0f056		440fb6942490140000		MOVZX 0x1490(SP), R10												
  binary-replication.go:766	0xa0f05f		4584d2				TESTL R10, R10													
  binary-replication.go:766	0xa0f062		41b900000000			MOVL $0x0, R9													
  binary-replication.go:801	0xa0f068		4889b42420020000		MOVQ SI, 0x220(SP)												
  binary-replication.go:801	0xa0f070		4c89842418020000		MOVQ R8, 0x218(SP)												
  binary-replication.go:798	0xa0f078		f20f11842428010000		MOVSD_XMM X0, 0x128(SP)												
  binary-replication.go:798	0xa0f081		f20f118c2420010000		MOVSD_XMM X1, 0x120(SP)												
  binary-replication.go:798	0xa0f08a		4c898c2418010000		MOVQ R9, 0x118(SP)												
  binary-replication.go:806	0xa0f092		48c7426800000000		MOVQ $0x0, 0x68(DX)												
  binary-replication.go:807	0xa0f09a		48c7828000000000000000		MOVQ $0x0, 0x80(DX)												
  binary-replication.go:809	0xa0f0a5		f20f109270070000		MOVSD_XMM 0x770(DX), X2												
  binary-replication.go:809	0xa0f0ad		f20f11942430020000		MOVSD_XMM X2, 0x230(SP)												
  binary-replication.go:809	0xa0f0b6		f20f109a80070000		MOVSD_XMM 0x780(DX), X3												
  binary-replication.go:809	0xa0f0be		f20f119c2428020000		MOVSD_XMM X3, 0x228(SP)												
  binary-replication.go:809	0xa0f0c7		f20f10a268070000		MOVSD_XMM 0x768(DX), X4												
  binary-replication.go:809	0xa0f0cf		f20f11a42410020000		MOVSD_XMM X4, 0x210(SP)												
  binary-replication.go:809	0xa0f0d8		f20f10aa78070000		MOVSD_XMM 0x778(DX), X5												
  binary-replication.go:809	0xa0f0e0		f20f11ac2408020000		MOVSD_XMM X5, 0x208(SP)												
  binary-replication.go:814	0xa0f0e9		7531				JNE 0xa0f11c													
  binary-replication.go:814	0xa0f0eb		4c8b9c2458020000		MOVQ 0x258(SP), R11												
  binary-replication.go:814	0xa0f0f3		4d8ba388010000			MOVQ 0x188(R11), R12												
  binary-replication.go:814	0xa0f0fa		4c2b6210			SUBQ 0x10(DX), R12												
  binary-replication.go:814	0xa0f0fe		4c8baa38070000			MOVQ 0x738(DX), R13												
  binary-replication.go:814	0xa0f105		4983fd01			CMPQ R13, $0x1													
  binary-replication.go:814	0xa0f109		41bf01000000			MOVL $0x1, R15													
  binary-replication.go:814	0xa0f10f		4d0f4ffd			CMOVG R13, R15													
  binary-replication.go:814	0xa0f113		4d39e7				CMPQ R15, R12													
  binary-replication.go:814	0xa0f116		0f878d000000			JA 0xa0f1a9													
  binary-replication.go:815	0xa0f11c		488b9a60070000			MOVQ 0x760(DX), BX												
  binary-replication.go:815	0xa0f123		488d0526f66d00			LEAQ 0x6df626(IP), AX												
  binary-replication.go:815	0xa0f12a		488d0df2041100			LEAQ 0x1104f2(IP), CX												
  binary-replication.go:815	0xa0f131		bf08000000			MOVL $0x8, DI													
  binary-replication.go:815	0xa0f136		e84510a0ff			CALL runtime.mapaccess1_faststr(SB)										
  binary-replication.go:815	0xa0f13b		f20f1000			MOVSD_XMM 0(AX), X0												
  binary-replication.go:816	0xa0f13f		488b942458020000		MOVQ 0x258(SP), DX												
  binary-replication.go:816	0xa0f147		488bb288010000			MOVQ 0x188(DX), SI												
  binary-replication.go:816	0xa0f14e		4c8b842488140000		MOVQ 0x1488(SP), R8												
  binary-replication.go:816	0xa0f156		49897010			MOVQ SI, 0x10(R8)												
  binary-replication.go:817	0xa0f15a		49c7403800000000		MOVQ $0x0, 0x38(R8)												
  binary-replication.go:819	0xa0f162		488bb42478020000		MOVQ 0x278(SP), SI												
  binary-replication.go:819	0xa0f16a		4c8b4e28			MOVQ 0x28(SI), R9												
  binary-replication.go:819	0xa0f16e		4c898c24380b0000		MOVQ R9, 0xb38(SP)												
  binary-replication.go:819	0xa0f176		4c8b5630			MOVQ 0x30(SI), R10												
  binary-replication.go:819	0xa0f17a		4c89942440020000		MOVQ R10, 0x240(SP)												
  binary-replication.go:822	0xa0f182		f20f59c0			MULSD X0, X0													
  binary-replication.go:822	0xa0f186		f20f11842400020000		MOVSD_XMM X0, 0x200(SP)												
  binary-replication.go:819	0xa0f18f		4531db				XORL R11, R11													
  binary-replication.go:819	0xa0f192		f20f108c2428010000		MOVSD_XMM 0x128(SP), X1												
  binary-replication.go:819	0xa0f19b		f20f10942420010000		MOVSD_XMM 0x120(SP), X2												
  binary-replication.go:819	0xa0f1a4		e91a3a0000			JMP 0xa12bc3													
  binary-replication.go:819	0xa0f1a9		31c0				XORL AX, AX													
  binary-replication.go:819	0xa0f1ab		31c9				XORL CX, CX													
  binary-replication.go:819	0xa0f1ad		31db				XORL BX, BX													
  binary-replication.go:819	0xa0f1af		48898424b0010000		MOVQ AX, 0x1b0(SP)												
  binary-replication.go:819	0xa0f1b7		48898c24a8010000		MOVQ CX, 0x1a8(SP)												
  binary-replication.go:819	0xa0f1bf		48899c24f80a0000		MOVQ BX, 0xaf8(SP)												
  binary-replication.go:837	0xa0f1c7		488b9a50070000			MOVQ 0x750(DX), BX												
  binary-replication.go:837	0xa0f1ce		488d050bff6d00			LEAQ 0x6dff0b(IP), AX												
  binary-replication.go:837	0xa0f1d5		488d0d94fd1000			LEAQ 0x10fd94(IP), CX												
  binary-replication.go:837	0xa0f1dc		bf07000000			MOVL $0x7, DI													
  binary-replication.go:837	0xa0f1e1		e89a0fa0ff			CALL runtime.mapaccess1_faststr(SB)										
  binary-replication.go:838	0xa0f1e6		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:838	0xa0f1ee		488b9a50070000			MOVQ 0x750(DX), BX												
  binary-replication.go:837	0xa0f1f5		488b5010			MOVQ 0x10(AX), DX												
  binary-replication.go:837	0xa0f1f9		4889942478010000		MOVQ DX, 0x178(SP)												
  binary-replication.go:838	0xa0f201		488d05d8fe6d00			LEAQ 0x6dfed8(IP), AX												
  binary-replication.go:838	0xa0f208		488d0d68fd1000			LEAQ 0x10fd68(IP), CX												
  binary-replication.go:838	0xa0f20f		bf07000000			MOVL $0x7, DI													
  binary-replication.go:838	0xa0f214		e8670fa0ff			CALL runtime.mapaccess1_faststr(SB)										
  binary-replication.go:842	0xa0f219		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:842	0xa0f221		488bb238070000			MOVQ 0x738(DX), SI												
  binary-replication.go:842	0xa0f228		4c8d46ff			LEAQ -0x1(SI), R8												
  binary-replication.go:838	0xa0f22c		4c8b4810			MOVQ 0x10(AX), R9												
  binary-replication.go:839	0xa0f230		f20f108230070000		MOVSD_XMM 0x730(DX), X0												
  binary-replication.go:842	0xa0f238		4983f83f			CMPQ R8, $0x3f													
  binary-replication.go:842	0xa0f23c		772c				JA 0xa0f26a													
  binary-replication.go:842	0xa0f23e		488b842478020000		MOVQ 0x278(SP), AX												
  binary-replication.go:842	0xa0f246		4c8b6008			MOVQ 0x8(AX), R12												
  binary-replication.go:842	0xa0f24a		4939b42400080000		CMPQ 0x800(R12), SI												
  binary-replication.go:842	0xa0f252		751e				JNE 0xa0f272													
  binary-replication.go:842	0xa0f254		4d85c9				TESTQ R9, R9													
  binary-replication.go:842	0xa0f257		7e19				JLE 0xa0f272													
  binary-replication.go:842	0xa0f259		4c8ba42478010000		MOVQ 0x178(SP), R12												
  binary-replication.go:842	0xa0f261		4d85e4				TESTQ R12, R12													
  binary-replication.go:842	0xa0f264		410f9fc5			SETG R13													
  binary-replication.go:842	0xa0f268		eb13				JMP 0xa0f27d													
  binary-replication.go:864	0xa0f26a		488b842478020000		MOVQ 0x278(SP), AX												
  binary-replication.go:1089	0xa0f272		4c8ba42478010000		MOVQ 0x178(SP), R12												
  binary-replication.go:1089	0xa0f27a		4531ed				XORL R13, R13													
  binary-replication.go:838	0xa0f27d		4c898c24a8000000		MOVQ R9, 0xa8(SP)												
  binary-replication.go:842	0xa0f285		44886c2476			MOVB R13, 0x76(SP)												
  binary-replication.go:844	0xa0f28a		4c8bbc2418010000		MOVQ 0x118(SP), R15												
  binary-replication.go:844	0xa0f292		4d85ff				TESTQ R15, R15													
  binary-replication.go:844	0xa0f295		0f8e6f010000			JLE 0xa0f40a													
  binary-replication.go:844	0xa0f29b		0f1f440000			NOPL 0(AX)(AX*1)												
  binary-replication.go:842	0xa0f2a0		4584ed				TESTL R13, R13													
  binary-replication.go:844	0xa0f2a3		0f8451010000			JE 0xa0f3fa													
  binary-replication.go:842	0xa0f2a9		4489e9				MOVL R13, CX													
  binary-replication.go:845	0xa0f2ac		4c8bac2458020000		MOVQ 0x258(SP), R13												
  binary-replication.go:845	0xa0f2b4		498b9d88010000			MOVQ 0x188(R13), BX												
  binary-replication.go:845	0xa0f2bb		488b3a				MOVQ 0(DX), DI													
  binary-replication.go:845	0xa0f2be		6690				NOPW														
  binary-replication.go:1089	0xa0f2c0		4983f901			CMPQ R9, $0x1													
  binary-replication.go:1089	0xa0f2c4		750b				JNE 0xa0f2d1													
  binary-replication.go:1089	0xa0f2c6		41b801000000			MOVL $0x1, R8													
  binary-replication.go:845	0xa0f2cc		e97c000000			JMP 0xa0f34d													
  binary-replication.go:1093	0xa0f2d1		4d85c9				TESTQ R9, R9													
  binary-replication.go:1093	0xa0f2d4		7e3a				JLE 0xa0f310													
  binary-replication.go:1093	0xa0f2d6		4d8d41ff			LEAQ -0x1(R9), R8												
  binary-replication.go:1093	0xa0f2da		4d85c1				TESTQ R8, R9													
  binary-replication.go:1093	0xa0f2dd		752e				JNE 0xa0f30d													
  binary-replication.go:1093	0xa0f2df		90				NOPL														
  binary-replication.go:1095	0xa0f2e0		4c85c3				TESTQ R8, BX													
  binary-replication.go:1095	0xa0f2e3		7508				JNE 0xa0f2ed													
  binary-replication.go:1095	0xa0f2e5		41b801000000			MOVL $0x1, R8													
  binary-replication.go:1095	0xa0f2eb		eb60				JMP 0xa0f34d													
  binary-replication.go:1095	0xa0f2ed		49f7d9				NEGQ R9														
  binary-replication.go:1095	0xa0f2f0		4d89ca				MOVQ R9, R10													
  binary-replication.go:1095	0xa0f2f3		4921d9				ANDQ BX, R9													
  binary-replication.go:1095	0xa0f2f6		4921fa				ANDQ DI, R10													
  binary-replication.go:1095	0xa0f2f9		4d39ca				CMPQ R10, R9													
  binary-replication.go:1095	0xa0f2fc		410f95c1			SETNE R9													
  binary-replication.go:1095	0xa0f300		4589c8				MOVL R9, R8													
  binary-replication.go:851	0xa0f303		4c8b8c24a8000000		MOVQ 0xa8(SP), R9												
  binary-replication.go:1095	0xa0f30b		eb40				JMP 0xa0f34d													
  binary-replication.go:1093	0xa0f30d		4d85c9				TESTQ R9, R9													
  binary-replication.go:1098	0xa0f310		0f84a2380000			JE 0xa12bb8													
  binary-replication.go:775	0xa0f316		4989c0				MOVQ AX, R8													
  binary-replication.go:1098	0xa0f319		4889d8				MOVQ BX, AX													
  binary-replication.go:766	0xa0f31c		4989d2				MOVQ DX, R10													
  binary-replication.go:1098	0xa0f31f		31d2				XORL DX, DX													
  binary-replication.go:1098	0xa0f321		49f7f1				DIVQ R9														
  binary-replication.go:1098	0xa0f324		4885d2				TESTQ DX, DX													
  binary-replication.go:1098	0xa0f327		7507				JNE 0xa0f330													
  binary-replication.go:1098	0xa0f329		ba01000000			MOVL $0x1, DX													
  binary-replication.go:1098	0xa0f32e		eb14				JMP 0xa0f344													
  binary-replication.go:1098	0xa0f330		4889c2				MOVQ AX, DX													
  binary-replication.go:1098	0xa0f333		4889f8				MOVQ DI, AX													
  binary-replication.go:1098	0xa0f336		4989d3				MOVQ DX, R11													
  binary-replication.go:1098	0xa0f339		31d2				XORL DX, DX													
  binary-replication.go:1098	0xa0f33b		49f7f1				DIVQ R9														
  binary-replication.go:1098	0xa0f33e		4c39d8				CMPQ AX, R11													
  binary-replication.go:1098	0xa0f341		0f95c2				SETNE DL													
  binary-replication.go:864	0xa0f344		4c89c0				MOVQ R8, AX													
  binary-replication.go:845	0xa0f347		4189d0				MOVL DX, R8													
  binary-replication.go:877	0xa0f34a		4c89d2				MOVQ R10, DX													
  binary-replication.go:1089	0xa0f34d		4983fc01			CMPQ R12, $0x1													
  binary-replication.go:1089	0xa0f351		750d				JNE 0xa0f360													
  binary-replication.go:1089	0xa0f353		41ba01000000			MOVL $0x1, R10													
  binary-replication.go:846	0xa0f359		e98c000000			JMP 0xa0f3ea													
  binary-replication.go:846	0xa0f35e		6690				NOPW														
  binary-replication.go:1093	0xa0f360		4d85e4				TESTQ R12, R12													
  binary-replication.go:1093	0xa0f363		7e3e				JLE 0xa0f3a3													
  binary-replication.go:1093	0xa0f365		4d8d5424ff			LEAQ -0x1(R12), R10												
  binary-replication.go:1093	0xa0f36a		4d85d4				TESTQ R10, R12													
  binary-replication.go:1093	0xa0f36d		7531				JNE 0xa0f3a0													
  binary-replication.go:1095	0xa0f36f		4c85d3				TESTQ R10, BX													
  binary-replication.go:1095	0xa0f372		7508				JNE 0xa0f37c													
  binary-replication.go:1095	0xa0f374		41ba01000000			MOVL $0x1, R10													
  binary-replication.go:1095	0xa0f37a		eb6e				JMP 0xa0f3ea													
  binary-replication.go:1095	0xa0f37c		49f7dc				NEGQ R12													
  binary-replication.go:1095	0xa0f37f		4d89e3				MOVQ R12, R11													
  binary-replication.go:1095	0xa0f382		4921dc				ANDQ BX, R12													
  binary-replication.go:1095	0xa0f385		4921fb				ANDQ DI, R11													
  binary-replication.go:1095	0xa0f388		4d39e3				CMPQ R11, R12													
  binary-replication.go:1095	0xa0f38b		410f95c4			SETNE R12													
  binary-replication.go:1095	0xa0f38f		4589e2				MOVL R12, R10													
  binary-replication.go:855	0xa0f392		4c8ba42478010000		MOVQ 0x178(SP), R12												
  binary-replication.go:1095	0xa0f39a		eb4e				JMP 0xa0f3ea													
  binary-replication.go:1095	0xa0f39c		0f1f4000			NOPL 0(AX)													
  binary-replication.go:1093	0xa0f3a0		4d85e4				TESTQ R12, R12													
  binary-replication.go:1098	0xa0f3a3		0f840a380000			JE 0xa12bb3													
  binary-replication.go:775	0xa0f3a9		4989c2				MOVQ AX, R10													
  binary-replication.go:1098	0xa0f3ac		4889d8				MOVQ BX, AX													
  binary-replication.go:766	0xa0f3af		4989d3				MOVQ DX, R11													
  binary-replication.go:1098	0xa0f3b2		31d2				XORL DX, DX													
  binary-replication.go:1098	0xa0f3b4		49f7f4				DIVQ R12													
  binary-replication.go:1098	0xa0f3b7		4885d2				TESTQ DX, DX													
  binary-replication.go:1098	0xa0f3ba		7507				JNE 0xa0f3c3													
  binary-replication.go:1098	0xa0f3bc		ba01000000			MOVL $0x1, DX													
  binary-replication.go:1098	0xa0f3c1		eb1e				JMP 0xa0f3e1													
  binary-replication.go:1098	0xa0f3c3		48898424f8010000		MOVQ AX, 0x1f8(SP)												
  binary-replication.go:1098	0xa0f3cb		4889f8				MOVQ DI, AX													
  binary-replication.go:1098	0xa0f3ce		31d2				XORL DX, DX													
  binary-replication.go:1098	0xa0f3d0		49f7f4				DIVQ R12													
  binary-replication.go:1098	0xa0f3d3		488b9424f8010000		MOVQ 0x1f8(SP), DX												
  binary-replication.go:1098	0xa0f3db		4839d0				CMPQ AX, DX													
  binary-replication.go:1098	0xa0f3de		0f95c2				SETNE DL													
  binary-replication.go:864	0xa0f3e1		4c89d0				MOVQ R10, AX													
  binary-replication.go:846	0xa0f3e4		4189d2				MOVL DX, R10													
  binary-replication.go:877	0xa0f3e7		4c89da				MOVQ R11, DX													
  binary-replication.go:766	0xa0f3ea		4989d3				MOVQ DX, R11													
  binary-replication.go:848	0xa0f3ed		31d2				XORL DX, DX													
  binary-replication.go:848	0xa0f3ef		4531ed				XORL R13, R13													
  binary-replication.go:848	0xa0f3f2		4531ff				XORL R15, R15													
  binary-replication.go:848	0xa0f3f5		e92f360000			JMP 0xa12a29													
  binary-replication.go:848	0xa0f3fa		31c9				XORL CX, CX													
  binary-replication.go:848	0xa0f3fc		31db				XORL BX, BX													
  binary-replication.go:848	0xa0f3fe		be01000000			MOVL $0x1, SI													
  binary-replication.go:848	0xa0f403		bf01000000			MOVL $0x1, DI													
  binary-replication.go:844	0xa0f408		eb0e				JMP 0xa0f418													
  binary-replication.go:844	0xa0f40a		31c9				XORL CX, CX													
  binary-replication.go:844	0xa0f40c		31db				XORL BX, BX													
  binary-replication.go:844	0xa0f40e		be01000000			MOVL $0x1, SI													
  binary-replication.go:844	0xa0f413		bf01000000			MOVL $0x1, DI													
  binary-replication.go:844	0xa0f418		48898c2498010000		MOVQ CX, 0x198(SP)												
  binary-replication.go:861	0xa0f420		803d0635830000			CMPB github.com/burntcustard/unicorn-mining-co/src/server/network.vectorReplication(SB), $0x0			
  binary-replication.go:861	0xa0f427		7459				JE 0xa0f482													
  binary-replication.go:861	0xa0f429		4d89f8				MOVQ R15, R8													
  binary-replication.go:861	0xa0f42c		49c1e702			SHLQ $0x2, R15													
  binary-replication.go:837	0xa0f430		4d89e2				MOVQ R12, R10													
  binary-replication.go:861	0xa0f433		4c8ba42498000000		MOVQ 0x98(SP), R12												
  binary-replication.go:861	0xa0f43b		0f1f440000			NOPL 0(AX)(AX*1)												
  binary-replication.go:861	0xa0f440		4d39fc				CMPQ R12, R15													
  binary-replication.go:861	0xa0f443		7e32				JLE 0xa0f477													
  binary-replication.go:861	0xa0f445		4c8bbc2458020000		MOVQ 0x258(SP), R15												
  binary-replication.go:861	0xa0f44d		4d8b9f78010000			MOVQ 0x178(R15), R11												
  binary-replication.go:861	0xa0f454		4d85db				TESTQ R11, R11													
  binary-replication.go:861	0xa0f457		743f				JE 0xa0f498													
  ordered-map.go:50		0xa0f459		4d8b5b20			MOVQ 0x20(R11), R11												
  ordered-map.go:50		0xa0f45d		0f1f00				NOPL 0(AX)													
  ordered-map.go:50		0xa0f460		4d85db				TESTQ R11, R11													
  ordered-map.go:50		0xa0f463		7405				JE 0xa0f46a													
  ordered-map.go:50		0xa0f465		4d8b1b				MOVQ 0(R11), R11												
  ordered-map.go:50		0xa0f468		eb03				JMP 0xa0f46d													
  ordered-map.go:50		0xa0f46a		4531db				XORL R11, R11													
  binary-replication.go:861	0xa0f46d		4983fb08			CMPQ R11, $0x8													
  binary-replication.go:861	0xa0f471		410f9dc3			SETGE R11													
  binary-replication.go:861	0xa0f475		eb24				JMP 0xa0f49b													
  binary-replication.go:1019	0xa0f477		4c8bbc2458020000		MOVQ 0x258(SP), R15												
  binary-replication.go:1019	0xa0f47f		90				NOPL														
  binary-replication.go:861	0xa0f480		eb16				JMP 0xa0f498													
  binary-replication.go:1018	0xa0f482		4d89f8				MOVQ R15, R8													
  binary-replication.go:935	0xa0f485		4d89e2				MOVQ R12, R10													
  binary-replication.go:992	0xa0f488		4c8ba42498000000		MOVQ 0x98(SP), R12												
  binary-replication.go:1019	0xa0f490		4c8bbc2458020000		MOVQ 0x258(SP), R15												
  binary-replication.go:861	0xa0f498		4531db				XORL R11, R11													
  binary-replication.go:864	0xa0f49b		488b4808			MOVQ 0x8(AX), CX												
  binary-replication.go:864	0xa0f49f		8401				TESTB AL, 0(CX)													
  binary-replication.go:861	0xa0f4a1		4584db				TESTL R11, R11													
  binary-replication.go:865	0xa0f4a4		743e				JE 0xa0f4e4													
  binary-replication.go:864	0xa0f4a6		f20f10a138080000		MOVSD_XMM 0x838(CX), X4												
  binary-replication.go:865	0xa0f4ae		f20f10942430020000		MOVSD_XMM 0x230(SP), X2												
  binary-replication.go:865	0xa0f4b7		660f2ed4			UCOMISD X4, X2													
  binary-replication.go:865	0xa0f4bb		7530				JNE 0xa0f4ed													
  binary-replication.go:865	0xa0f4bd		7a2e				JP 0xa0f4ed													
  binary-replication.go:864	0xa0f4bf		f20f10a148080000		MOVSD_XMM 0x848(CX), X4												
  binary-replication.go:865	0xa0f4c7		f20f109c2428020000		MOVSD_XMM 0x228(SP), X3												
  binary-replication.go:865	0xa0f4d0		660f2ee3			UCOMISD X3, X4													
  binary-replication.go:842	0xa0f4d4		4489e9				MOVL R13, CX													
  binary-replication.go:865	0xa0f4d7		410f94c3			SETE R11													
  binary-replication.go:865	0xa0f4db		410f9bc5			SETNP R13													
  binary-replication.go:865	0xa0f4df		4521eb				ANDL R13, R11													
  binary-replication.go:865	0xa0f4e2		eb18				JMP 0xa0f4fc													
  binary-replication.go:995	0xa0f4e4		f20f10942430020000		MOVSD_XMM 0x230(SP), X2												
  binary-replication.go:842	0xa0f4ed		4489e9				MOVL R13, CX													
  binary-replication.go:995	0xa0f4f0		f20f109c2428020000		MOVSD_XMM 0x228(SP), X3												
  binary-replication.go:995	0xa0f4f9		4531db				XORL R11, R11													
  binary-replication.go:995	0xa0f4fc		48899c24a0010000		MOVQ BX, 0x1a0(SP)												
  binary-replication.go:995	0xa0f504		4088742479			MOVB SI, 0x79(SP)												
  binary-replication.go:995	0xa0f509		40887c2474			MOVB DI, 0x74(SP)												
  binary-replication.go:865	0xa0f50e		4584db				TESTL R11, R11													
  binary-replication.go:867	0xa0f511		0f842e010000			JE 0xa0f645													
  replication-simd.go:14	0xa0f517		80780100			CMPB 0x1(AX), $0x0												
  replication-simd.go:14	0xa0f51b		7408				JE 0xa0f525													
  binary-replication.go:865	0xa0f51d		4584db				TESTL R11, R11													
  binary-replication.go:868	0xa0f520		e920010000			JMP 0xa0f645													
  replication-simd.go:18	0xa0f525		c6400101			MOVB $0x1, 0x1(AX)												
  replication-simd.go:19	0xa0f529		4c8b6830			MOVQ 0x30(AX), R13												
  replication-simd.go:21	0xa0f52d		4c39a8c8000000			CMPQ 0xc8(AX), R13												
  replication-simd.go:21	0xa0f534		0f8dde000000			JGE 0xa0f618													
  binary-replication.go:839	0xa0f53a		f20f11842400020000		MOVSD_XMM X0, 0x200(SP)												
  replication-simd.go:19	0xa0f543		4c89ac2440020000		MOVQ R13, 0x240(SP)												
  binary-replication.go:865	0xa0f54b		44885c2475			MOVB R11, 0x75(SP)												
  replication-simd.go:22	0xa0f550		4b8d4c2d00			LEAQ 0(R13)(R13*1), CX												
  replication-simd.go:22	0xa0f555		48898c2438020000		MOVQ CX, 0x238(SP)												
  replication-simd.go:22	0xa0f55d		488d052c4e7100			LEAQ 0x714e2c(IP), AX												
  replication-simd.go:22	0xa0f564		4889cb				MOVQ CX, BX													
  replication-simd.go:22	0xa0f567		e83430a8ff			CALL runtime.makeslice(SB)											
  replication-simd.go:22	0xa0f56c		488b942438020000		MOVQ 0x238(SP), DX												
  replication-simd.go:22	0xa0f574		488bb42478020000		MOVQ 0x278(SP), SI												
  replication-simd.go:22	0xa0f57c		488996c0000000			MOVQ DX, 0xc0(SI)												
  replication-simd.go:22	0xa0f583		488996c8000000			MOVQ DX, 0xc8(SI)												
  replication-simd.go:22	0xa0f58a		833dcf3f830000			CMPL runtime.writeBarrier(SB), $0x0										
  replication-simd.go:22	0xa0f591		7413				JE 0xa0f5a6													
  replication-simd.go:22	0xa0f593		488b96b8000000			MOVQ 0xb8(SI), DX												
  replication-simd.go:22	0xa0f59a		e8817da8ff			CALL runtime.gcWriteBarrier2(SB)										
  replication-simd.go:22	0xa0f59f		498903				MOVQ AX, 0(R11)													
  replication-simd.go:22	0xa0f5a2		49895308			MOVQ DX, 0x8(R11)												
  replication-simd.go:22	0xa0f5a6		488986b8000000			MOVQ AX, 0xb8(SI)												
  replication-simd.go:25	0xa0f5ad		4889f0				MOVQ SI, AX													
  binary-replication.go:842	0xa0f5b0		0fb64c2476			MOVZX 0x76(SP), CX												
  binary-replication.go:877	0xa0f5b5		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:920	0xa0f5bd		0fb6742479			MOVZX 0x79(SP), SI												
  binary-replication.go:920	0xa0f5c2		0fb67c2474			MOVZX 0x74(SP), DI												
  binary-replication.go:1018	0xa0f5c7		4c8b842418010000		MOVQ 0x118(SP), R8												
  binary-replication.go:935	0xa0f5cf		4c8b8c24a8000000		MOVQ 0xa8(SP), R9												
  binary-replication.go:935	0xa0f5d7		4c8b942478010000		MOVQ 0x178(SP), R10												
  binary-replication.go:865	0xa0f5df		440fb65c2475			MOVZX 0x75(SP), R11												
  binary-replication.go:992	0xa0f5e5		4c8ba42498000000		MOVQ 0x98(SP), R12												
  replication-simd.go:25	0xa0f5ed		4c8bac2440020000		MOVQ 0x240(SP), R13												
  binary-replication.go:1019	0xa0f5f5		4c8bbc2458020000		MOVQ 0x258(SP), R15												
  binary-replication.go:839	0xa0f5fd		f20f10842400020000		MOVSD_XMM 0x200(SP), X0												
  binary-replication.go:995	0xa0f606		f20f10942430020000		MOVSD_XMM 0x230(SP), X2												
  binary-replication.go:995	0xa0f60f		f20f109c2428020000		MOVSD_XMM 0x228(SP), X3												
  replication-simd.go:25	0xa0f618		488b98c8000000			MOVQ 0xc8(AX), BX												
  replication-simd.go:25	0xa0f61f		90				NOPL														
  replication-simd.go:25	0xa0f620		4c39eb				CMPQ BX, R13													
  replication-simd.go:25	0xa0f623		0f82bc330000			JB 0xa129e5													
  replication-simd.go:25	0xa0f629		4c89a8c0000000			MOVQ R13, 0xc0(AX)												
  replication-simd.go:27	0xa0f630		4c8b6828			MOVQ 0x28(AX), R13												
  replication-simd.go:27	0xa0f634		488b5830			MOVQ 0x30(AX), BX												
  replication-simd.go:27	0xa0f638		4531ff				XORL R15, R15													
  replication-simd.go:27	0xa0f63b		0f1f440000			NOPL 0(AX)(AX*1)												
  replication-simd.go:27	0xa0f640		e966330000			JMP 0xa129ab													
  binary-replication.go:839	0xa0f645		f20f59c0			MULSD X0, X0													
  binary-replication.go:839	0xa0f649		f20f118424a0000000		MOVSD_XMM X0, 0xa0(SP)												
  binary-replication.go:991	0xa0f652		7431				JE 0xa0f685													
  binary-replication.go:992	0xa0f654		4d89e5				MOVQ R12, R13													
  binary-replication.go:992	0xa0f657		4983e4f0			ANDQ $-0x10, R12												
  binary-replication.go:992	0xa0f65b		4c89a42460010000		MOVQ R12, 0x160(SP)												
  binary-replication.go:992	0xa0f663		4531db				XORL R11, R11													
  binary-replication.go:994	0xa0f666		4531db				XORL R11, R11													
  binary-replication.go:994	0xa0f669		4c899c2440020000		MOVQ R11, 0x240(SP)												
  binary-replication.go:994	0xa0f671		4531db				XORL R11, R11													
  binary-replication.go:994	0xa0f674		44885c2477			MOVB R11, 0x77(SP)												
  binary-replication.go:994	0xa0f679		4531db				XORL R11, R11													
  binary-replication.go:994	0xa0f67c		0f1f4000			NOPL 0(AX)													
  binary-replication.go:994	0xa0f680		e99b280000			JMP 0xa11f20													
  binary-replication.go:994	0xa0f685		4531db				XORL R11, R11													
  binary-replication.go:994	0xa0f688		4531ed				XORL R13, R13													
  binary-replication.go:994	0xa0f68b		4531db				XORL R11, R11													
  binary-replication.go:994	0xa0f68e		44885c2477			MOVB R11, 0x77(SP)												
  binary-replication.go:994	0xa0f693		4531db				XORL R11, R11													
  binary-replication.go:1006	0xa0f696		440fb67c2477			MOVZX 0x77(SP), R15												
  binary-replication.go:1006	0xa0f69c		f20f108c2428010000		MOVSD_XMM 0x128(SP), X1												
  binary-replication.go:1006	0xa0f6a5		f20f10a42420010000		MOVSD_XMM 0x120(SP), X4												
  binary-replication.go:1006	0xa0f6ae		488b9c2450020000		MOVQ 0x250(SP), BX												
  binary-replication.go:1006	0xa0f6b6		488bb42420020000		MOVQ 0x220(SP), SI												
  binary-replication.go:1006	0xa0f6be		6690				NOPW														
  binary-replication.go:1006	0xa0f6c0		eb24				JMP 0xa0f6e6													
  binary-replication.go:1006	0xa0f6c2		49ffc3				INCQ R11													
  binary-replication.go:920	0xa0f6c5		0fb67c2474			MOVZX 0x74(SP), DI												
  binary-replication.go:935	0xa0f6ca		4c8b8c24a8000000		MOVQ 0xa8(SP), R9												
  binary-replication.go:935	0xa0f6d2		4c8b942478010000		MOVQ 0x178(SP), R10												
  binary-replication.go:1011	0xa0f6da		0f10d5				MOVUPS X5, X2													
  binary-replication.go:1011	0xa0f6dd		f20f109c2428020000		MOVSD_XMM 0x228(SP), X3												
  binary-replication.go:1006	0xa0f6e6		4d39e3				CMPQ R11, R12													
  binary-replication.go:1006	0xa0f6e9		0f8dc2080000			JGE 0xa0ffb1													
  binary-replication.go:1007	0xa0f6ef		488bb890000000			MOVQ 0x90(AX), DI												
  binary-replication.go:1007	0xa0f6f6		4939fb				CMPQ R11, DI													
  binary-replication.go:1007	0xa0f6f9		0f8390270000			JAE 0xa11e8f													
  binary-replication.go:1007	0xa0f6ff		488bb888000000			MOVQ 0x88(AX), DI												
  binary-replication.go:1007	0xa0f706		f2420f102cdf			MOVSD_XMM 0(DI)(R11*8), X5											
  binary-replication.go:1007	0xa0f70c		488bb8a8000000			MOVQ 0xa8(AX), DI												
  binary-replication.go:1007	0xa0f713		f20f5ce9			SUBSD X1, X5													
  binary-replication.go:1007	0xa0f717		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-replication.go:1007	0xa0f720		4939fb				CMPQ R11, DI													
  binary-replication.go:1007	0xa0f723		0f8361270000			JAE 0xa11e8a													
  binary-replication.go:1007	0xa0f729		488bb8a0000000			MOVQ 0xa0(AX), DI												
  binary-replication.go:1007	0xa0f730		f2420f1034df			MOVSD_XMM 0(DI)(R11*8), X6											
  binary-replication.go:1007	0xa0f736		f20f5cf4			SUBSD X4, X6													
  binary-replication.go:1008	0xa0f73a		f20f59ed			MULSD X5, X5													
  binary-replication.go:1008	0xa0f73e		f20f59f6			MULSD X6, X6													
  binary-replication.go:1009	0xa0f742		488b7830			MOVQ 0x30(AX), DI												
  binary-replication.go:1008	0xa0f746		f20f58f5			ADDSD X5, X6													
  binary-replication.go:1009	0xa0f74a		4939fb				CMPQ R11, DI													
  binary-replication.go:1009	0xa0f74d		0f8332270000			JAE 0xa11e85													
  binary-replication.go:1009	0xa0f753		488b7828			MOVQ 0x28(AX), DI												
  binary-replication.go:1009	0xa0f757		4c8b4860			MOVQ 0x60(AX), R9												
  binary-replication.go:1009	0xa0f75b		4a8b3cdf			MOVQ 0(DI)(R11*8), DI												
  binary-replication.go:1009	0xa0f75f		90				NOPL														
  binary-replication.go:1009	0xa0f760		4d39cb				CMPQ R11, R9													
  binary-replication.go:1009	0xa0f763		0f8315270000			JAE 0xa11e7e													
  binary-replication.go:1009	0xa0f769		4c8b4858			MOVQ 0x58(AX), R9												
  binary-replication.go:1011	0xa0f76d		0f10ea				MOVUPS X2, X5													
  binary-replication.go:1011	0xa0f770		f20f59d2			MULSD X2, X2													
  binary-replication.go:1009	0xa0f774		4f8b0cd9			MOVQ 0(R9)(R11*8), R9												
  binary-replication.go:1011	0xa0f778		660f2ef2			UCOMISD X2, X6													
  binary-replication.go:1011	0xa0f77c		762d				JBE 0xa0f7ab													
  binary-replication.go:1011	0xa0f77e		4c8b5710			MOVQ 0x10(DI), R10												
  binary-replication.go:1011	0xa0f782		4c39942420140000		CMPQ 0x1420(SP), R10												
  binary-replication.go:1011	0xa0f78a		741f				JE 0xa0f7ab													
  binary-replication.go:1011	0xa0f78c		0f10d3				MOVUPS X3, X2													
  binary-replication.go:1011	0xa0f78f		f20f59db			MULSD X3, X3													
  binary-replication.go:1011	0xa0f793		660f2ef3			UCOMISD X3, X6													
  binary-replication.go:1011	0xa0f797		0f8725ffffff			JA 0xa0f6c2													
  binary-replication.go:1009	0xa0f79d		410fbae100			BTL $0x0, R9													
  binary-replication.go:1011	0xa0f7a2		0f831affffff			JAE 0xa0f6c2													
  binary-replication.go:896	0xa0f7a8		0f10da				MOVUPS X2, X3													
  binary-replication.go:1006	0xa0f7ab		4c899c2448010000		MOVQ R11, 0x148(SP)												
  binary-replication.go:872	0xa0f7b3		49c1e304			SHLQ $0x4, R11													
  binary-replication.go:877	0xa0f7b7		4c8b92b8000000			MOVQ 0xb8(DX), R10												
  binary-replication.go:872	0xa0f7be		498b0c1b			MOVQ 0(R11)(BX*1), CX												
  binary-replication.go:872	0xa0f7c2		4d8b5c1b08			MOVQ 0x8(R11)(BX*1), R11											
  binary-replication.go:877	0xa0f7c7		4c8ba42448010000		MOVQ 0x148(SP), R12												
  binary-replication.go:877	0xa0f7cf		4d39d4				CMPQ R12, R10													
  binary-replication.go:877	0xa0f7d2		0f83a1260000			JAE 0xa11e79													
  binary-replication.go:872	0xa0f7d8		48898c2468010000		MOVQ CX, 0x168(SP)												
  binary-replication.go:877	0xa0f7e0		4c8b92b0000000			MOVQ 0xb0(DX), R10												
  binary-replication.go:877	0xa0f7e7		4f8b14e2			MOVQ 0(R10)(R12*8), R10												
  binary-replication.go:877	0xa0f7eb		4d85d2				TESTQ R10, R10													
  binary-replication.go:877	0xa0f7ee		7432				JE 0xa0f822													
  binary-replication.go:877	0xa0f7f0		498b4a18			MOVQ 0x18(R10), CX												
  binary-replication.go:877	0xa0f7f4		48394f10			CMPQ 0x10(DI), CX												
  binary-replication.go:877	0xa0f7f8		7520				JNE 0xa0f81a													
  binary-replication.go:877	0xa0f7fa		660f1f440000			NOPW 0(AX)(AX*1)												
  binary-replication.go:877	0xa0f800		49397210			CMPQ 0x10(R10), SI												
  binary-replication.go:877	0xa0f804		750a				JNE 0xa0f810													
  binary-replication.go:659	0xa0f806		488b8c2468010000		MOVQ 0x168(SP), CX												
  binary-replication.go:878	0xa0f80e		eb15				JMP 0xa0f825													
  binary-replication.go:659	0xa0f810		488b8c2468010000		MOVQ 0x168(SP), CX												
  binary-replication.go:877	0xa0f818		eb08				JMP 0xa0f822													
  binary-replication.go:659	0xa0f81a		488b8c2468010000		MOVQ 0x168(SP), CX												
  binary-replication.go:877	0xa0f822		4531d2				XORL R10, R10													
  binary-replication.go:872	0xa0f825		4c899c24c8020000		MOVQ R11, 0x2c8(SP)												
  binary-replication.go:1008	0xa0f82d		f20f11b42488010000		MOVSD_XMM X6, 0x188(SP)												
  binary-replication.go:1009	0xa0f836		4889bc24b0020000		MOVQ DI, 0x2b0(SP)												
  binary-replication.go:1006	0xa0f83e		4c89ac2410010000		MOVQ R13, 0x110(SP)												
  binary-replication.go:1006	0xa0f846		4488bc2495000000		MOVB R15, 0x95(SP)												
  binary-replication.go:881	0xa0f84e		4d85d2				TESTQ R10, R10													
  binary-replication.go:881	0xa0f851		0f85b9000000			JNE 0xa0f910													
  binary-replication.go:1009	0xa0f857		4c898c2440020000		MOVQ R9, 0x240(SP)												
  binary-replication.go:882	0xa0f85f		488b9aa8000000			MOVQ 0xa8(DX), BX												
  binary-replication.go:882	0xa0f866		488b4f10			MOVQ 0x10(DI), CX												
  binary-replication.go:882	0xa0f86a		488d0537ca6d00			LEAQ 0x6dca37(IP), AX												
  binary-replication.go:882	0xa0f871		e8aafd9fff			CALL runtime.mapaccess1_fast64(SB)										
  binary-replication.go:882	0xa0f876		4c8b10				MOVQ 0(AX), R10													
  binary-replication.go:1007	0xa0f879		488b842478020000		MOVQ 0x278(SP), AX												
  binary-replication.go:659	0xa0f881		488b8c2468010000		MOVQ 0x168(SP), CX												
  binary-replication.go:904	0xa0f889		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:872	0xa0f891		488b9c2450020000		MOVQ 0x250(SP), BX												
  binary-replication.go:877	0xa0f899		488bb42420020000		MOVQ 0x220(SP), SI												
  binary-replication.go:900	0xa0f8a1		488bbc24b0020000		MOVQ 0x2b0(SP), DI												
  binary-replication.go:1018	0xa0f8a9		4c8b842418010000		MOVQ 0x118(SP), R8												
  binary-replication.go:1009	0xa0f8b1		4c8b8c2440020000		MOVQ 0x240(SP), R9												
  binary-replication.go:659	0xa0f8b9		4c8b9c24c8020000		MOVQ 0x2c8(SP), R11												
  binary-replication.go:1006	0xa0f8c1		4c8ba42448010000		MOVQ 0x148(SP), R12												
  binary-replication.go:1015	0xa0f8c9		4c8bac2410010000		MOVQ 0x110(SP), R13												
  binary-replication.go:1015	0xa0f8d1		440fb6bc2495000000		MOVZX 0x95(SP), R15												
  binary-replication.go:919	0xa0f8da		f20f108424a0000000		MOVSD_XMM 0xa0(SP), X0												
  binary-replication.go:1007	0xa0f8e3		f20f108c2428010000		MOVSD_XMM 0x128(SP), X1												
  binary-replication.go:896	0xa0f8ec		f20f109c2428020000		MOVSD_XMM 0x228(SP), X3												
  binary-replication.go:1007	0xa0f8f5		f20f10a42420010000		MOVSD_XMM 0x120(SP), X4												
  binary-replication.go:889	0xa0f8fe		f20f10ac2430020000		MOVSD_XMM 0x230(SP), X5												
  binary-replication.go:900	0xa0f907		f20f10b42488010000		MOVSD_XMM 0x188(SP), X6												
  binary-replication.go:885	0xa0f910		4d85d2				TESTQ R10, R10													
  binary-replication.go:888	0xa0f913		7405				JE 0xa0f91a													
  binary-replication.go:809	0xa0f915		0f10d5				MOVUPS X5, X2													
  binary-replication.go:889	0xa0f918		eb0c				JMP 0xa0f926													
  binary-replication.go:1011	0xa0f91a		0f10d5				MOVUPS X5, X2													
  binary-replication.go:889	0xa0f91d		f20f10ac2410020000		MOVSD_XMM 0x210(SP), X5												
  binary-replication.go:1009	0xa0f926		410fbae100			BTL $0x0, R9													
  binary-replication.go:892	0xa0f92b		7318				JAE 0xa0f945													
  binary-replication.go:885	0xa0f92d		4d85d2				TESTQ R10, R10													
  binary-replication.go:895	0xa0f930		7405				JE 0xa0f937													
  binary-replication.go:809	0xa0f932		0f10eb				MOVUPS X3, X5													
  binary-replication.go:896	0xa0f935		eb1a				JMP 0xa0f951													
  binary-replication.go:1011	0xa0f937		0f10eb				MOVUPS X3, X5													
  binary-replication.go:896	0xa0f93a		f20f109c2408020000		MOVSD_XMM 0x208(SP), X3												
  binary-replication.go:895	0xa0f943		eb0c				JMP 0xa0f951													
  binary-replication.go:895	0xa0f945		0f10dd				MOVUPS X5, X3													
  binary-replication.go:1011	0xa0f948		f20f10ac2428020000		MOVSD_XMM 0x228(SP), X5												
  binary-replication.go:900	0xa0f951		4c8b4f10			MOVQ 0x10(DI), R9												
  binary-replication.go:900	0xa0f955		4c398c2420140000		CMPQ 0x1420(SP), R9												
  binary-replication.go:900	0xa0f95d		740e				JE 0xa0f96d													
  binary-replication.go:900	0xa0f95f		f20f59db			MULSD X3, X3													
  binary-replication.go:900	0xa0f963		660f2ede			UCOMISD X6, X3													
  binary-replication.go:900	0xa0f967		0f8223060000			JB 0xa0ff90													
  binary-replication.go:882	0xa0f96d		4c89942488020000		MOVQ R10, 0x288(SP)												
  binary-replication.go:904	0xa0f975		4c8b4270			MOVQ 0x70(DX), R8												
  binary-replication.go:904	0xa0f979		488b7268			MOVQ 0x68(DX), SI												
  binary-replication.go:904	0xa0f97d		48ffc6				INCQ SI														
  binary-replication.go:904	0xa0f980		488b5a60			MOVQ 0x60(DX), BX												
  binary-replication.go:904	0xa0f984		4939f0				CMPQ R8, SI													
  binary-replication.go:904	0xa0f987		7208				JB 0xa0f991													
  binary-replication.go:885	0xa0f989		4d85d2				TESTQ R10, R10													
  binary-replication.go:904	0xa0f98c		e9e3000000			JMP 0xa0fa74													
  binary-replication.go:900	0xa0f991		4c898c24f0010000		MOVQ R9, 0x1f0(SP)												
  binary-replication.go:904	0xa0f999		4889d8				MOVQ BX, AX													
  binary-replication.go:904	0xa0f99c		4889f3				MOVQ SI, BX													
  binary-replication.go:904	0xa0f99f		4c89c1				MOVQ R8, CX													
  binary-replication.go:904	0xa0f9a2		bf01000000			MOVL $0x1, DI													
  binary-replication.go:904	0xa0f9a7		488d35224a7100			LEAQ 0x714a22(IP), SI												
  binary-replication.go:904	0xa0f9ae		e8cd2ca8ff			CALL runtime.growslice(SB)											
  binary-replication.go:904	0xa0f9b3		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:904	0xa0f9bb		48894a70			MOVQ CX, 0x70(DX)												
  binary-replication.go:904	0xa0f9bf		833d9a3b830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:904	0xa0f9c6		750d				JNE 0xa0f9d5													
  binary-replication.go:885	0xa0f9c8		4c8ba42488020000		MOVQ 0x288(SP), R12												
  binary-replication.go:885	0xa0f9d0		4d85e4				TESTQ R12, R12													
  binary-replication.go:904	0xa0f9d3		eb1b				JMP 0xa0f9f0													
  binary-replication.go:904	0xa0f9d5		4c8b6260			MOVQ 0x60(DX), R12												
  binary-replication.go:904	0xa0f9d9		e84279a8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:904	0xa0f9de		498903				MOVQ AX, 0(R11)													
  binary-replication.go:904	0xa0f9e1		4d896308			MOVQ R12, 0x8(R11)												
  binary-replication.go:885	0xa0f9e5		4c8ba42488020000		MOVQ 0x288(SP), R12												
  binary-replication.go:885	0xa0f9ed		4d85e4				TESTQ R12, R12													
  binary-replication.go:904	0xa0f9f0		48894260			MOVQ AX, 0x60(DX)												
  binary-replication.go:659	0xa0f9f4		488b8c2468010000		MOVQ 0x168(SP), CX												
  binary-replication.go:914	0xa0f9fc		488bbc24b0020000		MOVQ 0x2b0(SP), DI												
  binary-replication.go:904	0xa0fa04		4c8b8c24f0010000		MOVQ 0x1f0(SP), R9												
  binary-replication.go:907	0xa0fa0c		4d89e2				MOVQ R12, R10													
  binary-replication.go:659	0xa0fa0f		4c8b9c24c8020000		MOVQ 0x2c8(SP), R11												
  binary-replication.go:908	0xa0fa17		4c8ba42448010000		MOVQ 0x148(SP), R12												
  binary-replication.go:909	0xa0fa1f		4c8bac2410010000		MOVQ 0x110(SP), R13												
  binary-replication.go:911	0xa0fa27		440fb6bc2495000000		MOVZX 0x95(SP), R15												
  binary-replication.go:919	0xa0fa30		f20f108424a0000000		MOVSD_XMM 0xa0(SP), X0												
  binary-replication.go:1007	0xa0fa39		f20f108c2428010000		MOVSD_XMM 0x128(SP), X1												
  binary-replication.go:1011	0xa0fa42		f20f10942430020000		MOVSD_XMM 0x230(SP), X2												
  binary-replication.go:1007	0xa0fa4b		f20f10a42420010000		MOVSD_XMM 0x120(SP), X4												
  binary-replication.go:1011	0xa0fa54		f20f10ac2428020000		MOVSD_XMM 0x228(SP), X5												
  binary-replication.go:919	0xa0fa5d		f20f10b42488010000		MOVSD_XMM 0x188(SP), X6												
  binary-replication.go:904	0xa0fa66		4889de				MOVQ BX, SI													
  binary-replication.go:904	0xa0fa69		4889c3				MOVQ AX, BX													
  binary-replication.go:953	0xa0fa6c		488b842478020000		MOVQ 0x278(SP), AX												
  binary-replication.go:904	0xa0fa74		48897268			MOVQ SI, 0x68(DX)												
  binary-replication.go:904	0xa0fa78		4c894cf3f8			MOVQ R9, -0x8(BX)(SI*8)												
  binary-replication.go:904	0xa0fa7d		0f1f00				NOPL 0(AX)													
  binary-replication.go:906	0xa0fa80		0f848b000000			JE 0xa0fb11													
  binary-replication.go:1006	0xa0fa86		4489fb				MOVL R15, BX													
  binary-replication.go:907	0xa0fa89		4c8bbc2418020000		MOVQ 0x218(SP), R15												
  binary-replication.go:907	0xa0fa91		4d897a10			MOVQ R15, 0x10(R10)												
  binary-replication.go:908	0xa0fa95		488bb2b8000000			MOVQ 0xb8(DX), SI												
  binary-replication.go:908	0xa0fa9c		0f1f4000			NOPL 0(AX)													
  binary-replication.go:908	0xa0faa0		4939f4				CMPQ R12, SI													
  binary-replication.go:908	0xa0faa3		0f83cb230000			JAE 0xa11e74													
  binary-replication.go:908	0xa0faa9		488bb2b0000000			MOVQ 0xb0(DX), SI												
  binary-replication.go:908	0xa0fab0		833da93a830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:908	0xa0fab7		744c				JE 0xa0fb05													
  binary-replication.go:908	0xa0fab9		4e8b04e6			MOVQ 0(SI)(R12*8), R8												
  binary-replication.go:872	0xa0fabd		4d89d9				MOVQ R11, R9													
  binary-replication.go:908	0xa0fac0		e85b78a8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:908	0xa0fac5		4d8913				MOVQ R10, 0(R11)												
  binary-replication.go:908	0xa0fac8		4d894308			MOVQ R8, 0x8(R11)												
  binary-replication.go:659	0xa0facc		4d89cb				MOVQ R9, R11													
  binary-replication.go:919	0xa0facf		f20f108424a0000000		MOVSD_XMM 0xa0(SP), X0												
  binary-replication.go:1007	0xa0fad8		f20f108c2428010000		MOVSD_XMM 0x128(SP), X1												
  binary-replication.go:1011	0xa0fae1		f20f10942430020000		MOVSD_XMM 0x230(SP), X2												
  binary-replication.go:1007	0xa0faea		f20f10a42420010000		MOVSD_XMM 0x120(SP), X4												
  binary-replication.go:1011	0xa0faf3		f20f10ac2428020000		MOVSD_XMM 0x228(SP), X5												
  binary-replication.go:919	0xa0fafc		f20f10b42488010000		MOVSD_XMM 0x188(SP), X6												
  binary-replication.go:908	0xa0fb05		4e8914e6			MOVQ R10, 0(SI)(R12*8)												
  binary-replication.go:909	0xa0fb09		49ffc5				INCQ R13													
  binary-replication.go:885	0xa0fb0c		4d85d2				TESTQ R10, R10													
  binary-replication.go:909	0xa0fb0f		eb0f				JMP 0xa0fb20													
  binary-replication.go:973	0xa0fb11		4c8bbc2418020000		MOVQ 0x218(SP), R15												
  binary-replication.go:973	0xa0fb19		bb01000000			MOVL $0x1, BX													
  binary-replication.go:973	0xa0fb1e		6690				NOPW														
  binary-replication.go:914	0xa0fb20		741c				JE 0xa0fb3e													
  binary-replication.go:914	0xa0fb22		488bb42400140000		MOVQ 0x1400(SP), SI												
  binary-replication.go:914	0xa0fb2a		4c8b842408140000		MOVQ 0x1408(SP), R8												
  binary-replication.go:914	0xa0fb32		4c8b4f10			MOVQ 0x10(DI), R9												
  slices.go:97			0xa0fb36		4531ff				XORL R15, R15													
  slices.go:97			0xa0fb39		e9cd200000			JMP 0xa11c0b													
  binary-replication.go:953	0xa0fb3e		488b7048			MOVQ 0x48(AX), SI												
  binary-replication.go:953	0xa0fb42		4939f4				CMPQ R12, SI													
  binary-replication.go:953	0xa0fb45		0f83a9200000			JAE 0xa11bf4													
  binary-replication.go:909	0xa0fb4b		4c89ac24e8010000		MOVQ R13, 0x1e8(SP)												
  binary-replication.go:911	0xa0fb53		889c2494000000			MOVB BL, 0x94(SP)												
  binary-replication.go:953	0xa0fb5a		488b7040			MOVQ 0x40(AX), SI												
  binary-replication.go:953	0xa0fb5e		4a8b34e6			MOVQ 0(SI)(R12*8), SI												
  binary-replication.go:955	0xa0fb62		4885f6				TESTQ SI, SI													
  binary-replication.go:955	0xa0fb65		741e				JE 0xa0fb85													
  binary-replication.go:955	0xa0fb67		4c8b4630			MOVQ 0x30(SI), R8												
  binary-replication.go:955	0xa0fb6b		4c8b8c24f00a0000		MOVQ 0xaf0(SP), R9												
  binary-replication.go:955	0xa0fb73		4d394118			CMPQ 0x18(R9), R8												
  binary-replication.go:955	0xa0fb77		7514				JNE 0xa0fb8d													
  binary-replication.go:885	0xa0fb79		4d85d2				TESTQ R10, R10													
  binary-replication.go:885	0xa0fb7c		0f1f4000			NOPL 0(AX)													
  binary-replication.go:955	0xa0fb80		e9e0000000			JMP 0xa0fc65													
  binary-replication.go:659	0xa0fb85		4c8b8c24f00a0000		MOVQ 0xaf0(SP), R9												
  binary-replication.go:956	0xa0fb8d		90				NOPL														
  binary-replication.go:659	0xa0fb8e		4889c8				MOVQ CX, AX													
  binary-replication.go:659	0xa0fb91		4c89db				MOVQ R11, BX													
  binary-replication.go:659	0xa0fb94		4c89c9				MOVQ R9, CX													
  binary-replication.go:659	0xa0fb97		e8646fffff			CALL github.com/burntcustard/unicorn-mining-co/src/server/network.prepare(SB)					
  binary-replication.go:957	0xa0fb9c		488b942478020000		MOVQ 0x278(SP), DX												
  binary-replication.go:957	0xa0fba4		488b7248			MOVQ 0x48(DX), SI												
  binary-replication.go:957	0xa0fba8		488bbc2448010000		MOVQ 0x148(SP), DI												
  binary-replication.go:957	0xa0fbb0		4839f7				CMPQ DI, SI													
  binary-replication.go:957	0xa0fbb3		0f8336200000			JAE 0xa11bef													
  binary-replication.go:957	0xa0fbb9		488b7240			MOVQ 0x40(DX), SI												
  binary-replication.go:957	0xa0fbbd		833d9c39830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:957	0xa0fbc4		750d				JNE 0xa0fbd3													
  binary-replication.go:885	0xa0fbc6		4c8b842488020000		MOVQ 0x288(SP), R8												
  binary-replication.go:885	0xa0fbce		4d85c0				TESTQ R8, R8													
  binary-replication.go:957	0xa0fbd1		eb1b				JMP 0xa0fbee													
  binary-replication.go:957	0xa0fbd3		4c8b04fe			MOVQ 0(SI)(DI*8), R8												
  binary-replication.go:957	0xa0fbd7		e84477a8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:957	0xa0fbdc		498903				MOVQ AX, 0(R11)													
  binary-replication.go:957	0xa0fbdf		4d894308			MOVQ R8, 0x8(R11)												
  binary-replication.go:885	0xa0fbe3		4c8b842488020000		MOVQ 0x288(SP), R8												
  binary-replication.go:885	0xa0fbeb		4d85c0				TESTQ R8, R8													
  binary-replication.go:957	0xa0fbee		488904fe			MOVQ AX, 0(SI)(DI*8)												
  binary-replication.go:977	0xa0fbf2		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:1015	0xa0fbfa		0fb69c2494000000		MOVZX 0x94(SP), BX												
  binary-replication.go:973	0xa0fc02		488bbc24b0020000		MOVQ 0x2b0(SP), DI												
  binary-replication.go:984	0xa0fc0a		4c8b8c24f00a0000		MOVQ 0xaf0(SP), R9												
  binary-replication.go:964	0xa0fc12		4d89c2				MOVQ R8, R10													
  binary-replication.go:977	0xa0fc15		4c8ba42448010000		MOVQ 0x148(SP), R12												
  binary-replication.go:1015	0xa0fc1d		4c8bac24e8010000		MOVQ 0x1e8(SP), R13												
  binary-replication.go:973	0xa0fc25		4c8bbc2418020000		MOVQ 0x218(SP), R15												
  binary-replication.go:919	0xa0fc2d		f20f108424a0000000		MOVSD_XMM 0xa0(SP), X0												
  binary-replication.go:1007	0xa0fc36		f20f108c2428010000		MOVSD_XMM 0x128(SP), X1												
  binary-replication.go:1011	0xa0fc3f		f20f10942430020000		MOVSD_XMM 0x230(SP), X2												
  binary-replication.go:1007	0xa0fc48		f20f10a42420010000		MOVSD_XMM 0x120(SP), X4												
  binary-replication.go:1011	0xa0fc51		f20f10ac2428020000		MOVSD_XMM 0x228(SP), X5												
  binary-replication.go:957	0xa0fc5a		4889c6				MOVQ AX, SI													
  binary-replication.go:1007	0xa0fc5d		488b842478020000		MOVQ 0x278(SP), AX												
  binary-replication.go:963	0xa0fc65		746a				JE 0xa0fcd1													
  binary-replication.go:964	0xa0fc67		498b3a				MOVQ 0(R10), DI													
  binary-replication.go:966	0xa0fc6a		4839fe				CMPQ SI, DI													
  binary-replication.go:966	0xa0fc6d		7506				JNE 0xa0fc75													
  binary-replication.go:967	0xa0fc6f		498b4a08			MOVQ 0x8(R10), CX												
  binary-replication.go:967	0xa0fc73		eb07				JMP 0xa0fc7c													
  binary-replication.go:967	0xa0fc75		48c7c1ffffffff			MOVQ $-0x1, CX													
  binary-replication.go:970	0xa0fc7c		833ddd38830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:970	0xa0fc83		743c				JE 0xa0fcc1													
  binary-replication.go:970	0xa0fc85		4d8b02				MOVQ 0(R10), R8													
  binary-replication.go:970	0xa0fc88		e89376a8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:970	0xa0fc8d		498933				MOVQ SI, 0(R11)													
  binary-replication.go:970	0xa0fc90		4d894308			MOVQ R8, 0x8(R11)												
  binary-replication.go:919	0xa0fc94		f20f108424a0000000		MOVSD_XMM 0xa0(SP), X0												
  binary-replication.go:1007	0xa0fc9d		f20f108c2428010000		MOVSD_XMM 0x128(SP), X1												
  binary-replication.go:1011	0xa0fca6		f20f10942430020000		MOVSD_XMM 0x230(SP), X2												
  binary-replication.go:1007	0xa0fcaf		f20f10a42420010000		MOVSD_XMM 0x120(SP), X4												
  binary-replication.go:1011	0xa0fcb8		f20f10ac2428020000		MOVSD_XMM 0x228(SP), X5												
  binary-replication.go:970	0xa0fcc1		498932				MOVQ SI, 0(R10)													
  binary-replication.go:971	0xa0fcc4		4c8b4638			MOVQ 0x38(SI), R8												
  binary-replication.go:971	0xa0fcc8		4d894208			MOVQ R8, 0x8(R10)												
  binary-replication.go:971	0xa0fccc		e944010000			JMP 0xa0fe15													
  binary-replication.go:957	0xa0fcd1		4889b42498020000		MOVQ SI, 0x298(SP)												
  binary-replication.go:973	0xa0fcd9		b820000000			MOVL $0x20, AX													
  binary-replication.go:973	0xa0fcde		488d1d0b8e7500			LEAQ 0x758e0b(IP), BX												
  binary-replication.go:973	0xa0fce5		b901000000			MOVL $0x1, CX													
  binary-replication.go:973	0xa0fcea		e8911ba1ff			CALL runtime.mallocgcSmallScanNoHeaderSC4(SB)									
  binary-replication.go:973	0xa0fcef		833d6a38830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:973	0xa0fcf6		750a				JNE 0xa0fd02													
  binary-replication.go:973	0xa0fcf8		488b942498020000		MOVQ 0x298(SP), DX												
  binary-replication.go:973	0xa0fd00		eb10				JMP 0xa0fd12													
  binary-replication.go:973	0xa0fd02		e8f975a8ff			CALL runtime.gcWriteBarrier1(SB)										
  binary-replication.go:973	0xa0fd07		488b942498020000		MOVQ 0x298(SP), DX												
  binary-replication.go:973	0xa0fd0f		498913				MOVQ DX, 0(R11)													
  binary-replication.go:973	0xa0fd12		4889842488020000		MOVQ AX, 0x288(SP)												
  binary-replication.go:973	0xa0fd1a		488910				MOVQ DX, 0(AX)													
  binary-replication.go:973	0xa0fd1d		488b5238			MOVQ 0x38(DX), DX												
  binary-replication.go:973	0xa0fd21		48895008			MOVQ DX, 0x8(AX)												
  binary-replication.go:973	0xa0fd25		488b942418020000		MOVQ 0x218(SP), DX												
  binary-replication.go:973	0xa0fd2d		48895010			MOVQ DX, 0x10(AX)												
  binary-replication.go:973	0xa0fd31		488b9424b0020000		MOVQ 0x2b0(SP), DX												
  binary-replication.go:973	0xa0fd39		488b7210			MOVQ 0x10(DX), SI												
  binary-replication.go:973	0xa0fd3d		48897018			MOVQ SI, 0x18(AX)												
  binary-replication.go:974	0xa0fd41		488bb42488140000		MOVQ 0x1488(SP), SI												
  binary-replication.go:974	0xa0fd49		488b9ea8000000			MOVQ 0xa8(SI), BX												
  binary-replication.go:974	0xa0fd50		488b4a10			MOVQ 0x10(DX), CX												
  binary-replication.go:974	0xa0fd54		488d054dc56d00			LEAQ 0x6dc54d(IP), AX												
  binary-replication.go:974	0xa0fd5b		0f1f440000			NOPL 0(AX)(AX*1)												
  binary-replication.go:974	0xa0fd60		e87bfb9fff			CALL runtime.mapassign_fast64(SB)										
  binary-replication.go:974	0xa0fd65		833df437830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:974	0xa0fd6c		750a				JNE 0xa0fd78													
  binary-replication.go:974	0xa0fd6e		488bb42488020000		MOVQ 0x288(SP), SI												
  binary-replication.go:974	0xa0fd76		eb1c				JMP 0xa0fd94													
  binary-replication.go:974	0xa0fd78		488b10				MOVQ 0(AX), DX													
  binary-replication.go:974	0xa0fd7b		0f1f440000			NOPL 0(AX)(AX*1)												
  binary-replication.go:974	0xa0fd80		e89b75a8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:974	0xa0fd85		488bb42488020000		MOVQ 0x288(SP), SI												
  binary-replication.go:974	0xa0fd8d		498933				MOVQ SI, 0(R11)													
  binary-replication.go:974	0xa0fd90		49895308			MOVQ DX, 0x8(R11)												
  binary-replication.go:974	0xa0fd94		488930				MOVQ SI, 0(AX)													
  binary-replication.go:1007	0xa0fd97		488b842478020000		MOVQ 0x278(SP), AX												
  binary-replication.go:977	0xa0fd9f		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:1015	0xa0fda7		0fb69c2494000000		MOVZX 0x94(SP), BX												
  binary-replication.go:980	0xa0fdaf		488bb42498020000		MOVQ 0x298(SP), SI												
  binary-replication.go:984	0xa0fdb7		4c8b8c24f00a0000		MOVQ 0xaf0(SP), R9												
  binary-replication.go:977	0xa0fdbf		4c8ba42448010000		MOVQ 0x148(SP), R12												
  binary-replication.go:1015	0xa0fdc7		4c8bac24e8010000		MOVQ 0x1e8(SP), R13												
  binary-replication.go:907	0xa0fdcf		4c8bbc2418020000		MOVQ 0x218(SP), R15												
  binary-replication.go:919	0xa0fdd7		f20f108424a0000000		MOVSD_XMM 0xa0(SP), X0												
  binary-replication.go:1007	0xa0fde0		f20f108c2428010000		MOVSD_XMM 0x128(SP), X1												
  binary-replication.go:1011	0xa0fde9		f20f10942430020000		MOVSD_XMM 0x230(SP), X2												
  binary-replication.go:1007	0xa0fdf2		f20f10a42420010000		MOVSD_XMM 0x120(SP), X4												
  binary-replication.go:1011	0xa0fdfb		f20f10ac2428020000		MOVSD_XMM 0x228(SP), X5												
  binary-replication.go:1011	0xa0fe04		31ff				XORL DI, DI													
  binary-replication.go:1011	0xa0fe06		48c7c1ffffffff			MOVQ $-0x1, CX													
  binary-replication.go:973	0xa0fe0d		4c8b942488020000		MOVQ 0x288(SP), R10												
  binary-replication.go:977	0xa0fe15		4c8b82b8000000			MOVQ 0xb8(DX), R8												
  binary-replication.go:977	0xa0fe1c		0f1f4000			NOPL 0(AX)													
  binary-replication.go:977	0xa0fe20		4d39c4				CMPQ R12, R8													
  binary-replication.go:977	0xa0fe23		0f83c11d0000			JAE 0xa11bea													
  binary-replication.go:977	0xa0fe29		4c8b82b0000000			MOVQ 0xb0(DX), R8												
  binary-replication.go:980	0xa0fe30		4839f7				CMPQ DI, SI													
  binary-replication.go:981	0xa0fe33		41bb00000000			MOVL $0x0, R11													
  binary-replication.go:981	0xa0fe39		490f44fb			CMOVE R11, DI													
  binary-replication.go:977	0xa0fe3d		833d1c37830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:977	0xa0fe44		7420				JE 0xa0fe66													
  binary-replication.go:977	0xa0fe46		4f8b1ce0			MOVQ 0(R8)(R12*8), R11												
  binary-replication.go:977	0xa0fe4a		4c899c24e0010000		MOVQ R11, 0x1e0(SP)												
  binary-replication.go:977	0xa0fe52		e8c974a8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:977	0xa0fe57		4d8913				MOVQ R10, 0(R11)												
  binary-replication.go:977	0xa0fe5a		4c8bbc24e0010000		MOVQ 0x1e0(SP), R15												
  binary-replication.go:977	0xa0fe62		4d897b08			MOVQ R15, 0x8(R11)												
  binary-replication.go:977	0xa0fe66		4f8914e0			MOVQ R10, 0(R8)(R12*8)												
  binary-replication.go:984	0xa0fe6a		4c89c8				MOVQ R9, AX													
  binary-replication.go:984	0xa0fe6d		4889f3				MOVQ SI, BX													
  binary-replication.go:984	0xa0fe70		e80be6ffff			CALL github.com/burntcustard/unicorn-mining-co/src/server/network.(*BinarySnapshotBatch).fragment(SB)		
  binary-replication.go:984	0xa0fe75		84c9				TESTL CL, CL													
  binary-replication.go:980	0xa0fe77		0f84a5000000			JE 0xa0ff22													
  binary-replication.go:985	0xa0fe7d		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:985	0xa0fe85		488b8a88000000			MOVQ 0x88(DX), CX												
  binary-replication.go:985	0xa0fe8c		4c8ba280000000			MOVQ 0x80(DX), R12												
  binary-replication.go:985	0xa0fe93		49ffc4				INCQ R12													
  binary-replication.go:985	0xa0fe96		4c8b6a78			MOVQ 0x78(DX), R13												
  binary-replication.go:985	0xa0fe9a		4c39e1				CMPQ CX, R12													
  binary-replication.go:985	0xa0fe9d		7369				JAE 0xa0ff08													
  binary-replication.go:984	0xa0fe9f		48899c2440020000		MOVQ BX, 0x240(SP)												
  binary-replication.go:984	0xa0fea7		4889842438020000		MOVQ AX, 0x238(SP)												
  binary-replication.go:985	0xa0feaf		4c89e8				MOVQ R13, AX													
  binary-replication.go:985	0xa0feb2		4c89e3				MOVQ R12, BX													
  binary-replication.go:985	0xa0feb5		bf01000000			MOVL $0x1, DI													
  binary-replication.go:985	0xa0feba		488d353fde7300			LEAQ 0x73de3f(IP), SI												
  binary-replication.go:985	0xa0fec1		e8ba27a8ff			CALL runtime.growslice(SB)											
  binary-replication.go:985	0xa0fec6		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:985	0xa0fece		48898a88000000			MOVQ CX, 0x88(DX)												
  binary-replication.go:985	0xa0fed5		833d8436830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:985	0xa0fedc		7410				JE 0xa0feee													
  binary-replication.go:985	0xa0fede		4c8b6278			MOVQ 0x78(DX), R12												
  binary-replication.go:985	0xa0fee2		e83974a8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:985	0xa0fee7		498903				MOVQ AX, 0(R11)													
  binary-replication.go:985	0xa0feea		4d896308			MOVQ R12, 0x8(R11)												
  binary-replication.go:985	0xa0feee		48894278			MOVQ AX, 0x78(DX)												
  binary-replication.go:985	0xa0fef2		4989dc				MOVQ BX, R12													
  binary-replication.go:985	0xa0fef5		4989c5				MOVQ AX, R13													
  binary-replication.go:985	0xa0fef8		488b842438020000		MOVQ 0x238(SP), AX												
  binary-replication.go:985	0xa0ff00		488b9c2440020000		MOVQ 0x240(SP), BX												
  binary-replication.go:985	0xa0ff08		4c89a280000000			MOVQ R12, 0x80(DX)												
  binary-replication.go:985	0xa0ff0f		49ffcc				DECQ R12													
  binary-replication.go:985	0xa0ff12		49c1e404			SHLQ $0x4, R12													
  binary-replication.go:985	0xa0ff16		4b89442500			MOVQ AX, 0(R13)(R12*1)												
  binary-replication.go:985	0xa0ff1b		4b895c2508			MOVQ BX, 0x8(R13)(R12*1)											
  binary-replication.go:985	0xa0ff20		eb08				JMP 0xa0ff2a													
  binary-replication.go:877	0xa0ff22		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:1007	0xa0ff2a		488b842478020000		MOVQ 0x278(SP), AX												
  binary-replication.go:872	0xa0ff32		488b9c2450020000		MOVQ 0x250(SP), BX												
  binary-replication.go:877	0xa0ff3a		488bb42420020000		MOVQ 0x220(SP), SI												
  binary-replication.go:1018	0xa0ff42		4c8b842418010000		MOVQ 0x118(SP), R8												
  binary-replication.go:1006	0xa0ff4a		4c8ba42448010000		MOVQ 0x148(SP), R12												
  binary-replication.go:919	0xa0ff52		f20f108424a0000000		MOVSD_XMM 0xa0(SP), X0												
  binary-replication.go:1007	0xa0ff5b		f20f108c2428010000		MOVSD_XMM 0x128(SP), X1												
  binary-replication.go:1011	0xa0ff64		f20f10942430020000		MOVSD_XMM 0x230(SP), X2												
  binary-replication.go:1007	0xa0ff6d		f20f10a42420010000		MOVSD_XMM 0x120(SP), X4												
  binary-replication.go:1011	0xa0ff76		f20f10ac2428020000		MOVSD_XMM 0x228(SP), X5												
  binary-replication.go:1015	0xa0ff7f		4c8bac24e8010000		MOVQ 0x1e8(SP), R13												
  binary-replication.go:1015	0xa0ff87		440fb6bc2494000000		MOVZX 0x94(SP), R15												
  binary-replication.go:842	0xa0ff90		0fb64c2476			MOVZX 0x76(SP), CX												
  binary-replication.go:1006	0xa0ff95		4d89e3				MOVQ R12, R11													
  binary-replication.go:1006	0xa0ff98		4c8ba42498000000		MOVQ 0x98(SP), R12												
  binary-replication.go:1011	0xa0ffa0		0f10d5				MOVUPS X5, X2													
  binary-replication.go:1011	0xa0ffa3		f20f10ac2430020000		MOVSD_XMM 0x230(SP), X5												
  binary-replication.go:1011	0xa0ffac		e911f7ffff			JMP 0xa0f6c2													
  binary-replication.go:1006	0xa0ffb1		4584ff				TESTL R15, R15													
  binary-replication.go:1018	0xa0ffb4		7408				JE 0xa0ffbe													
  binary-replication.go:1018	0xa0ffb6		41bc01000000			MOVL $0x1, R12													
  binary-replication.go:1018	0xa0ffbc		eb07				JMP 0xa0ffc5													
  binary-replication.go:1018	0xa0ffbe		4d39c5				CMPQ R13, R8													
  binary-replication.go:1018	0xa0ffc1		410f95c4			SETNE R12													
  binary-replication.go:1018	0xa0ffc5		4488642477			MOVB R12, 0x77(SP)												
  binary-replication.go:1019	0xa0ffca		4c8bac2458020000		MOVQ 0x258(SP), R13												
  binary-replication.go:1019	0xa0ffd2		4d8bbd88010000			MOVQ 0x188(R13), R15												
  binary-replication.go:1019	0xa0ffd9		4c893a				MOVQ R15, 0(DX)													
  binary-replication.go:1019	0xa0ffdc		0f1f4000			NOPL 0(AX)													
  binary-replication.go:1018	0xa0ffe0		4584e4				TESTL R12, R12													
  binary-replication.go:1021	0xa0ffe3		0f84f8000000			JE 0xa100e1													
  binary-replication.go:1022	0xa0ffe9		488b9aa8000000			MOVQ 0xa8(DX), BX												
  binary-replication.go:1022	0xa0fff0		488d8c2490130000		LEAQ 0x1390(SP), CX												
  binary-replication.go:1022	0xa0fff8		440f1139			MOVUPS X15, 0(CX)												
  binary-replication.go:1022	0xa0fffc		440f117910			MOVUPS X15, 0x10(CX)												
  binary-replication.go:1022	0xa10001		440f117920			MOVUPS X15, 0x20(CX)												
  binary-replication.go:1022	0xa10006		440f117930			MOVUPS X15, 0x30(CX)												
  binary-replication.go:1022	0xa1000b		440f117940			MOVUPS X15, 0x40(CX)												
  binary-replication.go:1022	0xa10010		440f117950			MOVUPS X15, 0x50(CX)												
  binary-replication.go:1022	0xa10015		488d058cc26d00			LEAQ 0x6dc28c(IP), AX												
  binary-replication.go:1022	0xa1001c		0f1f4000			NOPL 0(AX)													
  binary-replication.go:1022	0xa10020		e8db49a1ff			CALL runtime.mapIterStart(SB)											
  binary-replication.go:1022	0xa10025		eb26				JMP 0xa1004d													
  binary-replication.go:1022	0xa10027		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-replication.go:1022	0xa10030		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-replication.go:1022	0xa10039		0f1f8000000000			NOPL 0(AX)													
  binary-replication.go:1022	0xa10040		488d842490130000		LEAQ 0x1390(SP), AX												
  binary-replication.go:1022	0xa10048		e87350a1ff			CALL runtime.mapIterNext(SB)											
  binary-replication.go:1022	0xa1004d		488b942490130000		MOVQ 0x1390(SP), DX												
  binary-replication.go:1022	0xa10055		4885d2				TESTQ DX, DX													
  binary-replication.go:1022	0xa10058		7471				JE 0xa100cb													
  binary-replication.go:1022	0xa1005a		488bb42498130000		MOVQ 0x1398(SP), SI												
  binary-replication.go:1022	0xa10062		488b36				MOVQ 0(SI), SI													
  binary-replication.go:1023	0xa10065		488bbc2418020000		MOVQ 0x218(SP), DI												
  binary-replication.go:1023	0xa1006d		48397e10			CMPQ 0x10(SI), DI												
  binary-replication.go:1023	0xa10071		74cd				JE 0xa10040													
  binary-replication.go:1022	0xa10073		4889b424b8020000		MOVQ SI, 0x2b8(SP)												
  binary-replication.go:1022	0xa1007b		488b0a				MOVQ 0(DX), CX													
  binary-replication.go:1024	0xa1007e		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:1024	0xa10086		488b9aa8000000			MOVQ 0xa8(DX), BX												
  binary-replication.go:1024	0xa1008d		488d0514c26d00			LEAQ 0x6dc214(IP), AX												
  binary-replication.go:1024	0xa10094		e86700a0ff			CALL runtime.mapdelete_fast64(SB)										
  binary-replication.go:1025	0xa10099		833dc034830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:1025	0xa100a0		750a				JNE 0xa100ac													
  binary-replication.go:1025	0xa100a2		488b8c24b8020000		MOVQ 0x2b8(SP), CX												
  binary-replication.go:1025	0xa100aa		eb13				JMP 0xa100bf													
  binary-replication.go:1025	0xa100ac		488b8c24b8020000		MOVQ 0x2b8(SP), CX												
  binary-replication.go:1025	0xa100b4		488b11				MOVQ 0(CX), DX													
  binary-replication.go:1025	0xa100b7		e84472a8ff			CALL runtime.gcWriteBarrier1(SB)										
  binary-replication.go:1025	0xa100bc		498913				MOVQ DX, 0(R11)													
  binary-replication.go:1025	0xa100bf		48c70100000000			MOVQ $0x0, 0(CX)												
  binary-replication.go:1025	0xa100c6		e975ffffff			JMP 0xa10040													
  binary-replication.go:1030	0xa100cb		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:1043	0xa100d3		440fb6642477			MOVZX 0x77(SP), R12												
  binary-replication.go:1043	0xa100d9		4c8bac2458020000		MOVQ 0x258(SP), R13												
  binary-replication.go:1030	0xa100e1		4c8bba98000000			MOVQ 0x98(DX), R15												
  binary-replication.go:1030	0xa100e8		4d85ff				TESTQ R15, R15													
  binary-replication.go:1030	0xa100eb		742e				JE 0xa1011b													
  binary-replication.go:1030	0xa100ed		4b8d1c7f			LEAQ 0(R15)(R15*2), BX												
  binary-replication.go:1030	0xa100f1		48c1e303			SHLQ $0x3, BX													
  binary-replication.go:1030	0xa100f5		488b8290000000			MOVQ 0x90(DX), AX												
  binary-replication.go:1030	0xa100fc		0f1f4000			NOPL 0(AX)													
  binary-replication.go:1030	0xa10100		e87be4a7ff			CALL runtime.memclrHasPointers(SB)										
  binary-replication.go:1032	0xa10105		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:1043	0xa1010d		440fb6642477			MOVZX 0x77(SP), R12												
  binary-replication.go:1043	0xa10113		4c8bac2458020000		MOVQ 0x258(SP), R13												
  binary-replication.go:1032	0xa1011b		4c8bba80000000			MOVQ 0x80(DX), R15												
  binary-replication.go:1032	0xa10122		4c39baa0000000			CMPQ 0xa0(DX), R15												
  binary-replication.go:1032	0xa10129		7d6d				JGE 0xa10198													
  binary-replication.go:1033	0xa1012b		4b8d0c3f			LEAQ 0(R15)(R15*1), CX												
  binary-replication.go:1033	0xa1012f		48898c2440020000		MOVQ CX, 0x240(SP)												
  binary-replication.go:1033	0xa10137		488d05ba096d00			LEAQ 0x6d09ba(IP), AX												
  binary-replication.go:1033	0xa1013e		4889cb				MOVQ CX, BX													
  binary-replication.go:1033	0xa10141		e85a24a8ff			CALL runtime.makeslice(SB)											
  binary-replication.go:1033	0xa10146		488b942440020000		MOVQ 0x240(SP), DX												
  binary-replication.go:1033	0xa1014e		488bb42488140000		MOVQ 0x1488(SP), SI												
  binary-replication.go:1033	0xa10156		48899698000000			MOVQ DX, 0x98(SI)												
  binary-replication.go:1033	0xa1015d		488996a0000000			MOVQ DX, 0xa0(SI)												
  binary-replication.go:1033	0xa10164		833df533830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:1033	0xa1016b		7413				JE 0xa10180													
  binary-replication.go:1033	0xa1016d		488b9690000000			MOVQ 0x90(SI), DX												
  binary-replication.go:1033	0xa10174		e8a771a8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:1033	0xa10179		498903				MOVQ AX, 0(R11)													
  binary-replication.go:1033	0xa1017c		49895308			MOVQ DX, 0x8(R11)												
  binary-replication.go:1033	0xa10180		48898690000000			MOVQ AX, 0x90(SI)												
  binary-replication.go:1036	0xa10187		4889f2				MOVQ SI, DX													
  binary-replication.go:1043	0xa1018a		440fb6642477			MOVZX 0x77(SP), R12												
  binary-replication.go:1043	0xa10190		4c8bac2458020000		MOVQ 0x258(SP), R13												
  binary-replication.go:1036	0xa10198		4c8bbaa0000000			MOVQ 0xa0(DX), R15												
  binary-replication.go:1036	0xa1019f		488b8280000000			MOVQ 0x80(DX), AX												
  binary-replication.go:1036	0xa101a6		4c39f8				CMPQ AX, R15													
  binary-replication.go:1036	0xa101a9		0f87361a0000			JA 0xa11be5													
  binary-replication.go:1036	0xa101af		4c8b7a78			MOVQ 0x78(DX), R15												
  binary-replication.go:1036	0xa101b3		48898298000000			MOVQ AX, 0x98(DX)												
  binary-replication.go:1037	0xa101ba		488b8a90000000			MOVQ 0x90(DX), CX												
  binary-replication.go:1037	0xa101c1		488b9aa0000000			MOVQ 0xa0(DX), BX												
  binary-replication.go:771	0xa101c8		4c89ee				MOVQ R13, SI													
  binary-replication.go:1039	0xa101cb		4531ed				XORL R13, R13													
  binary-replication.go:1018	0xa101ce		4489e7				MOVL R12, DI													
  binary-replication.go:1039	0xa101d1		4c8ba424f00a0000		MOVQ 0xaf0(SP), R12												
  binary-replication.go:1039	0xa101d9		eb0e				JMP 0xa101e9													
  binary-replication.go:1040	0xa101db		4e8904d1			MOVQ R8, 0(CX)(R10*8)												
  binary-replication.go:1039	0xa101df		4983c710			ADDQ $0x10, R15													
  binary-replication.go:1039	0xa101e3		49ffc5				INCQ R13													
  binary-replication.go:1043	0xa101e6		4c89ca				MOVQ R9, DX													
  binary-replication.go:1039	0xa101e9		4939c5				CMPQ R13, AX													
  binary-replication.go:1039	0xa101ec		0f8d89000000			JGE 0xa1027b													
  binary-replication.go:1039	0xa101f2		4d8b07				MOVQ 0(R15), R8													
  binary-replication.go:1039	0xa101f5		4d8b4f08			MOVQ 0x8(R15), R9												
  binary-replication.go:1040	0xa101f9		4d8b542410			MOVQ 0x10(R12), R10												
  binary-replication.go:1040	0xa101fe		4f8d1c08			LEAQ 0(R8)(R9*1), R11												
  binary-replication.go:1040	0xa10202		4d39da				CMPQ R10, R11													
  binary-replication.go:1040	0xa10205		0f82d0190000			JB 0xa11bdb													
  binary-replication.go:1040	0xa1020b		4d39d8				CMPQ R8, R11													
  binary-replication.go:1040	0xa1020e		0f87c2190000			JA 0xa11bd6													
  binary-replication.go:1040	0xa10214		4d8b1c24			MOVQ 0(R12), R11												
  binary-replication.go:1040	0xa10218		4d29c2				SUBQ R8, R10													
  binary-replication.go:1040	0xa1021b		4c89942440020000		MOVQ R10, 0x240(SP)												
  binary-replication.go:1040	0xa10223		49f7da				NEGQ R10													
  binary-replication.go:1040	0xa10226		49c1fa3f			SARQ $0x3f, R10													
  binary-replication.go:1040	0xa1022a		4d21d0				ANDQ R10, R8													
  binary-replication.go:1040	0xa1022d		4d01d8				ADDQ R11, R8													
  binary-replication.go:1039	0xa10230		4939c5				CMPQ R13, AX													
  binary-replication.go:1040	0xa10233		0f8398190000			JAE 0xa11bd1													
  binary-replication.go:1040	0xa10239		4f8d546d00			LEAQ 0(R13)(R13*2), R10												
  binary-replication.go:1040	0xa1023e		4e894cd108			MOVQ R9, 0x8(CX)(R10*8)												
  binary-replication.go:766	0xa10243		4989d1				MOVQ DX, R9													
  binary-replication.go:1040	0xa10246		488b942440020000		MOVQ 0x240(SP), DX												
  binary-replication.go:1040	0xa1024e		4a8954d110			MOVQ DX, 0x10(CX)(R10*8)											
  binary-replication.go:1040	0xa10253		833d0633830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:1040	0xa1025a		660f1f440000			NOPW 0(AX)(AX*1)												
  binary-replication.go:1040	0xa10260		0f8475ffffff			JE 0xa101db													
  binary-replication.go:1040	0xa10266		4a8b14d1			MOVQ 0(CX)(R10*8), DX												
  binary-replication.go:1040	0xa1026a		e8b170a8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:1040	0xa1026f		4d8903				MOVQ R8, 0(R11)													
  binary-replication.go:1040	0xa10272		49895308			MOVQ DX, 0x8(R11)												
  binary-replication.go:1040	0xa10276		e960ffffff			JMP 0xa101db													
  binary-replication.go:1043	0xa1027b		4c8b6248			MOVQ 0x48(DX), R12												
  binary-replication.go:1043	0xa1027f		4c8b6a58			MOVQ 0x58(DX), R13												
  binary-replication.go:1043	0xa10283		4c8dbc24d8020000		LEAQ 0x2d8(SP), R15												
  binary-replication.go:1043	0xa1028b		450f113f			MOVUPS X15, 0(R15)												
  binary-replication.go:1043	0xa1028f		450f117f10			MOVUPS X15, 0x10(R15)												
  binary-replication.go:1043	0xa10294		450f117f20			MOVUPS X15, 0x20(R15)												
  binary-replication.go:1043	0xa10299		450f117f30			MOVUPS X15, 0x30(R15)												
  binary-replication.go:1043	0xa1029e		450f117f40			MOVUPS X15, 0x40(R15)												
  binary-replication.go:1043	0xa102a3		450f117f50			MOVUPS X15, 0x50(R15)												
  binary-replication.go:1043	0xa102a8		450f117f60			MOVUPS X15, 0x60(R15)												
  binary-replication.go:1043	0xa102ad		450f117f70			MOVUPS X15, 0x70(R15)												
  binary-replication.go:1043	0xa102b2		450f11bf80000000		MOVUPS X15, 0x80(R15)												
  binary-replication.go:1043	0xa102ba		450f11bf90000000		MOVUPS X15, 0x90(R15)												
  binary-replication.go:1043	0xa102c2		450f11bfa0000000		MOVUPS X15, 0xa0(R15)												
  binary-replication.go:1043	0xa102ca		450f11bfa8000000		MOVUPS X15, 0xa8(R15)												
  binary-replication.go:1043	0xa102d2		440fb6bc2490140000		MOVZX 0x1490(SP), R15												
  binary-replication.go:1043	0xa102db		4488bc24f0020000		MOVB R15, 0x2f0(SP)												
  binary-replication.go:1043	0xa102e3		4088bc24f1020000		MOVB DI, 0x2f1(SP)												
  binary-replication.go:1043	0xa102eb		4c8bbe88010000			MOVQ 0x188(SI), R15												
  binary-replication.go:1043	0xa102f2		4c89bc24f8020000		MOVQ R15, 0x2f8(SP)												
  binary-replication.go:1043	0xa102fa		4c8bbe68010000			MOVQ 0x168(SI), R15												
  binary-replication.go:1043	0xa10301		4c89bc2400030000		MOVQ R15, 0x300(SP)												
  binary-replication.go:1043	0xa10309		4c8bbc2438140000		MOVQ 0x1438(SP), R15												
  binary-replication.go:1043	0xa10311		4c89bc2408030000		MOVQ R15, 0x308(SP)												
  binary-replication.go:1043	0xa10319		4c8bbc2470140000		MOVQ 0x1470(SP), R15												
  binary-replication.go:1043	0xa10321		4c89bc2440030000		MOVQ R15, 0x340(SP)												
  binary-replication.go:1043	0xa10329		4c8bbc2440140000		MOVQ 0x1440(SP), R15												
  binary-replication.go:1043	0xa10331		4c89bc2410030000		MOVQ R15, 0x310(SP)												
  binary-replication.go:1043	0xa10339		4c8bbc2448140000		MOVQ 0x1448(SP), R15												
  binary-replication.go:1043	0xa10341		4c89bc2418030000		MOVQ R15, 0x318(SP)												
  binary-replication.go:1043	0xa10349		4c8bbc2450140000		MOVQ 0x1450(SP), R15												
  binary-replication.go:1043	0xa10351		4c89bc2420030000		MOVQ R15, 0x320(SP)												
  binary-replication.go:1043	0xa10359		4c8bbc2460140000		MOVQ 0x1460(SP), R15												
  binary-replication.go:1043	0xa10361		488bb42468140000		MOVQ 0x1468(SP), SI												
  binary-replication.go:1043	0xa10369		488bbc2458140000		MOVQ 0x1458(SP), DI												
  binary-replication.go:1043	0xa10371		4889bc2428030000		MOVQ DI, 0x328(SP)												
  binary-replication.go:1043	0xa10379		4c89bc2430030000		MOVQ R15, 0x330(SP)												
  binary-replication.go:1043	0xa10381		4889b42438030000		MOVQ SI, 0x338(SP)												
  binary-replication.go:1043	0xa10389		4c8bbc24f80a0000		MOVQ 0xaf8(SP), R15												
  binary-replication.go:1043	0xa10391		4c89bc2460030000		MOVQ R15, 0x360(SP)												
  binary-replication.go:1043	0xa10399		4c8bbc24a8010000		MOVQ 0x1a8(SP), R15												
  binary-replication.go:1043	0xa103a1		4c89bc2468030000		MOVQ R15, 0x368(SP)												
  binary-replication.go:1043	0xa103a9		4c8bbc24b0010000		MOVQ 0x1b0(SP), R15												
  binary-replication.go:1043	0xa103b1		4c89bc2470030000		MOVQ R15, 0x370(SP)												
  binary-replication.go:1043	0xa103b9		4c8b7a60			MOVQ 0x60(DX), R15												
  binary-replication.go:1043	0xa103bd		488b7268			MOVQ 0x68(DX), SI												
  binary-replication.go:1043	0xa103c1		488b7a70			MOVQ 0x70(DX), DI												
  binary-replication.go:1043	0xa103c5		4c89bc2448030000		MOVQ R15, 0x348(SP)												
  binary-replication.go:1043	0xa103cd		4889b42450030000		MOVQ SI, 0x350(SP)												
  binary-replication.go:1043	0xa103d5		4889bc2458030000		MOVQ DI, 0x358(SP)												
  binary-replication.go:1043	0xa103dd		48898c24d8020000		MOVQ CX, 0x2d8(SP)												
  binary-replication.go:1043	0xa103e5		48898424e0020000		MOVQ AX, 0x2e0(SP)												
  binary-replication.go:1043	0xa103ed		48899c24e8020000		MOVQ BX, 0x2e8(SP)												
  binary-replication.go:1043	0xa103f5		4c8bba88060000			MOVQ 0x688(DX), R15												
  binary-replication.go:1043	0xa103fc		488b8290060000			MOVQ 0x690(DX), AX												
  binary-replication.go:1043	0xa10403		488b8a98060000			MOVQ 0x698(DX), CX												
  binary-replication.go:1043	0xa1040a		488b9aa0060000			MOVQ 0x6a0(DX), BX												
  binary-replication.go:1043	0xa10411		4c89fe				MOVQ R15, SI													
  binary-snapshot.go:477	0xa10414		49bfffffffffffff1f00		MOVQ $0x1fffffffffffff, R15											
  binary-snapshot.go:477	0xa1041e		6690				NOPW														
  binary-snapshot.go:477	0xa10420		4c39bc24f8020000		CMPQ 0x2f8(SP), R15												
  binary-snapshot.go:477	0xa10428		0f87b4010000			JA 0xa105e2													
  binary-snapshot.go:477	0xa1042e		4c39bc2400030000		CMPQ 0x300(SP), R15												
  binary-snapshot.go:477	0xa10436		0f87a6010000			JA 0xa105e2													
  binary-snapshot.go:481	0xa1043c		4883bc241803000000		CMPQ 0x318(SP), $0x0												
  binary-snapshot.go:481	0xa10445		7445				JE 0xa1048c													
  binary-snapshot.go:481	0xa10447		4c8bbc2420030000		MOVQ 0x320(SP), R15												
  binary-snapshot.go:481	0xa1044f		4d85ff				TESTQ R15, R15													
  binary-snapshot.go:481	0xa10452		7430				JE 0xa10484													
  binary-snapshot.go:481	0xa10454		f2410f1007			MOVSD_XMM 0(R15), X0												
  bits.go:39			0xa10459		0f57c9				XORPS X1, X1													
  bits.go:39			0xa1045c		660f2ec1			UCOMISD X1, X0													
  binary-snapshot.go:481	0xa10460		7222				JB 0xa10484													
  unsafe.go:35			0xa10462		66490f7ec7			MOVQ X0, R15													
  abs.go:14			0xa10467		490fbaf73f			BTRQ $0x3f, R15													
  unsafe.go:41			0xa1046c		66490f6ec7			MOVQ R15, X0													
  bits.go:52			0xa10471		90				NOPL														
  bits.go:56			0xa10472		f20f100d46961500		MOVSD_XMM $f64.7fefffffffffffff(SB), X1										
  bits.go:56			0xa1047a		660f2ec1			UCOMISD X1, X0													
  bits.go:56			0xa1047e		410f97c7			SETA R15													
  binary-snapshot.go:481	0xa10482		eb0b				JMP 0xa1048f													
  binary-snapshot.go:481	0xa10484		41bf01000000			MOVL $0x1, R15													
  binary-snapshot.go:481	0xa1048a		eb03				JMP 0xa1048f													
  binary-snapshot.go:481	0xa1048c		4531ff				XORL R15, R15													
  binary-snapshot.go:481	0xa1048f		4584ff				TESTL R15, R15													
  binary-snapshot.go:481	0xa10492		0f8533010000			JNE 0xa105cb													
  binary-snapshot.go:485	0xa10498		4c89a42460020000		MOVQ R12, 0x260(SP)												
  binary-snapshot.go:485	0xa104a0		48c784246802000000000000	MOVQ $0x0, 0x268(SP)												
  binary-snapshot.go:485	0xa104ac		4c89ac2470020000		MOVQ R13, 0x270(SP)												
  binary-snapshot.go:488	0xa104b4		440fb6bc24f0020000		MOVZX 0x2f0(SP), R15												
  binary-snapshot.go:492	0xa104bd		80bc24f102000000		CMPB 0x2f1(SP), $0x0												
  binary-snapshot.go:492	0xa104c5		7409				JE 0xa104d0													
  binary-snapshot.go:488	0xa104c7		4584ff				TESTL R15, R15													
  binary-snapshot.go:492	0xa104ca		7504				JNE 0xa104d0													
  binary-snapshot.go:493	0xa104cc		4183cf02			ORL $0x2, R15													
  binary-snapshot.go:496	0xa104d0		4883bc240803000000		CMPQ 0x308(SP), $0x0												
  binary-snapshot.go:496	0xa104d9		7404				JE 0xa104df													
  binary-snapshot.go:497	0xa104db		4183cf04			ORL $0x4, R15													
  binary-snapshot.go:500	0xa104df		4883bc244003000000		CMPQ 0x340(SP), $0x0												
  binary-snapshot.go:500	0xa104e8		7404				JE 0xa104ee													
  binary-snapshot.go:501	0xa104ea		4183cf08			ORL $0x8, R15													
  binary-snapshot.go:504	0xa104ee		4883bc241003000000		CMPQ 0x310(SP), $0x0												
  binary-snapshot.go:504	0xa104f7		7404				JE 0xa104fd													
  binary-snapshot.go:505	0xa104f9		4183cf10			ORL $0x10, R15													
  binary-snapshot.go:508	0xa104fd		4883bc241803000000		CMPQ 0x318(SP), $0x0												
  binary-snapshot.go:508	0xa10506		7404				JE 0xa1050c													
  binary-snapshot.go:509	0xa10508		4183cf20			ORL $0x20, R15													
  binary-snapshot.go:512	0xa1050c		4883bc246003000000		CMPQ 0x360(SP), $0x0												
  binary-snapshot.go:512	0xa10515		7404				JE 0xa1051b													
  binary-snapshot.go:513	0xa10517		4183cf40			ORL $0x40, R15													
  binary-replication.go:1043	0xa1051b		48899c24300b0000		MOVQ BX, 0xb30(SP)												
  binary-replication.go:1043	0xa10523		48898c24280b0000		MOVQ CX, 0xb28(SP)												
  binary-replication.go:1043	0xa1052b		48898424200b0000		MOVQ AX, 0xb20(SP)												
  binary-replication.go:1043	0xa10533		4889b424180b0000		MOVQ SI, 0xb18(SP)												
  binary-snapshot.go:513	0xa1053b		44887c2478			MOVB R15, 0x78(SP)												
  binary-snapshot.go:516	0xa10540		4983fd04			CMPQ R13, $0x4													
  binary-snapshot.go:516	0xa10544		735a				JAE 0xa105a0													
  binary-snapshot.go:516	0xa10546		4c89e0				MOVQ R12, AX													
  binary-snapshot.go:516	0xa10549		bb04000000			MOVL $0x4, BX													
  binary-snapshot.go:516	0xa1054e		4c89e9				MOVQ R13, CX													
  binary-snapshot.go:516	0xa10551		89df				MOVL BX, DI													
  binary-snapshot.go:516	0xa10553		488d35f63c7100			LEAQ 0x713cf6(IP), SI												
  binary-snapshot.go:516	0xa1055a		e82121a8ff			CALL runtime.growslice(SB)											
  binary-snapshot.go:516	0xa1055f		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-snapshot.go:516	0xa10567		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa1056f		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa10577		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa1057f		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-snapshot.go:572	0xa10587		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-snapshot.go:516	0xa1058f		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-snapshot.go:516	0xa10595		4989c4				MOVQ AX, R12													
  binary-snapshot.go:572	0xa10598		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:516	0xa105a0		48c784246802000004000000	MOVQ $0x4, 0x268(SP)												
  binary-snapshot.go:516	0xa105ac		41c6042455			MOVB $0x55, 0(R12)												
  binary-snapshot.go:516	0xa105b1		6641c74424014d01		MOVW $0x14d, 0x1(R12)												
  binary-snapshot.go:516	0xa105b9		45887c2403			MOVB R15, 0x3(R12)												
  binary-snapshot.go:517	0xa105be		4c8ba424f8020000		MOVQ 0x2f8(SP), R12												
  binary-control.go:80		0xa105c6		e98d000000			JMP 0xa10658													
  binary-replication.go:1043	0xa105cb		488b35ce8e7f00			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/protocol.ErrSnapshot(SB), SI				
  binary-replication.go:1043	0xa105d2		488b1dcf8e7f00			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/protocol.ErrSnapshot+8(SB), BX			
  binary-replication.go:1043	0xa105d9		31c0				XORL AX, AX													
  binary-replication.go:1043	0xa105db		31c9				XORL CX, CX													
  binary-replication.go:1043	0xa105dd		31ff				XORL DI, DI													
  binary-replication.go:1043	0xa105df		90				NOPL														
  binary-replication.go:1043	0xa105e0		eb14				JMP 0xa105f6													
  binary-replication.go:1043	0xa105e2		488b35b78e7f00			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/protocol.ErrSnapshot(SB), SI				
  binary-replication.go:1043	0xa105e9		488b1db88e7f00			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/protocol.ErrSnapshot+8(SB), BX			
  binary-replication.go:1043	0xa105f0		31c0				XORL AX, AX													
  binary-replication.go:1043	0xa105f2		31c9				XORL CX, CX													
  binary-replication.go:1043	0xa105f4		31ff				XORL DI, DI													
  binary-replication.go:1045	0xa105f6		4885f6				TESTQ SI, SI													
  binary-replication.go:1045	0xa105f9		7531				JNE 0xa1062c													
  binary-replication.go:1049	0xa105fb		48897a50			MOVQ DI, 0x50(DX)												
  binary-replication.go:1049	0xa105ff		48894a58			MOVQ CX, 0x58(DX)												
  binary-replication.go:1049	0xa10603		833d562f830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:1049	0xa1060a		7410				JE 0xa1061c													
  binary-replication.go:1049	0xa1060c		488b7248			MOVQ 0x48(DX), SI												
  binary-replication.go:1049	0xa10610		e80b6da8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:1049	0xa10615		498903				MOVQ AX, 0(R11)													
  binary-replication.go:1049	0xa10618		49897308			MOVQ SI, 0x8(R11)												
  binary-replication.go:1049	0xa1061c		48894248			MOVQ AX, 0x48(DX)												
  binary-replication.go:1050	0xa10620		4889fb				MOVQ DI, BX													
  binary-replication.go:1050	0xa10623		4881c4f0130000			ADDQ $0x13f0, SP												
  binary-replication.go:1050	0xa1062a		5d				POPQ BP														
  binary-replication.go:1050	0xa1062b		c3				RET														
  binary-replication.go:1046	0xa1062c		488b4608			MOVQ 0x8(SI), AX												
  binary-replication.go:1046	0xa10630		e84bf7a7ff			CALL runtime.gopanic(SB)											
  binary-replication.go:1046	0xa10635		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-replication.go:1046	0xa1063e		6690				NOPW														
  binary-control.go:77		0xa10640		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:81		0xa10648		4d89e5				MOVQ R12, R13													
  binary-control.go:81		0xa1064b		4183cd80			ORL $-0x80, R13													
  binary-control.go:77		0xa1064f		46886c07ff			MOVB R13, -0x1(DI)(R8*1)											
  binary-control.go:82		0xa10654		49c1ec07			SHRQ $0x7, R12													
  binary-control.go:81		0xa10658		4c89a42408010000		MOVQ R12, 0x108(SP)												
  binary-control.go:80		0xa10660		4981fc80000000			CMPQ R12, $0x80													
  binary-control.go:80		0xa10667		0f828b000000			JB 0xa106f8													
  binary-control.go:77		0xa1066d		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa10675		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-control.go:77		0xa1067d		48ffc7				INCQ DI														
  binary-control.go:77		0xa10680		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:77		0xa10688		4939fd				CMPQ R13, DI													
  binary-control.go:77		0xa1068b		73b3				JAE 0xa10640													
  binary-control.go:77		0xa1068d		4c89c0				MOVQ R8, AX													
  binary-control.go:77		0xa10690		4889fb				MOVQ DI, BX													
  binary-control.go:77		0xa10693		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa10696		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa1069b		488d35ae3b7100			LEAQ 0x713bae(IP), SI												
  binary-control.go:77		0xa106a2		e8d91fa8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa106a7		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa106af		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa106b7		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa106bf		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa106c7		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:81		0xa106cf		4c8ba42408010000		MOVQ 0x108(SP), R12												
  binary-snapshot.go:543	0xa106d7		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:77		0xa106dd		4889df				MOVQ BX, DI													
  binary-control.go:77		0xa106e0		4989c0				MOVQ AX, R8													
  binary-snapshot.go:572	0xa106e3		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa106eb		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa106f3		e948ffffff			JMP 0xa10640													
  binary-control.go:77		0xa106f8		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa10700		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-control.go:77		0xa10708		48ffc7				INCQ DI														
  binary-control.go:85		0xa1070b		90				NOPL														
  binary-control.go:77		0xa1070c		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:77		0xa10714		4939fd				CMPQ R13, DI													
  binary-control.go:77		0xa10717		7366				JAE 0xa1077f													
  binary-control.go:77		0xa10719		4c89c0				MOVQ R8, AX													
  binary-control.go:77		0xa1071c		4889fb				MOVQ DI, BX													
  binary-control.go:77		0xa1071f		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa10722		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa10727		488d35223b7100			LEAQ 0x713b22(IP), SI												
  binary-control.go:77		0xa1072e		e84d1fa8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa10733		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa1073b		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa10743		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa1074b		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa10753		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:77		0xa1075b		4c8ba42408010000		MOVQ 0x108(SP), R12												
  binary-snapshot.go:543	0xa10763		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:77		0xa10769		4889df				MOVQ BX, DI													
  binary-control.go:77		0xa1076c		4989c0				MOVQ AX, R8													
  binary-snapshot.go:572	0xa1076f		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa10777		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa1077f		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:77		0xa10787		46886407ff			MOVB R12, -0x1(DI)(R8*1)											
  binary-snapshot.go:518	0xa1078c		4c8ba42400030000		MOVQ 0x300(SP), R12												
  binary-control.go:80		0xa10794		eb18				JMP 0xa107ae													
  binary-control.go:77		0xa10796		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:81		0xa1079e		4d89e5				MOVQ R12, R13													
  binary-control.go:81		0xa107a1		4183cd80			ORL $-0x80, R13													
  binary-control.go:77		0xa107a5		46886c07ff			MOVB R13, -0x1(DI)(R8*1)											
  binary-control.go:82		0xa107aa		49c1ec07			SHRQ $0x7, R12													
  binary-control.go:81		0xa107ae		4c89a42400010000		MOVQ R12, 0x100(SP)												
  binary-control.go:81		0xa107b6		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-control.go:81		0xa107bf		90				NOPL														
  binary-control.go:80		0xa107c0		4981fc80000000			CMPQ R12, $0x80													
  binary-control.go:80		0xa107c7		0f828b000000			JB 0xa10858													
  binary-control.go:77		0xa107cd		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa107d5		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-control.go:77		0xa107dd		48ffc7				INCQ DI														
  binary-control.go:77		0xa107e0		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:77		0xa107e8		4939fd				CMPQ R13, DI													
  binary-control.go:77		0xa107eb		73a9				JAE 0xa10796													
  binary-control.go:77		0xa107ed		4c89c0				MOVQ R8, AX													
  binary-control.go:77		0xa107f0		4889fb				MOVQ DI, BX													
  binary-control.go:77		0xa107f3		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa107f6		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa107fb		488d354e3a7100			LEAQ 0x713a4e(IP), SI												
  binary-control.go:77		0xa10802		e8791ea8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa10807		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa1080f		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa10817		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa1081f		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa10827		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:81		0xa1082f		4c8ba42400010000		MOVQ 0x100(SP), R12												
  binary-snapshot.go:543	0xa10837		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:77		0xa1083d		4889df				MOVQ BX, DI													
  binary-control.go:77		0xa10840		4989c0				MOVQ AX, R8													
  binary-snapshot.go:572	0xa10843		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa1084b		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa10853		e93effffff			JMP 0xa10796													
  binary-control.go:77		0xa10858		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa10860		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-control.go:77		0xa10868		48ffc7				INCQ DI														
  binary-control.go:85		0xa1086b		90				NOPL														
  binary-control.go:77		0xa1086c		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:77		0xa10874		4939fd				CMPQ R13, DI													
  binary-control.go:77		0xa10877		7366				JAE 0xa108df													
  binary-control.go:77		0xa10879		4c89c0				MOVQ R8, AX													
  binary-control.go:77		0xa1087c		4889fb				MOVQ DI, BX													
  binary-control.go:77		0xa1087f		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa10882		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa10887		488d35c2397100			LEAQ 0x7139c2(IP), SI												
  binary-control.go:77		0xa1088e		e8ed1da8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa10893		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa1089b		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa108a3		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa108ab		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa108b3		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:77		0xa108bb		4c8ba42400010000		MOVQ 0x100(SP), R12												
  binary-snapshot.go:543	0xa108c3		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:77		0xa108c9		4889df				MOVQ BX, DI													
  binary-control.go:77		0xa108cc		4989c0				MOVQ AX, R8													
  binary-snapshot.go:572	0xa108cf		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa108d7		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa108df		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:77		0xa108e7		46886407ff			MOVB R12, -0x1(DI)(R8*1)											
  binary-snapshot.go:520	0xa108ec		4c8ba42408030000		MOVQ 0x308(SP), R12												
  binary-snapshot.go:520	0xa108f4		4d85e4				TESTQ R12, R12													
  binary-snapshot.go:520	0xa108f7		740c				JE 0xa10905													
  binary-snapshot.go:521	0xa108f9		4d8b2424			MOVQ 0(R12), R12												
  binary-snapshot.go:521	0xa108fd		0f1f00				NOPL 0(AX)													
  binary-control.go:80		0xa10900		e993110000			JMP 0xa11a98													
  binary-snapshot.go:524	0xa10905		4c8ba42440030000		MOVQ 0x340(SP), R12												
  binary-snapshot.go:524	0xa1090d		4d85e4				TESTQ R12, R12													
  binary-snapshot.go:524	0xa10910		7441				JE 0xa10953													
  binary-snapshot.go:525	0xa10912		498b1c24			MOVQ 0(R12), BX													
  binary-snapshot.go:525	0xa10916		488d842460020000		LEAQ 0x260(SP), AX												
  binary-snapshot.go:525	0xa1091e		6690				NOPW														
  binary-snapshot.go:525	0xa10920		e83bddbcff			CALL github.com/burntcustard/unicorn-mining-co/src/server/protocol.(*writer).signed(SB)				
  binary-snapshot.go:572	0xa10925		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa1092d		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa10935		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa1093d		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-snapshot.go:572	0xa10945		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-snapshot.go:543	0xa1094d		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-snapshot.go:528	0xa10953		4c8ba42410030000		MOVQ 0x310(SP), R12												
  binary-snapshot.go:528	0xa1095b		0f1f440000			NOPL 0(AX)(AX*1)												
  binary-snapshot.go:528	0xa10960		4d85e4				TESTQ R12, R12													
  binary-snapshot.go:528	0xa10963		7409				JE 0xa1096e													
  binary-snapshot.go:529	0xa10965		4d8b2424			MOVQ 0(R12), R12												
  binary-control.go:80		0xa10969		e9c20f0000			JMP 0xa11930													
  binary-snapshot.go:532	0xa1096e		4c8ba42418030000		MOVQ 0x318(SP), R12												
  binary-snapshot.go:532	0xa10976		4d85e4				TESTQ R12, R12													
  binary-snapshot.go:532	0xa10979		740a				JE 0xa10985													
  binary-snapshot.go:533	0xa1097b		4d8b2424			MOVQ 0(R12), R12												
  binary-snapshot.go:533	0xa1097f		90				NOPL														
  binary-control.go:80		0xa10980		e9530b0000			JMP 0xa114d8													
  binary-snapshot.go:543	0xa10985		41f6c740			TESTL $0x40, R15												
  binary-snapshot.go:543	0xa10989		740d				JE 0xa10998													
  binary-snapshot.go:544	0xa1098b		4c8ba42468030000		MOVQ 0x368(SP), R12												
  binary-control.go:80		0xa10993		e900080000			JMP 0xa11198													
  binary-snapshot.go:551	0xa10998		41f6c702			TESTL $0x2, R15													
  binary-snapshot.go:551	0xa1099c		740d				JE 0xa109ab													
  binary-snapshot.go:552	0xa1099e		4c8ba42450030000		MOVQ 0x350(SP), R12												
  binary-control.go:80		0xa109a6		e9c5040000			JMP 0xa10e70													
  binary-snapshot.go:559	0xa109ab		4883bc24d802000000		CMPQ 0x2d8(SP), $0x0												
  binary-snapshot.go:559	0xa109b4		740f				JE 0xa109c5													
  binary-snapshot.go:559	0xa109b6		4c8b8424e0020000		MOVQ 0x2e0(SP), R8												
  binary-snapshot.go:560	0xa109be		90				NOPL														
  binary-snapshot.go:560	0xa109bf		90				NOPL														
  binary-control.go:80		0xa109c0		e993020000			JMP 0xa10c58													
  binary-snapshot.go:569	0xa109c5		4c8ba42480030000		MOVQ 0x380(SP), R12												
  binary-control.go:80		0xa109cd		eb18				JMP 0xa109e7													
  binary-control.go:77		0xa109cf		4c89bc2468020000		MOVQ R15, 0x268(SP)												
  binary-control.go:81		0xa109d7		4d89e5				MOVQ R12, R13													
  binary-control.go:81		0xa109da		4183cd80			ORL $-0x80, R13													
  binary-control.go:77		0xa109de		45886c3fff			MOVB R13, -0x1(R15)(DI*1)											
  binary-control.go:82		0xa109e3		49c1ec07			SHRQ $0x7, R12													
  binary-control.go:81		0xa109e7		4c89a424b8000000		MOVQ R12, 0xb8(SP)												
  binary-control.go:80		0xa109ef		4981fc80000000			CMPQ R12, $0x80													
  binary-control.go:80		0xa109f6		0f8289000000			JB 0xa10a85													
  binary-control.go:77		0xa109fc		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa10a04		4c8bbc2468020000		MOVQ 0x268(SP), R15												
  binary-control.go:77		0xa10a0c		49ffc7				INCQ R15													
  binary-control.go:77		0xa10a0f		488bbc2460020000		MOVQ 0x260(SP), DI												
  binary-control.go:77		0xa10a17		4d39fd				CMPQ R13, R15													
  binary-control.go:77		0xa10a1a		73b3				JAE 0xa109cf													
  binary-control.go:77		0xa10a1c		4889f8				MOVQ DI, AX													
  binary-control.go:77		0xa10a1f		4c89fb				MOVQ R15, BX													
  binary-control.go:77		0xa10a22		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa10a25		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa10a2a		488d351f387100			LEAQ 0x71381f(IP), SI												
  binary-control.go:77		0xa10a31		e84a1ca8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa10a36		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa10a3e		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa10a46		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa10a4e		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa10a56		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:81		0xa10a5e		4c8ba424b8000000		MOVQ 0xb8(SP), R12												
  binary-control.go:77		0xa10a66		4989df				MOVQ BX, R15													
  binary-control.go:77		0xa10a69		4889c7				MOVQ AX, DI													
  binary-snapshot.go:572	0xa10a6c		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa10a74		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-snapshot.go:572	0xa10a7c		0f1f4000			NOPL 0(AX)													
  binary-control.go:77		0xa10a80		e94affffff			JMP 0xa109cf													
  binary-control.go:77		0xa10a85		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa10a8d		4c8bbc2468020000		MOVQ 0x268(SP), R15												
  binary-control.go:77		0xa10a95		49ffc7				INCQ R15													
  binary-control.go:85		0xa10a98		90				NOPL														
  binary-control.go:77		0xa10a99		488bbc2460020000		MOVQ 0x260(SP), DI												
  binary-control.go:77		0xa10aa1		4d39fd				CMPQ R13, R15													
  binary-control.go:77		0xa10aa4		7365				JAE 0xa10b0b													
  binary-control.go:77		0xa10aa6		4889f8				MOVQ DI, AX													
  binary-control.go:77		0xa10aa9		4c89fb				MOVQ R15, BX													
  binary-control.go:77		0xa10aac		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa10aaf		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa10ab4		488d3595377100			LEAQ 0x713795(IP), SI												
  binary-control.go:77		0xa10abb		0f1f440000			NOPL 0(AX)(AX*1)												
  binary-control.go:77		0xa10ac0		e8bb1ba8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa10ac5		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa10acd		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa10ad5		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa10add		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa10ae5		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:77		0xa10aed		4c8ba424b8000000		MOVQ 0xb8(SP), R12												
  binary-control.go:77		0xa10af5		4989df				MOVQ BX, R15													
  binary-control.go:77		0xa10af8		4889c7				MOVQ AX, DI													
  binary-snapshot.go:572	0xa10afb		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa10b03		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa10b0b		4c89bc2468020000		MOVQ R15, 0x268(SP)												
  binary-control.go:77		0xa10b13		4588643fff			MOVB R12, -0x1(R15)(DI*1)											
  binary-snapshot.go:571	0xa10b18		4c8ba42478030000		MOVQ 0x378(SP), R12												
  binary-snapshot.go:571	0xa10b20		4c8bac2480030000		MOVQ 0x380(SP), R13												
  binary-snapshot.go:571	0xa10b28		eb56				JMP 0xa10b80													
  binary-snapshot.go:571	0xa10b2a		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-snapshot.go:571	0xa10b33		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-snapshot.go:571	0xa10b3c		0f1f4000			NOPL 0(AX)													
  binary-snapshot.go:571	0xa10b40		4c8ba424100b0000		MOVQ 0xb10(SP), R12												
  binary-snapshot.go:571	0xa10b48		4983c440			ADDQ $0x40, R12													
  binary-snapshot.go:571	0xa10b4c		4c8bac2440020000		MOVQ 0x240(SP), R13												
  binary-snapshot.go:571	0xa10b54		49ffcd				DECQ R13													
  binary-snapshot.go:572	0xa10b57		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa10b5f		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa10b67		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa10b6f		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-snapshot.go:572	0xa10b77		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-snapshot.go:572	0xa10b7f		90				NOPL														
  binary-snapshot.go:571	0xa10b80		4d85ed				TESTQ R13, R13													
  binary-snapshot.go:571	0xa10b83		0f8e88000000			JLE 0xa10c11													
  binary-snapshot.go:571	0xa10b89		4c89ac2440020000		MOVQ R13, 0x240(SP)												
  binary-snapshot.go:571	0xa10b91		4c89a424100b0000		MOVQ R12, 0xb10(SP)												
  binary-snapshot.go:572	0xa10b99		498b1424			MOVQ 0(R12), DX													
  binary-snapshot.go:572	0xa10b9d		4d8b6c2408			MOVQ 0x8(R12), R13												
  binary-snapshot.go:572	0xa10ba2		498b7c2410			MOVQ 0x10(R12), DI												
  binary-snapshot.go:572	0xa10ba7		4d8b7c2418			MOVQ 0x18(R12), R15												
  binary-snapshot.go:572	0xa10bac		4d8b442420			MOVQ 0x20(R12), R8												
  binary-snapshot.go:572	0xa10bb1		4d8b4c2428			MOVQ 0x28(R12), R9												
  binary-snapshot.go:572	0xa10bb6		4d8b542430			MOVQ 0x30(R12), R10												
  binary-snapshot.go:572	0xa10bbb		4d8b5c2438			MOVQ 0x38(R12), R11												
  binary-snapshot.go:572	0xa10bc0		48893424			MOVQ SI, 0(SP)													
  binary-snapshot.go:572	0xa10bc4		4889442408			MOVQ AX, 0x8(SP)												
  binary-snapshot.go:572	0xa10bc9		48894c2410			MOVQ CX, 0x10(SP)												
  binary-snapshot.go:572	0xa10bce		48895c2418			MOVQ BX, 0x18(SP)												
  binary-snapshot.go:572	0xa10bd3		48c744242000000000		MOVQ $0x0, 0x20(SP)												
  binary-snapshot.go:572	0xa10bdc		488d842460020000		LEAQ 0x260(SP), AX												
  binary-snapshot.go:572	0xa10be4		4889d3				MOVQ DX, BX													
  binary-snapshot.go:572	0xa10be7		4c89e9				MOVQ R13, CX													
  binary-snapshot.go:572	0xa10bea		4c89fe				MOVQ R15, SI													
  binary-snapshot.go:572	0xa10bed		e80e5cbdff			CALL github.com/burntcustard/unicorn-mining-co/src/server/protocol.(*writer).record(SB)				
  binary-snapshot.go:572	0xa10bf2		4885c0				TESTQ AX, AX													
  binary-snapshot.go:572	0xa10bf5		0f8445ffffff			JE 0xa10b40													
  binary-replication.go:1049	0xa10bfb		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:1043	0xa10c03		4889c6				MOVQ AX, SI													
  binary-replication.go:1043	0xa10c06		31c0				XORL AX, AX													
  binary-replication.go:1043	0xa10c08		31c9				XORL CX, CX													
  binary-replication.go:1043	0xa10c0a		31ff				XORL DI, DI													
  binary-replication.go:1043	0xa10c0c		e9e5f9ffff			JMP 0xa105f6													
  binary-snapshot.go:577	0xa10c11		488b842460020000		MOVQ 0x260(SP), AX												
  binary-snapshot.go:577	0xa10c19		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-snapshot.go:577	0xa10c21		488b8c2470020000		MOVQ 0x270(SP), CX												
  binary-snapshot.go:577	0xa10c29		31f6				XORL SI, SI													
  binary-snapshot.go:577	0xa10c2b		31db				XORL BX, BX													
  binary-replication.go:1043	0xa10c2d		e9c4f9ffff			JMP 0xa105f6													
  binary-replication.go:1043	0xa10c32		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-replication.go:1043	0xa10c3b		0f1f440000			NOPL 0(AX)(AX*1)												
  binary-control.go:77		0xa10c40		48899c2468020000		MOVQ BX, 0x268(SP)												
  binary-control.go:81		0xa10c48		4d89c1				MOVQ R8, R9													
  binary-control.go:81		0xa10c4b		4183c980			ORL $-0x80, R9													
  binary-control.go:77		0xa10c4f		44884c03ff			MOVB R9, -0x1(BX)(AX*1)												
  binary-control.go:82		0xa10c54		49c1e807			SHRQ $0x7, R8													
  binary-control.go:81		0xa10c58		4c898424c0000000		MOVQ R8, 0xc0(SP)												
  binary-control.go:80		0xa10c60		4981f880000000			CMPQ R8, $0x80													
  binary-control.go:80		0xa10c67		7253				JB 0xa10cbc													
  binary-control.go:77		0xa10c69		488b8c2470020000		MOVQ 0x270(SP), CX												
  binary-control.go:77		0xa10c71		488b9c2468020000		MOVQ 0x268(SP), BX												
  binary-control.go:77		0xa10c79		48ffc3				INCQ BX														
  binary-control.go:77		0xa10c7c		488b842460020000		MOVQ 0x260(SP), AX												
  binary-control.go:77		0xa10c84		4839d9				CMPQ CX, BX													
  binary-control.go:77		0xa10c87		73b7				JAE 0xa10c40													
  binary-control.go:77		0xa10c89		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa10c8e		488d35bb357100			LEAQ 0x7135bb(IP), SI												
  binary-control.go:77		0xa10c95		e8e619a8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa10c9a		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa10ca2		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-replication.go:1049	0xa10caa		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-control.go:81		0xa10cb2		4c8b8424c0000000		MOVQ 0xc0(SP), R8												
  binary-control.go:77		0xa10cba		eb84				JMP 0xa10c40													
  binary-control.go:77		0xa10cbc		488b8c2470020000		MOVQ 0x270(SP), CX												
  binary-control.go:77		0xa10cc4		488b9c2468020000		MOVQ 0x268(SP), BX												
  binary-control.go:77		0xa10ccc		48ffc3				INCQ BX														
  binary-control.go:85		0xa10ccf		90				NOPL														
  binary-control.go:77		0xa10cd0		488b842460020000		MOVQ 0x260(SP), AX												
  binary-control.go:77		0xa10cd8		4839d9				CMPQ CX, BX													
  binary-control.go:77		0xa10cdb		7331				JAE 0xa10d0e													
  binary-control.go:77		0xa10cdd		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa10ce2		488d3567357100			LEAQ 0x713567(IP), SI												
  binary-control.go:77		0xa10ce9		e89219a8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa10cee		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa10cf6		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-replication.go:1049	0xa10cfe		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-control.go:77		0xa10d06		4c8b8424c0000000		MOVQ 0xc0(SP), R8												
  binary-control.go:77		0xa10d0e		48899c2468020000		MOVQ BX, 0x268(SP)												
  binary-control.go:77		0xa10d16		44884403ff			MOVB R8, -0x1(BX)(AX*1)												
  binary-snapshot.go:562	0xa10d1b		4c8b8424d8020000		MOVQ 0x2d8(SP), R8												
  binary-snapshot.go:562	0xa10d23		4c8b8c24e0020000		MOVQ 0x2e0(SP), R9												
  binary-snapshot.go:562	0xa10d2b		e985000000			JMP 0xa10db5													
  binary-snapshot.go:562	0xa10d30		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-snapshot.go:562	0xa10d39		0f1f8000000000			NOPL 0(AX)													
  binary-snapshot.go:563	0xa10d40		48898c2438020000		MOVQ CX, 0x238(SP)												
  binary-snapshot.go:563	0xa10d48		48899c24e8010000		MOVQ BX, 0x1e8(SP)												
  binary-snapshot.go:563	0xa10d50		48898424080b0000		MOVQ AX, 0xb08(SP)												
  binary-snapshot.go:563	0xa10d58		4c01d0				ADDQ R10, AX													
  binary-snapshot.go:563	0xa10d5b		4c89db				MOVQ R11, BX													
  binary-snapshot.go:563	0xa10d5e		4889f9				MOVQ DI, CX													
  binary-snapshot.go:563	0xa10d61		e8fa6ca8ff			CALL runtime.memmove(SB)											
  binary-snapshot.go:563	0xa10d66		488b9424080b0000		MOVQ 0xb08(SP), DX												
  binary-snapshot.go:563	0xa10d6e		4889942460020000		MOVQ DX, 0x260(SP)												
  binary-snapshot.go:563	0xa10d76		488b9424e8010000		MOVQ 0x1e8(SP), DX												
  binary-snapshot.go:563	0xa10d7e		4889942468020000		MOVQ DX, 0x268(SP)												
  binary-snapshot.go:563	0xa10d86		488b942438020000		MOVQ 0x238(SP), DX												
  binary-snapshot.go:563	0xa10d8e		4889942470020000		MOVQ DX, 0x270(SP)												
  binary-snapshot.go:562	0xa10d96		4c8b8424100b0000		MOVQ 0xb10(SP), R8												
  binary-snapshot.go:562	0xa10d9e		4983c018			ADDQ $0x18, R8													
  binary-snapshot.go:562	0xa10da2		4c8b8c2440020000		MOVQ 0x240(SP), R9												
  binary-snapshot.go:562	0xa10daa		49ffc9				DECQ R9														
  binary-replication.go:1049	0xa10dad		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:562	0xa10db5		4d85c9				TESTQ R9, R9													
  binary-snapshot.go:562	0xa10db8		7e7d				JLE 0xa10e37													
  binary-snapshot.go:562	0xa10dba		4c898c2440020000		MOVQ R9, 0x240(SP)												
  binary-snapshot.go:562	0xa10dc2		4c898424100b0000		MOVQ R8, 0xb10(SP)												
  binary-snapshot.go:562	0xa10dca		498b7808			MOVQ 0x8(R8), DI												
  binary-snapshot.go:563	0xa10dce		488b8c2470020000		MOVQ 0x270(SP), CX												
  binary-snapshot.go:563	0xa10dd6		4c8b942468020000		MOVQ 0x268(SP), R10												
  binary-snapshot.go:563	0xa10dde		4a8d1c17			LEAQ 0(DI)(R10*1), BX												
  binary-snapshot.go:562	0xa10de2		4d8b18				MOVQ 0(R8), R11													
  binary-snapshot.go:563	0xa10de5		488b842460020000		MOVQ 0x260(SP), AX												
  binary-snapshot.go:563	0xa10ded		4839d9				CMPQ CX, BX													
  binary-snapshot.go:563	0xa10df0		0f834affffff			JAE 0xa10d40													
  binary-snapshot.go:562	0xa10df6		4889bc2458010000		MOVQ DI, 0x158(SP)												
  binary-snapshot.go:562	0xa10dfe		4c899c24c0020000		MOVQ R11, 0x2c0(SP)												
  binary-snapshot.go:563	0xa10e06		4c89942438020000		MOVQ R10, 0x238(SP)												
  binary-snapshot.go:563	0xa10e0e		488d353b347100			LEAQ 0x71343b(IP), SI												
  binary-snapshot.go:563	0xa10e15		e86618a8ff			CALL runtime.growslice(SB)											
  binary-snapshot.go:563	0xa10e1a		488bbc2458010000		MOVQ 0x158(SP), DI												
  binary-snapshot.go:563	0xa10e22		4c8b942438020000		MOVQ 0x238(SP), R10												
  binary-snapshot.go:563	0xa10e2a		4c8b9c24c0020000		MOVQ 0x2c0(SP), R11												
  binary-snapshot.go:563	0xa10e32		e909ffffff			JMP 0xa10d40													
  binary-snapshot.go:566	0xa10e37		488b842460020000		MOVQ 0x260(SP), AX												
  binary-snapshot.go:566	0xa10e3f		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-snapshot.go:566	0xa10e47		488b8c2470020000		MOVQ 0x270(SP), CX												
  binary-snapshot.go:566	0xa10e4f		31f6				XORL SI, SI													
  binary-snapshot.go:566	0xa10e51		31db				XORL BX, BX													
  binary-replication.go:1043	0xa10e53		e99ef7ffff			JMP 0xa105f6													
  binary-control.go:77		0xa10e58		4c89bc2468020000		MOVQ R15, 0x268(SP)												
  binary-control.go:81		0xa10e60		4d89e5				MOVQ R12, R13													
  binary-control.go:81		0xa10e63		4183cd80			ORL $-0x80, R13													
  binary-control.go:77		0xa10e67		45886c3fff			MOVB R13, -0x1(R15)(DI*1)											
  binary-control.go:82		0xa10e6c		49c1ec07			SHRQ $0x7, R12													
  binary-control.go:81		0xa10e70		4c89a424d0000000		MOVQ R12, 0xd0(SP)												
  binary-control.go:81		0xa10e78		0f1f840000000000		NOPL 0(AX)(AX*1)												
  binary-control.go:80		0xa10e80		4981fc80000000			CMPQ R12, $0x80													
  binary-control.go:80		0xa10e87		0f8285000000			JB 0xa10f12													
  binary-control.go:77		0xa10e8d		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa10e95		4c8bbc2468020000		MOVQ 0x268(SP), R15												
  binary-control.go:77		0xa10e9d		49ffc7				INCQ R15													
  binary-control.go:77		0xa10ea0		488bbc2460020000		MOVQ 0x260(SP), DI												
  binary-control.go:77		0xa10ea8		4d39fd				CMPQ R13, R15													
  binary-control.go:77		0xa10eab		73ab				JAE 0xa10e58													
  binary-control.go:77		0xa10ead		4889f8				MOVQ DI, AX													
  binary-control.go:77		0xa10eb0		4c89fb				MOVQ R15, BX													
  binary-control.go:77		0xa10eb3		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa10eb6		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa10ebb		488d358e337100			LEAQ 0x71338e(IP), SI												
  binary-control.go:77		0xa10ec2		e8b917a8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa10ec7		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa10ecf		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa10ed7		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa10edf		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa10ee7		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:81		0xa10eef		4c8ba424d0000000		MOVQ 0xd0(SP), R12												
  binary-control.go:77		0xa10ef7		4989df				MOVQ BX, R15													
  binary-control.go:77		0xa10efa		4889c7				MOVQ AX, DI													
  binary-snapshot.go:572	0xa10efd		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa10f05		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa10f0d		e946ffffff			JMP 0xa10e58													
  binary-control.go:77		0xa10f12		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa10f1a		4c8bbc2468020000		MOVQ 0x268(SP), R15												
  binary-control.go:77		0xa10f22		49ffc7				INCQ R15													
  binary-control.go:85		0xa10f25		90				NOPL														
  binary-control.go:77		0xa10f26		488bbc2460020000		MOVQ 0x260(SP), DI												
  binary-control.go:77		0xa10f2e		4d39fd				CMPQ R13, R15													
  binary-control.go:77		0xa10f31		7360				JAE 0xa10f93													
  binary-control.go:77		0xa10f33		4889f8				MOVQ DI, AX													
  binary-control.go:77		0xa10f36		4c89fb				MOVQ R15, BX													
  binary-control.go:77		0xa10f39		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa10f3c		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa10f41		488d3508337100			LEAQ 0x713308(IP), SI												
  binary-control.go:77		0xa10f48		e83317a8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa10f4d		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa10f55		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa10f5d		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa10f65		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa10f6d		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:77		0xa10f75		4c8ba424d0000000		MOVQ 0xd0(SP), R12												
  binary-control.go:77		0xa10f7d		4989df				MOVQ BX, R15													
  binary-control.go:77		0xa10f80		4889c7				MOVQ AX, DI													
  binary-snapshot.go:572	0xa10f83		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa10f8b		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa10f93		4c89bc2468020000		MOVQ R15, 0x268(SP)												
  binary-control.go:77		0xa10f9b		4588643fff			MOVB R12, -0x1(R15)(DI*1)											
  binary-snapshot.go:554	0xa10fa0		4c8ba42448030000		MOVQ 0x348(SP), R12												
  binary-snapshot.go:554	0xa10fa8		4c89a424000b0000		MOVQ R12, 0xb00(SP)												
  binary-snapshot.go:554	0xa10fb0		4c8bac2450030000		MOVQ 0x350(SP), R13												
  binary-snapshot.go:554	0xa10fb8		4c89ac2440020000		MOVQ R13, 0x240(SP)												
  binary-snapshot.go:554	0xa10fc0		4531ff				XORL R15, R15													
  binary-snapshot.go:554	0xa10fc3		eb10				JMP 0xa10fd5													
  binary-control.go:77		0xa10fc5		4c898c2468020000		MOVQ R9, 0x268(SP)												
  binary-control.go:77		0xa10fcd		43887c11ff			MOVB DI, -0x1(R9)(R10*1)											
  binary-snapshot.go:554	0xa10fd2		49ffc7				INCQ R15													
  binary-snapshot.go:554	0xa10fd5		4d39ef				CMPQ R15, R13													
  binary-snapshot.go:554	0xa10fd8		0f8dcdf9ffff			JGE 0xa109ab													
  binary-snapshot.go:554	0xa10fde		4c89bc2438020000		MOVQ R15, 0x238(SP)												
  binary-snapshot.go:554	0xa10fe6		4b8b3cfc			MOVQ 0(R12)(R15*8), DI												
  binary-snapshot.go:555	0xa10fea		90				NOPL														
  binary-control.go:80		0xa10feb		eb2b				JMP 0xa11018													
  binary-control.go:80		0xa10fed		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-control.go:80		0xa10ff6		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-control.go:80		0xa10fff		90				NOPL														
  binary-control.go:77		0xa11000		4c898c2468020000		MOVQ R9, 0x268(SP)												
  binary-control.go:81		0xa11008		4989f8				MOVQ DI, R8													
  binary-control.go:81		0xa1100b		4183c880			ORL $-0x80, R8													
  binary-control.go:77		0xa1100f		47884411ff			MOVB R8, -0x1(R9)(R10*1)											
  binary-control.go:82		0xa11014		48c1ef07			SHRQ $0x7, DI													
  binary-control.go:81		0xa11018		4889bc24c8000000		MOVQ DI, 0xc8(SP)												
  binary-control.go:80		0xa11020		4881ff80000000			CMPQ DI, $0x80													
  binary-control.go:80		0xa11027		0f829d000000			JB 0xa110ca													
  binary-control.go:77		0xa1102d		4c8b842470020000		MOVQ 0x270(SP), R8												
  binary-control.go:77		0xa11035		4c8b8c2468020000		MOVQ 0x268(SP), R9												
  binary-control.go:77		0xa1103d		49ffc1				INCQ R9														
  binary-control.go:77		0xa11040		4c8b942460020000		MOVQ 0x260(SP), R10												
  binary-control.go:77		0xa11048		4d39c8				CMPQ R8, R9													
  binary-control.go:77		0xa1104b		73b3				JAE 0xa11000													
  binary-control.go:77		0xa1104d		4c89d0				MOVQ R10, AX													
  binary-control.go:77		0xa11050		4c89cb				MOVQ R9, BX													
  binary-control.go:77		0xa11053		4c89c1				MOVQ R8, CX													
  binary-control.go:77		0xa11056		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa1105b		488d35ee317100			LEAQ 0x7131ee(IP), SI												
  binary-control.go:77		0xa11062		e81916a8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa11067		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa1106f		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa11077		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa1107f		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa11087		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:81		0xa1108f		488bbc24c8000000		MOVQ 0xc8(SP), DI												
  binary-snapshot.go:554	0xa11097		4c8ba424000b0000		MOVQ 0xb00(SP), R12												
  binary-snapshot.go:554	0xa1109f		4c8bac2440020000		MOVQ 0x240(SP), R13												
  binary-snapshot.go:554	0xa110a7		4c8bbc2438020000		MOVQ 0x238(SP), R15												
  binary-control.go:77		0xa110af		4989d9				MOVQ BX, R9													
  binary-control.go:77		0xa110b2		4989c2				MOVQ AX, R10													
  binary-snapshot.go:572	0xa110b5		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa110bd		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa110c5		e936ffffff			JMP 0xa11000													
  binary-control.go:77		0xa110ca		4c8b842470020000		MOVQ 0x270(SP), R8												
  binary-control.go:77		0xa110d2		4c8b8c2468020000		MOVQ 0x268(SP), R9												
  binary-control.go:77		0xa110da		49ffc1				INCQ R9														
  binary-control.go:85		0xa110dd		90				NOPL														
  binary-control.go:77		0xa110de		4c8b942460020000		MOVQ 0x260(SP), R10												
  binary-control.go:77		0xa110e6		4d39c8				CMPQ R8, R9													
  binary-control.go:77		0xa110e9		0f83d6feffff			JAE 0xa10fc5													
  binary-control.go:77		0xa110ef		4c89d0				MOVQ R10, AX													
  binary-control.go:77		0xa110f2		4c89cb				MOVQ R9, BX													
  binary-control.go:77		0xa110f5		4c89c1				MOVQ R8, CX													
  binary-control.go:77		0xa110f8		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa110fd		488d354c317100			LEAQ 0x71314c(IP), SI												
  binary-control.go:77		0xa11104		e87715a8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa11109		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa11111		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa11119		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa11121		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa11129		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:77		0xa11131		488bbc24c8000000		MOVQ 0xc8(SP), DI												
  binary-snapshot.go:554	0xa11139		4c8ba424000b0000		MOVQ 0xb00(SP), R12												
  binary-snapshot.go:554	0xa11141		4c8bac2440020000		MOVQ 0x240(SP), R13												
  binary-snapshot.go:554	0xa11149		4c8bbc2438020000		MOVQ 0x238(SP), R15												
  binary-control.go:77		0xa11151		4989d9				MOVQ BX, R9													
  binary-control.go:77		0xa11154		4989c2				MOVQ AX, R10													
  binary-snapshot.go:572	0xa11157		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa1115f		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa11167		e959feffff			JMP 0xa10fc5													
  binary-control.go:77		0xa1116c		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-control.go:77		0xa11175		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-control.go:77		0xa1117e		6690				NOPW														
  binary-control.go:77		0xa11180		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:81		0xa11188		4d89e5				MOVQ R12, R13													
  binary-control.go:81		0xa1118b		4183cd80			ORL $-0x80, R13													
  binary-control.go:77		0xa1118f		46886c07ff			MOVB R13, -0x1(DI)(R8*1)											
  binary-control.go:82		0xa11194		49c1ec07			SHRQ $0x7, R12													
  binary-control.go:81		0xa11198		4c89a424d8000000		MOVQ R12, 0xd8(SP)												
  binary-control.go:80		0xa111a0		4981fc80000000			CMPQ R12, $0x80													
  binary-control.go:80		0xa111a7		0f828b000000			JB 0xa11238													
  binary-control.go:77		0xa111ad		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa111b5		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-control.go:77		0xa111bd		48ffc7				INCQ DI														
  binary-control.go:77		0xa111c0		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:77		0xa111c8		4939fd				CMPQ R13, DI													
  binary-control.go:77		0xa111cb		73b3				JAE 0xa11180													
  binary-control.go:77		0xa111cd		4c89c0				MOVQ R8, AX													
  binary-control.go:77		0xa111d0		4889fb				MOVQ DI, BX													
  binary-control.go:77		0xa111d3		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa111d6		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa111db		488d356e307100			LEAQ 0x71306e(IP), SI												
  binary-control.go:77		0xa111e2		e89914a8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa111e7		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa111ef		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa111f7		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa111ff		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa11207		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:81		0xa1120f		4c8ba424d8000000		MOVQ 0xd8(SP), R12												
  binary-snapshot.go:551	0xa11217		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:77		0xa1121d		4889df				MOVQ BX, DI													
  binary-control.go:77		0xa11220		4989c0				MOVQ AX, R8													
  binary-snapshot.go:572	0xa11223		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa1122b		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa11233		e948ffffff			JMP 0xa11180													
  binary-control.go:77		0xa11238		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa11240		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-control.go:77		0xa11248		48ffc7				INCQ DI														
  binary-control.go:85		0xa1124b		90				NOPL														
  binary-control.go:77		0xa1124c		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:77		0xa11254		4939fd				CMPQ R13, DI													
  binary-control.go:77		0xa11257		7366				JAE 0xa112bf													
  binary-control.go:77		0xa11259		4c89c0				MOVQ R8, AX													
  binary-control.go:77		0xa1125c		4889fb				MOVQ DI, BX													
  binary-control.go:77		0xa1125f		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa11262		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa11267		488d35e22f7100			LEAQ 0x712fe2(IP), SI												
  binary-control.go:77		0xa1126e		e80d14a8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa11273		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa1127b		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa11283		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa1128b		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa11293		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:77		0xa1129b		4c8ba424d8000000		MOVQ 0xd8(SP), R12												
  binary-snapshot.go:551	0xa112a3		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:77		0xa112a9		4889df				MOVQ BX, DI													
  binary-control.go:77		0xa112ac		4989c0				MOVQ AX, R8													
  binary-snapshot.go:572	0xa112af		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa112b7		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa112bf		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:77		0xa112c7		46886407ff			MOVB R12, -0x1(DI)(R8*1)											
  binary-snapshot.go:546	0xa112cc		4c8ba42460030000		MOVQ 0x360(SP), R12												
  binary-snapshot.go:546	0xa112d4		4c8bac2468030000		MOVQ 0x368(SP), R13												
  binary-snapshot.go:546	0xa112dc		eb28				JMP 0xa11306													
  binary-control.go:99		0xa112de		4c8b5c247a			MOVQ 0x7a(SP), R11												
  binary-control.go:99		0xa112e3		4f891c02			MOVQ R11, 0(R10)(R8*1)												
  binary-control.go:99		0xa112e7		4c898c2468020000		MOVQ R9, 0x268(SP)												
  binary-control.go:99		0xa112ef		4889bc2470020000		MOVQ DI, 0x270(SP)												
  binary-control.go:99		0xa112f7		4c89942460020000		MOVQ R10, 0x260(SP)												
  binary-snapshot.go:546	0xa112ff		4983c410			ADDQ $0x10, R12													
  binary-snapshot.go:546	0xa11303		49ffcd				DECQ R13													
  binary-snapshot.go:546	0xa11306		4d85ed				TESTQ R13, R13													
  binary-snapshot.go:546	0xa11309		0f8e89f6ffff			JLE 0xa10998													
  binary-snapshot.go:546	0xa1130f		4c89ac2440020000		MOVQ R13, 0x240(SP)												
  binary-snapshot.go:546	0xa11317		4c89a424100b0000		MOVQ R12, 0xb10(SP)												
  binary-snapshot.go:546	0xa1131f		f2410f100424			MOVSD_XMM 0(R12), X0												
  binary-snapshot.go:546	0xa11325		f2410f104c2408			MOVSD_XMM 0x8(R12), X1												
  binary-snapshot.go:547	0xa1132c		90				NOPL														
  binary-snapshot.go:99		0xa1132d		90				NOPL														
  binary-control.go:97		0xa1132e		48c784248200000000000000	MOVQ $0x0, 0x82(SP)												
  binary-control.go:98		0xa1133a		90				NOPL														
  binary.go:124			0xa1133b		f20f11842482000000		MOVSD_XMM X0, 0x82(SP)												
  binary-control.go:99		0xa11344		488bbc2470020000		MOVQ 0x270(SP), DI												
  binary-control.go:99		0xa1134c		4c8b842468020000		MOVQ 0x268(SP), R8												
  binary-control.go:99		0xa11354		4d8d4808			LEAQ 0x8(R8), R9												
  binary-control.go:99		0xa11358		4c8b942460020000		MOVQ 0x260(SP), R10												
  binary-control.go:99		0xa11360		4c39cf				CMPQ DI, R9													
  binary-control.go:99		0xa11363		0f8383000000			JAE 0xa113ec													
  binary-control.go:99		0xa11369		4c89842438020000		MOVQ R8, 0x238(SP)												
  binary-snapshot.go:546	0xa11371		f20f118c2430020000		MOVSD_XMM X1, 0x230(SP)												
  binary-control.go:99		0xa1137a		4c89d0				MOVQ R10, AX													
  binary-control.go:99		0xa1137d		4c89cb				MOVQ R9, BX													
  binary-control.go:99		0xa11380		4889f9				MOVQ DI, CX													
  binary-control.go:99		0xa11383		bf08000000			MOVL $0x8, DI													
  binary-control.go:99		0xa11388		488d35c12e7100			LEAQ 0x712ec1(IP), SI												
  binary-control.go:99		0xa1138f		e8ec12a8ff			CALL runtime.growslice(SB)											
  binary-replication.go:1049	0xa11394		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa1139c		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:99		0xa113a4		4c8b842438020000		MOVQ 0x238(SP), R8												
  binary-snapshot.go:546	0xa113ac		4c8ba424100b0000		MOVQ 0xb10(SP), R12												
  binary-snapshot.go:546	0xa113b4		4c8bac2440020000		MOVQ 0x240(SP), R13												
  binary-snapshot.go:551	0xa113bc		440fb67c2478			MOVZX 0x78(SP), R15												
  binary.go:124			0xa113c2		f20f108c2430020000		MOVSD_XMM 0x230(SP), X1												
  binary-control.go:99		0xa113cb		4989c2				MOVQ AX, R10													
  binary-control.go:99		0xa113ce		4989d9				MOVQ BX, R9													
  binary-control.go:99		0xa113d1		4889cf				MOVQ CX, DI													
  binary-snapshot.go:572	0xa113d4		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa113dc		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-snapshot.go:572	0xa113e4		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:99		0xa113ec		4c8b9c2482000000		MOVQ 0x82(SP), R11												
  binary-control.go:99		0xa113f4		4f891c02			MOVQ R11, 0(R10)(R8*1)												
  binary-control.go:99		0xa113f8		4c898c2468020000		MOVQ R9, 0x268(SP)												
  binary-control.go:99		0xa11400		4889bc2470020000		MOVQ DI, 0x270(SP)												
  binary-control.go:99		0xa11408		4c89942460020000		MOVQ R10, 0x260(SP)												
  binary-snapshot.go:99		0xa11410		90				NOPL														
  binary-control.go:97		0xa11411		48c744247a00000000		MOVQ $0x0, 0x7a(SP)												
  binary-control.go:98		0xa1141a		90				NOPL														
  binary.go:124			0xa1141b		f20f114c247a			MOVSD_XMM X1, 0x7a(SP)												
  binary-control.go:99		0xa11421		488bbc2470020000		MOVQ 0x270(SP), DI												
  binary-control.go:99		0xa11429		4c8b842468020000		MOVQ 0x268(SP), R8												
  binary-control.go:99		0xa11431		4d8d4808			LEAQ 0x8(R8), R9												
  binary-control.go:99		0xa11435		4c8b942460020000		MOVQ 0x260(SP), R10												
  binary-control.go:99		0xa1143d		0f1f00				NOPL 0(AX)													
  binary-control.go:99		0xa11440		4c39cf				CMPQ DI, R9													
  binary-control.go:99		0xa11443		0f8395feffff			JAE 0xa112de													
  binary-control.go:99		0xa11449		4c89842438020000		MOVQ R8, 0x238(SP)												
  binary-control.go:99		0xa11451		4c89d0				MOVQ R10, AX													
  binary-control.go:99		0xa11454		4c89cb				MOVQ R9, BX													
  binary-control.go:99		0xa11457		4889f9				MOVQ DI, CX													
  binary-control.go:99		0xa1145a		bf08000000			MOVL $0x8, DI													
  binary-control.go:99		0xa1145f		488d35ea2d7100			LEAQ 0x712dea(IP), SI												
  binary-control.go:99		0xa11466		e81512a8ff			CALL runtime.growslice(SB)											
  binary-replication.go:1049	0xa1146b		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa11473		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:99		0xa1147b		4c8b842438020000		MOVQ 0x238(SP), R8												
  binary-snapshot.go:546	0xa11483		4c8ba424100b0000		MOVQ 0xb10(SP), R12												
  binary-snapshot.go:546	0xa1148b		4c8bac2440020000		MOVQ 0x240(SP), R13												
  binary-snapshot.go:551	0xa11493		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:99		0xa11499		4989c2				MOVQ AX, R10													
  binary-control.go:99		0xa1149c		4889cf				MOVQ CX, DI													
  binary-control.go:99		0xa1149f		4989d9				MOVQ BX, R9													
  binary-snapshot.go:572	0xa114a2		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa114aa		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-snapshot.go:572	0xa114b2		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:99		0xa114ba		e91ffeffff			JMP 0xa112de													
  binary-control.go:99		0xa114bf		90				NOPL														
  binary-control.go:77		0xa114c0		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:81		0xa114c8		4d89e5				MOVQ R12, R13													
  binary-control.go:81		0xa114cb		4183cd80			ORL $-0x80, R13													
  binary-control.go:77		0xa114cf		46886c07ff			MOVB R13, -0x1(DI)(R8*1)											
  binary-control.go:82		0xa114d4		49c1ec07			SHRQ $0x7, R12													
  binary-control.go:81		0xa114d8		4c89a424e8000000		MOVQ R12, 0xe8(SP)												
  binary-control.go:80		0xa114e0		4981fc80000000			CMPQ R12, $0x80													
  binary-control.go:80		0xa114e7		0f828b000000			JB 0xa11578													
  binary-control.go:77		0xa114ed		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa114f5		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-control.go:77		0xa114fd		48ffc7				INCQ DI														
  binary-control.go:77		0xa11500		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:77		0xa11508		4939fd				CMPQ R13, DI													
  binary-control.go:77		0xa1150b		73b3				JAE 0xa114c0													
  binary-control.go:77		0xa1150d		4c89c0				MOVQ R8, AX													
  binary-control.go:77		0xa11510		4889fb				MOVQ DI, BX													
  binary-control.go:77		0xa11513		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa11516		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa1151b		488d352e2d7100			LEAQ 0x712d2e(IP), SI												
  binary-control.go:77		0xa11522		e85911a8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa11527		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa1152f		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa11537		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa1153f		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa11547		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:81		0xa1154f		4c8ba424e8000000		MOVQ 0xe8(SP), R12												
  binary-snapshot.go:543	0xa11557		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:77		0xa1155d		4889df				MOVQ BX, DI													
  binary-control.go:77		0xa11560		4989c0				MOVQ AX, R8													
  binary-snapshot.go:572	0xa11563		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa1156b		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa11573		e948ffffff			JMP 0xa114c0													
  binary-control.go:77		0xa11578		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa11580		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-control.go:77		0xa11588		48ffc7				INCQ DI														
  binary-control.go:85		0xa1158b		90				NOPL														
  binary-control.go:77		0xa1158c		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:77		0xa11594		4939fd				CMPQ R13, DI													
  binary-control.go:77		0xa11597		7366				JAE 0xa115ff													
  binary-control.go:77		0xa11599		4c89c0				MOVQ R8, AX													
  binary-control.go:77		0xa1159c		4889fb				MOVQ DI, BX													
  binary-control.go:77		0xa1159f		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa115a2		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa115a7		488d35a22c7100			LEAQ 0x712ca2(IP), SI												
  binary-control.go:77		0xa115ae		e8cd10a8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa115b3		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa115bb		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa115c3		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa115cb		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa115d3		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:77		0xa115db		4c8ba424e8000000		MOVQ 0xe8(SP), R12												
  binary-snapshot.go:543	0xa115e3		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:77		0xa115e9		4889df				MOVQ BX, DI													
  binary-control.go:77		0xa115ec		4989c0				MOVQ AX, R8													
  binary-snapshot.go:572	0xa115ef		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa115f7		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa115ff		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:77		0xa11607		46886407ff			MOVB R12, -0x1(DI)(R8*1)											
  binary-snapshot.go:534	0xa1160c		4c8ba42420030000		MOVQ 0x320(SP), R12												
  binary-snapshot.go:534	0xa11614		f2410f100424			MOVSD_XMM 0(R12), X0												
  binary-control.go:97		0xa1161a		48c784248a00000000000000	MOVQ $0x0, 0x8a(SP)												
  binary-control.go:98		0xa11626		90				NOPL														
  binary.go:124			0xa11627		f20f1184248a000000		MOVSD_XMM X0, 0x8a(SP)												
  binary-control.go:99		0xa11630		4c8ba42470020000		MOVQ 0x270(SP), R12												
  binary-control.go:99		0xa11638		4c8bac2468020000		MOVQ 0x268(SP), R13												
  binary-control.go:99		0xa11640		498d7d08			LEAQ 0x8(R13), DI												
  binary-control.go:99		0xa11644		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:99		0xa1164c		4939fc				CMPQ R12, DI													
  binary-control.go:99		0xa1164f		7361				JAE 0xa116b2													
  binary-control.go:99		0xa11651		4c89ac2440020000		MOVQ R13, 0x240(SP)												
  binary-control.go:99		0xa11659		4c89c0				MOVQ R8, AX													
  binary-control.go:99		0xa1165c		4889fb				MOVQ DI, BX													
  binary-control.go:99		0xa1165f		4c89e1				MOVQ R12, CX													
  binary-control.go:99		0xa11662		bf08000000			MOVL $0x8, DI													
  binary-control.go:99		0xa11667		488d35e22b7100			LEAQ 0x712be2(IP), SI												
  binary-control.go:99		0xa1166e		e80d10a8ff			CALL runtime.growslice(SB)											
  binary-replication.go:1049	0xa11673		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa1167b		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:99		0xa11683		4c8bac2440020000		MOVQ 0x240(SP), R13												
  binary-snapshot.go:543	0xa1168b		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:99		0xa11691		4989c0				MOVQ AX, R8													
  binary-control.go:99		0xa11694		4989cc				MOVQ CX, R12													
  binary-control.go:99		0xa11697		4889df				MOVQ BX, DI													
  binary-snapshot.go:572	0xa1169a		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa116a2		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-snapshot.go:572	0xa116aa		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:99		0xa116b2		4c8b8c248a000000		MOVQ 0x8a(SP), R9												
  binary-control.go:99		0xa116ba		4f890c28			MOVQ R9, 0(R8)(R13*1)												
  binary-control.go:99		0xa116be		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:99		0xa116c6		4c89a42470020000		MOVQ R12, 0x270(SP)												
  binary-control.go:99		0xa116ce		4c89842460020000		MOVQ R8, 0x260(SP)												
  binary-snapshot.go:535	0xa116d6		4c8ba42430030000		MOVQ 0x330(SP), R12												
  binary-snapshot.go:535	0xa116de		6690				NOPW														
  binary-control.go:80		0xa116e0		eb36				JMP 0xa11718													
  binary-control.go:80		0xa116e2		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-control.go:80		0xa116eb		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-control.go:80		0xa116f4		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-control.go:80		0xa116fd		0f1f00				NOPL 0(AX)													
  binary-control.go:77		0xa11700		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:81		0xa11708		4d89e5				MOVQ R12, R13													
  binary-control.go:81		0xa1170b		4183cd80			ORL $-0x80, R13													
  binary-control.go:77		0xa1170f		46886c07ff			MOVB R13, -0x1(DI)(R8*1)											
  binary-control.go:82		0xa11714		49c1ec07			SHRQ $0x7, R12													
  binary-control.go:81		0xa11718		4c89a424e0000000		MOVQ R12, 0xe0(SP)												
  binary-control.go:80		0xa11720		4981fc80000000			CMPQ R12, $0x80													
  binary-control.go:80		0xa11727		0f828b000000			JB 0xa117b8													
  binary-control.go:77		0xa1172d		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa11735		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-control.go:77		0xa1173d		48ffc7				INCQ DI														
  binary-control.go:77		0xa11740		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:77		0xa11748		4939fd				CMPQ R13, DI													
  binary-control.go:77		0xa1174b		73b3				JAE 0xa11700													
  binary-control.go:77		0xa1174d		4c89c0				MOVQ R8, AX													
  binary-control.go:77		0xa11750		4889fb				MOVQ DI, BX													
  binary-control.go:77		0xa11753		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa11756		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa1175b		488d35ee2a7100			LEAQ 0x712aee(IP), SI												
  binary-control.go:77		0xa11762		e8190fa8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa11767		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa1176f		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa11777		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa1177f		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa11787		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:81		0xa1178f		4c8ba424e0000000		MOVQ 0xe0(SP), R12												
  binary-snapshot.go:543	0xa11797		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:77		0xa1179d		4889df				MOVQ BX, DI													
  binary-control.go:77		0xa117a0		4989c0				MOVQ AX, R8													
  binary-snapshot.go:572	0xa117a3		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa117ab		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa117b3		e948ffffff			JMP 0xa11700													
  binary-control.go:77		0xa117b8		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa117c0		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-control.go:77		0xa117c8		48ffc7				INCQ DI														
  binary-control.go:85		0xa117cb		90				NOPL														
  binary-control.go:77		0xa117cc		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:77		0xa117d4		4939fd				CMPQ R13, DI													
  binary-control.go:77		0xa117d7		7366				JAE 0xa1183f													
  binary-control.go:77		0xa117d9		4c89c0				MOVQ R8, AX													
  binary-control.go:77		0xa117dc		4889fb				MOVQ DI, BX													
  binary-control.go:77		0xa117df		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa117e2		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa117e7		488d35622a7100			LEAQ 0x712a62(IP), SI												
  binary-control.go:77		0xa117ee		e88d0ea8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa117f3		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa117fb		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa11803		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa1180b		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa11813		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:77		0xa1181b		4c8ba424e0000000		MOVQ 0xe0(SP), R12												
  binary-snapshot.go:543	0xa11823		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:77		0xa11829		4889df				MOVQ BX, DI													
  binary-control.go:77		0xa1182c		4989c0				MOVQ AX, R8													
  binary-snapshot.go:572	0xa1182f		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa11837		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa1183f		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:77		0xa11847		46886407ff			MOVB R12, -0x1(DI)(R8*1)											
  binary-snapshot.go:537	0xa1184c		4c8ba42428030000		MOVQ 0x328(SP), R12												
  binary-snapshot.go:537	0xa11854		4c8bac2430030000		MOVQ 0x330(SP), R13												
  binary-snapshot.go:537	0xa1185c		0f1f4000			NOPL 0(AX)													
  binary-snapshot.go:537	0xa11860		e9a5000000			JMP 0xa1190a													
  binary-snapshot.go:537	0xa11865		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-snapshot.go:537	0xa1186e		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-snapshot.go:537	0xa11877		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-snapshot.go:537	0xa11880		4c89ac2440020000		MOVQ R13, 0x240(SP)												
  binary-snapshot.go:537	0xa11888		4c89a424100b0000		MOVQ R12, 0xb10(SP)												
  binary-snapshot.go:537	0xa11890		410f100424			MOVUPS 0(R12), X0												
  binary-snapshot.go:538	0xa11895		498b1c24			MOVQ 0(R12), BX													
  binary-snapshot.go:537	0xa11899		0f11842430010000		MOVUPS X0, 0x130(SP)												
  binary-snapshot.go:538	0xa118a1		488d842460020000		LEAQ 0x260(SP), AX												
  binary-snapshot.go:538	0xa118a9		e8b2cdbcff			CALL github.com/burntcustard/unicorn-mining-co/src/server/protocol.(*writer).signed(SB)				
  binary-snapshot.go:539	0xa118ae		488b9c2438010000		MOVQ 0x138(SP), BX												
  binary-snapshot.go:539	0xa118b6		488d842460020000		LEAQ 0x260(SP), AX												
  binary-snapshot.go:539	0xa118be		6690				NOPW														
  binary-snapshot.go:539	0xa118c0		e89bcdbcff			CALL github.com/burntcustard/unicorn-mining-co/src/server/protocol.(*writer).signed(SB)				
  binary-snapshot.go:537	0xa118c5		4c8ba424100b0000		MOVQ 0xb10(SP), R12												
  binary-snapshot.go:537	0xa118cd		4983c410			ADDQ $0x10, R12													
  binary-snapshot.go:537	0xa118d1		4c8bac2440020000		MOVQ 0x240(SP), R13												
  binary-snapshot.go:537	0xa118d9		49ffcd				DECQ R13													
  binary-snapshot.go:572	0xa118dc		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa118e4		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa118ec		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa118f4		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-snapshot.go:572	0xa118fc		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-snapshot.go:543	0xa11904		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-snapshot.go:537	0xa1190a		4d85ed				TESTQ R13, R13													
  binary-snapshot.go:537	0xa1190d		0f8f6dffffff			JG 0xa11880													
  binary-snapshot.go:537	0xa11913		e96df0ffff			JMP 0xa10985													
  binary-control.go:77		0xa11918		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:81		0xa11920		4d89e5				MOVQ R12, R13													
  binary-control.go:81		0xa11923		4183cd80			ORL $-0x80, R13													
  binary-control.go:77		0xa11927		46886c07ff			MOVB R13, -0x1(DI)(R8*1)											
  binary-control.go:82		0xa1192c		49c1ec07			SHRQ $0x7, R12													
  binary-control.go:81		0xa11930		4c89a424f0000000		MOVQ R12, 0xf0(SP)												
  binary-control.go:81		0xa11938		0f1f840000000000		NOPL 0(AX)(AX*1)												
  binary-control.go:80		0xa11940		4981fc80000000			CMPQ R12, $0x80													
  binary-control.go:80		0xa11947		0f828b000000			JB 0xa119d8													
  binary-control.go:77		0xa1194d		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa11955		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-control.go:77		0xa1195d		48ffc7				INCQ DI														
  binary-control.go:77		0xa11960		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:77		0xa11968		4939fd				CMPQ R13, DI													
  binary-control.go:77		0xa1196b		73ab				JAE 0xa11918													
  binary-control.go:77		0xa1196d		4c89c0				MOVQ R8, AX													
  binary-control.go:77		0xa11970		4889fb				MOVQ DI, BX													
  binary-control.go:77		0xa11973		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa11976		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa1197b		488d35ce287100			LEAQ 0x7128ce(IP), SI												
  binary-control.go:77		0xa11982		e8f90ca8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa11987		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa1198f		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa11997		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa1199f		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa119a7		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:81		0xa119af		4c8ba424f0000000		MOVQ 0xf0(SP), R12												
  binary-snapshot.go:543	0xa119b7		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:77		0xa119bd		4889df				MOVQ BX, DI													
  binary-control.go:77		0xa119c0		4989c0				MOVQ AX, R8													
  binary-snapshot.go:572	0xa119c3		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa119cb		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa119d3		e940ffffff			JMP 0xa11918													
  binary-control.go:77		0xa119d8		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa119e0		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-control.go:77		0xa119e8		48ffc7				INCQ DI														
  binary-control.go:85		0xa119eb		90				NOPL														
  binary-control.go:77		0xa119ec		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:77		0xa119f4		4939fd				CMPQ R13, DI													
  binary-control.go:77		0xa119f7		7366				JAE 0xa11a5f													
  binary-control.go:77		0xa119f9		4c89c0				MOVQ R8, AX													
  binary-control.go:77		0xa119fc		4889fb				MOVQ DI, BX													
  binary-control.go:77		0xa119ff		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa11a02		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa11a07		488d3542287100			LEAQ 0x712842(IP), SI												
  binary-control.go:77		0xa11a0e		e86d0ca8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa11a13		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa11a1b		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa11a23		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa11a2b		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa11a33		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:77		0xa11a3b		4c8ba424f0000000		MOVQ 0xf0(SP), R12												
  binary-snapshot.go:543	0xa11a43		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:77		0xa11a49		4889df				MOVQ BX, DI													
  binary-control.go:77		0xa11a4c		4989c0				MOVQ AX, R8													
  binary-snapshot.go:572	0xa11a4f		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa11a57		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa11a5f		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:77		0xa11a67		46886407ff			MOVB R12, -0x1(DI)(R8*1)											
  binary-snapshot.go:532	0xa11a6c		e9fdeeffff			JMP 0xa1096e													
  binary-snapshot.go:532	0xa11a71		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-snapshot.go:532	0xa11a7a		660f1f440000			NOPW 0(AX)(AX*1)												
  binary-control.go:77		0xa11a80		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:81		0xa11a88		4d89e5				MOVQ R12, R13													
  binary-control.go:81		0xa11a8b		4183cd80			ORL $-0x80, R13													
  binary-control.go:77		0xa11a8f		46886c07ff			MOVB R13, -0x1(DI)(R8*1)											
  binary-control.go:82		0xa11a94		49c1ec07			SHRQ $0x7, R12													
  binary-control.go:81		0xa11a98		4c89a424f8000000		MOVQ R12, 0xf8(SP)												
  binary-control.go:80		0xa11aa0		4981fc80000000			CMPQ R12, $0x80													
  binary-control.go:80		0xa11aa7		0f828b000000			JB 0xa11b38													
  binary-control.go:77		0xa11aad		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa11ab5		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-control.go:77		0xa11abd		48ffc7				INCQ DI														
  binary-control.go:77		0xa11ac0		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:77		0xa11ac8		4939fd				CMPQ R13, DI													
  binary-control.go:77		0xa11acb		73b3				JAE 0xa11a80													
  binary-control.go:77		0xa11acd		4c89c0				MOVQ R8, AX													
  binary-control.go:77		0xa11ad0		4889fb				MOVQ DI, BX													
  binary-control.go:77		0xa11ad3		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa11ad6		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa11adb		488d356e277100			LEAQ 0x71276e(IP), SI												
  binary-control.go:77		0xa11ae2		e8990ba8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa11ae7		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa11aef		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa11af7		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa11aff		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa11b07		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:81		0xa11b0f		4c8ba424f8000000		MOVQ 0xf8(SP), R12												
  binary-snapshot.go:543	0xa11b17		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:77		0xa11b1d		4889df				MOVQ BX, DI													
  binary-control.go:77		0xa11b20		4989c0				MOVQ AX, R8													
  binary-snapshot.go:572	0xa11b23		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa11b2b		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa11b33		e948ffffff			JMP 0xa11a80													
  binary-control.go:77		0xa11b38		4c8bac2470020000		MOVQ 0x270(SP), R13												
  binary-control.go:77		0xa11b40		488bbc2468020000		MOVQ 0x268(SP), DI												
  binary-control.go:77		0xa11b48		48ffc7				INCQ DI														
  binary-control.go:85		0xa11b4b		90				NOPL														
  binary-control.go:77		0xa11b4c		4c8b842460020000		MOVQ 0x260(SP), R8												
  binary-control.go:77		0xa11b54		4939fd				CMPQ R13, DI													
  binary-control.go:77		0xa11b57		7366				JAE 0xa11bbf													
  binary-control.go:77		0xa11b59		4c89c0				MOVQ R8, AX													
  binary-control.go:77		0xa11b5c		4889fb				MOVQ DI, BX													
  binary-control.go:77		0xa11b5f		4c89e9				MOVQ R13, CX													
  binary-control.go:77		0xa11b62		bf01000000			MOVL $0x1, DI													
  binary-control.go:77		0xa11b67		488d35e2267100			LEAQ 0x7126e2(IP), SI												
  binary-control.go:77		0xa11b6e		e80d0ba8ff			CALL runtime.growslice(SB)											
  binary-control.go:77		0xa11b73		48898c2470020000		MOVQ CX, 0x270(SP)												
  binary-control.go:77		0xa11b7b		4889842460020000		MOVQ AX, 0x260(SP)												
  binary-snapshot.go:572	0xa11b83		488b8c24280b0000		MOVQ 0xb28(SP), CX												
  binary-replication.go:1049	0xa11b8b		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-snapshot.go:572	0xa11b93		488bb424180b0000		MOVQ 0xb18(SP), SI												
  binary-control.go:77		0xa11b9b		4c8ba424f8000000		MOVQ 0xf8(SP), R12												
  binary-snapshot.go:543	0xa11ba3		440fb67c2478			MOVZX 0x78(SP), R15												
  binary-control.go:77		0xa11ba9		4889df				MOVQ BX, DI													
  binary-control.go:77		0xa11bac		4989c0				MOVQ AX, R8													
  binary-snapshot.go:572	0xa11baf		488b8424200b0000		MOVQ 0xb20(SP), AX												
  binary-snapshot.go:572	0xa11bb7		488b9c24300b0000		MOVQ 0xb30(SP), BX												
  binary-control.go:77		0xa11bbf		4889bc2468020000		MOVQ DI, 0x268(SP)												
  binary-control.go:77		0xa11bc7		46886407ff			MOVB R12, -0x1(DI)(R8*1)											
  binary-snapshot.go:524	0xa11bcc		e934edffff			JMP 0xa10905													
  binary-replication.go:1040	0xa11bd1		e8ea5aa8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:1040	0xa11bd6		e8e55aa8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:1040	0xa11bdb		0f1f440000			NOPL 0(AX)(AX*1)												
  binary-replication.go:1040	0xa11be0		e8db5aa8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:1036	0xa11be5		e8d65aa8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:977	0xa11bea		e8d15aa8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:957	0xa11bef		e8cc5aa8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:953	0xa11bf4		e8c75aa8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:953	0xa11bf9		0f1f8000000000			NOPL 0(AX)													
  slices.go:97			0xa11c00		49ffc7				INCQ R15													
  binary-replication.go:973	0xa11c03		488bbc24b0020000		MOVQ 0x2b0(SP), DI												
  slices.go:97			0xa11c0b		4d39c7				CMPQ R15, R8													
  slices.go:97			0xa11c0e		7d13				JGE 0xa11c23													
  slices.go:98			0xa11c10		4a8b3cfe			MOVQ 0(SI)(R15*8), DI												
  slices.go:98			0xa11c14		4c39cf				CMPQ DI, R9													
  slices.go:98			0xa11c17		75e7				JNE 0xa11c00													
  binary-replication.go:973	0xa11c19		488bbc24b0020000		MOVQ 0x2b0(SP), DI												
  slices.go:118			0xa11c21		eb07				JMP 0xa11c2a													
  slices.go:118			0xa11c23		49c7c7ffffffff			MOVQ $-0x1, R15													
  slices.go:118			0xa11c2a		4d85ff				TESTQ R15, R15													
  binary-replication.go:914	0xa11c2d		0f8d13020000			JGE 0xa11e46													
  binary-replication.go:842	0xa11c33		440fb67c2476			MOVZX 0x76(SP), R15												
  binary-replication.go:842	0xa11c39		0f1f8000000000			NOPL 0(AX)													
  binary-replication.go:842	0xa11c40		4584ff				TESTL R15, R15													
  binary-replication.go:915	0xa11c43		0f84b2000000			JE 0xa11cfb													
  binary-replication.go:919	0xa11c49		660f2ec6			UCOMISD X6, X0													
  binary-replication.go:919	0xa11c4d		7210				JB 0xa11c5f													
  binary-replication.go:920	0xa11c4f		488bb42498010000		MOVQ 0x198(SP), SI												
  binary-replication.go:920	0xa11c57		440fb6442474			MOVZX 0x74(SP), R8												
  binary-replication.go:921	0xa11c5d		eb0e				JMP 0xa11c6d													
  binary-replication.go:920	0xa11c5f		488bb424a0010000		MOVQ 0x1a0(SP), SI												
  binary-replication.go:920	0xa11c67		440fb6442479			MOVZX 0x79(SP), R8												
  binary-replication.go:924	0xa11c6d		4c8b4860			MOVQ 0x60(AX), R9												
  binary-replication.go:924	0xa11c71		4d39cc				CMPQ R12, R9													
  binary-replication.go:924	0xa11c74		0f83f5010000			JAE 0xa11e6f													
  binary-replication.go:924	0xa11c7a		4c8b4858			MOVQ 0x58(AX), R9												
  binary-replication.go:924	0xa11c7e		4f8b0ce1			MOVQ 0(R9)(R12*8), R9												
  binary-replication.go:924	0xa11c82		4983f901			CMPQ R9, $0x1													
  binary-replication.go:924	0xa11c86		7e4a				JLE 0xa11cd2													
  binary-replication.go:925	0xa11c88		4c8b4078			MOVQ 0x78(AX), R8												
  binary-replication.go:925	0xa11c8c		4d39c4				CMPQ R12, R8													
  binary-replication.go:925	0xa11c8f		0f83d5010000			JAE 0xa11e6a													
  binary-replication.go:925	0xa11c95		4c8b4070			MOVQ 0x70(AX), R8												
  binary-replication.go:925	0xa11c99		4f8b04e0			MOVQ 0(R8)(R12*8), R8												
  binary-replication.go:925	0xa11c9d		0f1f00				NOPL 0(AX)													
  binary-replication.go:925	0xa11ca0		4d85c0				TESTQ R8, R8													
  binary-replication.go:925	0xa11ca3		0f8cbc010000			JL 0xa11e65													
  binary-replication.go:872	0xa11ca9		4989c9				MOVQ CX, R9													
  binary-replication.go:925	0xa11cac		4c89c1				MOVQ R8, CX													
  binary-replication.go:925	0xa11caf		41bf01000000			MOVL $0x1, R15													
  binary-replication.go:925	0xa11cb5		49d3e7				SHLQ CL, R15													
  binary-replication.go:925	0xa11cb8		4883f940			CMPQ CX, $0x40													
  binary-replication.go:925	0xa11cbc		4819c9				SBBQ CX, CX													
  binary-replication.go:925	0xa11cbf		4921cf				ANDQ CX, R15													
  binary-replication.go:925	0xa11cc2		4985f7				TESTQ SI, R15													
  binary-replication.go:925	0xa11cc5		410f95c0			SETNE R8													
  binary-replication.go:659	0xa11cc9		4c89c9				MOVQ R9, CX													
  binary-replication.go:842	0xa11ccc		440fb67c2476			MOVZX 0x76(SP), R15												
  binary-replication.go:925	0xa11cd2		4584c0				TESTL R8, R8													
  binary-replication.go:928	0xa11cd5		0f855e010000			JNE 0xa11e39													
  binary-replication.go:877	0xa11cdb		488bb42420020000		MOVQ 0x220(SP), SI												
  binary-replication.go:1018	0xa11ce3		4c8b842418010000		MOVQ 0x118(SP), R8												
  binary-replication.go:1015	0xa11ceb		4189df				MOVL BX, R15													
  binary-replication.go:872	0xa11cee		488b9c2450020000		MOVQ 0x250(SP), BX												
  binary-replication.go:1015	0xa11cf6		e995e2ffff			JMP 0xa0ff90													
  binary-replication.go:940	0xa11cfb		488b7060			MOVQ 0x60(AX), SI												
  binary-replication.go:934	0xa11cff		660f2ec6			UCOMISD X6, X0													
  binary-replication.go:935	0xa11d03		4c8bbc2478010000		MOVQ 0x178(SP), R15												
  binary-replication.go:909	0xa11d0b		4d89e9				MOVQ R13, R9													
  binary-replication.go:935	0xa11d0e		4c8bac24a8000000		MOVQ 0xa8(SP), R13												
  binary-replication.go:935	0xa11d16		4d0f43fd			CMOVAE R13, R15													
  binary-replication.go:935	0xa11d1a		660f1f440000			NOPW 0(AX)(AX*1)												
  binary-replication.go:940	0xa11d20		4939f4				CMPQ R12, SI													
  binary-replication.go:934	0xa11d23		0f8334010000			JAE 0xa11e5d													
  binary-replication.go:940	0xa11d29		488b7058			MOVQ 0x58(AX), SI												
  binary-replication.go:940	0xa11d2d		4a8b34e6			MOVQ 0(SI)(R12*8), SI												
  binary-replication.go:940	0xa11d31		4883fe01			CMPQ SI, $0x1													
  binary-replication.go:940	0xa11d35		7e2b				JLE 0xa11d62													
  binary-replication.go:941	0xa11d37		488bb238070000			MOVQ 0x738(DX), SI												
  binary-replication.go:942	0xa11d3e		4c8b6878			MOVQ 0x78(AX), R13												
  binary-replication.go:941	0xa11d42		4c39fe				CMPQ SI, R15													
  binary-replication.go:941	0xa11d45		4c0f4ffe			CMOVG SI, R15													
  binary-replication.go:942	0xa11d49		4d39ec				CMPQ R12, R13													
  binary-replication.go:941	0xa11d4c		0f8306010000			JAE 0xa11e58													
  binary-replication.go:942	0xa11d52		4c8b6870			MOVQ 0x70(AX), R13												
  binary-replication.go:942	0xa11d56		4f8b6ce500			MOVQ 0(R13)(R12*8), R13												
  binary-replication.go:942	0xa11d5b		4c89ee				MOVQ R13, SI													
  binary-replication.go:942	0xa11d5e		6690				NOPW														
  binary-replication.go:942	0xa11d60		eb02				JMP 0xa11d64													
  binary-replication.go:942	0xa11d62		31f6				XORL SI, SI													
  binary-replication.go:945	0xa11d64		4c8bac2458020000		MOVQ 0x258(SP), R13												
  binary-replication.go:945	0xa11d6c		4d8b8588010000			MOVQ 0x188(R13), R8												
  binary-replication.go:945	0xa11d73		488b3a				MOVQ 0(DX), DI													
  binary-replication.go:945	0xa11d76		4901f0				ADDQ SI, R8													
  binary-replication.go:945	0xa11d79		4801fe				ADDQ DI, SI													
  binary-replication.go:945	0xa11d7c		0f1f4000			NOPL 0(AX)													
  binary-replication.go:1089	0xa11d80		4983ff01			CMPQ R15, $0x1													
  binary-replication.go:1089	0xa11d84		0f849e000000			JE 0xa11e28													
  binary-replication.go:1093	0xa11d8a		4d85ff				TESTQ R15, R15													
  binary-replication.go:1093	0xa11d8d		7e34				JLE 0xa11dc3													
  binary-replication.go:1093	0xa11d8f		498d7fff			LEAQ -0x1(R15), DI												
  binary-replication.go:1093	0xa11d93		4c85ff				TESTQ R15, DI													
  binary-replication.go:1093	0xa11d96		7528				JNE 0xa11dc0													
  binary-replication.go:1095	0xa11d98		4985f8				TESTQ DI, R8													
  binary-replication.go:1095	0xa11d9b		7508				JNE 0xa11da5													
  binary-replication.go:1095	0xa11d9d		41bf01000000			MOVL $0x1, R15													
  binary-replication.go:1095	0xa11da3		eb5b				JMP 0xa11e00													
  binary-replication.go:1095	0xa11da5		49f7df				NEGQ R15													
  binary-replication.go:1095	0xa11da8		4d21f8				ANDQ R15, R8													
  binary-replication.go:1095	0xa11dab		4c21fe				ANDQ R15, SI													
  binary-replication.go:1095	0xa11dae		4c39c6				CMPQ SI, R8													
  binary-replication.go:1095	0xa11db1		410f95c7			SETNE R15													
  binary-replication.go:1095	0xa11db5		eb49				JMP 0xa11e00													
  binary-replication.go:1095	0xa11db7		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-replication.go:1093	0xa11dc0		4d85ff				TESTQ R15, R15													
  binary-replication.go:1098	0xa11dc3		0f848a000000			JE 0xa11e53													
  binary-replication.go:775	0xa11dc9		4889c7				MOVQ AX, DI													
  binary-replication.go:1098	0xa11dcc		4c89c0				MOVQ R8, AX													
  binary-replication.go:766	0xa11dcf		4989d0				MOVQ DX, R8													
  binary-replication.go:1098	0xa11dd2		31d2				XORL DX, DX													
  binary-replication.go:1098	0xa11dd4		49f7f7				DIVQ R15													
  binary-replication.go:1098	0xa11dd7		4885d2				TESTQ DX, DX													
  binary-replication.go:1098	0xa11dda		7507				JNE 0xa11de3													
  binary-replication.go:1098	0xa11ddc		ba01000000			MOVL $0x1, DX													
  binary-replication.go:1098	0xa11de1		eb14				JMP 0xa11df7													
  binary-replication.go:1098	0xa11de3		4889c2				MOVQ AX, DX													
  binary-replication.go:1098	0xa11de6		4889f0				MOVQ SI, AX													
  binary-replication.go:1098	0xa11de9		4889d6				MOVQ DX, SI													
  binary-replication.go:1098	0xa11dec		31d2				XORL DX, DX													
  binary-replication.go:1098	0xa11dee		49f7f7				DIVQ R15													
  binary-replication.go:1098	0xa11df1		4839f0				CMPQ AX, SI													
  binary-replication.go:1098	0xa11df4		0f95c2				SETNE DL													
  binary-replication.go:1007	0xa11df7		4889f8				MOVQ DI, AX													
  binary-replication.go:947	0xa11dfa		4189d7				MOVL DX, R15													
  binary-replication.go:877	0xa11dfd		4c89c2				MOVQ R8, DX													
  binary-replication.go:947	0xa11e00		4584ff				TESTL R15, R15													
  binary-replication.go:947	0xa11e03		7523				JNE 0xa11e28													
  binary-replication.go:877	0xa11e05		488bb42420020000		MOVQ 0x220(SP), SI												
  binary-replication.go:1018	0xa11e0d		4c8b842418010000		MOVQ 0x118(SP), R8												
  binary-replication.go:1015	0xa11e15		4d89cd				MOVQ R9, R13													
  binary-replication.go:1015	0xa11e18		4189df				MOVL BX, R15													
  binary-replication.go:872	0xa11e1b		488b9c2450020000		MOVQ 0x250(SP), BX												
  binary-replication.go:1015	0xa11e23		e968e1ffff			JMP 0xa0ff90													
  binary-replication.go:973	0xa11e28		488bbc24b0020000		MOVQ 0x2b0(SP), DI												
  binary-replication.go:1015	0xa11e30		4d89cd				MOVQ R9, R13													
  binary-replication.go:842	0xa11e33		440fb67c2476			MOVZX 0x76(SP), R15												
  binary-replication.go:973	0xa11e39		4c8bbc2418020000		MOVQ 0x218(SP), R15												
  binary-replication.go:973	0xa11e41		e9f8dcffff			JMP 0xa0fb3e													
  binary-replication.go:973	0xa11e46		4c8bbc2418020000		MOVQ 0x218(SP), R15												
  binary-replication.go:914	0xa11e4e		e9ebdcffff			JMP 0xa0fb3e													
  binary-replication.go:1098	0xa11e53		e808e3a3ff			CALL runtime.panicdivide(SB)											
  binary-replication.go:942	0xa11e58		e86358a8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:940	0xa11e5d		0f1f00				NOPL 0(AX)													
  binary-replication.go:940	0xa11e60		e85b58a8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:925	0xa11e65		e896e2a3ff			CALL runtime.panicshift(SB)											
  binary-replication.go:925	0xa11e6a		e85158a8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:924	0xa11e6f		e84c58a8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:908	0xa11e74		e84758a8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:877	0xa11e79		e84258a8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:1009	0xa11e7e		6690				NOPW														
  binary-replication.go:1009	0xa11e80		e83b58a8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:1009	0xa11e85		e83658a8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:1007	0xa11e8a		e83158a8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:1007	0xa11e8f		e82c58a8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:994	0xa11e94		488d4310			LEAQ 0x10(BX), AX												
  binary-replication.go:842	0xa11e98		0fb64c2476			MOVZX 0x76(SP), CX												
  binary-replication.go:920	0xa11e9d		488b9c24a0010000		MOVQ 0x1a0(SP), BX												
  binary-replication.go:920	0xa11ea5		0fb67c2474			MOVZX 0x74(SP), DI												
  binary-replication.go:1018	0xa11eaa		4c8b842418010000		MOVQ 0x118(SP), R8												
  binary-replication.go:935	0xa11eb2		4c8b8c24a8000000		MOVQ 0xa8(SP), R9												
  binary-replication.go:935	0xa11eba		4c8b942478010000		MOVQ 0x178(SP), R10												
  binary-replication.go:994	0xa11ec2		4c8ba42460010000		MOVQ 0x160(SP), R12												
  binary-replication.go:1006	0xa11eca		4c8bac2498000000		MOVQ 0x98(SP), R13												
  binary-replication.go:1019	0xa11ed2		4c8bbc2458020000		MOVQ 0x258(SP), R15												
  binary-replication.go:919	0xa11eda		f20f108424a0000000		MOVSD_XMM 0xa0(SP), X0												
  binary-replication.go:995	0xa11ee3		f20f10942430020000		MOVSD_XMM 0x230(SP), X2												
  binary-replication.go:995	0xa11eec		f20f109c2428020000		MOVSD_XMM 0x228(SP), X3												
  binary-replication.go:994	0xa11ef5		4989c3				MOVQ AX, R11													
  binary-replication.go:994	0xa11ef8		4889942440020000		MOVQ DX, 0x240(SP)												
  binary-replication.go:994	0xa11f00		4088742477			MOVB SI, 0x77(SP)												
  binary-replication.go:995	0xa11f05		488b842478020000		MOVQ 0x278(SP), AX												
  binary-replication.go:877	0xa11f0d		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:920	0xa11f15		0fb6742479			MOVZX 0x79(SP), SI												
  binary-replication.go:920	0xa11f1a		660f1f440000			NOPW 0(AX)(AX*1)												
  binary-replication.go:994	0xa11f20		4d39e3				CMPQ R11, R12													
  binary-replication.go:994	0xa11f23		0f8da9070000			JGE 0xa126d2													
  binary-replication.go:994	0xa11f29		4c899c2490010000		MOVQ R11, 0x190(SP)												
  binary-replication.go:995	0xa11f31		0f10e2				MOVUPS X2, X4													
  binary-replication.go:995	0xa11f34		f20f59d4			MULSD X4, X2													
  binary-replication.go:995	0xa11f38		0f10e3				MOVUPS X3, X4													
  binary-replication.go:995	0xa11f3b		f20f59dc			MULSD X4, X3													
  binary-replication.go:995	0xa11f3f		488b8c2420140000		MOVQ 0x1420(SP), CX												
  binary-replication.go:995	0xa11f47		4c89db				MOVQ R11, BX													
  binary-replication.go:995	0xa11f4a		f20f10842428010000		MOVSD_XMM 0x128(SP), X0												
  binary-replication.go:995	0xa11f53		f20f108c2420010000		MOVSD_XMM 0x120(SP), X1												
  binary-replication.go:995	0xa11f5c		0f1f4000			NOPL 0(AX)													
  binary-replication.go:995	0xa11f60		e89bd90100			CALL github.com/burntcustard/unicorn-mining-co/src/server/network.(*ReplicationView).replicationBlock(SB)	
  binary-replication.go:995	0xa11f65		f7d0				NOTL AX														
  binary-replication.go:997	0xa11f67		488b942440020000		MOVQ 0x240(SP), DX												
  binary-replication.go:997	0xa11f6f		0fb6742477			MOVZX 0x77(SP), SI												
  binary-replication.go:997	0xa11f74		488b9c2490010000		MOVQ 0x190(SP), BX												
  binary-replication.go:997	0xa11f7c		488bbc2478020000		MOVQ 0x278(SP), DI												
  binary-replication.go:997	0xa11f84		4c8b842498000000		MOVQ 0x98(SP), R8												
  binary-replication.go:997	0xa11f8c		4c8b8c2450020000		MOVQ 0x250(SP), R9												
  binary-replication.go:997	0xa11f94		4c8b942488140000		MOVQ 0x1488(SP), R10												
  binary-replication.go:997	0xa11f9c		4c8b9c2420020000		MOVQ 0x220(SP), R11												
  binary-replication.go:997	0xa11fa4		6685c0				TESTW AX, AX													
  binary-replication.go:997	0xa11fa7		0f84e7feffff			JE 0xa11e94													
  binary-replication.go:998	0xa11fad		440fbce0			BSFL AX, R12													
  binary-replication.go:999	0xa11fb1		448d68ff			LEAL -0x1(AX), R13												
  binary-replication.go:1000	0xa11fb5		4e8d3c23			LEAQ 0(BX)(R12*1), R15												
  binary-replication.go:999	0xa11fb9		4421e8				ANDL R13, AX													
  binary-replication.go:1000	0xa11fbc		f2420f10a4e7d0000000		MOVSD_XMM 0xd0(DI)(R12*8), X4											
  binary-replication.go:872	0xa11fc6		4d39f8				CMPQ R8, R15													
  binary-replication.go:872	0xa11fc9		0f86bb090000			JBE 0xa1298a													
  binary-replication.go:872	0xa11fcf		4d89fc				MOVQ R15, R12													
  binary-replication.go:872	0xa11fd2		49c1e704			SHLQ $0x4, R15													
  binary-replication.go:873	0xa11fd6		4c8b6f30			MOVQ 0x30(DI), R13												
  binary-replication.go:872	0xa11fda		4b8b0c0f			MOVQ 0(R15)(R9*1), CX												
  binary-replication.go:872	0xa11fde		4f8b7c0f08			MOVQ 0x8(R15)(R9*1), R15											
  binary-replication.go:873	0xa11fe3		4d39e5				CMPQ R13, R12													
  binary-replication.go:873	0xa11fe6		0f8699090000			JBE 0xa12985													
  binary-replication.go:872	0xa11fec		48898c2470010000		MOVQ CX, 0x170(SP)												
  binary-replication.go:873	0xa11ff4		4c8b6f28			MOVQ 0x28(DI), R13												
  binary-replication.go:874	0xa11ff8		488b4f60			MOVQ 0x60(DI), CX												
  binary-replication.go:873	0xa11ffc		4f8b6ce500			MOVQ 0(R13)(R12*8), R13												
  binary-replication.go:874	0xa12001		4c39e1				CMPQ CX, R12													
  binary-replication.go:874	0xa12004		0f8674090000			JBE 0xa1297e													
  binary-replication.go:872	0xa1200a		4c89bc24d0020000		MOVQ R15, 0x2d0(SP)												
  binary-replication.go:874	0xa12012		488b4f58			MOVQ 0x58(DI), CX												
  binary-replication.go:877	0xa12016		4d8bbab8000000			MOVQ 0xb8(R10), R15												
  binary-replication.go:874	0xa1201d		4a8b0ce1			MOVQ 0(CX)(R12*8), CX												
  binary-replication.go:877	0xa12021		4d39e7				CMPQ R15, R12													
  binary-replication.go:877	0xa12024		0f864f090000			JBE 0xa12979													
  binary-replication.go:877	0xa1202a		4d8bbab0000000			MOVQ 0xb0(R10), R15												
  binary-replication.go:877	0xa12031		4f8b3ce7			MOVQ 0(R15)(R12*8), R15												
  binary-replication.go:877	0xa12035		4d85ff				TESTQ R15, R15													
  binary-replication.go:877	0xa12038		7430				JE 0xa1206a													
  binary-replication.go:877	0xa1203a		4d8b4f18			MOVQ 0x18(R15), R9												
  binary-replication.go:877	0xa1203e		6690				NOPW														
  binary-replication.go:877	0xa12040		4d394d10			CMPQ 0x10(R13), R9												
  binary-replication.go:877	0xa12044		751c				JNE 0xa12062													
  binary-replication.go:877	0xa12046		4d395f10			CMPQ 0x10(R15), R11												
  binary-replication.go:877	0xa1204a		750a				JNE 0xa12056													
  binary-replication.go:872	0xa1204c		4c8b8c2450020000		MOVQ 0x250(SP), R9												
  binary-replication.go:878	0xa12054		eb17				JMP 0xa1206d													
  binary-replication.go:872	0xa12056		4c8b8c2450020000		MOVQ 0x250(SP), R9												
  binary-replication.go:872	0xa1205e		6690				NOPW														
  binary-replication.go:877	0xa12060		eb08				JMP 0xa1206a													
  binary-replication.go:872	0xa12062		4c8b8c2450020000		MOVQ 0x250(SP), R9												
  binary-replication.go:877	0xa1206a		4531ff				XORL R15, R15													
  binary-replication.go:999	0xa1206d		6689842496000000		MOVW AX, 0x96(SP)												
  binary-replication.go:1000	0xa12075		4c89a42440020000		MOVQ R12, 0x240(SP)												
  binary-replication.go:1000	0xa1207d		f20f11a42480010000		MOVSD_XMM X4, 0x180(SP)												
  binary-replication.go:873	0xa12086		4c89ac24a8020000		MOVQ R13, 0x2a8(SP)												
  binary-replication.go:998	0xa1208e		48899424d8010000		MOVQ DX, 0x1d8(SP)												
  binary-replication.go:998	0xa12096		4088b42493000000		MOVB SI, 0x93(SP)												
  binary-replication.go:998	0xa1209e		6690				NOPW														
  binary-replication.go:881	0xa120a0		4d85ff				TESTQ R15, R15													
  binary-replication.go:881	0xa120a3		0f858b000000			JNE 0xa12134													
  binary-replication.go:874	0xa120a9		48898c2438020000		MOVQ CX, 0x238(SP)												
  binary-replication.go:882	0xa120b1		498b9aa8000000			MOVQ 0xa8(R10), BX												
  binary-replication.go:882	0xa120b8		498b4d10			MOVQ 0x10(R13), CX												
  binary-replication.go:882	0xa120bc		488d05e5a16d00			LEAQ 0x6da1e5(IP), AX												
  binary-replication.go:882	0xa120c3		e858d59fff			CALL runtime.mapaccess1_fast64(SB)										
  binary-replication.go:882	0xa120c8		4c8b38				MOVQ 0(AX), R15													
  binary-replication.go:998	0xa120cb		0fb7842496000000		MOVZX 0x96(SP), AX												
  binary-replication.go:874	0xa120d3		488b8c2438020000		MOVQ 0x238(SP), CX												
  binary-replication.go:1000	0xa120db		488b9424d8010000		MOVQ 0x1d8(SP), DX												
  binary-replication.go:1000	0xa120e3		488b9c2490010000		MOVQ 0x190(SP), BX												
  binary-replication.go:1000	0xa120eb		0fb6b42493000000		MOVZX 0x93(SP), SI												
  binary-replication.go:1000	0xa120f3		488bbc2478020000		MOVQ 0x278(SP), DI												
  binary-replication.go:872	0xa120fb		4c8b842498000000		MOVQ 0x98(SP), R8												
  binary-replication.go:872	0xa12103		4c8b8c2450020000		MOVQ 0x250(SP), R9												
  binary-replication.go:904	0xa1210b		4c8b942488140000		MOVQ 0x1488(SP), R10												
  binary-replication.go:877	0xa12113		4c8b9c2420020000		MOVQ 0x220(SP), R11												
  binary-replication.go:908	0xa1211b		4c8ba42440020000		MOVQ 0x240(SP), R12												
  binary-replication.go:900	0xa12123		4c8bac24a8020000		MOVQ 0x2a8(SP), R13												
  binary-replication.go:900	0xa1212b		f20f10a42480010000		MOVSD_XMM 0x180(SP), X4												
  binary-replication.go:885	0xa12134		4d85ff				TESTQ R15, R15													
  binary-replication.go:888	0xa12137		740b				JE 0xa12144													
  binary-replication.go:889	0xa12139		f20f10842430020000		MOVSD_XMM 0x230(SP), X0												
  binary-replication.go:889	0xa12142		eb09				JMP 0xa1214d													
  binary-replication.go:889	0xa12144		f20f10842410020000		MOVSD_XMM 0x210(SP), X0												
  binary-replication.go:874	0xa1214d		0fbae100			BTL $0x0, CX													
  binary-replication.go:892	0xa12151		7319				JAE 0xa1216c													
  binary-replication.go:885	0xa12153		4d85ff				TESTQ R15, R15													
  binary-replication.go:895	0xa12156		740b				JE 0xa12163													
  binary-replication.go:896	0xa12158		f20f10842428020000		MOVSD_XMM 0x228(SP), X0												
  binary-replication.go:896	0xa12161		eb09				JMP 0xa1216c													
  binary-replication.go:896	0xa12163		f20f10842408020000		MOVSD_XMM 0x208(SP), X0												
  binary-replication.go:900	0xa1216c		498b4d10			MOVQ 0x10(R13), CX												
  binary-replication.go:900	0xa12170		48398c2420140000		CMPQ 0x1420(SP), CX												
  binary-replication.go:900	0xa12178		740e				JE 0xa12188													
  binary-replication.go:900	0xa1217a		f20f59c0			MULSD X0, X0													
  binary-replication.go:900	0xa1217e		660f2ec4			UCOMISD X4, X0													
  binary-replication.go:900	0xa12182		0f821cfeffff			JB 0xa11fa4													
  binary-replication.go:882	0xa12188		4c89bc2490020000		MOVQ R15, 0x290(SP)												
  binary-replication.go:904	0xa12190		4d8b5a70			MOVQ 0x70(R10), R11												
  binary-replication.go:904	0xa12194		4d8b4a68			MOVQ 0x68(R10), R9												
  binary-replication.go:904	0xa12198		49ffc1				INCQ R9														
  binary-replication.go:904	0xa1219b		4d8b4260			MOVQ 0x60(R10), R8												
  binary-replication.go:904	0xa1219f		90				NOPL														
  binary-replication.go:904	0xa121a0		4d39cb				CMPQ R11, R9													
  binary-replication.go:904	0xa121a3		7208				JB 0xa121ad													
  binary-replication.go:885	0xa121a5		4d85ff				TESTQ R15, R15													
  binary-replication.go:904	0xa121a8		e9c2000000			JMP 0xa1226f													
  binary-replication.go:900	0xa121ad		48898c24f0010000		MOVQ CX, 0x1f0(SP)												
  binary-replication.go:904	0xa121b5		4c89c0				MOVQ R8, AX													
  binary-replication.go:904	0xa121b8		4c89cb				MOVQ R9, BX													
  binary-replication.go:904	0xa121bb		4c89d9				MOVQ R11, CX													
  binary-replication.go:904	0xa121be		bf01000000			MOVL $0x1, DI													
  binary-replication.go:904	0xa121c3		488d3506227100			LEAQ 0x712206(IP), SI												
  binary-replication.go:904	0xa121ca		e8b104a8ff			CALL runtime.growslice(SB)											
  binary-replication.go:904	0xa121cf		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:904	0xa121d7		48894a70			MOVQ CX, 0x70(DX)												
  binary-replication.go:904	0xa121db		833d7e13830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:904	0xa121e2		750d				JNE 0xa121f1													
  binary-replication.go:885	0xa121e4		4c8ba42490020000		MOVQ 0x290(SP), R12												
  binary-replication.go:885	0xa121ec		4d85e4				TESTQ R12, R12													
  binary-replication.go:904	0xa121ef		eb1b				JMP 0xa1220c													
  binary-replication.go:904	0xa121f1		4c8b6260			MOVQ 0x60(DX), R12												
  binary-replication.go:904	0xa121f5		e82651a8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:904	0xa121fa		498903				MOVQ AX, 0(R11)													
  binary-replication.go:904	0xa121fd		4d896308			MOVQ R12, 0x8(R11)												
  binary-replication.go:885	0xa12201		4c8ba42490020000		MOVQ 0x290(SP), R12												
  binary-replication.go:885	0xa12209		4d85e4				TESTQ R12, R12													
  binary-replication.go:904	0xa1220c		48894260			MOVQ AX, 0x60(DX)												
  binary-replication.go:904	0xa12210		488b8c24f0010000		MOVQ 0x1f0(SP), CX												
  binary-replication.go:909	0xa12218		488b9424d8010000		MOVQ 0x1d8(SP), DX												
  binary-replication.go:911	0xa12220		0fb6b42493000000		MOVZX 0x93(SP), SI												
  binary-replication.go:953	0xa12228		488bbc2478020000		MOVQ 0x278(SP), DI												
  binary-replication.go:904	0xa12230		4c8b942488140000		MOVQ 0x1488(SP), R10												
  binary-replication.go:908	0xa12238		4c8ba42440020000		MOVQ 0x240(SP), R12												
  binary-replication.go:914	0xa12240		4c8bac24a8020000		MOVQ 0x2a8(SP), R13												
  binary-replication.go:907	0xa12248		4c8bbc2490020000		MOVQ 0x290(SP), R15												
  binary-replication.go:919	0xa12250		f20f10a42480010000		MOVSD_XMM 0x180(SP), X4												
  binary-replication.go:904	0xa12259		4989d9				MOVQ BX, R9													
  binary-replication.go:904	0xa1225c		4989c0				MOVQ AX, R8													
  binary-replication.go:998	0xa1225f		0fb7842496000000		MOVZX 0x96(SP), AX												
  binary-replication.go:1000	0xa12267		488b9c2490010000		MOVQ 0x190(SP), BX												
  binary-replication.go:904	0xa1226f		4d894a68			MOVQ R9, 0x68(R10)												
  binary-replication.go:904	0xa12273		4b894cc8f8			MOVQ CX, -0x8(R8)(R9*8)												
  binary-replication.go:906	0xa12278		7454				JE 0xa122ce													
  binary-replication.go:873	0xa1227a		4c89e9				MOVQ R13, CX													
  binary-replication.go:907	0xa1227d		4c8bac2418020000		MOVQ 0x218(SP), R13												
  binary-replication.go:907	0xa12285		4d896f10			MOVQ R13, 0x10(R15)												
  binary-replication.go:908	0xa12289		4d8b82b8000000			MOVQ 0xb8(R10), R8												
  binary-replication.go:908	0xa12290		4d39e0				CMPQ R8, R12													
  binary-replication.go:908	0xa12293		0f86db060000			JBE 0xa12974													
  binary-replication.go:908	0xa12299		4d8b82b0000000			MOVQ 0xb0(R10), R8												
  binary-replication.go:908	0xa122a0		833db912830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:908	0xa122a7		7419				JE 0xa122c2													
  binary-replication.go:908	0xa122a9		4f8b0ce0			MOVQ 0(R8)(R12*8), R9												
  binary-replication.go:908	0xa122ad		e86e50a8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:908	0xa122b2		4d893b				MOVQ R15, 0(R11)												
  binary-replication.go:908	0xa122b5		4d894b08			MOVQ R9, 0x8(R11)												
  binary-replication.go:919	0xa122b9		f20f10a42480010000		MOVSD_XMM 0x180(SP), X4												
  binary-replication.go:908	0xa122c2		4f893ce0			MOVQ R15, 0(R8)(R12*8)												
  binary-replication.go:909	0xa122c6		48ffc2				INCQ DX														
  binary-replication.go:885	0xa122c9		4d85ff				TESTQ R15, R15													
  binary-replication.go:909	0xa122cc		eb12				JMP 0xa122e0													
  binary-replication.go:914	0xa122ce		4c89e9				MOVQ R13, CX													
  binary-replication.go:973	0xa122d1		4c8bac2418020000		MOVQ 0x218(SP), R13												
  binary-replication.go:973	0xa122d9		be01000000			MOVL $0x1, SI													
  binary-replication.go:973	0xa122de		6690				NOPW														
  binary-replication.go:914	0xa122e0		741c				JE 0xa122fe													
  binary-replication.go:914	0xa122e2		4c8b842400140000		MOVQ 0x1400(SP), R8												
  binary-replication.go:914	0xa122ea		4c8b8c2408140000		MOVQ 0x1408(SP), R9												
  binary-replication.go:914	0xa122f2		4c8b5910			MOVQ 0x10(CX), R11												
  slices.go:97			0xa122f6		4531ed				XORL R13, R13													
  slices.go:97			0xa122f9		e90d040000			JMP 0xa1270b													
  binary-replication.go:953	0xa122fe		4c8b4748			MOVQ 0x48(DI), R8												
  binary-replication.go:953	0xa12302		4d39e0				CMPQ R8, R12													
  binary-replication.go:953	0xa12305		0f86e9030000			JBE 0xa126f4													
  binary-replication.go:909	0xa1230b		48899424d0010000		MOVQ DX, 0x1d0(SP)												
  binary-replication.go:911	0xa12313		4088b42492000000		MOVB SI, 0x92(SP)												
  binary-replication.go:953	0xa1231b		4c8b4740			MOVQ 0x40(DI), R8												
  binary-replication.go:953	0xa1231f		4f8b04e0			MOVQ 0(R8)(R12*8), R8												
  binary-replication.go:955	0xa12323		4d85c0				TESTQ R8, R8													
  binary-replication.go:955	0xa12326		741d				JE 0xa12345													
  binary-replication.go:955	0xa12328		4d8b4830			MOVQ 0x30(R8), R9												
  binary-replication.go:955	0xa1232c		4c8b9c24f00a0000		MOVQ 0xaf0(SP), R11												
  binary-replication.go:955	0xa12334		4d394b18			CMPQ 0x18(R11), R9												
  binary-replication.go:955	0xa12338		7513				JNE 0xa1234d													
  binary-replication.go:885	0xa1233a		4d85ff				TESTQ R15, R15													
  binary-replication.go:885	0xa1233d		0f1f00				NOPL 0(AX)													
  binary-replication.go:955	0xa12340		e9d3000000			JMP 0xa12418													
  binary-replication.go:659	0xa12345		4c8b9c24f00a0000		MOVQ 0xaf0(SP), R11												
  binary-replication.go:956	0xa1234d		90				NOPL														
  binary-replication.go:659	0xa1234e		488b842470010000		MOVQ 0x170(SP), AX												
  binary-replication.go:659	0xa12356		488b9c24d0020000		MOVQ 0x2d0(SP), BX												
  binary-replication.go:659	0xa1235e		4c89d9				MOVQ R11, CX													
  binary-replication.go:659	0xa12361		e89a47ffff			CALL github.com/burntcustard/unicorn-mining-co/src/server/network.prepare(SB)					
  binary-replication.go:957	0xa12366		488b942478020000		MOVQ 0x278(SP), DX												
  binary-replication.go:957	0xa1236e		488b7248			MOVQ 0x48(DX), SI												
  binary-replication.go:957	0xa12372		488bbc2440020000		MOVQ 0x240(SP), DI												
  binary-replication.go:957	0xa1237a		660f1f440000			NOPW 0(AX)(AX*1)												
  binary-replication.go:957	0xa12380		4839fe				CMPQ SI, DI													
  binary-replication.go:957	0xa12383		0f8666030000			JBE 0xa126ef													
  binary-replication.go:957	0xa12389		488b7240			MOVQ 0x40(DX), SI												
  binary-replication.go:957	0xa1238d		833dcc11830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:957	0xa12394		750d				JNE 0xa123a3													
  binary-replication.go:885	0xa12396		4c8b842490020000		MOVQ 0x290(SP), R8												
  binary-replication.go:885	0xa1239e		4d85c0				TESTQ R8, R8													
  binary-replication.go:957	0xa123a1		eb1b				JMP 0xa123be													
  binary-replication.go:957	0xa123a3		4c8b04fe			MOVQ 0(SI)(DI*8), R8												
  binary-replication.go:957	0xa123a7		e8744fa8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:957	0xa123ac		498903				MOVQ AX, 0(R11)													
  binary-replication.go:957	0xa123af		4d894308			MOVQ R8, 0x8(R11)												
  binary-replication.go:885	0xa123b3		4c8b842490020000		MOVQ 0x290(SP), R8												
  binary-replication.go:885	0xa123bb		4d85c0				TESTQ R8, R8													
  binary-replication.go:957	0xa123be		488904fe			MOVQ AX, 0(SI)(DI*8)												
  binary-replication.go:973	0xa123c2		488b8c24a8020000		MOVQ 0x2a8(SP), CX												
  binary-replication.go:1000	0xa123ca		488b9424d0010000		MOVQ 0x1d0(SP), DX												
  binary-replication.go:1000	0xa123d2		488b9c2490010000		MOVQ 0x190(SP), BX												
  binary-replication.go:1000	0xa123da		0fb6b42492000000		MOVZX 0x92(SP), SI												
  binary-replication.go:1000	0xa123e2		488bbc2478020000		MOVQ 0x278(SP), DI												
  binary-replication.go:977	0xa123ea		4c8b942488140000		MOVQ 0x1488(SP), R10												
  binary-replication.go:984	0xa123f2		4c8b9c24f00a0000		MOVQ 0xaf0(SP), R11												
  binary-replication.go:977	0xa123fa		4c8ba42440020000		MOVQ 0x240(SP), R12												
  binary-replication.go:973	0xa12402		4c8bac2418020000		MOVQ 0x218(SP), R13												
  binary-replication.go:964	0xa1240a		4d89c7				MOVQ R8, R15													
  binary-replication.go:957	0xa1240d		4989c0				MOVQ AX, R8													
  binary-replication.go:998	0xa12410		0fb7842496000000		MOVZX 0x96(SP), AX												
  binary-replication.go:963	0xa12418		744b				JE 0xa12465													
  binary-replication.go:964	0xa1241a		4d8b0f				MOVQ 0(R15), R9													
  binary-replication.go:964	0xa1241d		0f1f00				NOPL 0(AX)													
  binary-replication.go:966	0xa12420		4d39c8				CMPQ R8, R9													
  binary-replication.go:966	0xa12423		7506				JNE 0xa1242b													
  binary-replication.go:967	0xa12425		498b4f08			MOVQ 0x8(R15), CX												
  binary-replication.go:967	0xa12429		eb07				JMP 0xa12432													
  binary-replication.go:967	0xa1242b		48c7c1ffffffff			MOVQ $-0x1, CX													
  binary-replication.go:970	0xa12432		833d2711830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:970	0xa12439		7419				JE 0xa12454													
  binary-replication.go:970	0xa1243b		4d8b2f				MOVQ 0(R15), R13												
  binary-replication.go:970	0xa1243e		6690				NOPW														
  binary-replication.go:970	0xa12440		e8db4ea8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:970	0xa12445		4d8903				MOVQ R8, 0(R11)													
  binary-replication.go:970	0xa12448		4d896b08			MOVQ R13, 0x8(R11)												
  binary-replication.go:984	0xa1244c		4c8b9c24f00a0000		MOVQ 0xaf0(SP), R11												
  binary-replication.go:970	0xa12454		4d8907				MOVQ R8, 0(R15)													
  binary-replication.go:971	0xa12457		4d8b6838			MOVQ 0x38(R8), R13												
  binary-replication.go:971	0xa1245b		4d896f08			MOVQ R13, 0x8(R15)												
  binary-replication.go:971	0xa1245f		90				NOPL														
  binary-replication.go:971	0xa12460		e918010000			JMP 0xa1257d													
  binary-replication.go:957	0xa12465		4c898424a0020000		MOVQ R8, 0x2a0(SP)												
  binary-replication.go:973	0xa1246d		b820000000			MOVL $0x20, AX													
  binary-replication.go:973	0xa12472		488d1d77667500			LEAQ 0x756677(IP), BX												
  binary-replication.go:973	0xa12479		b901000000			MOVL $0x1, CX													
  binary-replication.go:973	0xa1247e		6690				NOPW														
  binary-replication.go:973	0xa12480		e8fbf3a0ff			CALL runtime.mallocgcSmallScanNoHeaderSC4(SB)									
  binary-replication.go:973	0xa12485		833dd410830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:973	0xa1248c		750a				JNE 0xa12498													
  binary-replication.go:973	0xa1248e		488b9424a0020000		MOVQ 0x2a0(SP), DX												
  binary-replication.go:973	0xa12496		eb10				JMP 0xa124a8													
  binary-replication.go:973	0xa12498		e8634ea8ff			CALL runtime.gcWriteBarrier1(SB)										
  binary-replication.go:973	0xa1249d		488b9424a0020000		MOVQ 0x2a0(SP), DX												
  binary-replication.go:973	0xa124a5		498913				MOVQ DX, 0(R11)													
  binary-replication.go:973	0xa124a8		4889842490020000		MOVQ AX, 0x290(SP)												
  binary-replication.go:973	0xa124b0		488910				MOVQ DX, 0(AX)													
  binary-replication.go:973	0xa124b3		488b5238			MOVQ 0x38(DX), DX												
  binary-replication.go:973	0xa124b7		48895008			MOVQ DX, 0x8(AX)												
  binary-replication.go:973	0xa124bb		488b942418020000		MOVQ 0x218(SP), DX												
  binary-replication.go:973	0xa124c3		48895010			MOVQ DX, 0x10(AX)												
  binary-replication.go:973	0xa124c7		488b9424a8020000		MOVQ 0x2a8(SP), DX												
  binary-replication.go:973	0xa124cf		488b7210			MOVQ 0x10(DX), SI												
  binary-replication.go:973	0xa124d3		48897018			MOVQ SI, 0x18(AX)												
  binary-replication.go:974	0xa124d7		488bb42488140000		MOVQ 0x1488(SP), SI												
  binary-replication.go:974	0xa124df		488b9ea8000000			MOVQ 0xa8(SI), BX												
  binary-replication.go:974	0xa124e6		488b4a10			MOVQ 0x10(DX), CX												
  binary-replication.go:974	0xa124ea		488d05b79d6d00			LEAQ 0x6d9db7(IP), AX												
  binary-replication.go:974	0xa124f1		e8ead39fff			CALL runtime.mapassign_fast64(SB)										
  binary-replication.go:974	0xa124f6		833d6310830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:974	0xa124fd		750a				JNE 0xa12509													
  binary-replication.go:974	0xa124ff		488bb42490020000		MOVQ 0x290(SP), SI												
  binary-replication.go:974	0xa12507		eb17				JMP 0xa12520													
  binary-replication.go:974	0xa12509		488b10				MOVQ 0(AX), DX													
  binary-replication.go:974	0xa1250c		e80f4ea8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:974	0xa12511		488bb42490020000		MOVQ 0x290(SP), SI												
  binary-replication.go:974	0xa12519		498933				MOVQ SI, 0(R11)													
  binary-replication.go:974	0xa1251c		49895308			MOVQ DX, 0x8(R11)												
  binary-replication.go:974	0xa12520		488930				MOVQ SI, 0(AX)													
  binary-replication.go:998	0xa12523		0fb7842496000000		MOVZX 0x96(SP), AX												
  binary-replication.go:1000	0xa1252b		488b9424d0010000		MOVQ 0x1d0(SP), DX												
  binary-replication.go:1000	0xa12533		488b9c2490010000		MOVQ 0x190(SP), BX												
  binary-replication.go:1000	0xa1253b		0fb6b42492000000		MOVZX 0x92(SP), SI												
  binary-replication.go:1000	0xa12543		488bbc2478020000		MOVQ 0x278(SP), DI												
  binary-replication.go:980	0xa1254b		4c8b8424a0020000		MOVQ 0x2a0(SP), R8												
  binary-replication.go:977	0xa12553		4c8b942488140000		MOVQ 0x1488(SP), R10												
  binary-replication.go:984	0xa1255b		4c8b9c24f00a0000		MOVQ 0xaf0(SP), R11												
  binary-replication.go:977	0xa12563		4c8ba42440020000		MOVQ 0x240(SP), R12												
  binary-replication.go:977	0xa1256b		4531c9				XORL R9, R9													
  binary-replication.go:977	0xa1256e		48c7c1ffffffff			MOVQ $-0x1, CX													
  binary-replication.go:973	0xa12575		4c8bbc2490020000		MOVQ 0x290(SP), R15												
  binary-replication.go:977	0xa1257d		4d8baab8000000			MOVQ 0xb8(R10), R13												
  binary-replication.go:977	0xa12584		4d39e5				CMPQ R13, R12													
  binary-replication.go:977	0xa12587		0f865d010000			JBE 0xa126ea													
  binary-replication.go:977	0xa1258d		4d8baab0000000			MOVQ 0xb0(R10), R13												
  binary-replication.go:980	0xa12594		4d39c1				CMPQ R9, R8													
  binary-replication.go:981	0xa12597		ba00000000			MOVL $0x0, DX													
  binary-replication.go:981	0xa1259c		4c0f44ca			CMOVE DX, R9													
  binary-replication.go:977	0xa125a0		833db90f830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:977	0xa125a7		7419				JE 0xa125c2													
  binary-replication.go:977	0xa125a9		4b8b54e500			MOVQ 0(R13)(R12*8), DX												
  binary-replication.go:977	0xa125ae		e86d4da8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:977	0xa125b3		4d893b				MOVQ R15, 0(R11)												
  binary-replication.go:977	0xa125b6		49895308			MOVQ DX, 0x8(R11)												
  binary-replication.go:984	0xa125ba		4c8b9c24f00a0000		MOVQ 0xaf0(SP), R11												
  binary-replication.go:977	0xa125c2		4f897ce500			MOVQ R15, 0(R13)(R12*8)												
  binary-replication.go:984	0xa125c7		4c89d8				MOVQ R11, AX													
  binary-replication.go:984	0xa125ca		4c89c3				MOVQ R8, BX													
  binary-replication.go:984	0xa125cd		4c89cf				MOVQ R9, DI													
  binary-replication.go:984	0xa125d0		e8abbeffff			CALL github.com/burntcustard/unicorn-mining-co/src/server/network.(*BinarySnapshotBatch).fragment(SB)		
  binary-replication.go:984	0xa125d5		84c9				TESTL CL, CL													
  binary-replication.go:980	0xa125d7		0f84a5000000			JE 0xa12682													
  binary-replication.go:985	0xa125dd		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:985	0xa125e5		488b8a88000000			MOVQ 0x88(DX), CX												
  binary-replication.go:985	0xa125ec		4c8ba280000000			MOVQ 0x80(DX), R12												
  binary-replication.go:985	0xa125f3		49ffc4				INCQ R12													
  binary-replication.go:985	0xa125f6		4c8b6a78			MOVQ 0x78(DX), R13												
  binary-replication.go:985	0xa125fa		4c39e1				CMPQ CX, R12													
  binary-replication.go:985	0xa125fd		7369				JAE 0xa12668													
  binary-replication.go:984	0xa125ff		4889842440020000		MOVQ AX, 0x240(SP)												
  binary-replication.go:984	0xa12607		48899c2438020000		MOVQ BX, 0x238(SP)												
  binary-replication.go:985	0xa1260f		4c89e8				MOVQ R13, AX													
  binary-replication.go:985	0xa12612		4c89e3				MOVQ R12, BX													
  binary-replication.go:985	0xa12615		bf01000000			MOVL $0x1, DI													
  binary-replication.go:985	0xa1261a		488d35dfb67300			LEAQ 0x73b6df(IP), SI												
  binary-replication.go:985	0xa12621		e85a00a8ff			CALL runtime.growslice(SB)											
  binary-replication.go:985	0xa12626		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:985	0xa1262e		48898a88000000			MOVQ CX, 0x88(DX)												
  binary-replication.go:985	0xa12635		833d240f830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:985	0xa1263c		7410				JE 0xa1264e													
  binary-replication.go:985	0xa1263e		4c8b6278			MOVQ 0x78(DX), R12												
  binary-replication.go:985	0xa12642		e8d94ca8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:985	0xa12647		498903				MOVQ AX, 0(R11)													
  binary-replication.go:985	0xa1264a		4d896308			MOVQ R12, 0x8(R11)												
  binary-replication.go:985	0xa1264e		48894278			MOVQ AX, 0x78(DX)												
  binary-replication.go:985	0xa12652		4989dc				MOVQ BX, R12													
  binary-replication.go:985	0xa12655		4989c5				MOVQ AX, R13													
  binary-replication.go:985	0xa12658		488b842440020000		MOVQ 0x240(SP), AX												
  binary-replication.go:985	0xa12660		488b9c2438020000		MOVQ 0x238(SP), BX												
  binary-replication.go:985	0xa12668		4c89a280000000			MOVQ R12, 0x80(DX)												
  binary-replication.go:985	0xa1266f		49ffcc				DECQ R12													
  binary-replication.go:985	0xa12672		49c1e404			SHLQ $0x4, R12													
  binary-replication.go:985	0xa12676		4b89442500			MOVQ AX, 0(R13)(R12*1)												
  binary-replication.go:985	0xa1267b		4b895c2508			MOVQ BX, 0x8(R13)(R12*1)											
  binary-replication.go:985	0xa12680		eb08				JMP 0xa1268a													
  binary-replication.go:877	0xa12682		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:998	0xa1268a		0fb7842496000000		MOVZX 0x96(SP), AX												
  binary-replication.go:1000	0xa12692		488b9c2490010000		MOVQ 0x190(SP), BX												
  binary-replication.go:1000	0xa1269a		488bbc2478020000		MOVQ 0x278(SP), DI												
  binary-replication.go:872	0xa126a2		4c8b842498000000		MOVQ 0x98(SP), R8												
  binary-replication.go:872	0xa126aa		4c8b8c2450020000		MOVQ 0x250(SP), R9												
  binary-replication.go:877	0xa126b2		4989d2				MOVQ DX, R10													
  binary-replication.go:877	0xa126b5		4c8b9c2420020000		MOVQ 0x220(SP), R11												
  binary-replication.go:1000	0xa126bd		488b9424d0010000		MOVQ 0x1d0(SP), DX												
  binary-replication.go:1000	0xa126c5		0fb6b42492000000		MOVZX 0x92(SP), SI												
  binary-replication.go:997	0xa126cd		e9d2f8ffff			JMP 0xa11fa4													
  binary-replication.go:1006	0xa126d2		4d89ec				MOVQ R13, R12													
  binary-replication.go:1006	0xa126d5		4c8b9c2460010000		MOVQ 0x160(SP), R11												
  binary-replication.go:1006	0xa126dd		4c8bac2440020000		MOVQ 0x240(SP), R13												
  binary-replication.go:994	0xa126e5		e9accfffff			JMP 0xa0f696													
  binary-replication.go:977	0xa126ea		e8d14fa8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:957	0xa126ef		e8cc4fa8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:953	0xa126f4		e8c74fa8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:953	0xa126f9		0f1f8000000000			NOPL 0(AX)													
  slices.go:97			0xa12700		49ffc5				INCQ R13													
  binary-replication.go:973	0xa12703		488b8c24a8020000		MOVQ 0x2a8(SP), CX												
  slices.go:97			0xa1270b		4d39cd				CMPQ R13, R9													
  slices.go:97			0xa1270e		7d13				JGE 0xa12723													
  slices.go:98			0xa12710		4b8b0ce8			MOVQ 0(R8)(R13*8), CX												
  slices.go:98			0xa12714		4c39d9				CMPQ CX, R11													
  slices.go:98			0xa12717		75e7				JNE 0xa12700													
  binary-replication.go:973	0xa12719		488b8c24a8020000		MOVQ 0x2a8(SP), CX												
  slices.go:118			0xa12721		eb07				JMP 0xa1272a													
  slices.go:118			0xa12723		49c7c5ffffffff			MOVQ $-0x1, R13													
  slices.go:118			0xa1272a		4d85ed				TESTQ R13, R13													
  binary-replication.go:914	0xa1272d		0f8d12020000			JGE 0xa12945													
  binary-replication.go:842	0xa12733		440fb66c2476			MOVZX 0x76(SP), R13												
  binary-replication.go:842	0xa12739		0f1f8000000000			NOPL 0(AX)													
  binary-replication.go:842	0xa12740		4584ed				TESTL R13, R13													
  binary-replication.go:915	0xa12743		0f84c0000000			JE 0xa12809													
  binary-replication.go:919	0xa12749		f20f10ac24a0000000		MOVSD_XMM 0xa0(SP), X5												
  binary-replication.go:919	0xa12752		660f2eec			UCOMISD X4, X5													
  binary-replication.go:919	0xa12756		7210				JB 0xa12768													
  binary-replication.go:920	0xa12758		4c8b842498010000		MOVQ 0x198(SP), R8												
  binary-replication.go:920	0xa12760		440fb64c2474			MOVZX 0x74(SP), R9												
  binary-replication.go:921	0xa12766		eb0e				JMP 0xa12776													
  binary-replication.go:920	0xa12768		4c8b8424a0010000		MOVQ 0x1a0(SP), R8												
  binary-replication.go:920	0xa12770		440fb64c2479			MOVZX 0x79(SP), R9												
  binary-replication.go:924	0xa12776		4c8b5f60			MOVQ 0x60(DI), R11												
  binary-replication.go:924	0xa1277a		660f1f440000			NOPW 0(AX)(AX*1)												
  binary-replication.go:924	0xa12780		4d39e3				CMPQ R11, R12													
  binary-replication.go:924	0xa12783		0f86e6010000			JBE 0xa1296f													
  binary-replication.go:924	0xa12789		4c8b5f58			MOVQ 0x58(DI), R11												
  binary-replication.go:924	0xa1278d		4f8b1ce3			MOVQ 0(R11)(R12*8), R11												
  binary-replication.go:924	0xa12791		4983fb01			CMPQ R11, $0x1													
  binary-replication.go:924	0xa12795		7e4c				JLE 0xa127e3													
  binary-replication.go:925	0xa12797		4c8b4f78			MOVQ 0x78(DI), R9												
  binary-replication.go:925	0xa1279b		0f1f440000			NOPL 0(AX)(AX*1)												
  binary-replication.go:925	0xa127a0		4d39e1				CMPQ R9, R12													
  binary-replication.go:925	0xa127a3		0f86c1010000			JBE 0xa1296a													
  binary-replication.go:925	0xa127a9		4c8b4f70			MOVQ 0x70(DI), R9												
  binary-replication.go:925	0xa127ad		4f8b0ce1			MOVQ 0(R9)(R12*8), R9												
  binary-replication.go:925	0xa127b1		4d85c9				TESTQ R9, R9													
  binary-replication.go:925	0xa127b4		0f8cab010000			JL 0xa12965													
  binary-replication.go:873	0xa127ba		4989cb				MOVQ CX, R11													
  binary-replication.go:925	0xa127bd		4c89c9				MOVQ R9, CX													
  binary-replication.go:925	0xa127c0		41bd01000000			MOVL $0x1, R13													
  binary-replication.go:925	0xa127c6		49d3e5				SHLQ CL, R13													
  binary-replication.go:925	0xa127c9		4883f940			CMPQ CX, $0x40													
  binary-replication.go:925	0xa127cd		4819c9				SBBQ CX, CX													
  binary-replication.go:925	0xa127d0		4921cd				ANDQ CX, R13													
  binary-replication.go:925	0xa127d3		4d85c5				TESTQ R8, R13													
  binary-replication.go:925	0xa127d6		410f95c1			SETNE R9													
  binary-replication.go:973	0xa127da		4c89d9				MOVQ R11, CX													
  binary-replication.go:842	0xa127dd		440fb66c2476			MOVZX 0x76(SP), R13												
  binary-replication.go:925	0xa127e3		4584c9				TESTL R9, R9													
  binary-replication.go:928	0xa127e6		0f854c010000			JNE 0xa12938													
  binary-replication.go:872	0xa127ec		4c8b842498000000		MOVQ 0x98(SP), R8												
  binary-replication.go:872	0xa127f4		4c8b8c2450020000		MOVQ 0x250(SP), R9												
  binary-replication.go:877	0xa127fc		4c8b9c2420020000		MOVQ 0x220(SP), R11												
  binary-replication.go:1000	0xa12804		e99bf7ffff			JMP 0xa11fa4													
  binary-replication.go:940	0xa12809		4c8b4760			MOVQ 0x60(DI), R8												
  binary-replication.go:934	0xa1280d		f20f10ac24a0000000		MOVSD_XMM 0xa0(SP), X5												
  binary-replication.go:934	0xa12816		660f2eec			UCOMISD X4, X5													
  binary-replication.go:935	0xa1281a		4c8bac2478010000		MOVQ 0x178(SP), R13												
  binary-replication.go:882	0xa12822		4d89fb				MOVQ R15, R11													
  binary-replication.go:935	0xa12825		4c8bbc24a8000000		MOVQ 0xa8(SP), R15												
  binary-replication.go:935	0xa1282d		4d0f43ef			CMOVAE R15, R13													
  binary-replication.go:940	0xa12831		4d39e0				CMPQ R8, R12													
  binary-replication.go:934	0xa12834		0f8622010000			JBE 0xa1295c													
  binary-replication.go:940	0xa1283a		4c8b4758			MOVQ 0x58(DI), R8												
  binary-replication.go:940	0xa1283e		4f8b04e0			MOVQ 0(R8)(R12*8), R8												
  binary-replication.go:940	0xa12842		4983f801			CMPQ R8, $0x1													
  binary-replication.go:940	0xa12846		7e2e				JLE 0xa12876													
  binary-replication.go:941	0xa12848		4d8b8238070000			MOVQ 0x738(R10), R8												
  binary-replication.go:942	0xa1284f		4c8b7f78			MOVQ 0x78(DI), R15												
  binary-replication.go:941	0xa12853		4d39e8				CMPQ R8, R13													
  binary-replication.go:941	0xa12856		4d0f4fe8			CMOVG R8, R13													
  binary-replication.go:941	0xa1285a		660f1f440000			NOPW 0(AX)(AX*1)												
  binary-replication.go:942	0xa12860		4d39e7				CMPQ R15, R12													
  binary-replication.go:941	0xa12863		0f86ee000000			JBE 0xa12957													
  binary-replication.go:942	0xa12869		4c8b7f70			MOVQ 0x70(DI), R15												
  binary-replication.go:942	0xa1286d		4f8b3ce7			MOVQ 0(R15)(R12*8), R15												
  binary-replication.go:942	0xa12871		4d89f8				MOVQ R15, R8													
  binary-replication.go:942	0xa12874		eb03				JMP 0xa12879													
  binary-replication.go:942	0xa12876		4531c0				XORL R8, R8													
  binary-replication.go:945	0xa12879		4c8bbc2458020000		MOVQ 0x258(SP), R15												
  binary-replication.go:945	0xa12881		4d8bbf88010000			MOVQ 0x188(R15), R15												
  binary-replication.go:945	0xa12888		4d8b0a				MOVQ 0(R10), R9													
  binary-replication.go:945	0xa1288b		4d01c7				ADDQ R8, R15													
  binary-replication.go:945	0xa1288e		4d01c8				ADDQ R9, R8													
  binary-replication.go:1089	0xa12891		4983fd01			CMPQ R13, $0x1													
  binary-replication.go:1089	0xa12895		0f8494000000			JE 0xa1292f													
  binary-replication.go:1089	0xa1289b		0f1f440000			NOPL 0(AX)(AX*1)												
  binary-replication.go:1093	0xa128a0		4d85ed				TESTQ R13, R13													
  binary-replication.go:1093	0xa128a3		7e2b				JLE 0xa128d0													
  binary-replication.go:1093	0xa128a5		4d8d4dff			LEAQ -0x1(R13), R9												
  binary-replication.go:1093	0xa128a9		4d85e9				TESTQ R13, R9													
  binary-replication.go:1093	0xa128ac		751f				JNE 0xa128cd													
  binary-replication.go:1095	0xa128ae		4d85cf				TESTQ R9, R15													
  binary-replication.go:1095	0xa128b1		7508				JNE 0xa128bb													
  binary-replication.go:1095	0xa128b3		41bd01000000			MOVL $0x1, R13													
  binary-replication.go:1095	0xa128b9		eb52				JMP 0xa1290d													
  binary-replication.go:1095	0xa128bb		49f7dd				NEGQ R13													
  binary-replication.go:1095	0xa128be		4d21ef				ANDQ R13, R15													
  binary-replication.go:1095	0xa128c1		4d21e8				ANDQ R13, R8													
  binary-replication.go:1095	0xa128c4		4d39f8				CMPQ R8, R15													
  binary-replication.go:1095	0xa128c7		410f95c5			SETNE R13													
  binary-replication.go:1095	0xa128cb		eb40				JMP 0xa1290d													
  binary-replication.go:1093	0xa128cd		4d85ed				TESTQ R13, R13													
  binary-replication.go:1098	0xa128d0		0f847c000000			JE 0xa12952													
  binary-replication.go:999	0xa128d6		4189c1				MOVL AX, R9													
  binary-replication.go:1098	0xa128d9		4c89f8				MOVQ R15, AX													
  binary-replication.go:909	0xa128dc		4989d7				MOVQ DX, R15													
  binary-replication.go:1098	0xa128df		31d2				XORL DX, DX													
  binary-replication.go:1098	0xa128e1		49f7f5				DIVQ R13													
  binary-replication.go:1098	0xa128e4		4885d2				TESTQ DX, DX													
  binary-replication.go:1098	0xa128e7		7507				JNE 0xa128f0													
  binary-replication.go:1098	0xa128e9		ba01000000			MOVL $0x1, DX													
  binary-replication.go:1098	0xa128ee		eb14				JMP 0xa12904													
  binary-replication.go:1098	0xa128f0		4889c2				MOVQ AX, DX													
  binary-replication.go:1098	0xa128f3		4c89c0				MOVQ R8, AX													
  binary-replication.go:1098	0xa128f6		4989d0				MOVQ DX, R8													
  binary-replication.go:1098	0xa128f9		31d2				XORL DX, DX													
  binary-replication.go:1098	0xa128fb		49f7f5				DIVQ R13													
  binary-replication.go:1098	0xa128fe		4c39c0				CMPQ AX, R8													
  binary-replication.go:1098	0xa12901		0f95c2				SETNE DL													
  binary-replication.go:998	0xa12904		4489c8				MOVL R9, AX													
  binary-replication.go:947	0xa12907		4189d5				MOVL DX, R13													
  binary-replication.go:1000	0xa1290a		4c89fa				MOVQ R15, DX													
  binary-replication.go:947	0xa1290d		4584ed				TESTL R13, R13													
  binary-replication.go:947	0xa12910		751d				JNE 0xa1292f													
  binary-replication.go:872	0xa12912		4c8b842498000000		MOVQ 0x98(SP), R8												
  binary-replication.go:872	0xa1291a		4c8b8c2450020000		MOVQ 0x250(SP), R9												
  binary-replication.go:877	0xa12922		4c8b9c2420020000		MOVQ 0x220(SP), R11												
  binary-replication.go:1000	0xa1292a		e975f6ffff			JMP 0xa11fa4													
  binary-replication.go:842	0xa1292f		440fb66c2476			MOVZX 0x76(SP), R13												
  binary-replication.go:885	0xa12935		4d89df				MOVQ R11, R15													
  binary-replication.go:973	0xa12938		4c8bac2418020000		MOVQ 0x218(SP), R13												
  binary-replication.go:973	0xa12940		e9b9f9ffff			JMP 0xa122fe													
  binary-replication.go:973	0xa12945		4c8bac2418020000		MOVQ 0x218(SP), R13												
  binary-replication.go:914	0xa1294d		e9acf9ffff			JMP 0xa122fe													
  binary-replication.go:1098	0xa12952		e809d8a3ff			CALL runtime.panicdivide(SB)											
  binary-replication.go:942	0xa12957		e8644da8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:940	0xa1295c		0f1f4000			NOPL 0(AX)													
  binary-replication.go:940	0xa12960		e85b4da8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:925	0xa12965		e896d7a3ff			CALL runtime.panicshift(SB)											
  binary-replication.go:925	0xa1296a		e8514da8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:924	0xa1296f		e84c4da8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:908	0xa12974		e8474da8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:877	0xa12979		e8424da8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:874	0xa1297e		6690				NOPW														
  binary-replication.go:874	0xa12980		e83b4da8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:873	0xa12985		e8364da8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:872	0xa1298a		e8314da8ff			CALL runtime.panicBounds(SB)											
  replication-simd.go:28	0xa1298f		488bb8b8000000			MOVQ 0xb8(AX), DI												
  replication-simd.go:28	0xa12996		488b7610			MOVQ 0x10(SI), SI												
  replication-simd.go:28	0xa1299a		4a8934ff			MOVQ SI, 0(DI)(R15*8)												
  replication-simd.go:27	0xa1299e		49ffc7				INCQ R15													
  binary-replication.go:920	0xa129a1		0fb6742479			MOVZX 0x79(SP), SI												
  binary-replication.go:920	0xa129a6		0fb67c2474			MOVZX 0x74(SP), DI												
  replication-simd.go:27	0xa129ab		4939df				CMPQ R15, BX													
  replication-simd.go:27	0xa129ae		7d17				JGE 0xa129c7													
  replication-simd.go:27	0xa129b0		4b8b74fd00			MOVQ 0(R13)(R15*8), SI												
  replication-simd.go:28	0xa129b5		8406				TESTB AL, 0(SI)													
  replication-simd.go:28	0xa129b7		488bb8c0000000			MOVQ 0xc0(AX), DI												
  replication-simd.go:28	0xa129be		6690				NOPW														
  replication-simd.go:28	0xa129c0		4939ff				CMPQ R15, DI													
  replication-simd.go:28	0xa129c3		72ca				JB 0xa1298f													
  replication-simd.go:28	0xa129c5		eb18				JMP 0xa129df													
  binary-replication.go:865	0xa129c7		4584db				TESTL R11, R11													
  binary-replication.go:920	0xa129ca		488b9c24a0010000		MOVQ 0x1a0(SP), BX												
  binary-replication.go:1019	0xa129d2		4c8bbc2458020000		MOVQ 0x258(SP), R15												
  replication-simd.go:27	0xa129da		e966ccffff			JMP 0xa0f645													
  replication-simd.go:28	0xa129df		90				NOPL														
  replication-simd.go:28	0xa129e0		e8db4ca8ff			CALL runtime.panicBounds(SB)											
  replication-simd.go:25	0xa129e5		e8d64ca8ff			CALL runtime.panicBounds(SB)											
  replication-simd.go:25	0xa129ea		660f1f840000000000		NOPW 0(AX)(AX*1)												
  replication-simd.go:25	0xa129f3		660f1f840000000000		NOPW 0(AX)(AX*1)												
  replication-simd.go:25	0xa129fc		0f1f4000			NOPL 0(AX)													
  binary-replication.go:848	0xa12a00		4c8d6901			LEAQ 0x1(CX), R13												
  binary-replication.go:864	0xa12a04		488b842478020000		MOVQ 0x278(SP), AX												
  binary-replication.go:842	0xa12a0c		0fb64c2476			MOVZX 0x76(SP), CX												
  binary-replication.go:851	0xa12a11		4c8b8c24a8000000		MOVQ 0xa8(SP), R9												
  binary-replication.go:877	0xa12a19		4c8b9c2488140000		MOVQ 0x1488(SP), R11												
  binary-replication.go:855	0xa12a21		4c8ba42478010000		MOVQ 0x178(SP), R12												
  binary-replication.go:848	0xa12a29		4939f5				CMPQ R13, SI													
  binary-replication.go:848	0xa12a2c		0f8d62010000			JGE 0xa12b94													
  binary-replication.go:848	0xa12a32		4c89bc24a0010000		MOVQ R15, 0x1a0(SP)												
  binary-replication.go:849	0xa12a3a		498d4c1d00			LEAQ 0(R13)(BX*1), CX												
  binary-replication.go:849	0xa12a3f		4d8d5c3d00			LEAQ 0(R13)(DI*1), R11												
  binary-replication.go:851	0xa12a44		4c39ce				CMPQ SI, R9													
  binary-replication.go:851	0xa12a47		4c0f4fce			CMOVG SI, R9													
  binary-replication.go:1089	0xa12a4b		4983f901			CMPQ R9, $0x1													
  binary-replication.go:851	0xa12a4f		747a				JE 0xa12acb													
  binary-replication.go:1093	0xa12a51		498d41ff			LEAQ -0x1(R9), AX												
  binary-replication.go:1093	0xa12a55		4c85c8				TESTQ R9, AX													
  binary-replication.go:1093	0xa12a58		7529				JNE 0xa12a83													
  binary-replication.go:1095	0xa12a5a		4885c1				TESTQ AX, CX													
  binary-replication.go:1095	0xa12a5d		7507				JNE 0xa12a66													
  binary-replication.go:1095	0xa12a5f		b801000000			MOVL $0x1, AX													
  binary-replication.go:1095	0xa12a64		eb61				JMP 0xa12ac7													
  binary-replication.go:1095	0xa12a66		49f7d9				NEGQ R9														
  binary-replication.go:1095	0xa12a69		4889c8				MOVQ CX, AX													
  binary-replication.go:1095	0xa12a6c		4c21c9				ANDQ R9, CX													
  binary-replication.go:1095	0xa12a6f		4d21d9				ANDQ R11, R9													
  binary-replication.go:1095	0xa12a72		4939c9				CMPQ R9, CX													
  binary-replication.go:1095	0xa12a75		0f95c1				SETNE CL													
  binary-replication.go:1095	0xa12a78		4189c9				MOVL CX, R9													
  binary-replication.go:1095	0xa12a7b		4889c1				MOVQ AX, CX													
  binary-replication.go:1095	0xa12a7e		4489c8				MOVL R9, AX													
  binary-replication.go:1095	0xa12a81		eb44				JMP 0xa12ac7													
  binary-replication.go:848	0xa12a83		4889942498010000		MOVQ DX, 0x198(SP)												
  binary-replication.go:1098	0xa12a8b		4889c8				MOVQ CX, AX													
  binary-replication.go:1098	0xa12a8e		31d2				XORL DX, DX													
  binary-replication.go:1098	0xa12a90		49f7f1				DIVQ R9														
  binary-replication.go:1098	0xa12a93		4885d2				TESTQ DX, DX													
  binary-replication.go:1098	0xa12a96		7507				JNE 0xa12a9f													
  binary-replication.go:1098	0xa12a98		ba01000000			MOVL $0x1, DX													
  binary-replication.go:1098	0xa12a9d		eb1e				JMP 0xa12abd													
  binary-replication.go:1098	0xa12a9f		48898424f8010000		MOVQ AX, 0x1f8(SP)												
  binary-replication.go:1098	0xa12aa7		4c89d8				MOVQ R11, AX													
  binary-replication.go:1098	0xa12aaa		31d2				XORL DX, DX													
  binary-replication.go:1098	0xa12aac		49f7f1				DIVQ R9														
  binary-replication.go:1098	0xa12aaf		488b9424f8010000		MOVQ 0x1f8(SP), DX												
  binary-replication.go:1098	0xa12ab7		4839d0				CMPQ AX, DX													
  binary-replication.go:1098	0xa12aba		0f95c2				SETNE DL													
  binary-replication.go:851	0xa12abd		89d0				MOVL DX, AX													
  binary-replication.go:852	0xa12abf		488b942498010000		MOVQ 0x198(SP), DX												
  binary-replication.go:851	0xa12ac7		84c0				TESTL AL, AL													
  binary-replication.go:851	0xa12ac9		7427				JE 0xa12af2													
  binary-replication.go:849	0xa12acb		4989c9				MOVQ CX, R9													
  binary-replication.go:852	0xa12ace		4c89e9				MOVQ R13, CX													
  binary-replication.go:852	0xa12ad1		41bf01000000			MOVL $0x1, R15													
  binary-replication.go:852	0xa12ad7		49d3e7				SHLQ CL, R15													
  binary-replication.go:852	0xa12ada		4883f940			CMPQ CX, $0x40													
  binary-replication.go:852	0xa12ade		4819c0				SBBQ AX, AX													
  binary-replication.go:852	0xa12ae1		4921c7				ANDQ AX, R15													
  binary-replication.go:852	0xa12ae4		4c09fa				ORQ R15, DX													
  binary-replication.go:1095	0xa12ae7		4c89c9				MOVQ R9, CX													
  binary-replication.go:856	0xa12aea		4c8bbc24a0010000		MOVQ 0x1a0(SP), R15												
  binary-replication.go:855	0xa12af2		4c39e6				CMPQ SI, R12													
  binary-replication.go:855	0xa12af5		4c89e0				MOVQ R12, AX													
  binary-replication.go:855	0xa12af8		4c0f4fe6			CMOVG SI, R12													
  binary-replication.go:855	0xa12afc		0f1f4000			NOPL 0(AX)													
  binary-replication.go:1089	0xa12b00		4983fc01			CMPQ R12, $0x1													
  binary-replication.go:855	0xa12b04		7468				JE 0xa12b6e													
  binary-replication.go:1093	0xa12b06		4d8d4c24ff			LEAQ -0x1(R12), R9												
  binary-replication.go:1093	0xa12b0b		4d85e1				TESTQ R12, R9													
  binary-replication.go:1093	0xa12b0e		751f				JNE 0xa12b2f													
  binary-replication.go:1095	0xa12b10		4c85c9				TESTQ R9, CX													
  binary-replication.go:1095	0xa12b13		7508				JNE 0xa12b1d													
  binary-replication.go:1095	0xa12b15		41bc01000000			MOVL $0x1, R12													
  binary-replication.go:1095	0xa12b1b		eb4c				JMP 0xa12b69													
  binary-replication.go:1095	0xa12b1d		49f7dc				NEGQ R12													
  binary-replication.go:1095	0xa12b20		4c21e1				ANDQ R12, CX													
  binary-replication.go:1095	0xa12b23		4d21dc				ANDQ R11, R12													
  binary-replication.go:1095	0xa12b26		4939cc				CMPQ R12, CX													
  binary-replication.go:1095	0xa12b29		410f95c4			SETNE R12													
  binary-replication.go:1095	0xa12b2d		eb3a				JMP 0xa12b69													
  binary-replication.go:837	0xa12b2f		4989c1				MOVQ AX, R9													
  binary-replication.go:1098	0xa12b32		4889c8				MOVQ CX, AX													
  binary-replication.go:852	0xa12b35		4889d1				MOVQ DX, CX													
  binary-replication.go:1098	0xa12b38		31d2				XORL DX, DX													
  binary-replication.go:1098	0xa12b3a		49f7f4				DIVQ R12													
  binary-replication.go:1098	0xa12b3d		0f1f00				NOPL 0(AX)													
  binary-replication.go:1098	0xa12b40		4885d2				TESTQ DX, DX													
  binary-replication.go:1098	0xa12b43		7507				JNE 0xa12b4c													
  binary-replication.go:1098	0xa12b45		ba01000000			MOVL $0x1, DX													
  binary-replication.go:1098	0xa12b4a		eb14				JMP 0xa12b60													
  binary-replication.go:1098	0xa12b4c		4889c2				MOVQ AX, DX													
  binary-replication.go:1098	0xa12b4f		4c89d8				MOVQ R11, AX													
  binary-replication.go:1098	0xa12b52		4989d3				MOVQ DX, R11													
  binary-replication.go:1098	0xa12b55		31d2				XORL DX, DX													
  binary-replication.go:1098	0xa12b57		49f7f4				DIVQ R12													
  binary-replication.go:1098	0xa12b5a		4c39d8				CMPQ AX, R11													
  binary-replication.go:1098	0xa12b5d		0f95c2				SETNE DL													
  binary-replication.go:855	0xa12b60		4c89c8				MOVQ R9, AX													
  binary-replication.go:855	0xa12b63		4189d4				MOVL DX, R12													
  binary-replication.go:848	0xa12b66		4889ca				MOVQ CX, DX													
  binary-replication.go:855	0xa12b69		4584e4				TESTL R12, R12													
  binary-replication.go:855	0xa12b6c		741e				JE 0xa12b8c													
  binary-replication.go:856	0xa12b6e		4c89e9				MOVQ R13, CX													
  binary-replication.go:856	0xa12b71		41bc01000000			MOVL $0x1, R12													
  binary-replication.go:856	0xa12b77		49d3e4				SHLQ CL, R12													
  binary-replication.go:856	0xa12b7a		4883f940			CMPQ CX, $0x40													
  binary-replication.go:856	0xa12b7e		4d19c9				SBBQ R9, R9													
  binary-replication.go:856	0xa12b81		4d21cc				ANDQ R9, R12													
  binary-replication.go:856	0xa12b84		4d09e7				ORQ R12, R15													
  binary-replication.go:856	0xa12b87		e974feffff			JMP 0xa12a00													
  binary-replication.go:848	0xa12b8c		4c89e9				MOVQ R13, CX													
  binary-replication.go:855	0xa12b8f		e96cfeffff			JMP 0xa12a00													
  binary-replication.go:842	0xa12b94		4189cd				MOVL CX, R13													
  binary-replication.go:842	0xa12b97		4889d1				MOVQ DX, CX													
  binary-replication.go:842	0xa12b9a		4c89fb				MOVQ R15, BX													
  binary-replication.go:842	0xa12b9d		4489d6				MOVL R10, SI													
  binary-replication.go:842	0xa12ba0		4489c7				MOVL R8, DI													
  binary-replication.go:877	0xa12ba3		4c89da				MOVQ R11, DX													
  binary-replication.go:861	0xa12ba6		4c8bbc2418010000		MOVQ 0x118(SP), R15												
  binary-replication.go:861	0xa12bae		e965c8ffff			JMP 0xa0f418													
  binary-replication.go:1098	0xa12bb3		e8a8d5a3ff			CALL runtime.panicdivide(SB)											
  binary-replication.go:1098	0xa12bb8		e8a3d5a3ff			CALL runtime.panicdivide(SB)											
  binary-replication.go:1098	0xa12bbd		0f1f00				NOPL 0(AX)													
  binary-replication.go:819	0xa12bc0		49ffc3				INCQ R11													
  binary-replication.go:819	0xa12bc3		4d39d3				CMPQ R11, R10													
  binary-replication.go:819	0xa12bc6		0f8dc8010000			JGE 0xa12d94													
  binary-replication.go:820	0xa12bcc		4c8ba690000000			MOVQ 0x90(SI), R12												
  binary-replication.go:819	0xa12bd3		4f8b2cd9			MOVQ 0(R9)(R11*8), R13												
  binary-replication.go:819	0xa12bd7		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-replication.go:820	0xa12be0		4d39e3				CMPQ R11, R12													
  binary-replication.go:820	0xa12be3		0f83ce020000			JAE 0xa12eb7													
  binary-replication.go:820	0xa12be9		4c8ba688000000			MOVQ 0x88(SI), R12												
  binary-replication.go:820	0xa12bf0		f2430f101cdc			MOVSD_XMM 0(R12)(R11*8), X3											
  binary-replication.go:820	0xa12bf6		4c8ba6a8000000			MOVQ 0xa8(SI), R12												
  binary-replication.go:820	0xa12bfd		f20f5cd9			SUBSD X1, X3													
  binary-replication.go:820	0xa12c01		4d39e3				CMPQ R11, R12													
  binary-replication.go:820	0xa12c04		0f83a8020000			JAE 0xa12eb2													
  binary-replication.go:820	0xa12c0a		4c8ba6a0000000			MOVQ 0xa0(SI), R12												
  binary-replication.go:820	0xa12c11		f2430f1024dc			MOVSD_XMM 0(R12)(R11*8), X4											
  binary-replication.go:820	0xa12c17		f20f5ce2			SUBSD X2, X4													
  binary-replication.go:822	0xa12c1b		4983bd8800000008		CMPQ 0x88(R13), $0x8												
  binary-replication.go:822	0xa12c23		0f855c010000			JNE 0xa12d85													
  binary-replication.go:822	0xa12c29		4d8ba580000000			MOVQ 0x80(R13), R12												
  binary-replication.go:822	0xa12c30		49bf61737465726f6964		MOVQ $0x64696f7265747361, R15											
  binary-replication.go:822	0xa12c3a		660f1f440000			NOPW 0(AX)(AX*1)												
  binary-replication.go:822	0xa12c40		4d393c24			CMPQ 0(R12), R15												
  binary-replication.go:822	0xa12c44		0f8576ffffff			JNE 0xa12bc0													
  binary-replication.go:822	0xa12c4a		4180bd9100000000		CMPB 0x91(R13), $0x0												
  binary-replication.go:822	0xa12c52		0f8568ffffff			JNE 0xa12bc0													
  binary-replication.go:822	0xa12c58		4180bd9200000000		CMPB 0x92(R13), $0x0												
  binary-replication.go:822	0xa12c60		0f855affffff			JNE 0xa12bc0													
  binary-replication.go:822	0xa12c66		f20f59db			MULSD X3, X3													
  binary-replication.go:822	0xa12c6a		f20f59e4			MULSD X4, X4													
  binary-replication.go:822	0xa12c6e		f20f58e3			ADDSD X3, X4													
  binary-replication.go:822	0xa12c72		660f2ec4			UCOMISD X4, X0													
  binary-replication.go:822	0xa12c76		0f8244ffffff			JB 0xa12bc0													
  binary-replication.go:823	0xa12c7c		498b4840			MOVQ 0x40(R8), CX												
  binary-replication.go:823	0xa12c80		498b5838			MOVQ 0x38(R8), BX												
  binary-replication.go:823	0xa12c84		48ffc3				INCQ BX														
  binary-replication.go:823	0xa12c87		498b4030			MOVQ 0x30(R8), AX												
  binary-replication.go:823	0xa12c8b		f2410f105d18			MOVSD_XMM 0x18(R13), X3												
  binary-replication.go:823	0xa12c91		f2410f106520			MOVSD_XMM 0x20(R13), X4												
  binary-replication.go:823	0xa12c97		660f1f840000000000		NOPW 0(AX)(AX*1)												
  binary-replication.go:823	0xa12ca0		4839d9				CMPQ CX, BX													
  binary-replication.go:823	0xa12ca3		0f83bb000000			JAE 0xa12d64													
  binary-replication.go:823	0xa12ca9		f20f11a424c8010000		MOVSD_XMM X4, 0x1c8(SP)												
  binary-replication.go:823	0xa12cb2		f20f119c24c0010000		MOVSD_XMM X3, 0x1c0(SP)												
  binary-replication.go:819	0xa12cbb		4c899c2450010000		MOVQ R11, 0x150(SP)												
  binary-replication.go:823	0xa12cc3		bf01000000			MOVL $0x1, DI													
  binary-replication.go:823	0xa12cc8		488d3521ea7300			LEAQ 0x73ea21(IP), SI												
  binary-replication.go:823	0xa12ccf		e8acf9a7ff			CALL runtime.growslice(SB)											
  binary-replication.go:823	0xa12cd4		488b942488140000		MOVQ 0x1488(SP), DX												
  binary-replication.go:823	0xa12cdc		48894a40			MOVQ CX, 0x40(DX)												
  binary-replication.go:823	0xa12ce0		833d7908830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:823	0xa12ce7		7410				JE 0xa12cf9													
  binary-replication.go:823	0xa12ce9		4c8b4230			MOVQ 0x30(DX), R8												
  binary-replication.go:823	0xa12ced		e82e46a8ff			CALL runtime.gcWriteBarrier2(SB)										
  binary-replication.go:823	0xa12cf2		498903				MOVQ AX, 0(R11)													
  binary-replication.go:823	0xa12cf5		4d894308			MOVQ R8, 0x8(R11)												
  binary-replication.go:823	0xa12cf9		48894230			MOVQ AX, 0x30(DX)												
  binary-replication.go:845	0xa12cfd		488b942458020000		MOVQ 0x258(SP), DX												
  binary-replication.go:820	0xa12d05		488bb42478020000		MOVQ 0x278(SP), SI												
  binary-replication.go:823	0xa12d0d		4c8b842488140000		MOVQ 0x1488(SP), R8												
  binary-replication.go:819	0xa12d15		4c8b8c24380b0000		MOVQ 0xb38(SP), R9												
  binary-replication.go:819	0xa12d1d		4c8b942440020000		MOVQ 0x240(SP), R10												
  binary-replication.go:819	0xa12d25		4c8b9c2450010000		MOVQ 0x150(SP), R11												
  binary-replication.go:819	0xa12d2d		49bf61737465726f6964		MOVQ $0x64696f7265747361, R15											
  binary-replication.go:822	0xa12d37		f20f10842400020000		MOVSD_XMM 0x200(SP), X0												
  binary-replication.go:820	0xa12d40		f20f108c2428010000		MOVSD_XMM 0x128(SP), X1												
  binary-replication.go:820	0xa12d49		f20f10942420010000		MOVSD_XMM 0x120(SP), X2												
  binary-replication.go:823	0xa12d52		f20f109c24c0010000		MOVSD_XMM 0x1c0(SP), X3												
  binary-replication.go:823	0xa12d5b		f20f10a424c8010000		MOVSD_XMM 0x1c8(SP), X4												
  binary-replication.go:823	0xa12d64		49895838			MOVQ BX, 0x38(R8)												
  binary-replication.go:823	0xa12d68		4c8d63ff			LEAQ -0x1(BX), R12												
  binary-replication.go:823	0xa12d6c		49c1e404			SHLQ $0x4, R12													
  binary-replication.go:823	0xa12d70		f2420f111c20			MOVSD_XMM X3, 0(AX)(R12*1)											
  binary-replication.go:823	0xa12d76		f2420f11642008			MOVSD_XMM X4, 0x8(AX)(R12*1)											
  binary-replication.go:823	0xa12d7d		0f1f00				NOPL 0(AX)													
  binary-replication.go:823	0xa12d80		e93bfeffff			JMP 0xa12bc0													
  binary-replication.go:823	0xa12d85		49bf61737465726f6964		MOVQ $0x64696f7265747361, R15											
  binary-replication.go:822	0xa12d8f		e92cfeffff			JMP 0xa12bc0													
  binary-replication.go:766	0xa12d94		440fb68c2490140000		MOVZX 0x1490(SP), R9												
  binary-replication.go:766	0xa12d9d		0f1f00				NOPL 0(AX)													
  binary-replication.go:766	0xa12da0		4584c9				TESTL R9, R9													
  binary-replication.go:827	0xa12da3		751a				JNE 0xa12dbf													
  binary-replication.go:827	0xa12da5		4d8b5038			MOVQ 0x38(R8), R10												
  binary-replication.go:827	0xa12da9		4d395020			CMPQ 0x20(R8), R10												
  slices.go:21			0xa12dad		7510				JNE 0xa12dbf													
  binary-replication.go:827	0xa12daf		4d8b5830			MOVQ 0x30(R8), R11												
  binary-replication.go:827	0xa12db3		4d8b6018			MOVQ 0x18(R8), R12												
  slices.go:24			0xa12db7		4531ed				XORL R13, R13													
  slices.go:24			0xa12dba		e99a000000			JMP 0xa12e59													
  binary-replication.go:828	0xa12dbf		4d8b5038			MOVQ 0x38(R8), R10												
  binary-replication.go:828	0xa12dc3		4d8b5840			MOVQ 0x40(R8), R11												
  binary-replication.go:828	0xa12dc7		4d8b6030			MOVQ 0x30(R8), R12												
  binary-replication.go:828	0xa12dcb		4d8b6818			MOVQ 0x18(R8), R13												
  binary-replication.go:828	0xa12dcf		4d8b7820			MOVQ 0x20(R8), R15												
  binary-replication.go:828	0xa12dd3		498b4028			MOVQ 0x28(R8), AX												
  binary-replication.go:828	0xa12dd7		4d895020			MOVQ R10, 0x20(R8)												
  binary-replication.go:828	0xa12ddb		4d895828			MOVQ R11, 0x28(R8)												
  binary-replication.go:828	0xa12ddf		833d7a07830000			CMPL runtime.writeBarrier(SB), $0x0										
  binary-replication.go:828	0xa12de6		7431				JE 0xa12e19													
  binary-replication.go:828	0xa12de8		4d8b5018			MOVQ 0x18(R8), R10												
  binary-replication.go:828	0xa12dec		4d8b5830			MOVQ 0x30(R8), R11												
  binary-replication.go:828	0xa12df0		4c89d9				MOVQ R11, CX													
  binary-replication.go:828	0xa12df3		e86845a8ff			CALL runtime.gcWriteBarrier4(SB)										
  binary-replication.go:828	0xa12df8		4d8923				MOVQ R12, 0(R11)												
  binary-replication.go:828	0xa12dfb		4d895308			MOVQ R10, 0x8(R11)												
  binary-replication.go:828	0xa12dff		4d896b10			MOVQ R13, 0x10(R11)												
  binary-replication.go:828	0xa12e03		49894b18			MOVQ CX, 0x18(R11)												
  binary-replication.go:995	0xa12e07		f20f108c2428010000		MOVSD_XMM 0x128(SP), X1												
  binary-replication.go:995	0xa12e10		f20f10942420010000		MOVSD_XMM 0x120(SP), X2												
  binary-replication.go:828	0xa12e19		4d896018			MOVQ R12, 0x18(R8)												
  binary-replication.go:828	0xa12e1d		4d897838			MOVQ R15, 0x38(R8)												
  binary-replication.go:828	0xa12e21		49894040			MOVQ AX, 0x40(R8)												
  binary-replication.go:828	0xa12e25		4d896830			MOVQ R13, 0x30(R8)												
  binary-replication.go:829	0xa12e29		4d8b5020			MOVQ 0x20(R8), R10												
  binary-replication.go:829	0xa12e2d		4d8b5828			MOVQ 0x28(R8), R11												
  binary-replication.go:831	0xa12e31		4d85e4				TESTQ R12, R12													
  binary-replication.go:831	0xa12e34		750e				JNE 0xa12e44													
  binary-replication.go:831	0xa12e36		4531db				XORL R11, R11													
  binary-replication.go:831	0xa12e39		4531d2				XORL R10, R10													
  binary-replication.go:832	0xa12e3c		4c8da42448020000		LEAQ 0x248(SP), R12												
  binary-replication.go:837	0xa12e44		4c89c2				MOVQ R8, DX													
  binary-replication.go:837	0xa12e47		4c89d8				MOVQ R11, AX													
  binary-replication.go:837	0xa12e4a		4c89d1				MOVQ R10, CX													
  binary-replication.go:837	0xa12e4d		4c89e3				MOVQ R12, BX													
  binary-replication.go:837	0xa12e50		e95ac3ffff			JMP 0xa0f1af													
  slices.go:24			0xa12e55		4d8d6f01			LEAQ 0x1(R15), R13												
  slices.go:24			0xa12e59		4d39d5				CMPQ R13, R10													
  slices.go:24			0xa12e5c		7d49				JGE 0xa12ea7													
  slices.go:25			0xa12e5e		4d89ef				MOVQ R13, R15													
  slices.go:25			0xa12e61		49c1e504			SHLQ $0x4, R13													
  slices.go:25			0xa12e65		f2430f10042b			MOVSD_XMM 0(R11)(R13*1), X0											
  slices.go:25			0xa12e6b		f2430f101c2c			MOVSD_XMM 0(R12)(R13*1), X3											
  slices.go:25			0xa12e71		660f2ec3			UCOMISD X3, X0													
  slices.go:25			0xa12e75		0f8544ffffff			JNE 0xa12dbf													
  slices.go:25			0xa12e7b		0f1f440000			NOPL 0(AX)(AX*1)												
  slices.go:25			0xa12e80		0f8a39ffffff			JP 0xa12dbf													
  slices.go:25			0xa12e86		f2430f10442c08			MOVSD_XMM 0x8(R12)(R13*1), X0											
  slices.go:25			0xa12e8d		f2430f105c2b08			MOVSD_XMM 0x8(R11)(R13*1), X3											
  slices.go:25			0xa12e94		660f2ed8			UCOMISD X0, X3													
  slices.go:25			0xa12e98		0f8521ffffff			JNE 0xa12dbf													
  slices.go:25			0xa12e9e		6690				NOPW														
  slices.go:25			0xa12ea0		7bb3				JNP 0xa12e55													
  slices.go:25			0xa12ea2		e918ffffff			JMP 0xa12dbf													
  slices.go:25			0xa12ea7		4531db				XORL R11, R11													
  slices.go:25			0xa12eaa		4531d2				XORL R10, R10													
  slices.go:25			0xa12ead		4531e4				XORL R12, R12													
  binary-replication.go:827	0xa12eb0		eb92				JMP 0xa12e44													
  binary-replication.go:820	0xa12eb2		e80948a8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:820	0xa12eb7		e80448a8ff			CALL runtime.panicBounds(SB)											
  ordered-map.go:33		0xa12ebc		0f1f4000			NOPL 0(AX)													
  ordered-map.go:33		0xa12ec0		e8fb47a8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:794	0xa12ec5		e8f647a8ff			CALL runtime.panicBounds(SB)											
  binary-replication.go:787	0xa12eca		e8718aa5ff			CALL runtime.panicmakeslicelen(SB)										
  ordered-map.go:71		0xa12ecf		4c8d7f01			LEAQ 0x1(DI), R15												
  ordered-map.go:71		0xa12ed3		4d89cd				MOVQ R9, R13													
  binary-replication.go:1040	0xa12ed6		4c8b8c24f00a0000		MOVQ 0xaf0(SP), R9												
  binary-replication.go:1040	0xa12ede		6690				NOPW														
  ordered-map.go:71		0xa12ee0		4d39e7				CMPQ R15, R12													
  ordered-map.go:71		0xa12ee3		0f8d04010000			JGE 0xa12fed													
  ordered-map.go:72		0xa12ee9		498b7210			MOVQ 0x10(R10), SI												
  ordered-map.go:72		0xa12eed		4939f7				CMPQ R15, SI													
  ordered-map.go:72		0xa12ef0		0f8394060000			JAE 0xa1358a													
  ordered-map.go:72		0xa12ef6		498b7208			MOVQ 0x8(R10), SI												
  ordered-map.go:72		0xa12efa		4c89ff				MOVQ R15, DI													
  ordered-map.go:72		0xa12efd		49c1e705			SHLQ $0x5, R15													
  ordered-map.go:72		0xa12f01		460fb64c3e18			MOVZX 0x18(SI)(R15*1), R9											
  ordered-map.go:72		0xa12f07		4584c9				TESTL R9, R9													
  ordered-map.go:72		0xa12f0a		0f84d5000000			JE 0xa12fe5													
  ordered-map.go:73		0xa12f10		4d8d4d01			LEAQ 0x1(R13), R9												
  ordered-map.go:73		0xa12f14		4d8b6c3710			MOVQ 0x10(R15)(SI*1), R13											
  ordered-map.go:73		0xa12f19		4d8b7c3708			MOVQ 0x8(R15)(SI*1), R15											
  ordered-map.go:73		0xa12f1e		6690				NOPW														
  ordered-map.go:73		0xa12f20		4c39c9				CMPQ CX, R9													
  ordered-map.go:73		0xa12f23		737d				JAE 0xa12fa2													
  ordered-map.go:73		0xa12f25		4c89ac24080b0000		MOVQ R13, 0xb08(SP)												
  ordered-map.go:73		0xa12f2d		4c89bc24e0010000		MOVQ R15, 0x1e0(SP)												
  ordered-map.go:71		0xa12f35		4889bc24b8010000		MOVQ DI, 0x1b8(SP)												
  ordered-map.go:73		0xa12f3d		488d35fc8f7200			LEAQ 0x728ffc(IP), SI												
  ordered-map.go:73		0xa12f44		4c89d8				MOVQ R11, AX													
  ordered-map.go:73		0xa12f47		4c89cb				MOVQ R9, BX													
  ordered-map.go:73		0xa12f4a		bf01000000			MOVL $0x1, DI													
  ordered-map.go:73		0xa12f4f		e82cf7a7ff			CALL runtime.growslice(SB)											
  replication-common.go:259	0xa12f54		488b942478020000		MOVQ 0x278(SP), DX												
  ordered-map.go:71		0xa12f5c		488bbc24b8010000		MOVQ 0x1b8(SP), DI												
  binary-replication.go:797	0xa12f64		4c8b842458020000		MOVQ 0x258(SP), R8												
  ordered-map.go:72		0xa12f6c		4c8b9424480b0000		MOVQ 0xb48(SP), R10												
  ordered-map.go:71		0xa12f74		4c8ba42440020000		MOVQ 0x240(SP), R12												
  ordered-map.go:73		0xa12f7c		4c8bac24080b0000		MOVQ 0xb08(SP), R13												
  ordered-map.go:73		0xa12f84		4c8bbc24e0010000		MOVQ 0x1e0(SP), R15												
  ordered-map.go:73		0xa12f8c		4989c3				MOVQ AX, R11													
  ordered-map.go:73		0xa12f8f		4989d9				MOVQ BX, R9													
  binary-replication.go:786	0xa12f92		488b842488140000		MOVQ 0x1488(SP), AX												
  binary-replication.go:766	0xa12f9a		0fb69c2490140000		MOVZX 0x1490(SP), BX												
  ordered-map.go:73		0xa12fa2		498d71ff			LEAQ -0x1(R9), SI												
  ordered-map.go:73		0xa12fa6		48c1e604			SHLQ $0x4, SI													
  ordered-map.go:73		0xa12faa		4d893c33			MOVQ R15, 0(R11)(SI*1)												
  ordered-map.go:73		0xa12fae		833dab05830000			CMPL runtime.writeBarrier(SB), $0x0										
  ordered-map.go:73		0xa12fb5		7421				JE 0xa12fd8													
  ordered-map.go:73		0xa12fb7		4c899c2480020000		MOVQ R11, 0x280(SP)												
  ordered-map.go:73		0xa12fbf		4e8b7c1e08			MOVQ 0x8(SI)(R11*1), R15											
  ordered-map.go:73		0xa12fc4		e85743a8ff			CALL runtime.gcWriteBarrier2(SB)										
  ordered-map.go:73		0xa12fc9		4d892b				MOVQ R13, 0(R11)												
  ordered-map.go:73		0xa12fcc		4d897b08			MOVQ R15, 0x8(R11)												
  ordered-map.go:73		0xa12fd0		4c8b9c2480020000		MOVQ 0x280(SP), R11												
  ordered-map.go:73		0xa12fd8		4d896c3308			MOVQ R13, 0x8(R11)(SI*1)											
  ordered-map.go:73		0xa12fdd		0f1f00				NOPL 0(AX)													
  ordered-map.go:73		0xa12fe0		e9eafeffff			JMP 0xa12ecf													
  ordered-map.go:73		0xa12fe5		4d89e9				MOVQ R13, R9													
  ordered-map.go:72		0xa12fe8		e9e2feffff			JMP 0xa12ecf													
  replication-common.go:259	0xa12fed		4c896a18			MOVQ R13, 0x18(DX)												
  replication-common.go:259	0xa12ff1		48894a20			MOVQ CX, 0x20(DX)												
  replication-common.go:259	0xa12ff5		833d6405830000			CMPL runtime.writeBarrier(SB), $0x0										
  replication-common.go:259	0xa12ffc		7416				JE 0xa13014													
  replication-common.go:259	0xa12ffe		4c8b5210			MOVQ 0x10(DX), R10												
  ordered-map.go:71		0xa13002		4c89d9				MOVQ R11, CX													
  replication-common.go:259	0xa13005		e81643a8ff			CALL runtime.gcWriteBarrier2(SB)										
  replication-common.go:259	0xa1300a		49890b				MOVQ CX, 0(R11)													
  replication-common.go:259	0xa1300d		4d895308			MOVQ R10, 0x8(R11)												
  replication-common.go:259	0xa13011		4989cb				MOVQ CX, R11													
  ordered-map.go:71		0xa13014		4c89ac24b0000000		MOVQ R13, 0xb0(SP)												
  replication-common.go:259	0xa1301c		4c895a10			MOVQ R11, 0x10(DX)												
  replication-common.go:263	0xa13020		4c39aa98000000			CMPQ 0x98(DX), R13												
  replication-common.go:263	0xa13027		0f8df1010000			JGE 0xa1321e													
  replication-common.go:264	0xa1302d		4b8d4c2d00			LEAQ 0(R13)(R13*1), CX												
  replication-common.go:264	0xa13032		48898c2440020000		MOVQ CX, 0x240(SP)												
  replication-common.go:264	0xa1303a		488d05a7586b00			LEAQ 0x6b58a7(IP), AX												
  replication-common.go:264	0xa13041		4889cb				MOVQ CX, BX													
  replication-common.go:264	0xa13044		e857f5a7ff			CALL runtime.makeslice(SB)											
  replication-common.go:264	0xa13049		488b8c2440020000		MOVQ 0x240(SP), CX												
  replication-common.go:264	0xa13051		488b942478020000		MOVQ 0x278(SP), DX												
  replication-common.go:264	0xa13059		48894a30			MOVQ CX, 0x30(DX)												
  replication-common.go:264	0xa1305d		48894a38			MOVQ CX, 0x38(DX)												
  replication-common.go:264	0xa13061		833df804830000			CMPL runtime.writeBarrier(SB), $0x0										
  replication-common.go:264	0xa13068		7410				JE 0xa1307a													
  replication-common.go:264	0xa1306a		488b7228			MOVQ 0x28(DX), SI												
  replication-common.go:264	0xa1306e		e8ad42a8ff			CALL runtime.gcWriteBarrier2(SB)										
  replication-common.go:264	0xa13073		498903				MOVQ AX, 0(R11)													
  replication-common.go:264	0xa13076		49897308			MOVQ SI, 0x8(R11)												
  replication-common.go:264	0xa1307a		48894228			MOVQ AX, 0x28(DX)												
  replication-common.go:265	0xa1307e		488d0563806a00			LEAQ 0x6a8063(IP), AX												
  replication-common.go:265	0xa13085		4889cb				MOVQ CX, BX													
  replication-common.go:265	0xa13088		e813f5a7ff			CALL runtime.makeslice(SB)											
  replication-common.go:265	0xa1308d		488b8c2440020000		MOVQ 0x240(SP), CX												
  replication-common.go:265	0xa13095		488b942478020000		MOVQ 0x278(SP), DX												
  replication-common.go:265	0xa1309d		48894a48			MOVQ CX, 0x48(DX)												
  replication-common.go:265	0xa130a1		48894a50			MOVQ CX, 0x50(DX)												
  replication-common.go:265	0xa130a5		833db404830000			CMPL runtime.writeBarrier(SB), $0x0										
  replication-common.go:265	0xa130ac		7410				JE 0xa130be													
  replication-common.go:265	0xa130ae		488b7240			MOVQ 0x40(DX), SI												
  replication-common.go:265	0xa130b2		e86942a8ff			CALL runtime.gcWriteBarrier2(SB)										
  replication-common.go:265	0xa130b7		498903				MOVQ AX, 0(R11)													
  replication-common.go:265	0xa130ba		49897308			MOVQ SI, 0x8(R11)												
  replication-common.go:265	0xa130be		48894240			MOVQ AX, 0x40(DX)												
  replication-common.go:266	0xa130c2		488d0547137100			LEAQ 0x711347(IP), AX												
  replication-common.go:266	0xa130c9		4889cb				MOVQ CX, BX													
  replication-common.go:266	0xa130cc		e8cff4a7ff			CALL runtime.makeslice(SB)											
  replication-common.go:266	0xa130d1		488b8c2440020000		MOVQ 0x240(SP), CX												
  replication-common.go:266	0xa130d9		488b942478020000		MOVQ 0x278(SP), DX												
  replication-common.go:266	0xa130e1		48894a60			MOVQ CX, 0x60(DX)												
  replication-common.go:266	0xa130e5		48894a68			MOVQ CX, 0x68(DX)												
  replication-common.go:266	0xa130e9		833d7004830000			CMPL runtime.writeBarrier(SB), $0x0										
  replication-common.go:266	0xa130f0		7410				JE 0xa13102													
  replication-common.go:266	0xa130f2		488b7258			MOVQ 0x58(DX), SI												
  replication-common.go:266	0xa130f6		e82542a8ff			CALL runtime.gcWriteBarrier2(SB)										
  replication-common.go:266	0xa130fb		498903				MOVQ AX, 0(R11)													
  replication-common.go:266	0xa130fe		49897308			MOVQ SI, 0x8(R11)												
  replication-common.go:266	0xa13102		48894258			MOVQ AX, 0x58(DX)												
  replication-common.go:267	0xa13106		488d0503137100			LEAQ 0x711303(IP), AX												
  replication-common.go:267	0xa1310d		4889cb				MOVQ CX, BX													
  replication-common.go:267	0xa13110		e88bf4a7ff			CALL runtime.makeslice(SB)											
  replication-common.go:267	0xa13115		488b8c2440020000		MOVQ 0x240(SP), CX												
  replication-common.go:267	0xa1311d		488b942478020000		MOVQ 0x278(SP), DX												
  replication-common.go:267	0xa13125		48894a78			MOVQ CX, 0x78(DX)												
  replication-common.go:267	0xa13129		48898a80000000			MOVQ CX, 0x80(DX)												
  replication-common.go:267	0xa13130		833d2904830000			CMPL runtime.writeBarrier(SB), $0x0										
  replication-common.go:267	0xa13137		7413				JE 0xa1314c													
  replication-common.go:267	0xa13139		488b7270			MOVQ 0x70(DX), SI												
  replication-common.go:267	0xa1313d		0f1f00				NOPL 0(AX)													
  replication-common.go:267	0xa13140		e8db41a8ff			CALL runtime.gcWriteBarrier2(SB)										
  replication-common.go:267	0xa13145		498903				MOVQ AX, 0(R11)													
  replication-common.go:267	0xa13148		49897308			MOVQ SI, 0x8(R11)												
  replication-common.go:267	0xa1314c		48894270			MOVQ AX, 0x70(DX)												
  replication-common.go:268	0xa13150		488d0539147100			LEAQ 0x711439(IP), AX												
  replication-common.go:268	0xa13157		4889cb				MOVQ CX, BX													
  replication-common.go:268	0xa1315a		e841f4a7ff			CALL runtime.makeslice(SB)											
  replication-common.go:268	0xa1315f		488b8c2440020000		MOVQ 0x240(SP), CX												
  replication-common.go:268	0xa13167		488b942478020000		MOVQ 0x278(SP), DX												
  replication-common.go:268	0xa1316f		48898a90000000			MOVQ CX, 0x90(DX)												
  replication-common.go:268	0xa13176		48898a98000000			MOVQ CX, 0x98(DX)												
  replication-common.go:268	0xa1317d		833ddc03830000			CMPL runtime.writeBarrier(SB), $0x0										
  replication-common.go:268	0xa13184		7413				JE 0xa13199													
  replication-common.go:268	0xa13186		488bb288000000			MOVQ 0x88(DX), SI												
  replication-common.go:268	0xa1318d		e88e41a8ff			CALL runtime.gcWriteBarrier2(SB)										
  replication-common.go:268	0xa13192		498903				MOVQ AX, 0(R11)													
  replication-common.go:268	0xa13195		49897308			MOVQ SI, 0x8(R11)												
  replication-common.go:268	0xa13199		48898288000000			MOVQ AX, 0x88(DX)												
  replication-common.go:269	0xa131a0		488d05e9137100			LEAQ 0x7113e9(IP), AX												
  replication-common.go:269	0xa131a7		4889cb				MOVQ CX, BX													
  replication-common.go:269	0xa131aa		e8f1f3a7ff			CALL runtime.makeslice(SB)											
  replication-common.go:269	0xa131af		488b942440020000		MOVQ 0x240(SP), DX												
  replication-common.go:269	0xa131b7		488bb42478020000		MOVQ 0x278(SP), SI												
  replication-common.go:269	0xa131bf		488996a8000000			MOVQ DX, 0xa8(SI)												
  replication-common.go:269	0xa131c6		488996b0000000			MOVQ DX, 0xb0(SI)												
  replication-common.go:269	0xa131cd		833d8c03830000			CMPL runtime.writeBarrier(SB), $0x0										
  replication-common.go:269	0xa131d4		7416				JE 0xa131ec													
  replication-common.go:269	0xa131d6		488b96a0000000			MOVQ 0xa0(SI), DX												
  replication-common.go:269	0xa131dd		0f1f00				NOPL 0(AX)													
  replication-common.go:269	0xa131e0		e83b41a8ff			CALL runtime.gcWriteBarrier2(SB)										
  replication-common.go:269	0xa131e5		498903				MOVQ AX, 0(R11)													
  replication-common.go:269	0xa131e8		49895308			MOVQ DX, 0x8(R11)												
  replication-common.go:269	0xa131ec		488986a0000000			MOVQ AX, 0xa0(SI)												
  binary-replication.go:786	0xa131f3		488b842488140000		MOVQ 0x1488(SP), AX												
  replication-common.go:272	0xa131fb		4889f2				MOVQ SI, DX													
  binary-replication.go:766	0xa131fe		0fb69c2490140000		MOVZX 0x1490(SP), BX												
  binary-replication.go:797	0xa13206		4c8b842458020000		MOVQ 0x258(SP), R8												
  binary-replication.go:1040	0xa1320e		4c8b8c24f00a0000		MOVQ 0xaf0(SP), R9												
  replication-common.go:272	0xa13216		4c8bac24b0000000		MOVQ 0xb0(SP), R13												
  replication-common.go:272	0xa1321e		4c8b5238			MOVQ 0x38(DX), R10												
  replication-common.go:272	0xa13222		4d39d5				CMPQ R13, R10													
  replication-common.go:272	0xa13225		0f875a030000			JA 0xa13585													
  replication-common.go:272	0xa1322b		4c896a30			MOVQ R13, 0x30(DX)												
  replication-common.go:273	0xa1322f		4c8b5250			MOVQ 0x50(DX), R10												
  replication-common.go:273	0xa13233		4d39d5				CMPQ R13, R10													
  replication-common.go:273	0xa13236		0f8742030000			JA 0xa1357e													
  replication-common.go:273	0xa1323c		4c896a48			MOVQ R13, 0x48(DX)												
  replication-common.go:274	0xa13240		4d85ed				TESTQ R13, R13													
  replication-common.go:274	0xa13243		7440				JE 0xa13285													
  replication-common.go:274	0xa13245		4c89eb				MOVQ R13, BX													
  replication-common.go:274	0xa13248		48c1e303			SHLQ $0x3, BX													
  replication-common.go:274	0xa1324c		488b4240			MOVQ 0x40(DX), AX												
  replication-common.go:274	0xa13250		e82bb3a7ff			CALL runtime.memclrHasPointers(SB)										
  binary-replication.go:786	0xa13255		488b842488140000		MOVQ 0x1488(SP), AX												
  replication-common.go:275	0xa1325d		488b942478020000		MOVQ 0x278(SP), DX												
  binary-replication.go:766	0xa13265		0fb69c2490140000		MOVZX 0x1490(SP), BX												
  binary-replication.go:797	0xa1326d		4c8b842458020000		MOVQ 0x258(SP), R8												
  binary-replication.go:1040	0xa13275		4c8b8c24f00a0000		MOVQ 0xaf0(SP), R9												
  replication-common.go:275	0xa1327d		4c8bac24b0000000		MOVQ 0xb0(SP), R13												
  replication-common.go:275	0xa13285		4c8b5268			MOVQ 0x68(DX), R10												
  replication-common.go:275	0xa13289		4d39d5				CMPQ R13, R10													
  replication-common.go:275	0xa1328c		0f87e7020000			JA 0xa13579													
  replication-common.go:275	0xa13292		4c896a60			MOVQ R13, 0x60(DX)												
  replication-common.go:274	0xa13296		4d85ed				TESTQ R13, R13													
  replication-common.go:276	0xa13299		7440				JE 0xa132db													
  replication-common.go:276	0xa1329b		4c89eb				MOVQ R13, BX													
  replication-common.go:276	0xa1329e		48c1e303			SHLQ $0x3, BX													
  replication-common.go:276	0xa132a2		488b4258			MOVQ 0x58(DX), AX												
  replication-common.go:276	0xa132a6		e8b544a8ff			CALL runtime.memclrNoHeapPointers(SB)										
  binary-replication.go:786	0xa132ab		488b842488140000		MOVQ 0x1488(SP), AX												
  replication-common.go:277	0xa132b3		488b942478020000		MOVQ 0x278(SP), DX												
  binary-replication.go:766	0xa132bb		0fb69c2490140000		MOVZX 0x1490(SP), BX												
  binary-replication.go:797	0xa132c3		4c8b842458020000		MOVQ 0x258(SP), R8												
  binary-replication.go:1040	0xa132cb		4c8b8c24f00a0000		MOVQ 0xaf0(SP), R9												
  replication-common.go:277	0xa132d3		4c8bac24b0000000		MOVQ 0xb0(SP), R13												
  replication-common.go:277	0xa132db		4c8b9280000000			MOVQ 0x80(DX), R10												
  replication-common.go:277	0xa132e2		4d39d5				CMPQ R13, R10													
  replication-common.go:277	0xa132e5		0f8789020000			JA 0xa13574													
  replication-common.go:277	0xa132eb		4c896a78			MOVQ R13, 0x78(DX)												
  replication-common.go:278	0xa132ef		4c8b9298000000			MOVQ 0x98(DX), R10												
  replication-common.go:278	0xa132f6		4d39d5				CMPQ R13, R10													
  replication-common.go:278	0xa132f9		0f8770020000			JA 0xa1356f													
  replication-common.go:278	0xa132ff		4c89aa90000000			MOVQ R13, 0x90(DX)												
  replication-common.go:279	0xa13306		4c8b92b0000000			MOVQ 0xb0(DX), R10												
  replication-common.go:279	0xa1330d		4d39d5				CMPQ R13, R10													
  replication-common.go:279	0xa13310		0f8754020000			JA 0xa1356a													
  replication-common.go:279	0xa13316		4c89aaa8000000			MOVQ R13, 0xa8(DX)												
  replication-common.go:281	0xa1331d		4c8b5210			MOVQ 0x10(DX), R10												
  replication-common.go:281	0xa13321		4c8b5a18			MOVQ 0x18(DX), R11												
  replication-common.go:281	0xa13325		4c899c2440020000		MOVQ R11, 0x240(SP)												
  replication-common.go:281	0xa1332d		31c9				XORL CX, CX													
  replication-common.go:281	0xa1332f		eb55				JMP 0xa13386													
  replication-common.go:281	0xa13331		660f1f840000000000		NOPW 0(AX)(AX*1)												
  replication-common.go:281	0xa1333a		660f1f440000			NOPW 0(AX)(AX*1)												
  replication-common.go:296	0xa13340		4c8b6170			MOVQ 0x70(CX), R12												
  replication-common.go:296	0xa13344		498914dc			MOVQ DX, 0(R12)(BX*8)												
  replication-common.go:281	0xa13348		4c8b9424100b0000		MOVQ 0xb10(SP), R10												
  replication-common.go:281	0xa13350		4983c210			ADDQ $0x10, R10													
  replication-common.go:281	0xa13354		4c8d6301			LEAQ 0x1(BX), R12												
  binary-replication.go:786	0xa13358		488b842488140000		MOVQ 0x1488(SP), AX												
  replication-common.go:283	0xa13360		4889ca				MOVQ CX, DX													
  binary-replication.go:766	0xa13363		0fb69c2490140000		MOVZX 0x1490(SP), BX												
  binary-replication.go:797	0xa1336b		4c8b842458020000		MOVQ 0x258(SP), R8												
  binary-replication.go:1040	0xa13373		4c8b8c24f00a0000		MOVQ 0xaf0(SP), R9												
  replication-common.go:281	0xa1337b		4c8b9c2440020000		MOVQ 0x240(SP), R11												
  replication-common.go:281	0xa13383		4c89e1				MOVQ R12, CX													
  replication-common.go:281	0xa13386		4c39d9				CMPQ CX, R11													
  replication-common.go:281	0xa13389		0f8d4abaffff			JGE 0xa0edd9													
  replication-common.go:281	0xa1338f		48898c2440010000		MOVQ CX, 0x140(SP)												
  replication-common.go:281	0xa13397		4c899424100b0000		MOVQ R10, 0xb10(SP)												
  replication-common.go:281	0xa1339f		498b0a				MOVQ 0(R10), CX													
  replication-common.go:281	0xa133a2		498b4208			MOVQ 0x8(R10), AX												
  replication-common.go:282	0xa133a6		488b4918			MOVQ 0x18(CX), CX												
  replication-common.go:282	0xa133aa		ffd1				CALL CX														
  replication-common.go:283	0xa133ac		488b8c2478020000		MOVQ 0x278(SP), CX												
  replication-common.go:283	0xa133b4		488b5130			MOVQ 0x30(CX), DX												
  replication-common.go:283	0xa133b8		488b9c2440010000		MOVQ 0x140(SP), BX												
  replication-common.go:283	0xa133c0		4839d3				CMPQ BX, DX													
  replication-common.go:283	0xa133c3		0f839c010000			JAE 0xa13565													
  replication-common.go:283	0xa133c9		488b5128			MOVQ 0x28(CX), DX												
  replication-common.go:283	0xa133cd		833d8c01830000			CMPL runtime.writeBarrier(SB), $0x0										
  replication-common.go:283	0xa133d4		7410				JE 0xa133e6													
  replication-common.go:283	0xa133d6		4c8b04da			MOVQ 0(DX)(BX*8), R8												
  replication-common.go:283	0xa133da		e8413fa8ff			CALL runtime.gcWriteBarrier2(SB)										
  replication-common.go:283	0xa133df		498903				MOVQ AX, 0(R11)													
  replication-common.go:283	0xa133e2		4d894308			MOVQ R8, 0x8(R11)												
  replication-common.go:283	0xa133e6		488904da			MOVQ AX, 0(DX)(BX*8)												
  replication-common.go:284	0xa133ea		488d15f77c6a00			LEAQ 0x6a7cf7(IP), DX												
  replication-common.go:284	0xa133f1		48395070			CMPQ 0x70(AX), DX												
  replication-common.go:284	0xa133f5		7506				JNE 0xa133fd													
  replication-common.go:284	0xa133f7		488b5078			MOVQ 0x78(AX), DX												
  replication-common.go:284	0xa133fb		eb02				JMP 0xa133ff													
  replication-common.go:284	0xa133fd		31d2				XORL DX, DX													
  replication-common.go:284	0xa133ff		4c8b4148			MOVQ 0x48(CX), R8												
  replication-common.go:284	0xa13403		4c39c3				CMPQ BX, R8													
  replication-common.go:284	0xa13406		0f8352010000			JAE 0xa1355e													
  replication-common.go:284	0xa1340c		4c8b4140			MOVQ 0x40(CX), R8												
  replication-common.go:284	0xa13410		833d4901830000			CMPL runtime.writeBarrier(SB), $0x0										
  replication-common.go:284	0xa13417		7413				JE 0xa1342c													
  replication-common.go:284	0xa13419		4d8b0cd8			MOVQ 0(R8)(BX*8), R9												
  replication-common.go:284	0xa1341d		0f1f00				NOPL 0(AX)													
  replication-common.go:284	0xa13420		e8fb3ea8ff			CALL runtime.gcWriteBarrier2(SB)										
  replication-common.go:284	0xa13425		498913				MOVQ DX, 0(R11)													
  replication-common.go:284	0xa13428		4d894b08			MOVQ R9, 0x8(R11)												
  replication-common.go:284	0xa1342c		498914d8			MOVQ DX, 0(R8)(BX*8)												
  replication-common.go:285	0xa13430		488b9190000000			MOVQ 0x90(CX), DX												
  replication-common.go:285	0xa13437		4c8b81a0000000			MOVQ 0xa0(CX), R8												
  replication-common.go:285	0xa1343e		f20f104020			MOVSD_XMM 0x20(AX), X0												
  replication-common.go:285	0xa13443		4839d3				CMPQ BX, DX													
  replication-common.go:285	0xa13446		0f830d010000			JAE 0xa13559													
  replication-common.go:285	0xa1344c		488b9188000000			MOVQ 0x88(CX), DX												
  replication-common.go:285	0xa13453		4c8b89a8000000			MOVQ 0xa8(CX), R9												
  replication-common.go:285	0xa1345a		f20f104818			MOVSD_XMM 0x18(AX), X1												
  replication-common.go:285	0xa1345f		f20f110cda			MOVSD_XMM X1, 0(DX)(BX*8)											
  replication-common.go:285	0xa13464		4c39cb				CMPQ BX, R9													
  replication-common.go:285	0xa13467		0f83e7000000			JAE 0xa13554													
  replication-common.go:285	0xa1346d		f2410f1104d8			MOVSD_XMM X0, 0(R8)(BX*8)											
  replication-common.go:286	0xa13473		4883b88800000007		CMPQ 0x88(AX), $0x7												
  replication-common.go:286	0xa1347b		7520				JNE 0xa1349d													
  replication-common.go:286	0xa1347d		488b9080000000			MOVQ 0x80(AX), DX												
  replication-common.go:286	0xa13484		813a73746174			CMPL 0(DX), $0x74617473												
  replication-common.go:286	0xa1348a		7511				JNE 0xa1349d													
  replication-common.go:286	0xa1348c		66817a04696f			CMPW 0x4(DX), $0x6f69												
  replication-common.go:286	0xa13492		7509				JNE 0xa1349d													
  replication-common.go:286	0xa13494		807a066e			CMPB 0x6(DX), $0x6e												
  replication-common.go:286	0xa13498		0f94c2				SETE DL														
  replication-common.go:286	0xa1349b		eb03				JMP 0xa134a0													
  replication-common.go:286	0xa1349d		31d2				XORL DX, DX													
  replication-common.go:286	0xa1349f		90				NOPL														
  replication-common.go:286	0xa134a0		84d2				TESTL DL, DL													
  replication-common.go:288	0xa134a2		741e				JE 0xa134c2													
  replication-common.go:289	0xa134a4		4c8b4160			MOVQ 0x60(CX), R8												
  replication-common.go:289	0xa134a8		4c39c3				CMPQ BX, R8													
  replication-common.go:289	0xa134ab		0f839e000000			JAE 0xa1354f													
  replication-common.go:289	0xa134b1		4c8b4158			MOVQ 0x58(CX), R8												
  replication-common.go:289	0xa134b5		49c704d801000000		MOVQ $0x1, 0(R8)(BX*8)												
  replication-common.go:289	0xa134bd		0f1f00				NOPL 0(AX)													
  replication-common.go:286	0xa134c0		84d2				TESTL DL, DL													
  replication-common.go:292	0xa134c2		7521				JNE 0xa134e5													
  replication-common.go:292	0xa134c4		4883b88800000008		CMPQ 0x88(AX), $0x8												
  replication-common.go:292	0xa134cc		7532				JNE 0xa13500													
  replication-common.go:292	0xa134ce		488b9080000000			MOVQ 0x80(AX), DX												
  replication-common.go:292	0xa134d5		49b861737465726f6964		MOVQ $0x64696f7265747361, R8											
  replication-common.go:292	0xa134df		90				NOPL														
  replication-common.go:292	0xa134e0		4c3902				CMPQ 0(DX), R8													
  replication-common.go:292	0xa134e3		751b				JNE 0xa13500													
  replication-common.go:292	0xa134e5		80b89400000000			CMPB 0x94(AX), $0x0												
  replication-common.go:292	0xa134ec		7412				JE 0xa13500													
  replication-common.go:293	0xa134ee		488b5160			MOVQ 0x60(CX), DX												
  replication-common.go:293	0xa134f2		4839d3				CMPQ BX, DX													
  replication-common.go:293	0xa134f5		7353				JAE 0xa1354a													
  replication-common.go:293	0xa134f7		488b5158			MOVQ 0x58(CX), DX												
  replication-common.go:293	0xa134fb		48830cda02			ORQ $0x2, 0(DX)(BX*8)												
  replication-common.go:296	0xa13500		488b5108			MOVQ 0x8(CX), DX												
  replication-common.go:296	0xa13504		488b9200080000			MOVQ 0x800(DX), DX												
  replication-common.go:296	0xa1350b		4885d2				TESTQ DX, DX													
  replication-common.go:296	0xa1350e		7435				JE 0xa13545													
  replication-common.go:296	0xa13510		4c8b4178			MOVQ 0x78(CX), R8												
  replication-common.go:296	0xa13514		488b4010			MOVQ 0x10(AX), AX												
  replication-common.go:296	0xa13518		4989d1				MOVQ DX, R9													
  replication-common.go:296	0xa1351b		0f1f440000			NOPL 0(AX)(AX*1)												
  replication-common.go:296	0xa13520		4983f9ff			CMPQ R9, $-0x1													
  replication-common.go:296	0xa13524		7507				JNE 0xa1352d													
  replication-common.go:296	0xa13526		48f7d8				NEGQ AX														
  replication-common.go:296	0xa13529		31d2				XORL DX, DX													
  replication-common.go:296	0xa1352b		eb05				JMP 0xa13532													
  replication-common.go:296	0xa1352d		4899				CQO														
  replication-common.go:296	0xa1352f		49f7f9				IDIVQ R9													
  replication-common.go:296	0xa13532		4c39c3				CMPQ BX, R8													
  replication-common.go:296	0xa13535		0f8205feffff			JB 0xa13340													
  replication-common.go:296	0xa1353b		0f1f440000			NOPL 0(AX)(AX*1)												
  replication-common.go:296	0xa13540		e87b41a8ff			CALL runtime.panicBounds(SB)											
  replication-common.go:296	0xa13545		e816cca3ff			CALL runtime.panicdivide(SB)											
  replication-common.go:293	0xa1354a		e87141a8ff			CALL runtime.panicBounds(SB)											
  replication-common.go:289	0xa1354f		e86c41a8ff			CALL runtime.panicBounds(SB)											
  replication-common.go:285	0xa13554		e86741a8ff			CALL runtime.panicBounds(SB)											
  replication-common.go:285	0xa13559		e86241a8ff			CALL runtime.panicBounds(SB)											
  replication-common.go:284	0xa1355e		6690				NOPW														
  replication-common.go:284	0xa13560		e85b41a8ff			CALL runtime.panicBounds(SB)											
  replication-common.go:283	0xa13565		e85641a8ff			CALL runtime.panicBounds(SB)											
  replication-common.go:279	0xa1356a		e85141a8ff			CALL runtime.panicBounds(SB)											
  replication-common.go:278	0xa1356f		e84c41a8ff			CALL runtime.panicBounds(SB)											
  replication-common.go:277	0xa13574		e84741a8ff			CALL runtime.panicBounds(SB)											
  replication-common.go:275	0xa13579		e84241a8ff			CALL runtime.panicBounds(SB)											
  replication-common.go:273	0xa1357e		6690				NOPW														
  replication-common.go:273	0xa13580		e83b41a8ff			CALL runtime.panicBounds(SB)											
  replication-common.go:272	0xa13585		e83641a8ff			CALL runtime.panicBounds(SB)											
  ordered-map.go:72		0xa1358a		e83141a8ff			CALL runtime.panicBounds(SB)											
  ordered-map.go:72		0xa1358f		90				NOPL														
  binary-replication.go:763	0xa13590		4889842490000000		MOVQ AX, 0x90(SP)												
  binary-replication.go:763	0xa13598		889c2498000000			MOVB BL, 0x98(SP)												
  binary-replication.go:763	0xa1359f		90				NOPL														
  binary-replication.go:763	0xa135a0		e8db24a8ff			CALL runtime.morestack_noctxt.abi0(SB)										
  binary-replication.go:763	0xa135a5		488b842490000000		MOVQ 0x90(SP), AX												
  binary-replication.go:763	0xa135ad		0fb69c2498000000		MOVZX 0x98(SP), BX												
  binary-replication.go:763	0xa135b5		e906b6ffff			JMP github.com/burntcustard/unicorn-mining-co/src/server/network.(*BinaryReplicationManager).encode(SB)		
