TEXT github.com/burntcustard/unicorn-mining-co/src/server/gameplay.(*GameCollisions).Step(SB) /home/burntcustard/Documents/unicorn-mining-co/src/server/gameplay/game-collisions.go
  game-collisions.go:220	0x9f6000		4c8da424f0fdffff		LEAQ 0xfffffdf0(SP), R12																																																	
  game-collisions.go:220	0x9f6008		4d3b6610			CMPQ R12, 0x10(R14)																																																		
  game-collisions.go:220	0x9f600c		0f86a61e0000			JBE 0x9f7eb8																																																			
  game-collisions.go:220	0x9f6012		55				PUSHQ BP																																																			
  game-collisions.go:220	0x9f6013		4889e5				MOVQ SP, BP																																																			
  game-collisions.go:220	0x9f6016		4881ec88020000			SUBQ $0x288, SP																																																			
  game-collisions.go:221	0x9f601d		4889842498020000		MOVQ AX, 0x298(SP)																																																		
  game-collisions.go:221	0x9f6025		48899c24a0020000		MOVQ BX, 0x2a0(SP)																																																		
  game-collisions.go:221	0x9f602d		f20f118424a8020000		MOVSD_XMM X0, 0x2a8(SP)																																																		
  game-collisions.go:221	0x9f6036		48898c24b0020000		MOVQ CX, 0x2b0(SP)																																																		
  game-collisions.go:221	0x9f603e		488b9080080000			MOVQ 0x880(AX), DX																																																		
  game-collisions.go:221	0x9f6045		4885d2				TESTQ DX, DX																																																			
  game-collisions.go:221	0x9f6048		7431				JE 0x9f607b																																																			
  game-collisions.go:221	0x9f604a		486bda38			IMULQ $0x38, DX, BX																																																		
  game-collisions.go:221	0x9f604e		488b8078080000			MOVQ 0x878(AX), AX																																																		
  game-collisions.go:221	0x9f6055		e82685a9ff			CALL runtime.memclrHasPointers(SB)																																																
  game-collisions.go:222	0x9f605a		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:406	0x9f6062		488b8c24b0020000		MOVQ 0x2b0(SP), CX																																																		
  game-collisions.go:232	0x9f606a		488b9c24a0020000		MOVQ 0x2a0(SP), BX																																																		
  game-collisions.go:286	0x9f6072		f20f108424a8020000		MOVSD_XMM 0x2a8(SP), X0																																																		
  game-collisions.go:222	0x9f607b		48c7808008000000000000		MOVQ $0x0, 0x880(AX)																																																		
  game-collisions.go:223	0x9f6086		488b9020090000			MOVQ 0x920(AX), DX																																																		
  game-collisions.go:223	0x9f608d		4889942408020000		MOVQ DX, 0x208(SP)																																																		
  ordered-map.go:101		0x9f6095		488b7210			MOVQ 0x10(DX), SI																																																		
  ordered-map.go:101		0x9f6099		4885f6				TESTQ SI, SI																																																			
  ordered-map.go:101		0x9f609c		7419				JE 0x9f60b7																																																			
  ordered-map.go:101		0x9f609e		488d1cb6			LEAQ 0(SI)(SI*4), BX																																																		
  ordered-map.go:101		0x9f60a2		48c1e304			SHLQ $0x4, BX																																																			
  ordered-map.go:101		0x9f60a6		488b4208			MOVQ 0x8(DX), AX																																																		
  ordered-map.go:101		0x9f60aa		e8d184a9ff			CALL runtime.memclrHasPointers(SB)																																																
  ordered-map.go:102		0x9f60af		488b942408020000		MOVQ 0x208(SP), DX																																																		
  ordered-map.go:102		0x9f60b7		488b5a20			MOVQ 0x20(DX), BX																																																		
  ordered-map.go:102		0x9f60bb		488d059e546f00			LEAQ 0x6f549e(IP), AX																																																		
  ordered-map.go:102		0x9f60c2		e899f6a2ff			CALL runtime.mapclear(SB)																																																	
  ordered-map.go:104		0x9f60c7		488b8c2408020000		MOVQ 0x208(SP), CX																																																		
  ordered-map.go:104		0x9f60cf		48833900			CMPQ 0(CX), $0x0																																																		
  ordered-map.go:104		0x9f60d3		7508				JNE 0x9f60dd																																																			
  ordered-map.go:105		0x9f60d5		48c7411000000000		MOVQ $0x0, 0x10(CX)																																																		
  game-collisions.go:224	0x9f60dd		488b942498020000		MOVQ 0x298(SP), DX																																																		
  game-collisions.go:224	0x9f60e5		488b9a98080000			MOVQ 0x898(DX), BX																																																		
  game-collisions.go:224	0x9f60ec		4885db				TESTQ BX, BX																																																			
  game-collisions.go:224	0x9f60ef		741c				JE 0x9f610d																																																			
  game-collisions.go:224	0x9f60f1		48c1e304			SHLQ $0x4, BX																																																			
  game-collisions.go:224	0x9f60f5		488b8290080000			MOVQ 0x890(DX), AX																																																		
  game-collisions.go:224	0x9f60fc		0f1f4000			NOPL 0(AX)																																																			
  game-collisions.go:224	0x9f6100		e87b84a9ff			CALL runtime.memclrHasPointers(SB)																																																
  game-collisions.go:225	0x9f6105		488b942498020000		MOVQ 0x298(SP), DX																																																		
  game-collisions.go:225	0x9f610d		48c7829808000000000000		MOVQ $0x0, 0x898(DX)																																																		
  game-collisions.go:226	0x9f6118		488b9ac8080000			MOVQ 0x8c8(DX), BX																																																		
  game-collisions.go:226	0x9f611f		90				NOPL																																																				
  game-collisions.go:226	0x9f6120		4885db				TESTQ BX, BX																																																			
  game-collisions.go:226	0x9f6123		7418				JE 0x9f613d																																																			
  game-collisions.go:226	0x9f6125		48c1e303			SHLQ $0x3, BX																																																			
  game-collisions.go:226	0x9f6129		488b82c0080000			MOVQ 0x8c0(DX), AX																																																		
  game-collisions.go:226	0x9f6130		e84b84a9ff			CALL runtime.memclrHasPointers(SB)																																																
  game-collisions.go:227	0x9f6135		488b942498020000		MOVQ 0x298(SP), DX																																																		
  game-collisions.go:227	0x9f613d		48c782c808000000000000		MOVQ $0x0, 0x8c8(DX)																																																		
  game-collisions.go:228	0x9f6148		48ff02				INCQ 0(DX)																																																			
  game-collisions.go:229	0x9f614b		48c78424a000000000000000	MOVQ $0x0, 0xa0(SP)																																																		
  game-collisions.go:230	0x9f6157		c644244700			MOVB $0x0, 0x47(SP)																																																		
  game-collisions.go:232	0x9f615c		488d35dd8d0000			LEAQ github.com/burntcustard/unicorn-mining-co/src/server/gameplay.(*GameCollisions).Step.func1(SB), SI																																								
  game-collisions.go:232	0x9f6163		4889b42468020000		MOVQ SI, 0x268(SP)																																																		
  game-collisions.go:232	0x9f616b		4889942470020000		MOVQ DX, 0x270(SP)																																																		
  game-collisions.go:232	0x9f6173		488d9424a0000000		LEAQ 0xa0(SP), DX																																																		
  game-collisions.go:232	0x9f617b		4889942478020000		MOVQ DX, 0x278(SP)																																																		
  game-collisions.go:232	0x9f6183		488d542447			LEAQ 0x47(SP), DX																																																		
  game-collisions.go:232	0x9f6188		4889942480020000		MOVQ DX, 0x280(SP)																																																		
  game-collisions.go:232	0x9f6190		488b8424a0020000		MOVQ 0x2a0(SP), AX																																																		
  game-collisions.go:232	0x9f6198		488d1d015f1800			LEAQ github.com/burntcustard/unicorn-mining-co/src/server/utilities..dict.OrderedMap[int64,github.com/burntcustard/unicorn-mining-co/src/server/simulation.Entity](SB), BX																															
  game-collisions.go:232	0x9f619f		488d8c2468020000		LEAQ 0x268(SP), CX																																																		
  game-collisions.go:232	0x9f61a7		e814eac0ff			CALL github.com/burntcustard/unicorn-mining-co/src/server/utilities.(*OrderedMap[go.shape.int64,go.shape.interface { Base() *github.com/burntcustard/unicorn-mining-co/src/server/simulation.GameObject; Hitbox() []*github.com/burntcustard/unicorn-mining-co/src/server/collision.Collider; MaxSpeed() float64; Update(float64) }]).ForEach(SB)										
  game-collisions.go:250	0x9f61ac		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:250	0x9f61b4		488b9090080000			MOVQ 0x890(AX), DX																																																		
  game-collisions.go:250	0x9f61bb		4889942430010000		MOVQ DX, 0x130(SP)																																																		
  game-collisions.go:250	0x9f61c3		488bb098080000			MOVQ 0x898(AX), SI																																																		
  game-collisions.go:250	0x9f61ca		4889742450			MOVQ SI, 0x50(SP)																																																		
  game-collisions.go:252	0x9f61cf		807c244700			CMPB 0x47(SP), $0x0																																																		
  game-collisions.go:252	0x9f61d4		7522				JNE 0x9f61f8																																																			
  game-collisions.go:252	0x9f61d6		4c8b9870080000			MOVQ 0x870(AX), R11																																																		
  ordered-map.go:50		0x9f61dd		4d8b5b20			MOVQ 0x20(R11), R11																																																		
  ordered-map.go:50		0x9f61e1		4d85db				TESTQ R11, R11																																																			
  ordered-map.go:50		0x9f61e4		7405				JE 0x9f61eb																																																			
  ordered-map.go:50		0x9f61e6		4d8b1b				MOVQ 0(R11), R11																																																		
  ordered-map.go:50		0x9f61e9		eb03				JMP 0x9f61ee																																																			
  ordered-map.go:50		0x9f61eb		4531db				XORL R11, R11																																																			
  game-collisions.go:252	0x9f61ee		4c399c24a0000000		CMPQ 0xa0(SP), R11																																																		
  game-collisions.go:252	0x9f61f6		7457				JE 0x9f624f																																																			
  game-collisions.go:253	0x9f61f8		488d15618c0000			LEAQ github.com/burntcustard/unicorn-mining-co/src/server/gameplay.(*GameCollisions).Step.func2(SB), DX																																								
  game-collisions.go:253	0x9f61ff		4889942450020000		MOVQ DX, 0x250(SP)																																																		
  game-collisions.go:253	0x9f6207		4889842458020000		MOVQ AX, 0x258(SP)																																																		
  game-collisions.go:253	0x9f620f		488b9424a0020000		MOVQ 0x2a0(SP), DX																																																		
  game-collisions.go:253	0x9f6217		4889942460020000		MOVQ DX, 0x260(SP)																																																		
  game-collisions.go:253	0x9f621f		488b8070080000			MOVQ 0x870(AX), AX																																																		
  game-collisions.go:253	0x9f6226		488d1db3641800			LEAQ github.com/burntcustard/unicorn-mining-co/src/server/utilities..dict.OrderedMap[int64,*github.com/burntcustard/unicorn-mining-co/src/server/gameplay.BodyRecord](SB), BX																															
  game-collisions.go:253	0x9f622d		488d8c2450020000		LEAQ 0x250(SP), CX																																																		
  game-collisions.go:253	0x9f6235		e806a10000			CALL github.com/burntcustard/unicorn-mining-co/src/server/utilities.(*OrderedMap[go.shape.int64,go.shape.*uint8]).ForEach(SB)																																					
  game-collisions.go:267	0x9f623a		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:270	0x9f6242		488b942430010000		MOVQ 0x130(SP), DX																																																		
  game-collisions.go:270	0x9f624a		488b742450			MOVQ 0x50(SP), SI																																																		
  game-collisions.go:267	0x9f624f		488b98b0080000			MOVQ 0x8b0(AX), BX																																																		
  game-collisions.go:267	0x9f6256		4885db				TESTQ BX, BX																																																			
  game-collisions.go:267	0x9f6259		7425				JE 0x9f6280																																																			
  game-collisions.go:267	0x9f625b		48c1e303			SHLQ $0x3, BX																																																			
  game-collisions.go:267	0x9f625f		488b80a8080000			MOVQ 0x8a8(AX), AX																																																		
  game-collisions.go:267	0x9f6266		e81583a9ff			CALL runtime.memclrHasPointers(SB)																																																
  game-collisions.go:268	0x9f626b		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:270	0x9f6273		488b942430010000		MOVQ 0x130(SP), DX																																																		
  game-collisions.go:270	0x9f627b		488b742450			MOVQ 0x50(SP), SI																																																		
  game-collisions.go:268	0x9f6280		48c780b008000000000000		MOVQ $0x0, 0x8b0(AX)																																																		
  game-collisions.go:286	0x9f628b		f20f101dcd351700		MOVSD_XMM $f64.3ff0000000000000(SB), X3																																																
  game-collisions.go:286	0x9f6293		f20f10a424a8020000		MOVSD_XMM 0x2a8(SP), X4																																																		
  game-collisions.go:286	0x9f629c		f20f5edc			DIVSD X4, X3																																																			
  game-collisions.go:286	0x9f62a0		f20f119c24e0000000		MOVSD_XMM X3, 0xe0(SP)																																																		
  game-collisions.go:286	0x9f62a9		31c9				XORL CX, CX																																																			
  game-collisions.go:270	0x9f62ab		eb3b				JMP 0x9f62e8																																																			
  game-collisions.go:270	0x9f62ad		660f1f840000000000		NOPW 0(AX)(AX*1)																																																		
  game-collisions.go:270	0x9f62b6		660f1f840000000000		NOPW 0(AX)(AX*1)																																																		
  game-collisions.go:270	0x9f62bf		90				NOPL																																																				
  game-collisions.go:303	0x9f62c0		48897cdaf8			MOVQ DI, -0x8(DX)(BX*8)																																																		
  game-collisions.go:270	0x9f62c5		488b942400020000		MOVQ 0x200(SP), DX																																																		
  game-collisions.go:270	0x9f62cd		4883c210			ADDQ $0x10, DX																																																			
  game-collisions.go:270	0x9f62d1		488b8c24b0000000		MOVQ 0xb0(SP), CX																																																		
  game-collisions.go:270	0x9f62d9		48ffc1				INCQ CX																																																				
  game-collisions.go:270	0x9f62dc		488b742450			MOVQ 0x50(SP), SI																																																		
  vector.go:26			0x9f62e1		410f10da			MOVUPS X10, X3																																																			
  game-collisions.go:285	0x9f62e5		0f10e7				MOVUPS X7, X4																																																			
  game-collisions.go:270	0x9f62e8		4839f1				CMPQ CX, SI																																																			
  game-collisions.go:270	0x9f62eb		0f8d41040000			JGE 0x9f6732																																																			
  game-collisions.go:271	0x9f62f1		488b98c8080000			MOVQ 0x8c8(AX), BX																																																		
  game-collisions.go:271	0x9f62f8		0f1f840000000000		NOPL 0(AX)(AX*1)																																																		
  game-collisions.go:271	0x9f6300		4839d9				CMPQ CX, BX																																																			
  game-collisions.go:271	0x9f6303		0f83a91b0000			JAE 0x9f7eb2																																																			
  game-collisions.go:270	0x9f6309		48898c24b0000000		MOVQ CX, 0xb0(SP)																																																		
  game-collisions.go:270	0x9f6311		4889942400020000		MOVQ DX, 0x200(SP)																																																		
  game-collisions.go:270	0x9f6319		488b1a				MOVQ 0(DX), BX																																																			
  game-collisions.go:270	0x9f631c		48899c24c8000000		MOVQ BX, 0xc8(SP)																																																		
  game-collisions.go:270	0x9f6324		488b5208			MOVQ 0x8(DX), DX																																																		
  game-collisions.go:270	0x9f6328		4889942490010000		MOVQ DX, 0x190(SP)																																																		
  game-collisions.go:271	0x9f6330		488bb0c0080000			MOVQ 0x8c0(AX), SI																																																		
  game-collisions.go:271	0x9f6337		488b0cce			MOVQ 0(SI)(CX*8), CX																																																		
  game-collisions.go:271	0x9f633b		48898c2450010000		MOVQ CX, 0x150(SP)																																																		
  game-collisions.go:272	0x9f6343		488b4b18			MOVQ 0x18(BX), CX																																																		
  game-collisions.go:272	0x9f6347		4889d0				MOVQ DX, AX																																																			
  game-collisions.go:272	0x9f634a		ffd1				CALL CX																																																				
  game-collisions.go:272	0x9f634c		4889842470010000		MOVQ AX, 0x170(SP)																																																		
  game-collisions.go:274	0x9f6354		488bbc2450010000		MOVQ 0x150(SP), DI																																																		
  game-collisions.go:274	0x9f635c		0f1f4000			NOPL 0(AX)																																																			
  game-collisions.go:274	0x9f6360		4885ff				TESTQ DI, DI																																																			
  game-collisions.go:274	0x9f6363		7445				JE 0x9f63aa																																																			
  game-collisions.go:274	0x9f6365		488b5718			MOVQ 0x18(DI), DX																																																		
  game-collisions.go:274	0x9f6369		488b9c24c8000000		MOVQ 0xc8(SP), BX																																																		
  game-collisions.go:274	0x9f6371		4839da				CMPQ DX, BX																																																			
  game-collisions.go:274	0x9f6374		7404				JE 0x9f637a																																																			
  game-collisions.go:274	0x9f6376		31c9				XORL CX, CX																																																			
  game-collisions.go:274	0x9f6378		eb3a				JMP 0x9f63b4																																																			
  game-collisions.go:274	0x9f637a		488b5f20			MOVQ 0x20(DI), BX																																																		
  game-collisions.go:274	0x9f637e		4889d0				MOVQ DX, AX																																																			
  game-collisions.go:274	0x9f6381		488b8c2490010000		MOVQ 0x190(SP), CX																																																		
  game-collisions.go:274	0x9f6389		e8b209a2ff			CALL runtime.ifaceeq(SB)																																																	
  game-collisions.go:295	0x9f638e		488b9c24c8000000		MOVQ 0xc8(SP), BX																																																		
  game-collisions.go:274	0x9f6396		488bbc2450010000		MOVQ 0x150(SP), DI																																																		
  game-collisions.go:274	0x9f639e		89c1				MOVL AX, CX																																																			
  game-collisions.go:274	0x9f63a0		488b842470010000		MOVQ 0x170(SP), AX																																																		
  game-collisions.go:274	0x9f63a8		eb0a				JMP 0x9f63b4																																																			
  game-collisions.go:295	0x9f63aa		488b9c24c8000000		MOVQ 0xc8(SP), BX																																																		
  game-collisions.go:295	0x9f63b2		31c9				XORL CX, CX																																																			
  game-collisions.go:274	0x9f63b4		84c9				TESTL CL, CL																																																			
  game-collisions.go:274	0x9f63b6		745c				JE 0x9f6414																																																			
  game-collisions.go:274	0x9f63b8		488b5710			MOVQ 0x10(DI), DX																																																		
  game-collisions.go:274	0x9f63bc		807a2a00			CMPB 0x2a(DX), $0x0																																																		
  game-collisions.go:274	0x9f63c0		7452				JE 0x9f6414																																																			
  game-collisions.go:274	0x9f63c2		48837f7000			CMPQ 0x70(DI), $0x0																																																		
  game-collisions.go:274	0x9f63c7		744b				JE 0x9f6414																																																			
  game-collisions.go:274	0x9f63c9		488b9088000000			MOVQ 0x88(AX), DX																																																		
  game-collisions.go:274	0x9f63d0		4c8b9880000000			MOVQ 0x80(AX), R11																																																		
  game-collisions.go:274	0x9f63d7		4883fa08			CMPQ DX, $0x8																																																			
  game-collisions.go:274	0x9f63db		750f				JNE 0x9f63ec																																																			
  game-collisions.go:274	0x9f63dd		49bc61737465726f6964		MOVQ $0x64696f7265747361, R12																																																	
  game-collisions.go:274	0x9f63e7		4d3923				CMPQ 0(R11), R12																																																		
  game-collisions.go:274	0x9f63ea		741f				JE 0x9f640b																																																			
  game-collisions.go:274	0x9f63ec		4883fa07			CMPQ DX, $0x7																																																			
  game-collisions.go:274	0x9f63f0		7522				JNE 0x9f6414																																																			
  game-collisions.go:274	0x9f63f2		41813b73746174			CMPL 0(R11), $0x74617473																																																	
  game-collisions.go:274	0x9f63f9		7519				JNE 0x9f6414																																																			
  game-collisions.go:274	0x9f63fb		6641817b04696f			CMPW 0x4(R11), $0x6f69																																																		
  game-collisions.go:274	0x9f6402		7510				JNE 0x9f6414																																																			
  game-collisions.go:274	0x9f6404		41807b066e			CMPB 0x6(R11), $0x6e																																																		
  game-collisions.go:274	0x9f6409		7509				JNE 0x9f6414																																																			
  game-collisions.go:275	0x9f640b		c687d800000001			MOVB $0x1, 0xd8(DI)																																																		
  game-collisions.go:275	0x9f6412		eb28				JMP 0x9f643c																																																			
  game-collisions.go:277	0x9f6414		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:277	0x9f641c		488b8c2490010000		MOVQ 0x190(SP), CX																																																		
  game-collisions.go:277	0x9f6424		e877290000			CALL github.com/burntcustard/unicorn-mining-co/src/server/gameplay.(*GameCollisions).syncRecord(SB)																																								
  game-collisions.go:295	0x9f6429		488b9c24c8000000		MOVQ 0xc8(SP), BX																																																		
  game-collisions.go:280	0x9f6431		4889c7				MOVQ AX, DI																																																			
  game-collisions.go:282	0x9f6434		488b842470010000		MOVQ 0x170(SP), AX																																																		
  game-collisions.go:280	0x9f643c		f20f109fa8000000		MOVSD_XMM 0xa8(DI), X3																																																		
  game-collisions.go:280	0x9f6444		f20f10a798000000		MOVSD_XMM 0x98(DI), X4																																																		
  game-collisions.go:280	0x9f644c		f20f10afa0000000		MOVSD_XMM 0xa0(DI), X5																																																		
  game-collisions.go:282	0x9f6454		f20f585850			ADDSD 0x50(AX), X3																																																		
  game-collisions.go:283	0x9f6459		48c7405000000000		MOVQ $0x0, 0x50(AX)																																																		
  game-collisions.go:285	0x9f6461		0f57f6				XORPS X6, X6																																																			
  game-collisions.go:285	0x9f6464		f20f10bc24a8020000		MOVSD_XMM 0x2a8(SP), X7																																																		
  game-collisions.go:285	0x9f646d		660f2ef7			UCOMISD X7, X6																																																			
  game-collisions.go:285	0x9f6471		7502				JNE 0x9f6475																																																			
  game-collisions.go:285	0x9f6473		7b57				JNP 0x9f64cc																																																			
  game-collisions.go:286	0x9f6475		f2440f104018			MOVSD_XMM 0x18(AX), X8																																																		
  game-collisions.go:286	0x9f647b		f2440f104820			MOVSD_XMM 0x20(AX), X9																																																		
  vector.go:24			0x9f6481		f2440f5cc4			SUBSD X4, X8																																																			
  vector.go:24			0x9f6486		f2440f5ccd			SUBSD X5, X9																																																			
  vector.go:26			0x9f648b		f2440f109424e0000000		MOVSD_XMM 0xe0(SP), X10																																																		
  vector.go:26			0x9f6495		f2450f59c2			MULSD X10, X8																																																			
  vector.go:26			0x9f649a		f2450f59ca			MULSD X10, X9																																																			
  game-collisions.go:286	0x9f649f		f2440f118780000000		MOVSD_XMM X8, 0x80(DI)																																																		
  game-collisions.go:286	0x9f64a8		f2440f118f88000000		MOVSD_XMM X9, 0x88(DI)																																																		
  game-collisions.go:287	0x9f64b1		f2440f104038			MOVSD_XMM 0x38(AX), X8																																																		
  game-collisions.go:287	0x9f64b7		f2440f5cc3			SUBSD X3, X8																																																			
  game-collisions.go:287	0x9f64bc		f2440f5ec7			DIVSD X7, X8																																																			
  game-collisions.go:287	0x9f64c1		f2440f118790000000		MOVSD_XMM X8, 0x90(DI)																																																		
  game-collisions.go:287	0x9f64ca		eb1d				JMP 0x9f64e9																																																			
  game-collisions.go:289	0x9f64cc		440f11bf80000000		MOVUPS X15, 0x80(DI)																																																		
  game-collisions.go:290	0x9f64d4		48c7879000000000000000		MOVQ $0x0, 0x90(DI)																																																		
  vector.go:26			0x9f64df		f2440f109424e0000000		MOVSD_XMM 0xe0(SP), X10																																																		
  game-collisions.go:293	0x9f64e9		f20f11a7b0000000		MOVSD_XMM X4, 0xb0(DI)																																																		
  game-collisions.go:293	0x9f64f1		f20f11afb8000000		MOVSD_XMM X5, 0xb8(DI)																																																		
  game-collisions.go:293	0x9f64f9		f20f119fc0000000		MOVSD_XMM X3, 0xc0(DI)																																																		
  game-collisions.go:295	0x9f6501		488d1590b27a00			LEAQ 0x7ab290(IP), DX																																																		
  game-collisions.go:295	0x9f6508		4839d3				CMPQ BX, DX																																																			
  game-collisions.go:295	0x9f650b		750a				JNE 0x9f6517																																																			
  game-collisions.go:295	0x9f650d		488b842490010000		MOVQ 0x190(SP), AX																																																		
  game-collisions.go:295	0x9f6515		eb05				JMP 0x9f651c																																																			
  game-collisions.go:295	0x9f6517		b800000000			MOVL $0x0, AX																																																			
  game-collisions.go:280	0x9f651c		4889bc2450010000		MOVQ DI, 0x150(SP)																																																		
  game-collisions.go:295	0x9f6524		0f8530010000			JNE 0x9f665a																																																			
  game-collisions.go:296	0x9f652a		48c787e800000000000000		MOVQ $0x0, 0xe8(DI)																																																		
  game-collisions.go:285	0x9f6535		660f2ef7			UCOMISD X7, X6																																																			
  game-collisions.go:298	0x9f6539		750b				JNE 0x9f6546																																																			
  game-collisions.go:298	0x9f653b		0f1f440000			NOPL 0(AX)(AX*1)																																																		
  game-collisions.go:298	0x9f6540		0f8b14010000			JNP 0x9f665a																																																			
  game-collisions.go:295	0x9f6546		4889842480010000		MOVQ AX, 0x180(SP)																																																		
  game-collisions.go:299	0x9f654e		488b00				MOVQ 0(AX), AX																																																			
  game-collisions.go:299	0x9f6551		f20f104008			MOVSD_XMM 0x8(AX), X0																																																		
  ease.go:7			0x9f6556		f20f100d22331700		MOVSD_XMM $f64.400921fb54442d18(SB), X1																																																
  ease.go:7			0x9f655e		f20f59c1			MULSD X1, X0																																																			
  ease.go:7			0x9f6562		e83953aeff			CALL math.Cos(SB)																																																		
  ease.go:7			0x9f6567		f20f100df1321700		MOVSD_XMM $f64.3ff0000000000000(SB), X1																																																
  ease.go:7			0x9f656f		f20f5cc8			SUBSD X0, X1																																																			
  ease.go:7			0x9f6573		f20f1005cd321700		MOVSD_XMM $f64.3fe0000000000000(SB), X0																																																
  ease.go:7			0x9f657b		f20f59c1			MULSD X1, X0																																																			
  ease.go:7			0x9f657f		f20f100df9321700		MOVSD_XMM $f64.400921fb54442d18(SB), X1																																																
  ease.go:7			0x9f6587		f20f59c1			MULSD X1, X0																																																			
  ease.go:7			0x9f658b		e81053aeff			CALL math.Cos(SB)																																																		
  game-collisions.go:299	0x9f6590		488b842450010000		MOVQ 0x150(SP), AX																																																		
  game-collisions.go:299	0x9f6598		f20f1088e0000000		MOVSD_XMM 0xe0(AX), X1																																																		
  ease.go:7			0x9f65a0		f20f1015b8321700		MOVSD_XMM $f64.3ff0000000000000(SB), X2																																																
  ease.go:7			0x9f65a8		f20f5cd0			SUBSD X0, X2																																																			
  ease.go:7			0x9f65ac		f20f101d94321700		MOVSD_XMM $f64.3fe0000000000000(SB), X3																																																
  ease.go:7			0x9f65b4		f20f59d3			MULSD X3, X2																																																			
  ease.go:7			0x9f65b8		f20f11542448			MOVSD_XMM X2, 0x48(SP)																																																		
  ease.go:7			0x9f65be		f20f1005ba321700		MOVSD_XMM $f64.400921fb54442d18(SB), X0																																																
  ease.go:7			0x9f65c6		f20f59c1			MULSD X1, X0																																																			
  ease.go:7			0x9f65ca		e8d152aeff			CALL math.Cos(SB)																																																		
  ease.go:7			0x9f65cf		f20f100d89321700		MOVSD_XMM $f64.3ff0000000000000(SB), X1																																																
  ease.go:7			0x9f65d7		f20f5cc8			SUBSD X0, X1																																																			
  ease.go:7			0x9f65db		f20f100565321700		MOVSD_XMM $f64.3fe0000000000000(SB), X0																																																
  ease.go:7			0x9f65e3		f20f59c1			MULSD X1, X0																																																			
  ease.go:7			0x9f65e7		f20f100d91321700		MOVSD_XMM $f64.400921fb54442d18(SB), X1																																																
  ease.go:7			0x9f65ef		f20f59c1			MULSD X1, X0																																																			
  ease.go:7			0x9f65f3		e8a852aeff			CALL math.Cos(SB)																																																		
  game-collisions.go:299	0x9f65f8		488b842480010000		MOVQ 0x180(SP), AX																																																		
  game-collisions.go:299	0x9f6600		488b00				MOVQ 0(AX), AX																																																			
  ease.go:7			0x9f6603		f20f100d55321700		MOVSD_XMM $f64.3ff0000000000000(SB), X1																																																
  ease.go:7			0x9f660b		f20f5cc8			SUBSD X0, X1																																																			
  ease.go:7			0x9f660f		f20f101531321700		MOVSD_XMM $f64.3fe0000000000000(SB), X2																																																
  ease.go:7			0x9f6617		f20f59ca			MULSD X2, X1																																																			
  game-collisions.go:299	0x9f661b		f20f105c2448			MOVSD_XMM 0x48(SP), X3																																																		
  game-collisions.go:299	0x9f6621		f20f5cd9			SUBSD X1, X3																																																			
  game-collisions.go:299	0x9f6625		f20f5998c8000000		MULSD 0xc8(AX), X3																																																		
  game-collisions.go:299	0x9f662d		f20f108c24a8020000		MOVSD_XMM 0x2a8(SP), X1																																																		
  game-collisions.go:299	0x9f6636		f20f5ed9			DIVSD X1, X3																																																			
  game-collisions.go:299	0x9f663a		488b842450010000		MOVQ 0x150(SP), AX																																																		
  game-collisions.go:299	0x9f6642		f20f1198e8000000		MOVSD_XMM X3, 0xe8(AX)																																																		
  game-collisions.go:303	0x9f664a		4889c7				MOVQ AX, DI																																																			
  game-collisions.go:285	0x9f664d		0f10f9				MOVUPS X1, X7																																																			
  vector.go:26			0x9f6650		f2440f109424e0000000		MOVSD_XMM 0xe0(SP), X10																																																		
  game-collisions.go:303	0x9f665a		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:303	0x9f6662		488b88b8080000			MOVQ 0x8b8(AX), CX																																																		
  game-collisions.go:303	0x9f6669		488b98b0080000			MOVQ 0x8b0(AX), BX																																																		
  game-collisions.go:303	0x9f6670		48ffc3				INCQ BX																																																				
  game-collisions.go:303	0x9f6673		488b90a8080000			MOVQ 0x8a8(AX), DX																																																		
  game-collisions.go:303	0x9f667a		4839d9				CMPQ CX, BX																																																			
  game-collisions.go:303	0x9f667d		736f				JAE 0x9f66ee																																																			
  game-collisions.go:303	0x9f667f		4889d0				MOVQ DX, AX																																																			
  game-collisions.go:303	0x9f6682		bf01000000			MOVL $0x1, DI																																																			
  game-collisions.go:303	0x9f6687		488d3542186b00			LEAQ 0x6b1842(IP), SI																																																		
  game-collisions.go:303	0x9f668e		e8edbfa9ff			CALL runtime.growslice(SB)																																																	
  game-collisions.go:303	0x9f6693		488b942498020000		MOVQ 0x298(SP), DX																																																		
  game-collisions.go:303	0x9f669b		48898ab8080000			MOVQ CX, 0x8b8(DX)																																																		
  game-collisions.go:303	0x9f66a2		833db7ce840000			CMPL runtime.writeBarrier(SB), $0x0																																																
  game-collisions.go:303	0x9f66a9		7416				JE 0x9f66c1																																																			
  game-collisions.go:303	0x9f66ab		4c8b9aa8080000			MOVQ 0x8a8(DX), R11																																																		
  game-collisions.go:303	0x9f66b2		4c89d9				MOVQ R11, CX																																																			
  game-collisions.go:303	0x9f66b5		e8660caaff			CALL runtime.gcWriteBarrier2(SB)																																																
  game-collisions.go:303	0x9f66ba		498903				MOVQ AX, 0(R11)																																																			
  game-collisions.go:303	0x9f66bd		49894b08			MOVQ CX, 0x8(R11)																																																		
  game-collisions.go:303	0x9f66c1		488982a8080000			MOVQ AX, 0x8a8(DX)																																																		
  game-collisions.go:303	0x9f66c8		488bbc2450010000		MOVQ 0x150(SP), DI																																																		
  game-collisions.go:285	0x9f66d0		f20f10bc24a8020000		MOVSD_XMM 0x2a8(SP), X7																																																		
  vector.go:26			0x9f66d9		f2440f109424e0000000		MOVSD_XMM 0xe0(SP), X10																																																		
  game-collisions.go:303	0x9f66e3		4889c2				MOVQ AX, DX																																																			
  game-collisions.go:303	0x9f66e6		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:303	0x9f66ee		488998b0080000			MOVQ BX, 0x8b0(AX)																																																		
  game-collisions.go:303	0x9f66f5		833d64ce840000			CMPL runtime.writeBarrier(SB), $0x0																																																
  game-collisions.go:303	0x9f66fc		0f1f4000			NOPL 0(AX)																																																			
  game-collisions.go:303	0x9f6700		0f84bafbffff			JE 0x9f62c0																																																			
  game-collisions.go:303	0x9f6706		4c8b5cdaf8			MOVQ -0x8(DX)(BX*8), R11																																																	
  game-collisions.go:303	0x9f670b		4c89d9				MOVQ R11, CX																																																			
  game-collisions.go:303	0x9f670e		e80d0caaff			CALL runtime.gcWriteBarrier2(SB)																																																
  game-collisions.go:303	0x9f6713		49893b				MOVQ DI, 0(R11)																																																			
  game-collisions.go:303	0x9f6716		49894b08			MOVQ CX, 0x8(R11)																																																		
  game-collisions.go:285	0x9f671a		f20f10bc24a8020000		MOVSD_XMM 0x2a8(SP), X7																																																		
  vector.go:26			0x9f6723		f2440f109424e0000000		MOVSD_XMM 0xe0(SP), X10																																																		
  game-collisions.go:303	0x9f672d		e98efbffff			JMP 0x9f62c0																																																			
  game-collisions.go:306	0x9f6732		488bb8b0080000			MOVQ 0x8b0(AX), DI																																																		
  game-collisions.go:306	0x9f6739		4889bc2498000000		MOVQ DI, 0x98(SP)																																																		
  game-collisions.go:306	0x9f6741		488b90a8080000			MOVQ 0x8a8(AX), DX																																																		
  game-collisions.go:306	0x9f6748		4889942478010000		MOVQ DX, 0x178(SP)																																																		
  game-collisions.go:578	0x9f6750		4839b810090000			CMPQ 0x910(AX), DI																																																		
  game-collisions.go:578	0x9f6757		0f8ddf000000			JGE 0x9f683c																																																			
  game-collisions.go:579	0x9f675d		488d0c3f			LEAQ 0(DI)(DI*1), CX																																																		
  game-collisions.go:579	0x9f6761		48898c2410010000		MOVQ CX, 0x110(SP)																																																		
  game-collisions.go:579	0x9f6769		488d0560de7200			LEAQ 0x72de60(IP), AX																																																		
  game-collisions.go:579	0x9f6770		4889cb				MOVQ CX, BX																																																			
  game-collisions.go:579	0x9f6773		e828bea9ff			CALL runtime.makeslice(SB)																																																	
  game-collisions.go:579	0x9f6778		488b942410010000		MOVQ 0x110(SP), DX																																																		
  game-collisions.go:579	0x9f6780		488bb42498020000		MOVQ 0x298(SP), SI																																																		
  game-collisions.go:579	0x9f6788		48899610090000			MOVQ DX, 0x910(SI)																																																		
  game-collisions.go:579	0x9f678f		48899618090000			MOVQ DX, 0x918(SI)																																																		
  game-collisions.go:579	0x9f6796		833dc3cd840000			CMPL runtime.writeBarrier(SB), $0x0																																																
  game-collisions.go:579	0x9f679d		7413				JE 0x9f67b2																																																			
  game-collisions.go:579	0x9f679f		488b9608090000			MOVQ 0x908(SI), DX																																																		
  game-collisions.go:579	0x9f67a6		e8750baaff			CALL runtime.gcWriteBarrier2(SB)																																																
  game-collisions.go:579	0x9f67ab		498903				MOVQ AX, 0(R11)																																																			
  game-collisions.go:579	0x9f67ae		49895308			MOVQ DX, 0x8(R11)																																																		
  game-collisions.go:579	0x9f67b2		48898608090000			MOVQ AX, 0x908(SI)																																																		
  game-collisions.go:580	0x9f67b9		488b8c2498000000		MOVQ 0x98(SP), CX																																																		
  game-collisions.go:580	0x9f67c1		4889cb				MOVQ CX, BX																																																			
  game-collisions.go:580	0x9f67c4		48c1e303			SHLQ $0x3, BX																																																			
  game-collisions.go:580	0x9f67c8		48899c2410010000		MOVQ BX, 0x110(SP)																																																		
  game-collisions.go:580	0x9f67d0		488d05b9dd7200			LEAQ 0x72ddb9(IP), AX																																																		
  game-collisions.go:580	0x9f67d7		4889d9				MOVQ BX, CX																																																			
  game-collisions.go:580	0x9f67da		e8c1bda9ff			CALL runtime.makeslice(SB)																																																	
  game-collisions.go:580	0x9f67df		488b942410010000		MOVQ 0x110(SP), DX																																																		
  game-collisions.go:580	0x9f67e7		488bb42498020000		MOVQ 0x298(SP), SI																																																		
  game-collisions.go:580	0x9f67ef		488996e0080000			MOVQ DX, 0x8e0(SI)																																																		
  game-collisions.go:580	0x9f67f6		488996e8080000			MOVQ DX, 0x8e8(SI)																																																		
  game-collisions.go:580	0x9f67fd		833d5ccd840000			CMPL runtime.writeBarrier(SB), $0x0																																																
  game-collisions.go:580	0x9f6804		7413				JE 0x9f6819																																																			
  game-collisions.go:580	0x9f6806		488b96d8080000			MOVQ 0x8d8(SI), DX																																																		
  game-collisions.go:580	0x9f680d		e80e0baaff			CALL runtime.gcWriteBarrier2(SB)																																																
  game-collisions.go:580	0x9f6812		498903				MOVQ AX, 0(R11)																																																			
  game-collisions.go:580	0x9f6815		49895308			MOVQ DX, 0x8(R11)																																																		
  game-collisions.go:580	0x9f6819		488986d8080000			MOVQ AX, 0x8d8(SI)																																																		
  game-collisions.go:583	0x9f6820		4889f0				MOVQ SI, AX																																																			
  game-collisions.go:598	0x9f6823		488b942478010000		MOVQ 0x178(SP), DX																																																		
  game-collisions.go:586	0x9f682b		488bbc2498000000		MOVQ 0x98(SP), DI																																																		
  world.go:132			0x9f6833		f20f10a424a8020000		MOVSD_XMM 0x2a8(SP), X4																																																		
  game-collisions.go:583	0x9f683c		488b88f8080000			MOVQ 0x8f8(AX), CX																																																		
  game-collisions.go:583	0x9f6843		48894c2468			MOVQ CX, 0x68(SP)																																																		
  game-collisions.go:583	0x9f6848		4c8b9800090000			MOVQ 0x900(AX), R11																																																		
  game-collisions.go:583	0x9f684f		488b98f0080000			MOVQ 0x8f0(AX), BX																																																		
  game-collisions.go:586	0x9f6856		4839f9				CMPQ CX, DI																																																			
  game-collisions.go:586	0x9f6859		0f8f06010000			JG 0x9f6965																																																			
  game-collisions.go:589	0x9f685f		4989fc				MOVQ DI, R12																																																			
  game-collisions.go:589	0x9f6862		4929cc				SUBQ CX, R12																																																			
  slices.go:426			0x9f6865		4d89dd				MOVQ R11, R13																																																			
  slices.go:426			0x9f6868		4929cb				SUBQ CX, R11																																																			
  slices.go:426			0x9f686b		4d29dc				SUBQ R11, R12																																																			
  slices.go:426			0x9f686e		4d85e4				TESTQ R12, R12																																																			
  slices.go:426			0x9f6871		0f8ea3000000			JLE 0x9f691a																																																			
  slices.go:428			0x9f6877		4f8d042c			LEAQ 0(R12)(R13*1), R8																																																		
  slices.go:428			0x9f687b		0f1f440000			NOPL 0(AX)(AX*1)																																																		
  slices.go:428			0x9f6880		4d39c5				CMPQ R13, R8																																																			
  slices.go:428			0x9f6883		7331				JAE 0x9f68b6																																																			
  slices.go:426			0x9f6885		4c89a42490000000		MOVQ R12, 0x90(SP)																																																		
  slices.go:428			0x9f688d		4889d8				MOVQ BX, AX																																																			
  slices.go:428			0x9f6890		4c89c3				MOVQ R8, BX																																																			
  slices.go:428			0x9f6893		4c89e9				MOVQ R13, CX																																																			
  slices.go:428			0x9f6896		4c89e7				MOVQ R12, DI																																																			
  slices.go:428			0x9f6899		488d3570db7200			LEAQ 0x72db70(IP), SI																																																		
  slices.go:428			0x9f68a0		e8dbbda9ff			CALL runtime.growslice(SB)																																																	
  slices.go:428			0x9f68a5		4c8ba42490000000		MOVQ 0x90(SP), R12																																																		
  slices.go:428			0x9f68ad		4989cd				MOVQ CX, R13																																																			
  slices.go:428			0x9f68b0		4989d8				MOVQ BX, R8																																																			
  slices.go:428			0x9f68b3		4889c3				MOVQ AX, BX																																																			
  slices.go:428			0x9f68b6		4c896c2470			MOVQ R13, 0x70(SP)																																																		
  slices.go:428			0x9f68bb		48899c2438010000		MOVQ BX, 0x138(SP)																																																		
  slices.go:428			0x9f68c3		4d29e0				SUBQ R12, R8																																																			
  slices.go:428			0x9f68c6		4a8d04c3			LEAQ 0(BX)(R8*8), AX																																																		
  slices.go:428			0x9f68ca		49c1e403			SHLQ $0x3, R12																																																			
  slices.go:428			0x9f68ce		4c89e3				MOVQ R12, BX																																																			
  slices.go:428			0x9f68d1		e88a0eaaff			CALL runtime.memclrNoHeapPointers(SB)																																																
  slices.go:428			0x9f68d6		488b4c2470			MOVQ 0x70(SP), CX																																																		
  slices.go:428			0x9f68db		488b542468			MOVQ 0x68(SP), DX																																																		
  slices.go:428			0x9f68e0		4839d1				CMPQ CX, DX																																																			
  slices.go:428			0x9f68e3		0f82c4150000			JB 0x9f7ead																																																			
  game-collisions.go:589	0x9f68e9		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:589	0x9f68f1		4889d1				MOVQ DX, CX																																																			
  game-collisions.go:598	0x9f68f4		488b942478010000		MOVQ 0x178(SP), DX																																																		
  game-collisions.go:591	0x9f68fc		488bbc2498000000		MOVQ 0x98(SP), DI																																																		
  world.go:132			0x9f6904		f20f10a424a8020000		MOVSD_XMM 0x2a8(SP), X4																																																		
  game-collisions.go:589	0x9f690d		4c8b6c2470			MOVQ 0x70(SP), R13																																																		
  game-collisions.go:589	0x9f6912		488b9c2438010000		MOVQ 0x138(SP), BX																																																		
  game-collisions.go:589	0x9f691a		488988f8080000			MOVQ CX, 0x8f8(AX)																																																		
  game-collisions.go:589	0x9f6921		4c89a800090000			MOVQ R13, 0x900(AX)																																																		
  game-collisions.go:589	0x9f6928		833d31cc840000			CMPL runtime.writeBarrier(SB), $0x0																																																
  game-collisions.go:589	0x9f692f		7424				JE 0x9f6955																																																			
  game-collisions.go:589	0x9f6931		4c8b98f0080000			MOVQ 0x8f0(AX), R11																																																		
  game-collisions.go:589	0x9f6938		4c89de				MOVQ R11, SI																																																			
  game-collisions.go:589	0x9f693b		0f1f440000			NOPL 0(AX)(AX*1)																																																		
  game-collisions.go:589	0x9f6940		e8db09aaff			CALL runtime.gcWriteBarrier2(SB)																																																
  game-collisions.go:589	0x9f6945		49891b				MOVQ BX, 0(R11)																																																			
  game-collisions.go:589	0x9f6948		49897308			MOVQ SI, 0x8(R11)																																																		
  world.go:132			0x9f694c		f20f10a424a8020000		MOVSD_XMM 0x2a8(SP), X4																																																		
  game-collisions.go:589	0x9f6955		488998f0080000			MOVQ BX, 0x8f0(AX)																																																		
  game-collisions.go:583	0x9f695c		4889cb				MOVQ CX, BX																																																			
  game-collisions.go:583	0x9f695f		90				NOPL																																																				
  game-collisions.go:591	0x9f6960		e988140000			JMP 0x9f7ded																																																			
  game-collisions.go:587	0x9f6965		488d15d4840000			LEAQ github.com/burntcustard/unicorn-mining-co/src/server/gameplay.(*GameCollisions).findFree.func1(SB), DX																																							
  game-collisions.go:587	0x9f696c		4889942418010000		MOVQ DX, 0x118(SP)																																																		
  game-collisions.go:587	0x9f6974		4889bc2420010000		MOVQ DI, 0x120(SP)																																																		
  game-collisions.go:587	0x9f697c		488d055d9c1700			LEAQ slices..dict.DeleteFunc[[]int,int](SB), AX																																															
  game-collisions.go:587	0x9f6983		4c89df				MOVQ R11, DI																																																			
  game-collisions.go:587	0x9f6986		488db42418010000		LEAQ 0x118(SP), SI																																																		
  game-collisions.go:587	0x9f698e		e8edb40000			CALL slices.DeleteFunc[go.shape.[]int,go.shape.int](SB)																																														
  game-collisions.go:587	0x9f6993		488b942498020000		MOVQ 0x298(SP), DX																																																		
  game-collisions.go:587	0x9f699b		48899af8080000			MOVQ BX, 0x8f8(DX)																																																		
  game-collisions.go:587	0x9f69a2		48898a00090000			MOVQ CX, 0x900(DX)																																																		
  game-collisions.go:587	0x9f69a9		833db0cb840000			CMPL runtime.writeBarrier(SB), $0x0																																																
  game-collisions.go:587	0x9f69b0		741a				JE 0x9f69cc																																																			
  game-collisions.go:587	0x9f69b2		4c8b9af0080000			MOVQ 0x8f0(DX), R11																																																		
  game-collisions.go:587	0x9f69b9		4c89d9				MOVQ R11, CX																																																			
  game-collisions.go:587	0x9f69bc		0f1f4000			NOPL 0(AX)																																																			
  game-collisions.go:587	0x9f69c0		e85b09aaff			CALL runtime.gcWriteBarrier2(SB)																																																
  game-collisions.go:587	0x9f69c5		498903				MOVQ AX, 0(R11)																																																			
  game-collisions.go:587	0x9f69c8		49894b08			MOVQ CX, 0x8(R11)																																																		
  game-collisions.go:587	0x9f69cc		488982f0080000			MOVQ AX, 0x8f0(DX)																																																		
  game-collisions.go:596	0x9f69d3		4c8b9ae0080000			MOVQ 0x8e0(DX), R11																																																		
  game-collisions.go:596	0x9f69da		4c8ba2d8080000			MOVQ 0x8d8(DX), R12																																																		
  game-collisions.go:596	0x9f69e1		4c8baae8080000			MOVQ 0x8e8(DX), R13																																																		
  game-collisions.go:596	0x9f69e8		4c8bba10090000			MOVQ 0x910(DX), R15																																																		
  game-collisions.go:596	0x9f69ef		488b8208090000			MOVQ 0x908(DX), AX																																																		
  game-collisions.go:596	0x9f69f6		4c8b82f8080000			MOVQ 0x8f8(DX), R8																																																		
  game-collisions.go:596	0x9f69fd		488b9af0080000			MOVQ 0x8f0(DX), BX																																																		
  game-collisions.go:596	0x9f6a04		488bba00090000			MOVQ 0x900(DX), DI																																																		
  game-collisions.go:596	0x9f6a0b		4889bc2488000000		MOVQ DI, 0x88(SP)																																																		
  game-collisions.go:596	0x9f6a13		4c89e9				MOVQ R13, CX																																																			
  game-collisions.go:598	0x9f6a16		4531ed				XORL R13, R13																																																			
  game-collisions.go:598	0x9f6a19		488bb42498000000		MOVQ 0x98(SP), SI																																																		
  game-collisions.go:598	0x9f6a21		4c8b8c2478010000		MOVQ 0x178(SP), R9																																																		
  game-collisions.go:598	0x9f6a29		eb26				JMP 0x9f6a51																																																			
  game-collisions.go:598	0x9f6a2b		660f1f840000000000		NOPW 0(AX)(AX*1)																																																		
  game-collisions.go:598	0x9f6a34		660f1f840000000000		NOPW 0(AX)(AX*1)																																																		
  game-collisions.go:598	0x9f6a3d		0f1f00				NOPL 0(AX)																																																			
  game-collisions.go:605	0x9f6a40		42c6041001			MOVB $0x1, 0(AX)(R10*1)																																																		
  game-collisions.go:598	0x9f6a45		4d8d6a01			LEAQ 0x1(R10), R13																																																		
  sort.go:32			0x9f6a49		488bbc2488000000		MOVQ 0x88(SP), DI																																																		
  game-collisions.go:598	0x9f6a51		4939f5				CMPQ R13, SI																																																			
  game-collisions.go:598	0x9f6a54		0f8de4000000			JGE 0x9f6b3e																																																			
  game-collisions.go:598	0x9f6a5a		4f8b14e9			MOVQ 0(R9)(R13*8), R10																																																		
  game-collisions.go:599	0x9f6a5e		498b3a				MOVQ 0(R10), DI																																																			
  game-collisions.go:599	0x9f6a61		f20f105f18			MOVSD_XMM 0x18(DI), X3																																																		
  game-collisions.go:599	0x9f6a66		f20f106720			MOVSD_XMM 0x20(DI), X4																																																		
  game-collisions.go:599	0x9f6a6b		f2410f10aab0000000		MOVSD_XMM 0xb0(R10), X5																																																		
  game-collisions.go:599	0x9f6a74		f2410f10b2b8000000		MOVSD_XMM 0xb8(R10), X6																																																		
  game-collisions.go:600	0x9f6a7d		f20f5cdd			SUBSD X5, X3																																																			
  game-collisions.go:600	0x9f6a81		f20f5ce6			SUBSD X6, X4																																																			
  game-collisions.go:601	0x9f6a85		0f10fb				MOVUPS X3, X7																																																			
  game-collisions.go:601	0x9f6a88		f20f59db			MULSD X3, X3																																																			
  game-collisions.go:601	0x9f6a8c		440f10c4			MOVUPS X4, X8																																																			
  game-collisions.go:601	0x9f6a90		f20f59e4			MULSD X4, X4																																																			
  game-collisions.go:601	0x9f6a94		f20f58e3			ADDSD X3, X4																																																			
  game-collisions.go:603	0x9f6a98		f20f101da82d1700		MOVSD_XMM $f64.3fe0000000000000(SB), X3																																																
  game-collisions.go:603	0x9f6aa0		f20f59fb			MULSD X3, X7																																																			
  game-collisions.go:603	0x9f6aa4		f20f58ef			ADDSD X7, X5																																																			
  game-collisions.go:604	0x9f6aa8		4c89ef				MOVQ R13, DI																																																			
  game-collisions.go:604	0x9f6aab		49c1e502			SHLQ $0x2, R13																																																			
  sqrt.go:94			0x9f6aaf		f20f51e4			SQRTSD X4, X4																																																			
  game-collisions.go:602	0x9f6ab3		f2410f58a2c8000000		ADDSD 0xc8(R10), X4																																																		
  game-collisions.go:602	0x9f6abc		f20f58a220060000		ADDSD 0x620(DX), X4																																																		
  game-collisions.go:604	0x9f6ac4		0f10fd				MOVUPS X5, X7																																																			
  game-collisions.go:604	0x9f6ac7		f20f5cec			SUBSD X4, X5																																																			
  game-collisions.go:604	0x9f6acb		4d39eb				CMPQ R11, R13																																																			
  game-collisions.go:604	0x9f6ace		0f8605130000			JBE 0x9f7dd9																																																			
  game-collisions.go:604	0x9f6ad4		4989fa				MOVQ DI, R10																																																			
  game-collisions.go:604	0x9f6ad7		48c1e705			SHLQ $0x5, DI																																																			
  game-collisions.go:604	0x9f6adb		f2410f112c3c			MOVSD_XMM X5, 0(R12)(DI*1)																																																	
  game-collisions.go:604	0x9f6ae1		498d7d01			LEAQ 0x1(R13), DI																																																		
  game-collisions.go:604	0x9f6ae5		4939fb				CMPQ R11, DI																																																			
  game-collisions.go:604	0x9f6ae8		0f86e6120000			JBE 0x9f7dd4																																																			
  game-collisions.go:604	0x9f6aee		f2430f117cec08			MOVSD_XMM X7, 0x8(R12)(R13*8)																																																	
  game-collisions.go:604	0x9f6af5		498d7d02			LEAQ 0x2(R13), DI																																																		
  game-collisions.go:604	0x9f6af9		f2440f59c3			MULSD X3, X8																																																			
  game-collisions.go:604	0x9f6afe		f2410f58f0			ADDSD X8, X6																																																			
  game-collisions.go:604	0x9f6b03		4939fb				CMPQ R11, DI																																																			
  game-collisions.go:604	0x9f6b06		0f86c3120000			JBE 0x9f7dcf																																																			
  game-collisions.go:604	0x9f6b0c		f2430f1174ec10			MOVSD_XMM X6, 0x10(R12)(R13*8)																																																	
  game-collisions.go:604	0x9f6b13		498d7d03			LEAQ 0x3(R13), DI																																																		
  game-collisions.go:604	0x9f6b17		660f1f840000000000		NOPW 0(AX)(AX*1)																																																		
  game-collisions.go:604	0x9f6b20		4939fb				CMPQ R11, DI																																																			
  game-collisions.go:604	0x9f6b23		0f86a1120000			JBE 0x9f7dca																																																			
  game-collisions.go:604	0x9f6b29		f2430f1164ec18			MOVSD_XMM X4, 0x18(R12)(R13*8)																																																	
  game-collisions.go:605	0x9f6b30		4d39fa				CMPQ R10, R15																																																			
  game-collisions.go:605	0x9f6b33		0f8207ffffff			JB 0x9f6a40																																																			
  game-collisions.go:605	0x9f6b39		e987120000			JMP 0x9f7dc5																																																			
  game-collisions.go:596	0x9f6b3e		48899c2460010000		MOVQ BX, 0x160(SP)																																																		
  game-collisions.go:596	0x9f6b46		4c89842480000000		MOVQ R8, 0x80(SP)																																																		
  game-collisions.go:596	0x9f6b4e		4c89bc24c0000000		MOVQ R15, 0xc0(SP)																																																		
  game-collisions.go:596	0x9f6b56		4889842488010000		MOVQ AX, 0x188(SP)																																																		
  game-collisions.go:596	0x9f6b5e		4c899c24d0000000		MOVQ R11, 0xd0(SP)																																																		
  game-collisions.go:596	0x9f6b66		4c89a424d0010000		MOVQ R12, 0x1d0(SP)																																																		
  game-collisions.go:584	0x9f6b6e		4c8b6c2468			MOVQ 0x68(SP), R13																																																		
  game-collisions.go:584	0x9f6b73		4d85ed				TESTQ R13, R13																																																			
  game-collisions.go:608	0x9f6b76		740d				JE 0x9f6b85																																																			
  game-collisions.go:608	0x9f6b78		41ba01000000			MOVL $0x1, R10																																																			
  game-collisions.go:608	0x9f6b7e		6690				NOPW																																																				
  game-collisions.go:608	0x9f6b80		e986110000			JMP 0x9f7d0b																																																			
  game-collisions.go:622	0x9f6b85		488d1534820000			LEAQ github.com/burntcustard/unicorn-mining-co/src/server/gameplay.(*GameCollisions).findFree.func2(SB), DX																																							
  game-collisions.go:622	0x9f6b8c		4889942410020000		MOVQ DX, 0x210(SP)																																																		
  game-collisions.go:622	0x9f6b94		4c899c2420020000		MOVQ R11, 0x220(SP)																																																		
  game-collisions.go:622	0x9f6b9c		48898c2428020000		MOVQ CX, 0x228(SP)																																																		
  game-collisions.go:622	0x9f6ba4		4c89a42418020000		MOVQ R12, 0x218(SP)																																																		
  sort.go:32			0x9f6bac		488d05ad001800			LEAQ slices..dict.pdqsortCmpFunc[int](SB), AX																																															
  sort.go:32			0x9f6bb3		4d0fbdc8			BSRQ R8, R9																																																			
  sort.go:32			0x9f6bb7		48c7c2ffffffff			MOVQ $-0x1, DX																																																			
  sort.go:32			0x9f6bbe		4c0f44ca			CMOVE DX, R9																																																			
  sort.go:32			0x9f6bc2		49ffc1				INCQ R9																																																				
  sort.go:32			0x9f6bc5		4c89c1				MOVQ R8, CX																																																			
  sort.go:32			0x9f6bc8		31f6				XORL SI, SI																																																			
  sort.go:32			0x9f6bca		4c8d942410020000		LEAQ 0x210(SP), R10																																																		
  sort.go:32			0x9f6bd2		e8099c0000			CALL slices.pdqsortCmpFunc[go.shape.int](SB)																																															
  game-collisions.go:635	0x9f6bd7		31d2				XORL DX, DX																																																			
  game-collisions.go:635	0x9f6bd9		4c8b8c2498000000		MOVQ 0x98(SP), R9																																																		
  game-collisions.go:635	0x9f6be1		4c8b942480000000		MOVQ 0x80(SP), R10																																																		
  game-collisions.go:635	0x9f6be9		4c8b9c2460010000		MOVQ 0x160(SP), R11																																																		
  game-collisions.go:635	0x9f6bf1		4c8ba42478010000		MOVQ 0x178(SP), R12																																																		
  game-collisions.go:635	0x9f6bf9		4c8bac24d0000000		MOVQ 0xd0(SP), R13																																																		
  game-collisions.go:635	0x9f6c01		4c8bbc24d0010000		MOVQ 0x1d0(SP), R15																																																		
  game-collisions.go:635	0x9f6c09		eb03				JMP 0x9f6c0e																																																			
  game-collisions.go:635	0x9f6c0b		48ffc2				INCQ DX																																																				
  game-collisions.go:635	0x9f6c0e		4c39ca				CMPQ DX, R9																																																			
  game-collisions.go:635	0x9f6c11		0f8d1b020000			JGE 0x9f6e32																																																			
  game-collisions.go:635	0x9f6c17		660f1f840000000000		NOPW 0(AX)(AX*1)																																																		
  game-collisions.go:637	0x9f6c20		4c39d2				CMPQ DX, R10																																																			
  game-collisions.go:637	0x9f6c23		0f83cb100000			JAE 0x9f7cf4																																																			
  game-collisions.go:637	0x9f6c29		498b04d3			MOVQ 0(R11)(DX*8), AX																																																		
  game-collisions.go:637	0x9f6c2d		4c39c8				CMPQ AX, R9																																																			
  game-collisions.go:637	0x9f6c30		0f83b9100000			JAE 0x9f7cef																																																			
  game-collisions.go:637	0x9f6c36		498b0cc4			MOVQ 0(R12)(AX*8), CX																																																		
  game-collisions.go:637	0x9f6c3a		488b19				MOVQ 0(CX), BX																																																			
  game-collisions.go:637	0x9f6c3d		80bb9000000000			CMPB 0x90(BX), $0x0																																																		
  game-collisions.go:637	0x9f6c44		7523				JNE 0x9f6c69																																																			
  game-collisions.go:637	0x9f6c46		4883793000			CMPQ 0x30(CX), $0x0																																																		
  game-collisions.go:637	0x9f6c4b		751c				JNE 0x9f6c69																																																			
  game-collisions.go:637	0x9f6c4d		4883b9d000000000		CMPQ 0xd0(CX), $0x0																																																		
  game-collisions.go:637	0x9f6c55		7512				JNE 0x9f6c69																																																			
  game-collisions.go:655	0x9f6c57		488bb424c0000000		MOVQ 0xc0(SP), SI																																																		
  game-collisions.go:655	0x9f6c5f		488bbc2488010000		MOVQ 0x188(SP), DI																																																		
  game-collisions.go:638	0x9f6c67		eba2				JMP 0x9f6c0b																																																			
  game-collisions.go:641	0x9f6c69		48c1e002			SHLQ $0x2, AX																																																			
  game-collisions.go:642	0x9f6c6d		488d4801			LEAQ 0x1(AX), CX																																																		
  game-collisions.go:642	0x9f6c71		4939cd				CMPQ R13, CX																																																			
  game-collisions.go:642	0x9f6c74		0f8670100000			JBE 0x9f7cea																																																			
  game-collisions.go:642	0x9f6c7a		488d4803			LEAQ 0x3(AX), CX																																																		
  game-collisions.go:642	0x9f6c7e		f2410f105cc708			MOVSD_XMM 0x8(R15)(AX*8), X3																																																	
  game-collisions.go:642	0x9f6c85		4939cd				CMPQ R13, CX																																																			
  game-collisions.go:642	0x9f6c88		0f8657100000			JBE 0x9f7ce5																																																			
  game-collisions.go:642	0x9f6c8e		f2410f585cc718			ADDSD 0x18(R15)(AX*8), X3																																																	
  game-collisions.go:644	0x9f6c95		488d4a01			LEAQ 0x1(DX), CX																																																		
  game-collisions.go:659	0x9f6c99		488d5802			LEAQ 0x2(AX), BX																																																		
  game-collisions.go:644	0x9f6c9d		488bb424c0000000		MOVQ 0xc0(SP), SI																																																		
  game-collisions.go:644	0x9f6ca5		488bbc2488010000		MOVQ 0x188(SP), DI																																																		
  game-collisions.go:644	0x9f6cad		eb31				JMP 0x9f6ce0																																																			
  game-collisions.go:644	0x9f6caf		660f1f840000000000		NOPW 0(AX)(AX*1)																																																		
  game-collisions.go:644	0x9f6cb8		0f1f840000000000		NOPL 0(AX)(AX*1)																																																		
  game-collisions.go:644	0x9f6cc0		48ffc1				INCQ CX																																																				
  game-collisions.go:644	0x9f6cc3		4c8b8c2498000000		MOVQ 0x98(SP), R9																																																		
  game-collisions.go:645	0x9f6ccb		4c8b942480000000		MOVQ 0x80(SP), R10																																																		
  game-collisions.go:651	0x9f6cd3		4c8ba42478010000		MOVQ 0x178(SP), R12																																																		
  game-collisions.go:651	0x9f6cdb		0f1f440000			NOPL 0(AX)(AX*1)																																																		
  game-collisions.go:644	0x9f6ce0		4c39c9				CMPQ CX, R9																																																			
  game-collisions.go:644	0x9f6ce3		0f8d22ffffff			JGE 0x9f6c0b																																																			
  game-collisions.go:645	0x9f6ce9		4c39d1				CMPQ CX, R10																																																			
  game-collisions.go:645	0x9f6cec		0f83ec0f0000			JAE 0x9f7cde																																																			
  game-collisions.go:645	0x9f6cf2		4d8b04cb			MOVQ 0(R11)(CX*8), R8																																																		
  game-collisions.go:645	0x9f6cf6		4c89842410010000		MOVQ R8, 0x110(SP)																																																		
  game-collisions.go:645	0x9f6cfe		49c1e002			SHLQ $0x2, R8																																																			
  game-collisions.go:647	0x9f6d02		4d39c5				CMPQ R13, R8																																																			
  game-collisions.go:647	0x9f6d05		0f86ce0f0000			JBE 0x9f7cd9																																																			
  game-collisions.go:647	0x9f6d0b		4c8b942410010000		MOVQ 0x110(SP), R10																																																		
  game-collisions.go:647	0x9f6d13		49c1e205			SHLQ $0x5, R10																																																			
  game-collisions.go:647	0x9f6d17		f2430f102417			MOVSD_XMM 0(R15)(R10*1), X4																																																	
  game-collisions.go:647	0x9f6d1d		660f2ee3			UCOMISD X3, X4																																																			
  game-collisions.go:647	0x9f6d21		0f87fe000000			JA 0x9f6e25																																																			
  game-collisions.go:651	0x9f6d27		4c8b942410010000		MOVQ 0x110(SP), R10																																																		
  game-collisions.go:651	0x9f6d2f		4d39ca				CMPQ R10, R9																																																			
  game-collisions.go:651	0x9f6d32		0f839c0f0000			JAE 0x9f7cd4																																																			
  game-collisions.go:651	0x9f6d38		4f8b24d4			MOVQ 0(R12)(R10*8), R12																																																		
  game-collisions.go:651	0x9f6d3c		4d8b0c24			MOVQ 0(R12), R9																																																			
  game-collisions.go:651	0x9f6d40		4180b99000000000		CMPB 0x90(R9), $0x0																																																		
  game-collisions.go:651	0x9f6d48		751c				JNE 0x9f6d66																																																			
  game-collisions.go:651	0x9f6d4a		49837c243000			CMPQ 0x30(R12), $0x0																																																		
  game-collisions.go:651	0x9f6d50		7514				JNE 0x9f6d66																																																			
  game-collisions.go:651	0x9f6d52		4983bc24d000000000		CMPQ 0xd0(R12), $0x0																																																		
  game-collisions.go:651	0x9f6d5b		0f1f440000			NOPL 0(AX)(AX*1)																																																		
  game-collisions.go:651	0x9f6d60		0f845affffff			JE 0x9f6cc0																																																			
  game-collisions.go:655	0x9f6d66		4d8b0cd3			MOVQ 0(R11)(DX*8), R9																																																		
  game-collisions.go:655	0x9f6d6a		4939f1				CMPQ R9, SI																																																			
  game-collisions.go:655	0x9f6d6d		0f835c0f0000			JAE 0x9f7ccf																																																			
  game-collisions.go:655	0x9f6d73		460fb6240f			MOVZX 0(DI)(R9*1), R12																																																		
  game-collisions.go:655	0x9f6d78		4584e4				TESTL R12, R12																																																			
  game-collisions.go:655	0x9f6d7b		751a				JNE 0x9f6d97																																																			
  game-collisions.go:655	0x9f6d7d		0f1f00				NOPL 0(AX)																																																			
  game-collisions.go:655	0x9f6d80		4939f2				CMPQ R10, SI																																																			
  game-collisions.go:655	0x9f6d83		0f83410f0000			JAE 0x9f7cca																																																			
  game-collisions.go:655	0x9f6d89		460fb62417			MOVZX 0(DI)(R10*1), R12																																																		
  game-collisions.go:655	0x9f6d8e		4584e4				TESTL R12, R12																																																			
  game-collisions.go:655	0x9f6d91		0f8429ffffff			JE 0x9f6cc0																																																			
  game-collisions.go:659	0x9f6d97		4d8d6001			LEAQ 0x1(R8), R12																																																		
  game-collisions.go:659	0x9f6d9b		f2410f1064c708			MOVSD_XMM 0x8(R15)(AX*8), X4																																																	
  game-collisions.go:659	0x9f6da2		4d39e5				CMPQ R13, R12																																																			
  game-collisions.go:659	0x9f6da5		0f861a0f0000			JBE 0x9f7cc5																																																			
  game-collisions.go:659	0x9f6dab		f2430f5c64c708			SUBSD 0x8(R15)(R8*8), X4																																																	
  game-collisions.go:659	0x9f6db2		4939dd				CMPQ R13, BX																																																			
  game-collisions.go:659	0x9f6db5		0f86030f0000			JBE 0x9f7cbe																																																			
  game-collisions.go:659	0x9f6dbb		4d8d6002			LEAQ 0x2(R8), R12																																																		
  game-collisions.go:659	0x9f6dbf		f2410f106cc710			MOVSD_XMM 0x10(R15)(AX*8), X5																																																	
  game-collisions.go:659	0x9f6dc6		4d39e5				CMPQ R13, R12																																																			
  game-collisions.go:659	0x9f6dc9		0f86ea0e0000			JBE 0x9f7cb9																																																			
  game-collisions.go:660	0x9f6dcf		4d8d6003			LEAQ 0x3(R8), R12																																																		
  game-collisions.go:659	0x9f6dd3		f2430f5c6cc710			SUBSD 0x10(R15)(R8*8), X5																																																	
  game-collisions.go:660	0x9f6dda		f2410f1074c718			MOVSD_XMM 0x18(R15)(AX*8), X6																																																	
  game-collisions.go:660	0x9f6de1		4d39e5				CMPQ R13, R12																																																			
  game-collisions.go:660	0x9f6de4		0f86ca0e0000			JBE 0x9f7cb4																																																			
  game-collisions.go:660	0x9f6dea		f2430f5874c718			ADDSD 0x18(R15)(R8*8), X6																																																	
  game-collisions.go:662	0x9f6df1		f20f59e4			MULSD X4, X4																																																			
  game-collisions.go:662	0x9f6df5		f20f59ed			MULSD X5, X5																																																			
  game-collisions.go:662	0x9f6df9		f20f58ec			ADDSD X4, X5																																																			
  game-collisions.go:662	0x9f6dfd		f20f59f6			MULSD X6, X6																																																			
  game-collisions.go:662	0x9f6e01		660f2ef5			UCOMISD X5, X6																																																			
  game-collisions.go:662	0x9f6e05		0f82b5feffff			JB 0x9f6cc0																																																			
  game-collisions.go:663	0x9f6e0b		42c6040f00			MOVB $0x0, 0(DI)(R9*1)																																																		
  game-collisions.go:663	0x9f6e10		4939f2				CMPQ R10, SI																																																			
  game-collisions.go:663	0x9f6e13		0f83960e0000			JAE 0x9f7caf																																																			
  game-collisions.go:663	0x9f6e19		42c6041700			MOVB $0x0, 0(DI)(R10*1)																																																		
  game-collisions.go:663	0x9f6e1e		6690				NOPW																																																				
  game-collisions.go:663	0x9f6e20		e99bfeffff			JMP 0x9f6cc0																																																			
  game-collisions.go:637	0x9f6e25		4c8b942480000000		MOVQ 0x80(SP), R10																																																		
  game-collisions.go:648	0x9f6e2d		e9d9fdffff			JMP 0x9f6c0b																																																			
  game-collisions.go:308	0x9f6e32		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:308	0x9f6e3a		488b90a8080000			MOVQ 0x8a8(AX), DX																																																		
  game-collisions.go:308	0x9f6e41		48899424f8010000		MOVQ DX, 0x1f8(SP)																																																		
  game-collisions.go:308	0x9f6e49		4c8b88b0080000			MOVQ 0x8b0(AX), R9																																																		
  game-collisions.go:308	0x9f6e50		4c898c2410010000		MOVQ R9, 0x110(SP)																																																		
  game-collisions.go:308	0x9f6e58		4531d2				XORL R10, R10																																																			
  game-collisions.go:308	0x9f6e5b		4c8b9c24c0000000		MOVQ 0xc0(SP), R11																																																		
  game-collisions.go:308	0x9f6e63		4c8ba42488010000		MOVQ 0x188(SP), R12																																																		
  game-collisions.go:308	0x9f6e6b		eb16				JMP 0x9f6e83																																																			
  game-collisions.go:308	0x9f6e6d		660f1f840000000000		NOPW 0(AX)(AX*1)																																																		
  game-collisions.go:308	0x9f6e76		660f1f840000000000		NOPW 0(AX)(AX*1)																																																		
  game-collisions.go:308	0x9f6e7f		90				NOPL																																																				
  game-collisions.go:308	0x9f6e80		49ffc2				INCQ R10																																																			
  game-collisions.go:308	0x9f6e83		4d39ca				CMPQ R10, R9																																																			
  game-collisions.go:308	0x9f6e86		0f8d01020000			JGE 0x9f708d																																																			
  game-collisions.go:308	0x9f6e8c		4a8b3cd2			MOVQ 0(DX)(R10*8), DI																																																		
  game-collisions.go:309	0x9f6e90		8407				TESTB AL, 0(DI)																																																			
  game-collisions.go:311	0x9f6e92		4d39da				CMPQ R10, R11																																																			
  game-collisions.go:311	0x9f6e95		0f830f0e0000			JAE 0x9f7caa																																																			
  game-collisions.go:308	0x9f6e9b		4c899424b8000000		MOVQ R10, 0xb8(SP)																																																		
  game-collisions.go:308	0x9f6ea3		4889bc2448010000		MOVQ DI, 0x148(SP)																																																		
  game-collisions.go:311	0x9f6eab		470fb62c14			MOVZX 0(R12)(R10*1), R13																																																	
  game-collisions.go:309	0x9f6eb0		4c8b7f10			MOVQ 0x10(DI), R15																																																		
  game-collisions.go:311	0x9f6eb4		4584ed				TESTL R13, R13																																																			
  game-collisions.go:311	0x9f6eb7		7475				JE 0x9f6f2e																																																			
  game-collisions.go:311	0x9f6eb9		4983bf8800000000		CMPQ 0x88(R15), $0x0																																																		
  game-collisions.go:311	0x9f6ec1		756b				JNE 0x9f6f2e																																																			
  game-collisions.go:312	0x9f6ec3		41807f2a00			CMPB 0x2a(R15), $0x0																																																		
  game-collisions.go:312	0x9f6ec8		7540				JNE 0x9f6f0a																																																			
  game-collisions.go:313	0x9f6eca		4c89f8				MOVQ R15, AX																																																			
  game-collisions.go:313	0x9f6ecd		e86ec2c1ff			CALL github.com/burntcustard/unicorn-mining-co/src/server/physics.(*Body).Park(SB)																																										
  game-collisions.go:340	0x9f6ed2		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:308	0x9f6eda		488b9424f8010000		MOVQ 0x1f8(SP), DX																																																		
  game-collisions.go:139	0x9f6ee2		488bbc2448010000		MOVQ 0x148(SP), DI																																																		
  game-collisions.go:308	0x9f6eea		4c8b8c2410010000		MOVQ 0x110(SP), R9																																																		
  game-collisions.go:308	0x9f6ef2		4c8b9424b8000000		MOVQ 0xb8(SP), R10																																																		
  game-collisions.go:311	0x9f6efa		4c8b9c24c0000000		MOVQ 0xc0(SP), R11																																																		
  game-collisions.go:311	0x9f6f02		4c8ba42488010000		MOVQ 0x188(SP), R12																																																		
  game-collisions.go:139	0x9f6f0a		80bfd900000000			CMPB 0xd9(DI), $0x0																																																		
  game-collisions.go:139	0x9f6f11		0f8569ffffff			JNE 0x9f6e80																																																			
  game-collisions.go:143	0x9f6f17		c687d900000001			MOVB $0x1, 0xd9(DI)																																																		
  game-collisions.go:144	0x9f6f1e		4c8b2f				MOVQ 0(DI), R13																																																			
  game-collisions.go:144	0x9f6f21		41c6859400000001		MOVB $0x1, 0x94(R13)																																																		
  game-collisions.go:316	0x9f6f29		e952ffffff			JMP 0x9f6e80																																																			
  game-collisions.go:309	0x9f6f2e		4c89bc24d8010000		MOVQ R15, 0x1d8(SP)																																																		
  game-collisions.go:320	0x9f6f36		80bfd800000000			CMPB 0xd8(DI), $0x0																																																		
  game-collisions.go:320	0x9f6f3d		7454				JE 0x9f6f93																																																			
  game-collisions.go:321	0x9f6f3f		c687d800000000			MOVB $0x0, 0xd8(DI)																																																		
  game-collisions.go:322	0x9f6f46		488b5f18			MOVQ 0x18(DI), BX																																																		
  game-collisions.go:322	0x9f6f4a		488b4f20			MOVQ 0x20(DI), CX																																																		
  game-collisions.go:322	0x9f6f4e		e84d1e0000			CALL github.com/burntcustard/unicorn-mining-co/src/server/gameplay.(*GameCollisions).syncRecord(SB)																																								
  game-collisions.go:326	0x9f6f53		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:308	0x9f6f5b		488b9424f8010000		MOVQ 0x1f8(SP), DX																																																		
  game-collisions.go:325	0x9f6f63		488bbc2448010000		MOVQ 0x148(SP), DI																																																		
  game-collisions.go:308	0x9f6f6b		4c8b8c2410010000		MOVQ 0x110(SP), R9																																																		
  game-collisions.go:308	0x9f6f73		4c8b9424b8000000		MOVQ 0xb8(SP), R10																																																		
  game-collisions.go:311	0x9f6f7b		4c8b9c24c0000000		MOVQ 0xc0(SP), R11																																																		
  game-collisions.go:311	0x9f6f83		4c8ba42488010000		MOVQ 0x188(SP), R12																																																		
  game-collisions.go:330	0x9f6f8b		4c8bbc24d8010000		MOVQ 0x1d8(SP), R15																																																		
  game-collisions.go:325	0x9f6f93		488b8fd0000000			MOVQ 0xd0(DI), CX																																																		
  game-collisions.go:325	0x9f6f9a		4885c9				TESTQ CX, CX																																																			
  game-collisions.go:325	0x9f6f9d		7454				JE 0x9f6ff3																																																			
  game-collisions.go:326	0x9f6f9f		488b7770			MOVQ 0x70(DI), SI																																																		
  game-collisions.go:326	0x9f6fa3		4c8b4778			MOVQ 0x78(DI), R8																																																		
  game-collisions.go:326	0x9f6fa7		488d1d7aa77a00			LEAQ 0x7aa77a(IP), BX																																																		
  game-collisions.go:326	0x9f6fae		e84d210000			CALL github.com/burntcustard/unicorn-mining-co/src/server/gameplay.(*GameCollisions).syncDetailed(SB)																																								
  game-collisions.go:327	0x9f6fb3		833da6c5840000			CMPL runtime.writeBarrier(SB), $0x0																																																
  game-collisions.go:327	0x9f6fba		750a				JNE 0x9f6fc6																																																			
  game-collisions.go:327	0x9f6fbc		488b8c2448010000		MOVQ 0x148(SP), CX																																																		
  game-collisions.go:327	0x9f6fc4		eb17				JMP 0x9f6fdd																																																			
  game-collisions.go:327	0x9f6fc6		488b8c2448010000		MOVQ 0x148(SP), CX																																																		
  game-collisions.go:327	0x9f6fce		488b91d0000000			MOVQ 0xd0(CX), DX																																																		
  game-collisions.go:327	0x9f6fd5		e82603aaff			CALL runtime.gcWriteBarrier1(SB)																																																
  game-collisions.go:327	0x9f6fda		498913				MOVQ DX, 0(R11)																																																			
  game-collisions.go:327	0x9f6fdd		48c781d000000000000000		MOVQ $0x0, 0xd0(CX)																																																		
  game-collisions.go:330	0x9f6fe8		4889cf				MOVQ CX, DI																																																			
  game-collisions.go:330	0x9f6feb		4c8bbc24d8010000		MOVQ 0x1d8(SP), R15																																																		
  game-collisions.go:330	0x9f6ff3		f20f1087b0000000		MOVSD_XMM 0xb0(DI), X0																																																		
  game-collisions.go:330	0x9f6ffb		f20f108fb8000000		MOVSD_XMM 0xb8(DI), X1																																																		
  game-collisions.go:330	0x9f7003		f20f1097c0000000		MOVSD_XMM 0xc0(DI), X2																																																		
  game-collisions.go:330	0x9f700b		4c89f8				MOVQ R15, AX																																																			
  game-collisions.go:330	0x9f700e		e82dbdc1ff			CALL github.com/burntcustard/unicorn-mining-co/src/server/physics.(*Body).SetTransform(SB)																																									
  game-collisions.go:331	0x9f7013		488b8c2448010000		MOVQ 0x148(SP), CX																																																		
  game-collisions.go:331	0x9f701b		f20f109988000000		MOVSD_XMM 0x88(CX), X3																																																		
  game-collisions.go:331	0x9f7023		f20f10a180000000		MOVSD_XMM 0x80(CX), X4																																																		
  game-collisions.go:331	0x9f702b		488b8424d8010000		MOVQ 0x1d8(SP), AX																																																		
  game-collisions.go:331	0x9f7033		f20f116070			MOVSD_XMM X4, 0x70(AX)																																																		
  game-collisions.go:331	0x9f7038		f20f115878			MOVSD_XMM X3, 0x78(AX)																																																		
  game-collisions.go:332	0x9f703d		f20f109990000000		MOVSD_XMM 0x90(CX), X3																																																		
  game-collisions.go:332	0x9f7045		f20f119880000000		MOVSD_XMM X3, 0x80(AX)																																																		
  game-collisions.go:334	0x9f704d		80782a00			CMPB 0x2a(AX), $0x0																																																		
  game-collisions.go:334	0x9f7051		7405				JE 0x9f7058																																																			
  game-collisions.go:335	0x9f7053		e8a8c1c1ff			CALL github.com/burntcustard/unicorn-mining-co/src/server/physics.(*Body).Unpark(SB)																																										
  game-collisions.go:340	0x9f7058		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:308	0x9f7060		488b9424f8010000		MOVQ 0x1f8(SP), DX																																																		
  game-collisions.go:308	0x9f7068		4c8b8c2410010000		MOVQ 0x110(SP), R9																																																		
  game-collisions.go:308	0x9f7070		4c8b9424b8000000		MOVQ 0xb8(SP), R10																																																		
  game-collisions.go:311	0x9f7078		4c8b9c24c0000000		MOVQ 0xc0(SP), R11																																																		
  game-collisions.go:311	0x9f7080		4c8ba42488010000		MOVQ 0x188(SP), R12																																																		
  game-collisions.go:311	0x9f7088		e9f3fdffff			JMP 0x9f6e80																																																			
  game-collisions.go:340	0x9f708d		488b5008			MOVQ 0x8(AX), DX																																																		
  game-collisions.go:340	0x9f7091		4889942428010000		MOVQ DX, 0x128(SP)																																																		
  world.go:105			0x9f7099		4c8b4210			MOVQ 0x10(DX), R8																																																		
  world.go:105			0x9f709d		4c8b4a20			MOVQ 0x20(DX), R9																																																		
  world.go:105			0x9f70a1		4f8d0c09			LEAQ 0(R9)(R9*1), R9																																																		
  world.go:105			0x9f70a5		4d8d8980000000			LEAQ 0x80(R9), R9																																																		
  game-collisions.go:340	0x9f70ac		4c8b9010060000			MOVQ 0x610(AX), R10																																																		
  game-collisions.go:340	0x9f70b3		4c89542458			MOVQ R10, 0x58(SP)																																																		
  game-collisions.go:340	0x9f70b8		4c8b9818060000			MOVQ 0x618(AX), R11																																																		
  game-collisions.go:340	0x9f70bf		4c895c2478			MOVQ R11, 0x78(SP)																																																		
  world.go:105			0x9f70c4		4d39c8				CMPQ R8, R9																																																			
  world.go:105			0x9f70c7		7e0f				JLE 0x9f70d8																																																			
  world.go:105			0x9f70c9		4c8b4a08			MOVQ 0x8(DX), R9																																																		
  world.go:108			0x9f70cd		4531e4				XORL R12, R12																																																			
  world.go:108			0x9f70d0		4531ed				XORL R13, R13																																																			
  world.go:108			0x9f70d3		e9eb0a0000			JMP 0x9f7bc3																																																			
  world.go:120			0x9f70d8		80bab000000000			CMPB 0xb0(DX), $0x0																																																		
  world.go:120			0x9f70df		90				NOPL																																																				
  world.go:120			0x9f70e0		0f8488000000			JE 0x9f716e																																																			
  world.go:121			0x9f70e6		90				NOPL																																																				
  world.go:160			0x9f70e7		b810000000			MOVL $0x10, AX																																																			
  world.go:160			0x9f70ec		488d1d4de97400			LEAQ 0x74e94d(IP), BX																																																		
  world.go:160			0x9f70f3		b901000000			MOVL $0x1, CX																																																			
  world.go:160			0x9f70f8		e803a0a2ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)																																															
  world.go:160			0x9f70fd		488d157cefc2ff			LEAQ 0xffc2ef7c(IP), DX																																																		
  world.go:160			0x9f7104		488910				MOVQ DX, 0(AX)																																																			
  world.go:160			0x9f7107		833d52c4840000			CMPL runtime.writeBarrier(SB), $0x0																																																
  world.go:160			0x9f710e		750a				JNE 0x9f711a																																																			
  world.go:160			0x9f7110		488b942428010000		MOVQ 0x128(SP), DX																																																		
  world.go:160			0x9f7118		eb10				JMP 0x9f712a																																																			
  world.go:160			0x9f711a		e8e101aaff			CALL runtime.gcWriteBarrier1(SB)																																																
  world.go:160			0x9f711f		488b942428010000		MOVQ 0x128(SP), DX																																																		
  world.go:160			0x9f7127		498913				MOVQ DX, 0(R11)																																																			
  world.go:160			0x9f712a		48895008			MOVQ DX, 0x8(AX)																																																		
  world.go:160			0x9f712e		488b5240			MOVQ 0x40(DX), DX																																																		
  world.go:160			0x9f7132		488d1d67421800			LEAQ github.com/burntcustard/unicorn-mining-co/src/server/collision..dict.BroadPhase[*github.com/burntcustard/unicorn-mining-co/src/server/physics.Fixture](SB), BX																																
  world.go:160			0x9f7139		4889c1				MOVQ AX, CX																																																			
  world.go:160			0x9f713c		4889d0				MOVQ DX, AX																																																			
  world.go:160			0x9f713f		90				NOPL																																																				
  world.go:160			0x9f7140		e85bbfc2ff			CALL github.com/burntcustard/unicorn-mining-co/src/server/collision.(*BroadPhase[go.shape.*uint8]).UpdatePairs(SB)																																						
  world.go:122			0x9f7145		488b842428010000		MOVQ 0x128(SP), AX																																																		
  world.go:122			0x9f714d		c680b000000000			MOVB $0x0, 0xb0(AX)																																																		
  game-collisions.go:342	0x9f7154		488b842498020000		MOVQ 0x298(SP), AX																																																		
  world.go:125			0x9f715c		488b942428010000		MOVQ 0x128(SP), DX																																																		
  world.go:132			0x9f7164		4c8b542458			MOVQ 0x58(SP), R10																																																		
  world.go:132			0x9f7169		4c8b5c2478			MOVQ 0x78(SP), R11																																																		
  world.go:125			0x9f716e		c682b100000001			MOVB $0x1, 0xb1(DX)																																																		
  world.go:163			0x9f7175		488b9aa0000000			MOVQ 0xa0(DX), BX																																																		
  world.go:126			0x9f717c		90				NOPL																																																				
  world.go:126			0x9f717d		0f1f00				NOPL 0(AX)																																																			
  world.go:163			0x9f7180		4885db				TESTQ BX, BX																																																			
  world.go:163			0x9f7183		742a				JE 0x9f71af																																																			
  world.go:163			0x9f7185		48c1e303			SHLQ $0x3, BX																																																			
  world.go:163			0x9f7189		488b8298000000			MOVQ 0x98(DX), AX																																																		
  world.go:163			0x9f7190		e8eb73a9ff			CALL runtime.memclrHasPointers(SB)																																																
  game-collisions.go:342	0x9f7195		488b842498020000		MOVQ 0x298(SP), AX																																																		
  world.go:164			0x9f719d		488b942428010000		MOVQ 0x128(SP), DX																																																		
  world.go:132			0x9f71a5		4c8b542458			MOVQ 0x58(SP), R10																																																		
  world.go:132			0x9f71aa		4c8b5c2478			MOVQ 0x78(SP), R11																																																		
  world.go:164			0x9f71af		48c782a000000000000000		MOVQ $0x0, 0xa0(DX)																																																		
  world.go:166			0x9f71ba		4c8b8290000000			MOVQ 0x90(DX), R8																																																		
  world.go:166			0x9f71c1		eb07				JMP 0x9f71ca																																																			
  world.go:166			0x9f71c3		4d8b80a0000000			MOVQ 0xa0(R8), R8																																																		
  world.go:166			0x9f71ca		4d85c0				TESTQ R8, R8																																																			
  world.go:166			0x9f71cd		0f84fb000000			JE 0x9f72ce																																																			
  world.go:167			0x9f71d3		41c6402800			MOVB $0x0, 0x28(R8)																																																		
  world.go:168			0x9f71d8		833d81c3840000			CMPL runtime.writeBarrier(SB), $0x0																																																
  world.go:168			0x9f71df		90				NOPL																																																				
  world.go:168			0x9f71e0		741a				JE 0x9f71fc																																																			
  world.go:168			0x9f71e2		4d8b4818			MOVQ 0x18(R8), R9																																																		
  world.go:168			0x9f71e6		4d8b6010			MOVQ 0x10(R8), R12																																																		
  game-collisions.go:340	0x9f71ea		4c89d9				MOVQ R11, CX																																																			
  world.go:168			0x9f71ed		e82e01aaff			CALL runtime.gcWriteBarrier2(SB)																																																
  world.go:168			0x9f71f2		4d8923				MOVQ R12, 0(R11)																																																		
  world.go:168			0x9f71f5		4d894b08			MOVQ R9, 0x8(R11)																																																		
  world.go:132			0x9f71f9		4989cb				MOVQ CX, R11																																																			
  world.go:168			0x9f71fc		450f117810			MOVUPS X15, 0x10(R8)																																																		
  world.go:170			0x9f7201		4180782a00			CMPB 0x2a(R8), $0x0																																																		
  world.go:170			0x9f7206		740d				JE 0x9f7215																																																			
  world.go:171			0x9f7208		49c7801801000000000000		MOVQ $0x0, 0x118(R8)																																																		
  world.go:171			0x9f7213		ebae				JMP 0x9f71c3																																																			
  world.go:173			0x9f7215		488b8aa8000000			MOVQ 0xa8(DX), CX																																																		
  world.go:173			0x9f721c		488b9aa0000000			MOVQ 0xa0(DX), BX																																																		
  world.go:173			0x9f7223		48ffc3				INCQ BX																																																				
  world.go:173			0x9f7226		4c8b8a98000000			MOVQ 0x98(DX), R9																																																		
  world.go:173			0x9f722d		4839d9				CMPQ CX, BX																																																			
  world.go:173			0x9f7230		736b				JAE 0x9f729d																																																			
  world.go:166			0x9f7232		4c898424e0010000		MOVQ R8, 0x1e0(SP)																																																		
  world.go:173			0x9f723a		4c89c8				MOVQ R9, AX																																																			
  world.go:173			0x9f723d		bf01000000			MOVL $0x1, DI																																																			
  world.go:173			0x9f7242		488d350f816c00			LEAQ 0x6c810f(IP), SI																																																		
  world.go:173			0x9f7249		e832b4a9ff			CALL runtime.growslice(SB)																																																	
  world.go:173			0x9f724e		488b942428010000		MOVQ 0x128(SP), DX																																																		
  world.go:173			0x9f7256		48898aa8000000			MOVQ CX, 0xa8(DX)																																																		
  world.go:173			0x9f725d		833dfcc2840000			CMPL runtime.writeBarrier(SB), $0x0																																																
  world.go:173			0x9f7264		7413				JE 0x9f7279																																																			
  world.go:173			0x9f7266		4c8b8298000000			MOVQ 0x98(DX), R8																																																		
  world.go:173			0x9f726d		e8ae00aaff			CALL runtime.gcWriteBarrier2(SB)																																																
  world.go:173			0x9f7272		498903				MOVQ AX, 0(R11)																																																			
  world.go:173			0x9f7275		4d894308			MOVQ R8, 0x8(R11)																																																		
  world.go:173			0x9f7279		48898298000000			MOVQ AX, 0x98(DX)																																																		
  world.go:173			0x9f7280		4c8b8424e0010000		MOVQ 0x1e0(SP), R8																																																		
  world.go:132			0x9f7288		4c8b542458			MOVQ 0x58(SP), R10																																																		
  world.go:132			0x9f728d		4c8b5c2478			MOVQ 0x78(SP), R11																																																		
  world.go:173			0x9f7292		4989c1				MOVQ AX, R9																																																			
  game-collisions.go:342	0x9f7295		488b842498020000		MOVQ 0x298(SP), AX																																																		
  world.go:173			0x9f729d		48899aa0000000			MOVQ BX, 0xa0(DX)																																																		
  world.go:173			0x9f72a4		833db5c2840000			CMPL runtime.writeBarrier(SB), $0x0																																																
  world.go:173			0x9f72ab		7417				JE 0x9f72c4																																																			
  world.go:173			0x9f72ad		4d8b64d9f8			MOVQ -0x8(R9)(BX*8), R12																																																	
  game-collisions.go:340	0x9f72b2		4c89d9				MOVQ R11, CX																																																			
  world.go:173			0x9f72b5		e86600aaff			CALL runtime.gcWriteBarrier2(SB)																																																
  world.go:173			0x9f72ba		4d8903				MOVQ R8, 0(R11)																																																			
  world.go:173			0x9f72bd		4d896308			MOVQ R12, 0x8(R11)																																																		
  world.go:132			0x9f72c1		4989cb				MOVQ CX, R11																																																			
  world.go:173			0x9f72c4		4d8944d9f8			MOVQ R8, -0x8(R9)(BX*8)																																																		
  world.go:173			0x9f72c9		e9f5feffff			JMP 0x9f71c3																																																			
  world.go:128			0x9f72ce		80ba5802000000			CMPB 0x258(DX), $0x0																																																		
  world.go:128			0x9f72d5		741a				JE 0x9f72f1																																																			
  world.go:129			0x9f72d7		4889d0				MOVQ DX, AX																																																			
  world.go:129			0x9f72da		e8a18dc2ff			CALL github.com/burntcustard/unicorn-mining-co/src/server/physics.(*World).prepareCollisionNeighbors(SB)																																							
  world.go:132			0x9f72df		488b942428010000		MOVQ 0x128(SP), DX																																																		
  world.go:132			0x9f72e7		4c8b542458			MOVQ 0x58(SP), R10																																																		
  world.go:132			0x9f72ec		4c8b5c2478			MOVQ 0x78(SP), R11																																																		
  world.go:132			0x9f72f1		f20f108424a8020000		MOVSD_XMM 0x2a8(SP), X0																																																		
  world.go:132			0x9f72fa		f20f1182c0000000		MOVSD_XMM X0, 0xc0(DX)																																																		
  world.go:132			0x9f7302		4c8992c8000000			MOVQ R10, 0xc8(DX)																																																		
  world.go:132			0x9f7309		4c899ad0000000			MOVQ R11, 0xd0(DX)																																																		
  world.go:133			0x9f7310		4889d0				MOVQ DX, AX																																																			
  world.go:133			0x9f7313		e8e897c2ff			CALL github.com/burntcustard/unicorn-mining-co/src/server/physics.(*World).UpdateContacts(SB)																																									
  world.go:135			0x9f7318		f20f108424a8020000		MOVSD_XMM 0x2a8(SP), X0																																																		
  world.go:135			0x9f7321		0f57c9				XORPS X1, X1																																																			
  world.go:135			0x9f7324		660f2ec1			UCOMISD X1, X0																																																			
  world.go:135			0x9f7328		0f8657010000			JBE 0x9f7485																																																			
  world.go:136			0x9f732e		488b942428010000		MOVQ 0x128(SP), DX																																																		
  world.go:136			0x9f7336		488b4238			MOVQ 0x38(DX), AX																																																		
  world.go:136			0x9f733a		f20f1082c0000000		MOVSD_XMM 0xc0(DX), X0																																																		
  world.go:136			0x9f7342		488b9ac8000000			MOVQ 0xc8(DX), BX																																																		
  world.go:136			0x9f7349		488b8ad0000000			MOVQ 0xd0(DX), CX																																																		
  world.go:136			0x9f7350		e82b30c2ff			CALL github.com/burntcustard/unicorn-mining-co/src/server/physics.(*Solver).SolveWorld(SB)																																									
  world.go:138			0x9f7355		488b942428010000		MOVQ 0x128(SP), DX																																																		
  world.go:138			0x9f735d		488bb298000000			MOVQ 0x98(DX), SI																																																		
  world.go:138			0x9f7364		4889b424f0010000		MOVQ SI, 0x1f0(SP)																																																		
  world.go:138			0x9f736c		488bbaa0000000			MOVQ 0xa0(DX), DI																																																		
  world.go:138			0x9f7373		4889bc2410010000		MOVQ DI, 0x110(SP)																																																		
  world.go:138			0x9f737b		4531c0				XORL R8, R8																																																			
  world.go:138			0x9f737e		6690				NOPW																																																				
  world.go:138			0x9f7380		eb03				JMP 0x9f7385																																																			
  world.go:138			0x9f7382		49ffc0				INCQ R8																																																				
  world.go:138			0x9f7385		4939f8				CMPQ R8, DI																																																			
  world.go:138			0x9f7388		7d3d				JGE 0x9f73c7																																																			
  world.go:138			0x9f738a		4a8b04c6			MOVQ 0(SI)(R8*8), AX																																																		
  world.go:139			0x9f738e		80782800			CMPB 0x28(AX), $0x0																																																		
  world.go:139			0x9f7392		74ee				JE 0x9f7382																																																			
  world.go:138			0x9f7394		4c89842408010000		MOVQ R8, 0x108(SP)																																																		
  world.go:140			0x9f739c		0f1f4000			NOPL 0(AX)																																																			
  world.go:140			0x9f73a0		e89bc0c1ff			CALL github.com/burntcustard/unicorn-mining-co/src/server/physics.(*Body).SynchronizeFixtures(SB)																																								
  world.go:160			0x9f73a5		488b942428010000		MOVQ 0x128(SP), DX																																																		
  world.go:138			0x9f73ad		488bb424f0010000		MOVQ 0x1f0(SP), SI																																																		
  world.go:138			0x9f73b5		488bbc2410010000		MOVQ 0x110(SP), DI																																																		
  world.go:138			0x9f73bd		4c8b842408010000		MOVQ 0x108(SP), R8																																																		
  world.go:140			0x9f73c5		ebbb				JMP 0x9f7382																																																			
  world.go:144			0x9f73c7		90				NOPL																																																				
  world.go:160			0x9f73c8		b810000000			MOVL $0x10, AX																																																			
  world.go:160			0x9f73cd		488d1d6ce67400			LEAQ 0x74e66c(IP), BX																																																		
  world.go:160			0x9f73d4		b901000000			MOVL $0x1, CX																																																			
  world.go:160			0x9f73d9		e8229da2ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)																																															
  world.go:160			0x9f73de		488d159becc2ff			LEAQ 0xffc2ec9b(IP), DX																																																		
  world.go:160			0x9f73e5		488910				MOVQ DX, 0(AX)																																																			
  world.go:160			0x9f73e8		833d71c1840000			CMPL runtime.writeBarrier(SB), $0x0																																																
  world.go:160			0x9f73ef		750f				JNE 0x9f7400																																																			
  world.go:160			0x9f73f1		488b942428010000		MOVQ 0x128(SP), DX																																																		
  world.go:160			0x9f73f9		eb15				JMP 0x9f7410																																																			
  world.go:160			0x9f73fb		0f1f440000			NOPL 0(AX)(AX*1)																																																		
  world.go:160			0x9f7400		e8fbfea9ff			CALL runtime.gcWriteBarrier1(SB)																																																
  world.go:160			0x9f7405		488b942428010000		MOVQ 0x128(SP), DX																																																		
  world.go:160			0x9f740d		498913				MOVQ DX, 0(R11)																																																			
  world.go:160			0x9f7410		48895008			MOVQ DX, 0x8(AX)																																																		
  world.go:160			0x9f7414		488b5240			MOVQ 0x40(DX), DX																																																		
  world.go:160			0x9f7418		488d1d813f1800			LEAQ github.com/burntcustard/unicorn-mining-co/src/server/collision..dict.BroadPhase[*github.com/burntcustard/unicorn-mining-co/src/server/physics.Fixture](SB), BX																																
  world.go:160			0x9f741f		4889c1				MOVQ AX, CX																																																			
  world.go:160			0x9f7422		4889d0				MOVQ DX, AX																																																			
  world.go:160			0x9f7425		e876bcc2ff			CALL github.com/burntcustard/unicorn-mining-co/src/server/collision.(*BroadPhase[go.shape.*uint8]).UpdatePairs(SB)																																						
  world.go:146			0x9f742a		488b842428010000		MOVQ 0x128(SP), AX																																																		
  world.go:146			0x9f7432		80b85802000000			CMPB 0x258(AX), $0x0																																																		
  world.go:146			0x9f7439		7412				JE 0x9f744d																																																			
  world.go:146			0x9f743b		0f1f440000			NOPL 0(AX)(AX*1)																																																		
  world.go:147			0x9f7440		e83b8cc2ff			CALL github.com/burntcustard/unicorn-mining-co/src/server/physics.(*World).prepareCollisionNeighbors(SB)																																							
  world.go:150			0x9f7445		488b842428010000		MOVQ 0x128(SP), AX																																																		
  world.go:150			0x9f744d		488b5038			MOVQ 0x38(AX), DX																																																		
  world.go:150			0x9f7451		f20f1080c0000000		MOVSD_XMM 0xc0(AX), X0																																																		
  world.go:150			0x9f7459		488b98c8000000			MOVQ 0xc8(AX), BX																																																		
  world.go:150			0x9f7460		488b88d0000000			MOVQ 0xd0(AX), CX																																																		
  world.go:150			0x9f7467		4889d0				MOVQ DX, AX																																																			
  world.go:150			0x9f746a		e8514cc2ff			CALL github.com/burntcustard/unicorn-mining-co/src/server/physics.(*Solver).SolveWorldTOI(SB)																																									
  world.go:135			0x9f746f		f20f108c24a8020000		MOVSD_XMM 0x2a8(SP), X1																																																		
  world.go:135			0x9f7478		0f57d2				XORPS X2, X2																																																			
  world.go:135			0x9f747b		660f2eca			UCOMISD X2, X1																																																			
  world.go:135			0x9f747f		0f10c1				MOVUPS X1, X0																																																			
  world.go:135			0x9f7482		0f57c9				XORPS X1, X1																																																			
  world.go:153			0x9f7485		488b842428010000		MOVQ 0x128(SP), AX																																																		
  world.go:153			0x9f748d		c680b100000000			MOVB $0x0, 0xb1(AX)																																																		
  world.go:155			0x9f7494		7611				JBE 0x9f74a7																																																			
  world.go:156			0x9f7496		e8a50fc2ff			CALL github.com/burntcustard/unicorn-mining-co/src/server/physics.(*World).recoverOverlaps(SB)																																									
  world.go:135			0x9f749b		f20f108424a8020000		MOVSD_XMM 0x2a8(SP), X0																																																		
  world.go:135			0x9f74a4		0f57c9				XORPS X1, X1																																																			
  game-collisions.go:342	0x9f74a7		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:342	0x9f74af		488b90a8080000			MOVQ 0x8a8(AX), DX																																																		
  game-collisions.go:342	0x9f74b6		488bb0b0080000			MOVQ 0x8b0(AX), SI																																																		
  game-collisions.go:342	0x9f74bd		31ff				XORL DI, DI																																																			
  game-collisions.go:342	0x9f74bf		90				NOPL																																																				
  game-collisions.go:342	0x9f74c0		eb03				JMP 0x9f74c5																																																			
  game-collisions.go:342	0x9f74c2		48ffc7				INCQ DI																																																				
  game-collisions.go:342	0x9f74c5		4839f7				CMPQ DI, SI																																																			
  game-collisions.go:342	0x9f74c8		7d2e				JGE 0x9f74f8																																																			
  game-collisions.go:342	0x9f74ca		4c8b04fa			MOVQ 0(DX)(DI*8), R8																																																		
  game-collisions.go:343	0x9f74ce		4d8b4810			MOVQ 0x10(R8), R9																																																		
  game-collisions.go:343	0x9f74d2		4180792a00			CMPB 0x2a(R9), $0x0																																																		
  game-collisions.go:343	0x9f74d7		75e9				JNE 0x9f74c2																																																			
  game-collisions.go:139	0x9f74d9		4180b8d900000000		CMPB 0xd9(R8), $0x0																																																		
  game-collisions.go:139	0x9f74e1		75df				JNE 0x9f74c2																																																			
  game-collisions.go:143	0x9f74e3		41c680d900000001		MOVB $0x1, 0xd9(R8)																																																		
  game-collisions.go:144	0x9f74eb		4d8b00				MOVQ 0(R8), R8																																																			
  game-collisions.go:144	0x9f74ee		41c6809400000001		MOVB $0x1, 0x94(R8)																																																		
  game-collisions.go:344	0x9f74f6		ebca				JMP 0x9f74c2																																																			
  game-collisions.go:348	0x9f74f8		488b9078080000			MOVQ 0x878(AX), DX																																																		
  game-collisions.go:348	0x9f74ff		488bb080080000			MOVQ 0x880(AX), SI																																																		
  game-collisions.go:348	0x9f7506		eb40				JMP 0x9f7548																																																			
  game-collisions.go:678	0x9f7508		488b4e18			MOVQ 0x18(SI), CX																																																		
  game-collisions.go:678	0x9f750c		488b842458010000		MOVQ 0x158(SP), AX																																																		
  game-collisions.go:678	0x9f7514		ffd1				CALL CX																																																				
  game-collisions.go:678	0x9f7516		c6809400000000			MOVB $0x0, 0x94(AX)																																																		
  game-collisions.go:348	0x9f751d		488b942400020000		MOVQ 0x200(SP), DX																																																		
  game-collisions.go:348	0x9f7525		4883c238			ADDQ $0x38, DX																																																			
  game-collisions.go:348	0x9f7529		488bb42410010000		MOVQ 0x110(SP), SI																																																		
  game-collisions.go:348	0x9f7531		48ffce				DECQ SI																																																				
  game-collisions.go:353	0x9f7534		488b842498020000		MOVQ 0x298(SP), AX																																																		
  world.go:135			0x9f753c		f20f108424a8020000		MOVSD_XMM 0x2a8(SP), X0																																																		
  world.go:135			0x9f7545		0f57c9				XORPS X1, X1																																																			
  game-collisions.go:348	0x9f7548		4885f6				TESTQ SI, SI																																																			
  game-collisions.go:348	0x9f754b		0f8ea5010000			JLE 0x9f76f6																																																			
  game-collisions.go:349	0x9f7551		488b3a				MOVQ 0(DX), DI																																																			
  game-collisions.go:348	0x9f7554		4c8d842498010000		LEAQ 0x198(SP), R8																																																		
  game-collisions.go:348	0x9f755c		440f1032			MOVUPS 0(DX), X14																																																		
  game-collisions.go:348	0x9f7560		450f1130			MOVUPS X14, 0(R8)																																																		
  game-collisions.go:348	0x9f7564		440f107210			MOVUPS 0x10(DX), X14																																																		
  game-collisions.go:348	0x9f7569		450f117010			MOVUPS X14, 0x10(R8)																																																		
  game-collisions.go:348	0x9f756e		440f107220			MOVUPS 0x20(DX), X14																																																		
  game-collisions.go:348	0x9f7573		450f117020			MOVUPS X14, 0x20(R8)																																																		
  game-collisions.go:348	0x9f7578		440f107228			MOVUPS 0x28(DX), X14																																																		
  game-collisions.go:348	0x9f757d		450f117028			MOVUPS X14, 0x28(R8)																																																		
  game-collisions.go:349	0x9f7582		488b5f60			MOVQ 0x60(DI), BX																																																		
  game-collisions.go:349	0x9f7586		488b4f68			MOVQ 0x68(DI), CX																																																		
  game-collisions.go:349	0x9f758a		4885db				TESTQ BX, BX																																																			
  game-collisions.go:349	0x9f758d		0f8408060000			JE 0x9f7b9b																																																			
  game-collisions.go:348	0x9f7593		4889b42410010000		MOVQ SI, 0x110(SP)																																																		
  game-collisions.go:348	0x9f759b		4889942400020000		MOVQ DX, 0x200(SP)																																																		
  game-collisions.go:349	0x9f75a3		488b3d465d8100			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/gameplay..typeAssert.0(SB), DI																																									
  game-collisions.go:349	0x9f75aa		4c8b07				MOVQ 0(DI), R8																																																			
  game-collisions.go:349	0x9f75ad		448b4b10			MOVL 0x10(BX), R9																																																		
  game-collisions.go:349	0x9f75b1		4d89ca				MOVQ R9, R10																																																			
  game-collisions.go:349	0x9f75b4		4d21c1				ANDQ R8, R9																																																			
  game-collisions.go:349	0x9f75b7		49c1e104			SHLQ $0x4, R9																																																			
  game-collisions.go:349	0x9f75bb		4e8b5c0f08			MOVQ 0x8(DI)(R9*1), R11																																																		
  game-collisions.go:349	0x9f75c0		4939db				CMPQ R11, BX																																																			
  game-collisions.go:349	0x9f75c3		7435				JE 0x9f75fa																																																			
  game-collisions.go:349	0x9f75c5		4d8d4a01			LEAQ 0x1(R10), R9																																																		
  game-collisions.go:349	0x9f75c9		4d85db				TESTQ R11, R11																																																			
  game-collisions.go:349	0x9f75cc		75e3				JNE 0x9f75b1																																																			
  game-collisions.go:349	0x9f75ce		48898c24e8010000		MOVQ CX, 0x1e8(SP)																																																		
  game-collisions.go:349	0x9f75d6		488d05135d8100			LEAQ github.com/burntcustard/unicorn-mining-co/src/server/gameplay..typeAssert.0(SB), AX																																									
  game-collisions.go:349	0x9f75dd		0f1f00				NOPL 0(AX)																																																			
  game-collisions.go:349	0x9f75e0		e89b60a2ff			CALL runtime.typeAssert(SB)																																																	
  game-collisions.go:349	0x9f75e5		488b8c24e8010000		MOVQ 0x1e8(SP), CX																																																		
  game-collisions.go:349	0x9f75ed		4889c3				MOVQ AX, BX																																																			
  game-collisions.go:349	0x9f75f0		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:349	0x9f75f8		eb05				JMP 0x9f75ff																																																			
  game-collisions.go:349	0x9f75fa		4a8b5c0f10			MOVQ 0x10(DI)(R9*1), BX																																																		
  game-collisions.go:349	0x9f75ff		90				NOPL																																																				
  game-collisions.go:349	0x9f7600		e8fb120000			CALL github.com/burntcustard/unicorn-mining-co/src/server/gameplay.(*GameCollisions).touched(SB)																																								
  game-collisions.go:350	0x9f7605		488b9424a0010000		MOVQ 0x1a0(SP), DX																																																		
  game-collisions.go:350	0x9f760d		488b5a60			MOVQ 0x60(DX), BX																																																		
  game-collisions.go:350	0x9f7611		488b4268			MOVQ 0x68(DX), AX																																																		
  game-collisions.go:350	0x9f7615		4885db				TESTQ BX, BX																																																			
  game-collisions.go:350	0x9f7618		0f8471050000			JE 0x9f7b8f																																																			
  game-collisions.go:350	0x9f761e		4889842458010000		MOVQ AX, 0x158(SP)																																																		
  game-collisions.go:350	0x9f7626		488b0de35c8100			MOVQ github.com/burntcustard/unicorn-mining-co/src/server/gameplay..typeAssert.1(SB), CX																																									
  game-collisions.go:350	0x9f762d		488b11				MOVQ 0(CX), DX																																																			
  game-collisions.go:350	0x9f7630		8b7310				MOVL 0x10(BX), SI																																																		
  game-collisions.go:350	0x9f7633		4889f7				MOVQ SI, DI																																																			
  game-collisions.go:350	0x9f7636		4821d6				ANDQ DX, SI																																																			
  game-collisions.go:350	0x9f7639		48c1e604			SHLQ $0x4, SI																																																			
  game-collisions.go:350	0x9f763d		4c8b443108			MOVQ 0x8(CX)(SI*1), R8																																																		
  game-collisions.go:350	0x9f7642		4939d8				CMPQ R8, BX																																																			
  game-collisions.go:350	0x9f7645		7422				JE 0x9f7669																																																			
  game-collisions.go:350	0x9f7647		488d7701			LEAQ 0x1(DI), SI																																																		
  game-collisions.go:350	0x9f764b		4d85c0				TESTQ R8, R8																																																			
  game-collisions.go:350	0x9f764e		75e3				JNE 0x9f7633																																																			
  game-collisions.go:350	0x9f7650		488d05b95c8100			LEAQ github.com/burntcustard/unicorn-mining-co/src/server/gameplay..typeAssert.1(SB), AX																																									
  game-collisions.go:350	0x9f7657		e82460a2ff			CALL runtime.typeAssert(SB)																																																	
  game-collisions.go:350	0x9f765c		4889c1				MOVQ AX, CX																																																			
  game-collisions.go:672	0x9f765f		488b842458010000		MOVQ 0x158(SP), AX																																																		
  game-collisions.go:350	0x9f7667		eb05				JMP 0x9f766e																																																			
  game-collisions.go:350	0x9f7669		488b4c3110			MOVQ 0x10(CX)(SI*1), CX																																																		
  game-collisions.go:350	0x9f766e		48898c24e8010000		MOVQ CX, 0x1e8(SP)																																																		
  game-collisions.go:672	0x9f7676		488b4918			MOVQ 0x18(CX), CX																																																		
  game-collisions.go:672	0x9f767a		ffd1				CALL CX																																																				
  game-collisions.go:672	0x9f767c		488d0d4d086b00			LEAQ 0x6b084d(IP), CX																																																		
  game-collisions.go:672	0x9f7683		48394860			CMPQ 0x60(AX), CX																																																		
  game-collisions.go:672	0x9f7687		7506				JNE 0x9f768f																																																			
  game-collisions.go:672	0x9f7689		488b5068			MOVQ 0x68(AX), DX																																																		
  game-collisions.go:672	0x9f768d		eb02				JMP 0x9f7691																																																			
  game-collisions.go:672	0x9f768f		31d2				XORL DX, DX																																																			
  game-collisions.go:674	0x9f7691		4885d2				TESTQ DX, DX																																																			
  game-collisions.go:674	0x9f7694		7453				JE 0x9f76e9																																																			
  game-collisions.go:674	0x9f7696		488b4218			MOVQ 0x18(DX), AX																																																		
  game-collisions.go:674	0x9f769a		488bb424e8010000		MOVQ 0x1e8(SP), SI																																																		
  game-collisions.go:674	0x9f76a2		4839c6				CMPQ SI, AX																																																			
  game-collisions.go:674	0x9f76a5		7404				JE 0x9f76ab																																																			
  game-collisions.go:674	0x9f76a7		31c0				XORL AX, AX																																																			
  game-collisions.go:674	0x9f76a9		eb2a				JMP 0x9f76d5																																																			
  game-collisions.go:672	0x9f76ab		4889942440010000		MOVQ DX, 0x140(SP)																																																		
  game-collisions.go:674	0x9f76b3		488b5a20			MOVQ 0x20(DX), BX																																																		
  game-collisions.go:674	0x9f76b7		488b8c2458010000		MOVQ 0x158(SP), CX																																																		
  game-collisions.go:674	0x9f76bf		90				NOPL																																																				
  game-collisions.go:674	0x9f76c0		e87bf6a1ff			CALL runtime.ifaceeq(SB)																																																	
  game-collisions.go:675	0x9f76c5		488b942440010000		MOVQ 0x140(SP), DX																																																		
  game-collisions.go:678	0x9f76cd		488bb424e8010000		MOVQ 0x1e8(SP), SI																																																		
  game-collisions.go:674	0x9f76d5		84c0				TESTL AL, AL																																																			
  game-collisions.go:674	0x9f76d7		0f842bfeffff			JE 0x9f7508																																																			
  game-collisions.go:675	0x9f76dd		c682d900000000			MOVB $0x0, 0xd9(DX)																																																		
  game-collisions.go:675	0x9f76e4		e91ffeffff			JMP 0x9f7508																																																			
  game-collisions.go:678	0x9f76e9		488bb424e8010000		MOVQ 0x1e8(SP), SI																																																		
  game-collisions.go:674	0x9f76f1		e912feffff			JMP 0x9f7508																																																			
  game-collisions.go:353	0x9f76f6		488b90a8080000			MOVQ 0x8a8(AX), DX																																																		
  game-collisions.go:353	0x9f76fd		48899424f8010000		MOVQ DX, 0x1f8(SP)																																																		
  game-collisions.go:353	0x9f7705		488bb0b0080000			MOVQ 0x8b0(AX), SI																																																		
  game-collisions.go:353	0x9f770c		4889b42410010000		MOVQ SI, 0x110(SP)																																																		
  game-collisions.go:353	0x9f7714		31ff				XORL DI, DI																																																			
  game-collisions.go:353	0x9f7716		eb0a				JMP 0x9f7722																																																			
  game-collisions.go:353	0x9f7718		48ffc7				INCQ DI																																																				
  world.go:135			0x9f771b		410f10c5			MOVUPS X13, X0																																																			
  world.go:135			0x9f771f		0f57c9				XORPS X1, X1																																																			
  game-collisions.go:353	0x9f7722		4839f7				CMPQ DI, SI																																																			
  game-collisions.go:353	0x9f7725		0f8d62030000			JGE 0x9f7a8d																																																			
  game-collisions.go:353	0x9f772b		4c8b04fa			MOVQ 0(DX)(DI*8), R8																																																		
  game-collisions.go:354	0x9f772f		4d8b4810			MOVQ 0x10(R8), R9																																																		
  game-collisions.go:354	0x9f7733		4d8b10				MOVQ 0(R8), R10																																																			
  game-collisions.go:354	0x9f7736		f2410f109080000000		MOVSD_XMM 0x80(R8), X2																																																		
  game-collisions.go:354	0x9f773f		f2410f109888000000		MOVSD_XMM 0x88(R8), X3																																																		
  game-collisions.go:354	0x9f7748		f2410f10a090000000		MOVSD_XMM 0x90(R8), X4																																																		
  game-collisions.go:354	0x9f7751		f2410f10a8b0000000		MOVSD_XMM 0xb0(R8), X5																																																		
  game-collisions.go:354	0x9f775a		f2410f10b0b8000000		MOVSD_XMM 0xb8(R8), X6																																																		
  game-collisions.go:356	0x9f7763		4180792a00			CMPB 0x2a(R9), $0x0																																																		
  game-collisions.go:356	0x9f7768		0f8489020000			JE 0x9f79f7																																																			
  game-collisions.go:354	0x9f776e		f2410f10b8c0000000		MOVSD_XMM 0xc0(R8), X7																																																		
  game-collisions.go:359	0x9f7777		f2440f100500211700		MOVSD_XMM $f64.400921fb54442d18(SB), X8																																																
  game-collisions.go:359	0x9f7780		66410f2ef8			UCOMISD X8, X7																																																			
  game-collisions.go:359	0x9f7785		7622				JBE 0x9f77a9																																																			
  game-collisions.go:360	0x9f7787		f2440f100d10211700		MOVSD_XMM $f64.401921fb54442d18(SB), X9																																																
  game-collisions.go:360	0x9f7790		f2410f5cf9			SUBSD X9, X7																																																			
  game-collisions.go:360	0x9f7795		f2440f100db2281700		MOVSD_XMM $f64.c00921fb54442d18(SB), X9																																																
  game-collisions.go:360	0x9f779e		f2440f1015f9201700		MOVSD_XMM $f64.401921fb54442d18(SB), X10																																															
  game-collisions.go:360	0x9f77a7		eb29				JMP 0x9f77d2																																																			
  game-collisions.go:361	0x9f77a9		f2440f100d9e281700		MOVSD_XMM $f64.c00921fb54442d18(SB), X9																																																
  game-collisions.go:361	0x9f77b2		66440f2ecf			UCOMISD X7, X9																																																			
  game-collisions.go:361	0x9f77b7		7610				JBE 0x9f77c9																																																			
  game-collisions.go:362	0x9f77b9		f2440f1015de201700		MOVSD_XMM $f64.401921fb54442d18(SB), X10																																															
  game-collisions.go:362	0x9f77c2		f2410f58fa			ADDSD X10, X7																																																			
  game-collisions.go:362	0x9f77c7		eb09				JMP 0x9f77d2																																																			
  game-collisions.go:362	0x9f77c9		f2440f1015ce201700		MOVSD_XMM $f64.401921fb54442d18(SB), X10																																															
  unsafe.go:35			0x9f77d2		66490f7ef8			MOVQ X7, R8																																																			
  abs.go:14			0x9f77d7		490fbaf03f			BTRQ $0x3f, R8																																																			
  unsafe.go:41			0x9f77dc		664d0f6ed8			MOVQ R8, X11																																																			
  game-collisions.go:365	0x9f77e1		66450f2ec3			UCOMISD X11, X8																																																			
  game-collisions.go:365	0x9f77e6		7209				JB 0x9f77f1																																																			
  world.go:135			0x9f77e8		660f2ec1			UCOMISD X1, X0																																																			
  game-collisions.go:365	0x9f77ec		e9d3000000			JMP 0x9f78c4																																																			
  game-collisions.go:353	0x9f77f1		4889bc2408010000		MOVQ DI, 0x108(SP)																																																		
  game-collisions.go:354	0x9f77f9		4c89942468010000		MOVQ R10, 0x168(SP)																																																		
  game-collisions.go:354	0x9f7801		f20f11642460			MOVSD_XMM X4, 0x60(SP)																																																		
  game-collisions.go:354	0x9f7807		f20f11942400010000		MOVSD_XMM X2, 0x100(SP)																																																		
  game-collisions.go:354	0x9f7810		f20f11b424f8000000		MOVSD_XMM X6, 0xf8(SP)																																																		
  game-collisions.go:354	0x9f7819		f20f119c24f0000000		MOVSD_XMM X3, 0xf0(SP)																																																		
  game-collisions.go:354	0x9f7822		f20f11ac24e8000000		MOVSD_XMM X5, 0xe8(SP)																																																		
  game-collisions.go:366	0x9f782b		0f10c7				MOVUPS X7, X0																																																			
  game-collisions.go:366	0x9f782e		e80d4aaeff			CALL math.Sincos(SB)																																																		
  atan2.go:34			0x9f7833		e8c824aeff			CALL math.atan2(SB)																																																		
  world.go:135			0x9f7838		f20f108c24a8020000		MOVSD_XMM 0x2a8(SP), X1																																																		
  world.go:135			0x9f7841		0f57d2				XORPS X2, X2																																																			
  world.go:135			0x9f7844		660f2eca			UCOMISD X2, X1																																																			
  game-collisions.go:374	0x9f7848		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:353	0x9f7850		488b9424f8010000		MOVQ 0x1f8(SP), DX																																																		
  game-collisions.go:353	0x9f7858		488bb42410010000		MOVQ 0x110(SP), SI																																																		
  game-collisions.go:353	0x9f7860		488bbc2408010000		MOVQ 0x108(SP), DI																																																		
  game-collisions.go:392	0x9f7868		4c8b942468010000		MOVQ 0x168(SP), R10																																																		
  game-collisions.go:392	0x9f7870		0f57c9				XORPS X1, X1																																																			
  game-collisions.go:371	0x9f7873		f20f10942400010000		MOVSD_XMM 0x100(SP), X2																																																		
  game-collisions.go:371	0x9f787c		f20f109c24f0000000		MOVSD_XMM 0xf0(SP), X3																																																		
  game-collisions.go:380	0x9f7885		f20f10642460			MOVSD_XMM 0x60(SP), X4																																																		
  game-collisions.go:392	0x9f788b		f20f10ac24e8000000		MOVSD_XMM 0xe8(SP), X5																																																		
  game-collisions.go:392	0x9f7894		f20f10b424f8000000		MOVSD_XMM 0xf8(SP), X6																																																		
  game-collisions.go:392	0x9f789d		f2440f1005da1f1700		MOVSD_XMM $f64.400921fb54442d18(SB), X8																																																
  game-collisions.go:392	0x9f78a6		f2440f100da1271700		MOVSD_XMM $f64.c00921fb54442d18(SB), X9																																																
  game-collisions.go:392	0x9f78af		f2440f1015e81f1700		MOVSD_XMM $f64.401921fb54442d18(SB), X10																																															
  game-collisions.go:369	0x9f78b8		0f10f8				MOVUPS X0, X7																																																			
  game-collisions.go:371	0x9f78bb		f20f108424a8020000		MOVSD_XMM 0x2a8(SP), X0																																																		
  game-collisions.go:369	0x9f78c4		0f8612010000			JBE 0x9f79dc																																																			
  game-collisions.go:371	0x9f78ca		440f10d8			MOVUPS X0, X11																																																			
  game-collisions.go:371	0x9f78ce		f20f59c2			MULSD X2, X0																																																			
  game-collisions.go:371	0x9f78d2		450f10e3			MOVUPS X11, X12																																																			
  game-collisions.go:371	0x9f78d6		f2440f59db			MULSD X3, X11																																																			
  game-collisions.go:372	0x9f78db		f20f59c0			MULSD X0, X0																																																			
  game-collisions.go:372	0x9f78df		f2450f59db			MULSD X11, X11																																																			
  game-collisions.go:372	0x9f78e4		f2440f58d8			ADDSD X0, X11																																																			
  game-collisions.go:374	0x9f78e9		f2440f10a800060000		MOVSD_XMM 0x600(AX), X13																																																	
  game-collisions.go:374	0x9f78f2		450f10f5			MOVUPS X13, X14																																																			
  game-collisions.go:374	0x9f78f6		f2450f59ed			MULSD X13, X13																																																			
  game-collisions.go:374	0x9f78fb		66450f2edd			UCOMISD X13, X11																																																		
  game-collisions.go:374	0x9f7900		761a				JBE 0x9f791c																																																			
  sqrt.go:94			0x9f7902		f2450f51db			SQRTSD X11, X11																																																			
  game-collisions.go:375	0x9f7907		f2450f5ef3			DIVSD X11, X14																																																			
  game-collisions.go:376	0x9f790c		450f10de			MOVUPS X14, X11																																																			
  game-collisions.go:376	0x9f7910		f2440f59f2			MULSD X2, X14																																																			
  game-collisions.go:377	0x9f7915		f2440f59db			MULSD X3, X11																																																			
  game-collisions.go:377	0x9f791a		eb08				JMP 0x9f7924																																																			
  game-collisions.go:380	0x9f791c		440f10db			MOVUPS X3, X11																																																			
  game-collisions.go:380	0x9f7920		440f10f2			MOVUPS X2, X14																																																			
  game-collisions.go:380	0x9f7924		450f10ec			MOVUPS X12, X13																																																			
  game-collisions.go:380	0x9f7928		f2440f59e4			MULSD X4, X12																																																			
  game-collisions.go:382	0x9f792d		410f10c4			MOVUPS X12, X0																																																			
  game-collisions.go:382	0x9f7931		f2450f59e4			MULSD X12, X12																																																			
  game-collisions.go:382	0x9f7936		f20f108808060000		MOVSD_XMM 0x608(AX), X1																																																		
  game-collisions.go:382	0x9f793e		f20f59c9			MULSD X1, X1																																																			
  game-collisions.go:382	0x9f7942		66440f2ee1			UCOMISD X1, X12																																																			
  game-collisions.go:382	0x9f7947		7629				JBE 0x9f7972																																																			
  unsafe.go:35			0x9f7949		66490f7ec0			MOVQ X0, R8																																																			
  abs.go:14			0x9f794e		490fbaf03f			BTRQ $0x3f, R8																																																			
  abs.go:14			0x9f7953		4c898424d8000000		MOVQ R8, 0xd8(SP)																																																		
  game-collisions.go:383	0x9f795b		f20f108808060000		MOVSD_XMM 0x608(AX), X1																																																		
  game-collisions.go:383	0x9f7963		f20f5e8c24d8000000		DIVSD 0xd8(SP), X1																																																		
  game-collisions.go:383	0x9f796c		f20f59cc			MULSD X4, X1																																																			
  game-collisions.go:383	0x9f7970		eb03				JMP 0x9f7975																																																			
  game-collisions.go:386	0x9f7972		0f10cc				MOVUPS X4, X1																																																			
  game-collisions.go:386	0x9f7975		450f10e6			MOVUPS X14, X12																																																			
  game-collisions.go:386	0x9f7979		f2450f59f5			MULSD X13, X14																																																			
  game-collisions.go:386	0x9f797e		f2410f58ee			ADDSD X14, X5																																																			
  game-collisions.go:386	0x9f7983		f2410f116a18			MOVSD_XMM X5, 0x18(R10)																																																		
  game-collisions.go:386	0x9f7989		410f10eb			MOVUPS X11, X5																																																			
  game-collisions.go:386	0x9f798d		f2450f59dd			MULSD X13, X11																																																			
  game-collisions.go:386	0x9f7992		f2410f58f3			ADDSD X11, X6																																																			
  game-collisions.go:386	0x9f7997		f2410f117220			MOVSD_XMM X6, 0x20(R10)																																																		
  game-collisions.go:387	0x9f799d		0f10f1				MOVUPS X1, X6																																																			
  game-collisions.go:387	0x9f79a0		f2410f59cd			MULSD X13, X1																																																			
  game-collisions.go:388	0x9f79a5		f2440f5ce2			SUBSD X2, X12																																																			
  game-collisions.go:388	0x9f79aa		f2450f586228			ADDSD 0x28(R10), X12																																																		
  game-collisions.go:388	0x9f79b0		f2450f116228			MOVSD_XMM X12, 0x28(R10)																																																	
  game-collisions.go:389	0x9f79b6		f20f5ceb			SUBSD X3, X5																																																			
  game-collisions.go:389	0x9f79ba		f2410f586a30			ADDSD 0x30(R10), X5																																																		
  game-collisions.go:389	0x9f79c0		f2410f116a30			MOVSD_XMM X5, 0x30(R10)																																																		
  game-collisions.go:390	0x9f79c6		f20f5cf4			SUBSD X4, X6																																																			
  game-collisions.go:390	0x9f79ca		f2410f587240			ADDSD 0x40(R10), X6																																																		
  game-collisions.go:390	0x9f79d0		f2410f117240			MOVSD_XMM X6, 0x40(R10)																																																		
  game-collisions.go:387	0x9f79d6		f20f58f9			ADDSD X1, X7																																																			
  game-collisions.go:390	0x9f79da		eb10				JMP 0x9f79ec																																																			
  game-collisions.go:392	0x9f79dc		f2410f116a18			MOVSD_XMM X5, 0x18(R10)																																																		
  game-collisions.go:392	0x9f79e2		f2410f117220			MOVSD_XMM X6, 0x20(R10)																																																		
  world.go:135			0x9f79e8		440f10e8			MOVUPS X0, X13																																																			
  game-collisions.go:395	0x9f79ec		f2410f117a38			MOVSD_XMM X7, 0x38(R10)																																																		
  game-collisions.go:396	0x9f79f2		e921fdffff			JMP 0x9f7718																																																			
  body.go:211			0x9f79f7		f2410f10a9e8000000		MOVSD_XMM 0xe8(R9), X5																																																		
  body.go:211			0x9f7a00		f2410f10b1e0000000		MOVSD_XMM 0xe0(R9), X6																																																		
  game-collisions.go:399	0x9f7a09		f2410f117218			MOVSD_XMM X6, 0x18(R10)																																																		
  game-collisions.go:399	0x9f7a0f		f2410f116a20			MOVSD_XMM X5, 0x20(R10)																																																		
  body.go:213			0x9f7a15		f2410f10a910010000		MOVSD_XMM 0x110(R9), X5																																																		
  game-collisions.go:400	0x9f7a1e		f2410f116a38			MOVSD_XMM X5, 0x38(R10)																																																		
  game-collisions.go:401	0x9f7a24		f2410f106970			MOVSD_XMM 0x70(R9), X5																																																		
  game-collisions.go:401	0x9f7a2a		f20f5cea			SUBSD X2, X5																																																			
  game-collisions.go:401	0x9f7a2e		f2410f586a28			ADDSD 0x28(R10), X5																																																		
  game-collisions.go:401	0x9f7a34		f2410f116a28			MOVSD_XMM X5, 0x28(R10)																																																		
  game-collisions.go:402	0x9f7a3a		f2410f105178			MOVSD_XMM 0x78(R9), X2																																																		
  game-collisions.go:402	0x9f7a40		f20f5cd3			SUBSD X3, X2																																																			
  game-collisions.go:402	0x9f7a44		f2410f585230			ADDSD 0x30(R10), X2																																																		
  game-collisions.go:402	0x9f7a4a		f2410f115230			MOVSD_XMM X2, 0x30(R10)																																																		
  game-collisions.go:403	0x9f7a50		f2410f109180000000		MOVSD_XMM 0x80(R9), X2																																																		
  game-collisions.go:403	0x9f7a59		f20f5cd4			SUBSD X4, X2																																																			
  game-collisions.go:403	0x9f7a5d		f2410f585240			ADDSD 0x40(R10), X2																																																		
  game-collisions.go:403	0x9f7a63		f2410f115240			MOVSD_XMM X2, 0x40(R10)																																																		
  game-collisions.go:403	0x9f7a69		f2440f10050e1e1700		MOVSD_XMM $f64.400921fb54442d18(SB), X8																																																
  game-collisions.go:403	0x9f7a72		f2440f100dd5251700		MOVSD_XMM $f64.c00921fb54442d18(SB), X9																																																
  game-collisions.go:403	0x9f7a7b		f2440f10151c1e1700		MOVSD_XMM $f64.401921fb54442d18(SB), X10																																															
  world.go:135			0x9f7a84		440f10e8			MOVUPS X0, X13																																																			
  game-collisions.go:403	0x9f7a88		e98bfcffff			JMP 0x9f7718																																																			
  game-collisions.go:339	0x9f7a8d		488d90f0050000			LEAQ 0x5f0(AX), DX																																																		
  game-collisions.go:406	0x9f7a94		488d35e56a0000			LEAQ github.com/burntcustard/unicorn-mining-co/src/server/gameplay.(*GameCollisions).Step.func3(SB), SI																																								
  game-collisions.go:406	0x9f7a9b		4889b42430020000		MOVQ SI, 0x230(SP)																																																		
  game-collisions.go:406	0x9f7aa3		4889942438020000		MOVQ DX, 0x238(SP)																																																		
  game-collisions.go:406	0x9f7aab		488b9424b0020000		MOVQ 0x2b0(SP), DX																																																		
  game-collisions.go:406	0x9f7ab3		4889942440020000		MOVQ DX, 0x240(SP)																																																		
  game-collisions.go:406	0x9f7abb		4889842448020000		MOVQ AX, 0x248(SP)																																																		
  game-collisions.go:406	0x9f7ac3		488b8020090000			MOVQ 0x920(AX), AX																																																		
  game-collisions.go:406	0x9f7aca		488d1dcf4a1800			LEAQ github.com/burntcustard/unicorn-mining-co/src/server/utilities..dict.OrderedMap[*github.com/burntcustard/unicorn-mining-co/src/server/physics.Contact,github.com/burntcustard/unicorn-mining-co/src/server/gameplay.impactRecord](SB), BX																							
  game-collisions.go:406	0x9f7ad1		488d8c2430020000		LEAQ 0x230(SP), CX																																																		
  game-collisions.go:406	0x9f7ad9		e8c28b0000			CALL github.com/burntcustard/unicorn-mining-co/src/server/utilities.(*OrderedMap[go.shape.*github.com/burntcustard/unicorn-mining-co/src/server/physics.Contact,go.shape.struct { github.com/burntcustard/unicorn-mining-co/src/server/gameplay.contact github.com/burntcustard/unicorn-mining-co/src/server/collision.Contact; github.com/burntcustard/unicorn-mining-co/src/server/gameplay.impact float64 }]).ForEach(SB)	
  world.go:135			0x9f7ade		f20f108424a8020000		MOVSD_XMM 0x2a8(SP), X0																																																		
  world.go:135			0x9f7ae7		0f57c9				XORPS X1, X1																																																			
  world.go:135			0x9f7aea		660f2ec1			UCOMISD X1, X0																																																			
  game-collisions.go:450	0x9f7aee		7615				JBE 0x9f7b05																																																			
  game-collisions.go:451	0x9f7af0		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:451	0x9f7af8		488b9c24b0020000		MOVQ 0x2b0(SP), BX																																																		
  game-collisions.go:451	0x9f7b00		e8fb030000			CALL github.com/burntcustard/unicorn-mining-co/src/server/gameplay.(*GameCollisions).damageCrushedShips(SB)																																							
  game-collisions.go:454	0x9f7b05		488b942498020000		MOVQ 0x298(SP), DX																																																		
  game-collisions.go:454	0x9f7b0d		488bb2a8080000			MOVQ 0x8a8(DX), SI																																																		
  game-collisions.go:454	0x9f7b14		488bbab0080000			MOVQ 0x8b0(DX), DI																																																		
  game-collisions.go:454	0x9f7b1b		4531c0				XORL R8, R8																																																			
  game-collisions.go:454	0x9f7b1e		6690				NOPW																																																				
  game-collisions.go:454	0x9f7b20		eb21				JMP 0x9f7b43																																																			
  game-collisions.go:454	0x9f7b22		660f1f840000000000		NOPW 0(AX)(AX*1)																																																		
  game-collisions.go:454	0x9f7b2b		660f1f840000000000		NOPW 0(AX)(AX*1)																																																		
  game-collisions.go:454	0x9f7b34		660f1f840000000000		NOPW 0(AX)(AX*1)																																																		
  game-collisions.go:454	0x9f7b3d		0f1f00				NOPL 0(AX)																																																			
  game-collisions.go:454	0x9f7b40		49ffc0				INCQ R8																																																				
  game-collisions.go:454	0x9f7b43		4939f8				CMPQ R8, DI																																																			
  game-collisions.go:454	0x9f7b46		7d29				JGE 0x9f7b71																																																			
  game-collisions.go:454	0x9f7b48		4e8b0cc6			MOVQ 0(SI)(R8*8), R9																																																		
  game-collisions.go:455	0x9f7b4c		4c8d15459c7a00			LEAQ 0x7a9c45(IP), R10																																																		
  game-collisions.go:455	0x9f7b53		4d395118			CMPQ 0x18(R9), R10																																																		
  game-collisions.go:455	0x9f7b57		75e7				JNE 0x9f7b40																																																			
  game-collisions.go:455	0x9f7b59		4d8b5920			MOVQ 0x20(R9), R11																																																		
  game-collisions.go:456	0x9f7b5d		4d8b1b				MOVQ 0(R11), R11																																																		
  game-collisions.go:456	0x9f7b60		f2410f104308			MOVSD_XMM 0x8(R11), X0																																																		
  game-collisions.go:456	0x9f7b66		f2410f1181e0000000		MOVSD_XMM X0, 0xe0(R9)																																																		
  game-collisions.go:456	0x9f7b6f		ebcf				JMP 0x9f7b40																																																			
  game-collisions.go:460	0x9f7b71		488b8278080000			MOVQ 0x878(DX), AX																																																		
  game-collisions.go:460	0x9f7b78		488b9a80080000			MOVQ 0x880(DX), BX																																																		
  game-collisions.go:460	0x9f7b7f		488b8a88080000			MOVQ 0x888(DX), CX																																																		
  game-collisions.go:460	0x9f7b86		4881c488020000			ADDQ $0x288, SP																																																			
  game-collisions.go:460	0x9f7b8d		5d				POPQ BP																																																				
  game-collisions.go:460	0x9f7b8e		c3				RET																																																				
  game-collisions.go:350	0x9f7b8f		488d05aa437400			LEAQ 0x7443aa(IP), AX																																																		
  game-collisions.go:350	0x9f7b96		e84558a2ff			CALL runtime.panicnildottype(SB)																																																
  game-collisions.go:349	0x9f7b9b		488d059e437400			LEAQ 0x74439e(IP), AX																																																		
  game-collisions.go:349	0x9f7ba2		e83958a2ff			CALL runtime.panicnildottype(SB)																																																
  game-collisions.go:349	0x9f7ba7		660f1f840000000000		NOPW 0(AX)(AX*1)																																																		
  game-collisions.go:349	0x9f7bb0		660f1f840000000000		NOPW 0(AX)(AX*1)																																																		
  game-collisions.go:349	0x9f7bb9		0f1f8000000000			NOPL 0(AX)																																																			
  world.go:108			0x9f7bc0		49ffc5				INCQ R13																																																			
  world.go:108			0x9f7bc3		4d39c5				CMPQ R13, R8																																																			
  world.go:108			0x9f7bc6		7d50				JGE 0x9f7c18																																																			
  world.go:108			0x9f7bc8		4f8b3ce9			MOVQ 0(R9)(R13*8), R15																																																		
  world.go:109			0x9f7bcc		4d85ff				TESTQ R15, R15																																																			
  world.go:109			0x9f7bcf		74ef				JE 0x9f7bc0																																																			
  world.go:110			0x9f7bd1		4d8927				MOVQ R12, 0(R15)																																																		
  world.go:111			0x9f7bd4		488b4a10			MOVQ 0x10(DX), CX																																																		
  world.go:111			0x9f7bd8		0f1f840000000000		NOPL 0(AX)(AX*1)																																																		
  world.go:111			0x9f7be0		4939cc				CMPQ R12, CX																																																			
  world.go:111			0x9f7be3		0f83bc000000			JAE 0x9f7ca5																																																			
  world.go:111			0x9f7be9		488b4a08			MOVQ 0x8(DX), CX																																																		
  world.go:111			0x9f7bed		833d6cb9840000			CMPL runtime.writeBarrier(SB), $0x0																																																
  world.go:111			0x9f7bf4		7419				JE 0x9f7c0f																																																			
  world.go:111			0x9f7bf6		4a8b1ce1			MOVQ 0(CX)(R12*8), BX																																																		
  game-collisions.go:340	0x9f7bfa		4c89de				MOVQ R11, SI																																																			
  game-collisions.go:340	0x9f7bfd		0f1f00				NOPL 0(AX)																																																			
  world.go:111			0x9f7c00		e81bf7a9ff			CALL runtime.gcWriteBarrier2(SB)																																																
  world.go:111			0x9f7c05		4d893b				MOVQ R15, 0(R11)																																																		
  world.go:111			0x9f7c08		49895b08			MOVQ BX, 0x8(R11)																																																		
  world.go:132			0x9f7c0c		4989f3				MOVQ SI, R11																																																			
  world.go:111			0x9f7c0f		4e893ce1			MOVQ R15, 0(CX)(R12*8)																																																		
  world.go:112			0x9f7c13		49ffc4				INCQ R12																																																			
  world.go:112			0x9f7c16		eba8				JMP 0x9f7bc0																																																			
  world.go:116			0x9f7c18		488b5a10			MOVQ 0x10(DX), BX																																																		
  world.go:116			0x9f7c1c		0f1f4000			NOPL 0(AX)																																																			
  world.go:116			0x9f7c20		4939dc				CMPQ R12, BX																																																			
  world.go:116			0x9f7c23		7779				JA 0x9f7c9e																																																			
  world.go:116			0x9f7c25		4c8b4208			MOVQ 0x8(DX), R8																																																		
  world.go:116			0x9f7c29		4c8b4a18			MOVQ 0x18(DX), R9																																																		
  world.go:116			0x9f7c2d		4c29e3				SUBQ R12, BX																																																			
  world.go:116			0x9f7c30		4d89e5				MOVQ R12, R13																																																			
  world.go:116			0x9f7c33		4d29cc				SUBQ R9, R12																																																			
  world.go:116			0x9f7c36		4d89e9				MOVQ R13, R9																																																			
  world.go:116			0x9f7c39		49c1e503			SHLQ $0x3, R13																																																			
  world.go:116			0x9f7c3d		49c1fc3f			SARQ $0x3f, R12																																																			
  world.go:116			0x9f7c41		4d21e5				ANDQ R12, R13																																																			
  world.go:116			0x9f7c44		4d01e8				ADDQ R13, R8																																																			
  world.go:116			0x9f7c47		4885db				TESTQ BX, BX																																																			
  world.go:116			0x9f7c4a		743b				JE 0x9f7c87																																																			
  world.go:108			0x9f7c4c		4c898c2410010000		MOVQ R9, 0x110(SP)																																																		
  world.go:116			0x9f7c54		48c1e303			SHLQ $0x3, BX																																																			
  world.go:116			0x9f7c58		4c89c0				MOVQ R8, AX																																																			
  world.go:116			0x9f7c5b		0f1f440000			NOPL 0(AX)(AX*1)																																																		
  world.go:116			0x9f7c60		e81b69a9ff			CALL runtime.memclrHasPointers(SB)																																																
  game-collisions.go:342	0x9f7c65		488b842498020000		MOVQ 0x298(SP), AX																																																		
  world.go:117			0x9f7c6d		488b942428010000		MOVQ 0x128(SP), DX																																																		
  world.go:117			0x9f7c75		4c8b8c2410010000		MOVQ 0x110(SP), R9																																																		
  world.go:132			0x9f7c7d		4c8b542458			MOVQ 0x58(SP), R10																																																		
  world.go:132			0x9f7c82		4c8b5c2478			MOVQ 0x78(SP), R11																																																		
  world.go:117			0x9f7c87		4c8b4218			MOVQ 0x18(DX), R8																																																		
  world.go:117			0x9f7c8b		4d39c1				CMPQ R9, R8																																																			
  world.go:117			0x9f7c8e		7709				JA 0x9f7c99																																																			
  world.go:117			0x9f7c90		4c894a10			MOVQ R9, 0x10(DX)																																																		
  world.go:117			0x9f7c94		e93ff4ffff			JMP 0x9f70d8																																																			
  world.go:117			0x9f7c99		e822faa9ff			CALL runtime.panicBounds(SB)																																																	
  world.go:116			0x9f7c9e		6690				NOPW																																																				
  world.go:116			0x9f7ca0		e81bfaa9ff			CALL runtime.panicBounds(SB)																																																	
  world.go:111			0x9f7ca5		e816faa9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:311	0x9f7caa		e811faa9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:663	0x9f7caf		e80cfaa9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:660	0x9f7cb4		e807faa9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:659	0x9f7cb9		e802faa9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:659	0x9f7cbe		6690				NOPW																																																				
  game-collisions.go:659	0x9f7cc0		e8fbf9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:659	0x9f7cc5		e8f6f9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:655	0x9f7cca		e8f1f9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:655	0x9f7ccf		e8ecf9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:651	0x9f7cd4		e8e7f9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:647	0x9f7cd9		e8e2f9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:645	0x9f7cde		6690				NOPW																																																				
  game-collisions.go:645	0x9f7ce0		e8dbf9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:642	0x9f7ce5		e8d6f9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:642	0x9f7cea		e8d1f9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:637	0x9f7cef		e8ccf9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:637	0x9f7cf4		e8c7f9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:637	0x9f7cf9		0f1f8000000000			NOPL 0(AX)																																																			
  game-collisions.go:619	0x9f7d00		4c896ccb08			MOVQ R13, 0x8(BX)(CX*8)																																																		
  game-collisions.go:609	0x9f7d05		49ffc2				INCQ R10																																																			
  game-collisions.go:308	0x9f7d08		4889fa				MOVQ DI, DX																																																			
  game-collisions.go:609	0x9f7d0b		4939f2				CMPQ R10, SI																																																			
  game-collisions.go:609	0x9f7d0e		0f8dc3eeffff			JGE 0x9f6bd7																																																			
  game-collisions.go:610	0x9f7d14		4d39c2				CMPQ R10, R8																																																			
  game-collisions.go:610	0x9f7d17		0f83a0000000			JAE 0x9f7dbd																																																			
  game-collisions.go:610	0x9f7d1d		4e8b2cd3			MOVQ 0(BX)(R10*8), R13																																																		
  game-collisions.go:611	0x9f7d21		4c89e9				MOVQ R13, CX																																																			
  game-collisions.go:611	0x9f7d24		49c1e502			SHLQ $0x2, R13																																																			
  game-collisions.go:611	0x9f7d28		4d39eb				CMPQ R11, R13																																																			
  game-collisions.go:611	0x9f7d2b		0f8687000000			JBE 0x9f7db8																																																			
  game-collisions.go:611	0x9f7d31		4989cd				MOVQ CX, R13																																																			
  game-collisions.go:611	0x9f7d34		48c1e105			SHLQ $0x5, CX																																																			
  game-collisions.go:611	0x9f7d38		f2410f101c0c			MOVSD_XMM 0(R12)(CX*1), X3																																																	
  game-collisions.go:612	0x9f7d3e		498d4aff			LEAQ -0x1(R10), CX																																																		
  game-collisions.go:614	0x9f7d42		eb13				JMP 0x9f7d57																																																			
  game-collisions.go:615	0x9f7d44		488b942410010000		MOVQ 0x110(SP), DX																																																		
  game-collisions.go:615	0x9f7d4c		488954cb08			MOVQ DX, 0x8(BX)(CX*8)																																																		
  game-collisions.go:616	0x9f7d51		48ffc9				DECQ CX																																																				
  game-collisions.go:308	0x9f7d54		4889fa				MOVQ DI, DX																																																			
  game-collisions.go:614	0x9f7d57		4885c9				TESTQ CX, CX																																																			
  game-collisions.go:614	0x9f7d5a		7c3b				JL 0x9f7d97																																																			
  game-collisions.go:614	0x9f7d5c		488b3ccb			MOVQ 0(BX)(CX*8), DI																																																		
  game-collisions.go:614	0x9f7d60		4889bc2410010000		MOVQ DI, 0x110(SP)																																																		
  game-collisions.go:614	0x9f7d68		48c1e702			SHLQ $0x2, DI																																																			
  game-collisions.go:614	0x9f7d6c		4939fb				CMPQ R11, DI																																																			
  game-collisions.go:614	0x9f7d6f		7642				JBE 0x9f7db3																																																			
  game-collisions.go:221	0x9f7d71		4889d7				MOVQ DX, DI																																																			
  game-collisions.go:614	0x9f7d74		488b942410010000		MOVQ 0x110(SP), DX																																																		
  game-collisions.go:614	0x9f7d7c		48c1e205			SHLQ $0x5, DX																																																			
  game-collisions.go:614	0x9f7d80		f2410f102414			MOVSD_XMM 0(R12)(DX*1), X4																																																	
  game-collisions.go:614	0x9f7d86		660f2ee3			UCOMISD X3, X4																																																			
  game-collisions.go:614	0x9f7d8a		760e				JBE 0x9f7d9a																																																			
  game-collisions.go:615	0x9f7d8c		488d5101			LEAQ 0x1(CX), DX																																																		
  game-collisions.go:615	0x9f7d90		4939d0				CMPQ R8, DX																																																			
  game-collisions.go:615	0x9f7d93		77af				JA 0x9f7d44																																																			
  game-collisions.go:615	0x9f7d95		eb17				JMP 0x9f7dae																																																			
  game-collisions.go:308	0x9f7d97		4889d7				MOVQ DX, DI																																																			
  game-collisions.go:619	0x9f7d9a		488d5101			LEAQ 0x1(CX), DX																																																		
  game-collisions.go:619	0x9f7d9e		6690				NOPW																																																				
  game-collisions.go:619	0x9f7da0		4939d0				CMPQ R8, DX																																																			
  game-collisions.go:619	0x9f7da3		0f8757ffffff			JA 0x9f7d00																																																			
  game-collisions.go:619	0x9f7da9		e812f9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:615	0x9f7dae		e80df9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:614	0x9f7db3		e808f9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:611	0x9f7db8		e803f9a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:610	0x9f7dbd		0f1f00				NOPL 0(AX)																																																			
  game-collisions.go:610	0x9f7dc0		e8fbf8a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:605	0x9f7dc5		e8f6f8a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:604	0x9f7dca		e8f1f8a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:604	0x9f7dcf		e8ecf8a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:604	0x9f7dd4		e8e7f8a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:604	0x9f7dd9		e8e2f8a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:592	0x9f7dde		4c89a0f8080000			MOVQ R12, 0x8f8(AX)																																																		
  game-collisions.go:592	0x9f7de5		4b894ce5f8			MOVQ CX, -0x8(R13)(R12*8)																																																	
  game-collisions.go:591	0x9f7dea		48ffc1				INCQ CX																																																				
  game-collisions.go:591	0x9f7ded		4839f9				CMPQ CX, DI																																																			
  game-collisions.go:591	0x9f7df0		0f8daf000000			JGE 0x9f7ea5																																																			
  game-collisions.go:592	0x9f7df6		4c8b9800090000			MOVQ 0x900(AX), R11																																																		
  game-collisions.go:592	0x9f7dfd		4c8ba0f8080000			MOVQ 0x8f8(AX), R12																																																		
  game-collisions.go:592	0x9f7e04		49ffc4				INCQ R12																																																			
  game-collisions.go:592	0x9f7e07		4c8ba8f0080000			MOVQ 0x8f0(AX), R13																																																		
  game-collisions.go:592	0x9f7e0e		4d39e3				CMPQ R11, R12																																																			
  game-collisions.go:592	0x9f7e11		73cb				JAE 0x9f7dde																																																			
  game-collisions.go:591	0x9f7e13		48898c24a8000000		MOVQ CX, 0xa8(SP)																																																		
  game-collisions.go:592	0x9f7e1b		4c89e8				MOVQ R13, AX																																																			
  game-collisions.go:592	0x9f7e1e		4c89e3				MOVQ R12, BX																																																			
  game-collisions.go:592	0x9f7e21		4c89d9				MOVQ R11, CX																																																			
  game-collisions.go:592	0x9f7e24		bf01000000			MOVL $0x1, DI																																																			
  game-collisions.go:592	0x9f7e29		488d35e0c57200			LEAQ 0x72c5e0(IP), SI																																																		
  game-collisions.go:592	0x9f7e30		e84ba8a9ff			CALL runtime.growslice(SB)																																																	
  game-collisions.go:592	0x9f7e35		488b942498020000		MOVQ 0x298(SP), DX																																																		
  game-collisions.go:592	0x9f7e3d		48898a00090000			MOVQ CX, 0x900(DX)																																																		
  game-collisions.go:592	0x9f7e44		833d15b7840000			CMPL runtime.writeBarrier(SB), $0x0																																																
  game-collisions.go:592	0x9f7e4b		7416				JE 0x9f7e63																																																			
  game-collisions.go:592	0x9f7e4d		4c8b9af0080000			MOVQ 0x8f0(DX), R11																																																		
  game-collisions.go:592	0x9f7e54		4c89d9				MOVQ R11, CX																																																			
  game-collisions.go:592	0x9f7e57		e8c4f4a9ff			CALL runtime.gcWriteBarrier2(SB)																																																
  game-collisions.go:592	0x9f7e5c		498903				MOVQ AX, 0(R11)																																																			
  game-collisions.go:592	0x9f7e5f		49894b08			MOVQ CX, 0x8(R11)																																																		
  game-collisions.go:592	0x9f7e63		488982f0080000			MOVQ AX, 0x8f0(DX)																																																		
  game-collisions.go:592	0x9f7e6a		488b8c24a8000000		MOVQ 0xa8(SP), CX																																																		
  game-collisions.go:598	0x9f7e72		488b942478010000		MOVQ 0x178(SP), DX																																																		
  game-collisions.go:591	0x9f7e7a		488bbc2498000000		MOVQ 0x98(SP), DI																																																		
  world.go:132			0x9f7e82		f20f10a424a8020000		MOVSD_XMM 0x2a8(SP), X4																																																		
  game-collisions.go:592	0x9f7e8b		4989dc				MOVQ BX, R12																																																			
  game-collisions.go:592	0x9f7e8e		4989c5				MOVQ AX, R13																																																			
  game-collisions.go:592	0x9f7e91		488b842498020000		MOVQ 0x298(SP), AX																																																		
  game-collisions.go:584	0x9f7e99		488b5c2468			MOVQ 0x68(SP), BX																																																		
  game-collisions.go:584	0x9f7e9e		6690				NOPW																																																				
  game-collisions.go:592	0x9f7ea0		e939ffffff			JMP 0x9f7dde																																																			
  game-collisions.go:596	0x9f7ea5		4889c2				MOVQ AX, DX																																																			
  game-collisions.go:591	0x9f7ea8		e926ebffff			JMP 0x9f69d3																																																			
  slices.go:428			0x9f7ead		e80ef8a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:271	0x9f7eb2		e809f8a9ff			CALL runtime.panicBounds(SB)																																																	
  game-collisions.go:271	0x9f7eb7		90				NOPL																																																				
  game-collisions.go:220	0x9f7eb8		4889442408			MOVQ AX, 0x8(SP)																																																		
  game-collisions.go:220	0x9f7ebd		48895c2410			MOVQ BX, 0x10(SP)																																																		
  game-collisions.go:220	0x9f7ec2		f20f11442418			MOVSD_XMM X0, 0x18(SP)																																																		
  game-collisions.go:220	0x9f7ec8		48894c2420			MOVQ CX, 0x20(SP)																																																		
  game-collisions.go:220	0x9f7ecd		e8aedba9ff			CALL runtime.morestack_noctxt.abi0(SB)																																																
  game-collisions.go:220	0x9f7ed2		488b442408			MOVQ 0x8(SP), AX																																																		
  game-collisions.go:220	0x9f7ed7		488b5c2410			MOVQ 0x10(SP), BX																																																		
  game-collisions.go:220	0x9f7edc		f20f10442418			MOVSD_XMM 0x18(SP), X0																																																		
  game-collisions.go:220	0x9f7ee2		488b4c2420			MOVQ 0x20(SP), CX																																																		
  game-collisions.go:220	0x9f7ee7		e914e1ffff			JMP github.com/burntcustard/unicorn-mining-co/src/server/gameplay.(*GameCollisions).Step(SB)																																									
